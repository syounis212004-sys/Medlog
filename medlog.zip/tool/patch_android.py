#!/usr/bin/env python3
"""Patches the freshly generated Flutter android/ folder for MedLog.

usage: patch_android.py <android_dir> <tool_dir>

1. MainActivity.kt  -> adds the FLAG_SECURE channel (screenshot / recent-apps protection)
2. AndroidManifest  -> app label "MedLog" + allowBackup=false (no cloud auto-backup of patient data)
3. app/build.gradle(.kts) -> release signing from android/key.properties
4. root build.gradle(.kts) -> compileSdk 36 for all plugin modules (AndroidX lifecycle needs it)
"""
import pathlib
import re
import sys

android = pathlib.Path(sys.argv[1])
tool = pathlib.Path(sys.argv[2])


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


# ---------------------------------------------------------------- 1. MainActivity
src_root = android / "app" / "src" / "main"
found = list(src_root.glob("**/MainActivity.kt")) + list(src_root.glob("**/MainActivity.java"))
if not found:
    fail("MainActivity not found in generated android project")
old = found[0]
m = re.search(r"^\s*package\s+([\w.]+)", old.read_text(), re.M)
if not m:
    fail("could not read package name from MainActivity")
package = m.group(1)
tpl = (tool / "MainActivity.kt.tpl").read_text().replace("__PACKAGE__", package)
target = old.with_suffix(".kt")
if old.suffix == ".java":
    old.unlink()
target.write_text(tpl)
print("MainActivity patched:", target, "package", package)

# ---------------------------------------------------------------- 2. Manifest
manifest = src_root / "AndroidManifest.xml"
x = manifest.read_text()
x = re.sub(r'android:label="[^"]*"', 'android:label="MedLog"', x, count=1)
if "android:allowBackup" in x:
    x = re.sub(r'android:allowBackup="[^"]*"', 'android:allowBackup="false"', x, count=1)
else:
    x = x.replace("<application", '<application\n        android:allowBackup="false"', 1)
if "android.permission.INTERNET" not in x:
    x = x.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
https_intent = '<intent>\n            <action android:name="android.intent.action.VIEW"/>\n            <data android:scheme="https"/>\n        </intent>'
if "<queries>" in x:
    x = x.replace("<queries>", "<queries>\n        " + https_intent, 1)
else:
    x = x.replace("<application", "<queries>\n        " + https_intent + "\n    </queries>\n    <application", 1)
manifest.write_text(x)
print("Manifest patched")

# ---------------------------------------------------------------- 3. Gradle signing
gradle = None
for name in ("build.gradle.kts", "build.gradle"):
    p = android / "app" / name
    if p.exists():
        gradle = p
        break
if gradle is None:
    fail("app/build.gradle(.kts) not found")

txt = gradle.read_text()
if gradle.suffix == ".kts":
    block = '''    signingConfigs {
        create("release") {
            val props = Properties()
            val kp = rootProject.file("key.properties")
            if (kp.exists()) {
                val input = kp.inputStream()
                props.load(input)
                input.close()
            }
            keyAlias = props.getProperty("keyAlias")
            keyPassword = props.getProperty("keyPassword")
            val sf: String? = props.getProperty("storeFile")
            if (sf != null) {
                storeFile = file(sf)
            }
            storePassword = props.getProperty("storePassword")
        }
    }

'''
    txt = "import java.util.Properties\n\n" + txt
    txt = txt.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("release")')
    ok = 'signingConfigs.getByName("release")' in txt
else:
    block = '''    signingConfigs {
        release {
            def props = new Properties()
            def kp = rootProject.file("key.properties")
            if (kp.exists()) {
                kp.withInputStream { props.load(it) }
            }
            keyAlias props["keyAlias"]
            keyPassword props["keyPassword"]
            storeFile props["storeFile"] ? file(props["storeFile"]) : null
            storePassword props["storePassword"]
        }
    }

'''
    txt = txt.replace("signingConfigs.debug", "signingConfigs.release")
    ok = "signingConfigs.release" in txt

mm = re.search(r"^[ \t]*buildTypes\s*\{", txt, re.M)
if not mm:
    fail("buildTypes block not found in gradle file")
txt = txt[: mm.start()] + block + txt[mm.start():]
if not ok:
    fail("release signingConfig line not found in gradle file (template changed?)")
gradle.write_text(txt)
print("Gradle patched:", gradle)

# ---------------------------------------------------------------- 4. compileSdk for plugins
root = None
for name in ("build.gradle.kts", "build.gradle"):
    p = android / name
    if p.exists():
        root = p
        break
if root is None:
    fail("root build.gradle(.kts) not found")

if root.suffix == ".kts":
    extra = '''
subprojects {
    if (name != "app") {
        val forceSdk = {
            val ext = extensions.findByName("android")
            if (ext != null) {
                ext.javaClass.getMethod("setCompileSdk", Integer::class.javaObjectType).invoke(ext, 36)
            }
        }
        if (state.executed) forceSdk() else afterEvaluate { forceSdk() }
    }
}
'''
else:
    extra = '''
subprojects {
    if (project.name != "app") {
        def forceSdk = {
            def ext = project.extensions.findByName("android")
            if (ext != null) {
                ext.compileSdkVersion(36)
            }
        }
        if (project.state.executed) { forceSdk() } else { project.afterEvaluate { forceSdk() } }
    }
}
'''
root.write_text(root.read_text() + extra)
print("Root gradle patched:", root)
