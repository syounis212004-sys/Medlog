#!/usr/bin/env python3
"""Patches the freshly generated Flutter android/ folder for MedLog.

usage: patch_android.py <android_dir> <tool_dir>

1. MainActivity.kt  -> adds the FLAG_SECURE channel (screenshot / recent-apps protection)
2. AndroidManifest  -> app label "MedLog" + allowBackup=false (no cloud auto-backup of patient data)
3. app/build.gradle(.kts) -> release signing from android/key.properties
"""
import pathlib
import re
import sys

android = pathlib.Path(sys.argv[1])
tool = pathlib.Path(sys.argv[2])


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


# ---------------------------------------------------------------- 1. MainActivity
src_root = android / "app" / "src" / "main"
found = list(src_root.glob("**/MainActivity.kt")) + list(src_root.glob("**/MainActivity.java"))
if not found:
    fail("MainActivity not found in generated android project")
old = found[0]
m = re.search(r"^\s*package\s+([\w.]+)", old.read_text(), re.M)
if not m:
    fail("could not read package name from MainActivity")
package = m.group(1)
tpl = (tool / "MainActivity.kt.tpl").read_text().replace("__PACKAGE__", package)
target = old.with_suffix(".kt")
if old.suffix == ".java":
    old.unlink()
target.write_text(tpl)
print("MainActivity patched:", target, "package", package)

# ---------------------------------------------------------------- 2. Manifest
manifest = src_root / "AndroidManifest.xml"
x = manifest.read_text()
x = re.sub(r'android:label="[^"]*"', 'android:label="MedLog"', x, count=1)
if "android:allowBackup" in x:
    x = re.sub(r'android:allowBackup="[^"]*"', 'android:allowBackup="false"', x, count=1)
else:
    x = x.replace("<application", '<application\n        android:allowBackup="false"', 1)
manifest.write_text(x)
print("Manifest patched")

# ---------------------------------------------------------------- 3. Gradle signing
gradle = None
for name in ("build.gradle.kts", "build.gradle"):
    p = android / "app" / name
    if p.exists():
        gradle = p
        break
if gradle is None:
    fail("app/build.gradle(.kts) not found")

txt = gradle.read_text()
if gradle.suffix == ".kts":
    block = '''    signingConfigs {
        create("release") {
            val props = java.util.Properties()
            val kp = rootProject.file("key.properties")
            if (kp.exists()) {
                kp.inputStream().use { props.load(it) }
            }
            keyAlias = props.getProperty("keyAlias")
            keyPassword = props.getProperty("keyPassword")
            storeFile = props.getProperty("storeFile")?.let { file(it) }
            storePassword = props.getProperty("storePassword")
        }
    }

'''
    txt = txt.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("release")')
    ok = 'signingConfigs.getByName("release")' in txt
else:
    block = '''    signingConfigs {
        release {
            def props = new Properties()
            def kp = rootProject.file("key.properties")
            if (kp.exists()) {
                kp.withInputStream { props.load(it) }
            }
            keyAlias props["keyAlias"]
            keyPassword props["keyPassword"]
            storeFile props["storeFile"] ? file(props["storeFile"]) : null
            storePassword props["storePassword"]
        }
    }

'''
    txt = txt.replace("signingConfigs.debug", "signingConfigs.release")
    ok = "signingConfigs.release" in txt

mm = re.search(r"^[ \t]*buildTypes\s*\{", txt, re.M)
if not mm:
    fail("buildTypes block not found in gradle file")
txt = txt[: mm.start()] + block + txt[mm.start():]
if not ok:
    fail("release signingConfig line not found in gradle file (template changed?)")
gradle.write_text(txt)
print("Gradle patched:", gradle)
