import 'package:crypto/crypto.dart';
import 'dart:convert';

import 'data.dart';
import 'lib_text.dart';
import 'library.dart';
import 'search_index.dart' show normText;

/// Everything the user keeps about library articles: favorites, recent reading,
/// personal notes and review cards. All of it stays on the phone (in the same
/// private files as the rest of MedLog).

String _key(String packId, String title) => '$packId|$title';

bool isFavorite(String packId, String title) => store.listOf('libfav').any((e) => e['id'] == _key(packId, title));

Future<bool> toggleFavorite(String packId, String title) async {
  final k = _key(packId, title);
  if (isFavorite(packId, title)) {
    await store.removeExtra('libfav', k);
    return false;
  }
  await store.upsertExtra('libfav', {'id': k, 'pack': packId, 'title': title, 'date': nowIso()});
  return true;
}

List<J> favorites() {
  final l = [...store.listOf('libfav')];
  l.sort((a, b) => '${b['date']}'.compareTo('${a['date']}'));
  return l;
}

/// Last opened articles, newest first (max 12).
List<Map<String, dynamic>> recentArticles() {
  final r = store.settings['libRecent'];
  if (r is! List) return <Map<String, dynamic>>[];
  return [for (final e in r) if (e is Map) Map<String, dynamic>.from(e)];
}

void noteRecent(String packId, String title) {
  final l = recentArticles()..removeWhere((e) => e['p'] == packId && e['t'] == title);
  l.insert(0, {'p': packId, 't': title});
  store.settings['libRecent'] = l.take(12).toList();
  store.saveSettings();
}

String noteFor(String packId, String title) {
  for (final e in store.listOf('libnotes')) {
    if (e['id'] == _key(packId, title)) return '${e['text'] ?? ''}';
  }
  return '';
}

Future<void> saveNote(String packId, String title, String text) async {
  final k = _key(packId, title);
  if (text.trim().isEmpty) {
    await store.removeExtra('libnotes', k);
  } else {
    await store.upsertExtra('libnotes', {'id': k, 'pack': packId, 'title': title, 'text': text, 'date': nowIso()});
  }
}

String _cardId(String front) => md5.convert(utf8.encode(front)).toString().substring(0, 16);

/// A review card made from a library article (shows up in the spaced review).
Future<bool> addLibraryCard({required String front, required String back, required String source, String packId = '', String title = ''}) async {
  final id = _cardId(front);
  if (store.listOf('libcards').any((e) => e['id'] == id)) return false;
  await store.upsertExtra('libcards', {'id': id, 'front': front, 'back': back, 'source': source, 'pack': packId, 'title': title, 'date': nowIso()});
  return true;
}

/// Course (pack id) that matches the name of a rotation, e.g. "Orthopedics" -> "orthopedics".
String? packIdForRotation(String name) {
  final n = name.toLowerCase();
  const rules = <List<String>>[
    ['orthop', 'orthopedics'],
    ['cardio', 'cardiology'],
    ['pulmon', 'pulmonology'],
    ['chest', 'pulmonology'],
    ['gastro', 'gastroenterology'],
    ['nephro', 'nephrology-urology'],
    ['urolog', 'nephrology-urology'],
    ['endocr', 'endocrinology'],
    ['neuro', 'neurology'],
    ['psych', 'psychiatry'],
    ['infect', 'infectious-diseases'],
    ['hemat', 'hematology-oncology'],
    ['oncol', 'hematology-oncology'],
    ['pediat', 'pediatrics'],
    ['paediat', 'pediatrics'],
    ['ob/gyn', 'obstetrics-gynecology'],
    ['obstet', 'obstetrics-gynecology'],
    ['gyn', 'obstetrics-gynecology'],
    ['emergency', 'emergency-critical-care'],
    ['icu', 'emergency-critical-care'],
    ['intensive', 'emergency-critical-care'],
    ['derm', 'dermatology'],
    ['ophthal', 'ophthalmology'],
    ['ent', 'ent'],
    ['otolaryn', 'ent'],
    ['anesth', 'anesthesiology'],
    ['radiolog', 'radiology'],
    ['rheumat', 'rheumatology-immunology'],
    ['surg', 'surgery'],
    ['internal', 'general-medicine'],
    ['family', 'general-medicine'],
  ];
  for (final r in rules) {
    if (n.contains(r[0])) return r[1];
  }
  return null;
}

/// One article per day from the course of the current rotation (or any course you have).
Future<LibHit?> topicOfTheDay() async {
  if (!library.ready || library.textPacks.isEmpty) return null;
  final rot = store.currentRotation();
  var id = rot == null ? null : packIdForRotation('${rot['name'] ?? ''}');
  if (id == null || library.pack(id) == null) {
    final list = library.textPacks.where((p) => p.kind == 'wiki').toList();
    if (list.isEmpty) return null;
    list.sort((a, b) => a.id.compareTo(b.id));
    id = list[DateTime.now().day % list.length].id;
  }
  final i = await library.dailyPick(id, todayStr());
  if (i == null) return null;
  final titles = await library.titlesOf(id);
  final leads = await library.leadsOf(id);
  return LibHit(id, i, titles[i], leads[i], 0);
}

/// Articles that talk about what the case is about (final or working diagnosis).
Future<List<LibHit>> articlesForCase(CaseRec c) async {
  final dx = [c.s('finalDx'), c.s('workingDx')].firstWhere((e) => e.trim().isNotEmpty, orElse: () => '');
  final q = dx.trim().isNotEmpty ? dx : c.s('cc');
  if (q.trim().isEmpty || !library.ready) return const [];
  var hits = await library.searchEx(q, limit: 8);
  if (hits.isEmpty) {
    final fix = await library.didYouMean(q);
    if (fix != null) hits = await library.searchEx(fix, limit: 8);
  }
  return hits;
}

/// Your cases whose diagnosis or complaint mentions the article's subject.
List<CaseRec> casesAbout(String title) {
  final t = normText(title).trim();
  if (t.length < 4) return const [];
  final out = <CaseRec>[];
  for (final c in store.cases.values) {
    final hay = normText('${c.s('finalDx')} ${c.s('workingDx')} ${c.s('ddx')} ${c.s('cc')}');
    if (hay.contains(t) || (kLibAbbrev.values.contains(t) && hay.contains(t))) out.add(c);
  }
  return out;
}
