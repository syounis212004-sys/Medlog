import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'ai/ai_context.dart';
import 'i18n.dart';
import 'screens_calc.dart';
import 'screens_calendar.dart';
import 'screens_dosing.dart';
import 'app_icons.dart';
import 'screens_ai_study.dart' show AiHubScreen;
import 'screens_learn.dart';
import 'screens_library.dart' show DictionaryScreen;
import 'screens_portfolio.dart';
import 'screens_ref.dart';
import 'screens_search.dart';
import 'ph.dart';

/// Fifth tab: the things used at the bedside and for planning, one tap away from anywhere.
/// They used to be buried in the Library and in the Home toolbar.
class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  void _open(BuildContext context, Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  Widget _tile(BuildContext context, IconData icon, String title, String sub, Widget Function() screen, {Key? key}) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Material(
      key: key,
      color: cs.surfaceContainerLow,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _open(context, screen()),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: [
            CircleAvatar(radius: 20, backgroundColor: cs.secondaryContainer, child: Icon(icon, color: cs.onSecondaryContainer)),
            const SizedBox(height: 10),
            m.Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            m.Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          ]),
        ),
      ),
    );
  }

  Widget _grid(List<Widget> tiles) => LayoutBuilder(builder: (context, c) {
        final cols = c.maxWidth >= 600 ? 3 : 2;
        const gap = 10.0;
        final rows = <Widget>[];
        for (var i = 0; i < tiles.length; i += cols) {
          final cells = <Widget>[];
          for (var j = 0; j < cols; j++) {
            if (j > 0) cells.add(const SizedBox(width: gap));
            cells.add(Expanded(child: i + j < tiles.length ? tiles[i + j] : const SizedBox.shrink()));
          }
          if (rows.isNotEmpty) rows.add(const SizedBox(height: gap));
          rows.add(IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: cells)));
        }
        return Column(children: rows);
      });

  Widget _head(BuildContext context, String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
        child: m.Text(t, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      );

  @override
  Widget build(BuildContext context) {
    return AiContextScope(
      ctx: const AiScreenContext(kind: 'tools', title: 'Tools'),
      child: Scaffold(
        appBar: AppBar(title: Text('Tools')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
          children: [
            _head(context, tr('Study')),
            _grid([
              _tile(context, AppIcons.learn, tr('Learn'), tr('Flashcards, questions and self-tests'), () => const LearnScreen(), key: const Key('tool_learn')),
              _tile(context, AppIcons.ai, tr('AI study'), tr('Question bank, coach and viva practice'), () => const AiHubScreen(), key: const Key('tool_ai')),
            ]),
            _head(context, tr('At the bedside')),
            _grid([
              _tile(context, AppIcons.calculator, tr('Calculators'), tr('Ready clinical formulas'), () => const CalculatorsScreen(), key: const Key('tool_calc')),
              _tile(context, AppIcons.doses, tr('Doses & durations'), tr('From your own files, offline'), () => const DosingScreen(), key: const Key('tool_doses')),
              _tile(context, Ph.rows, tr('Presentation cards'), tr('Ask, examine, red flags, first steps'), () => const BedsideCardsScreen()),
              _tile(context, AppIcons.guideline, tr('Guidelines'), tr('Where to find the current ones'), () => const GuidelinesScreen()),
            ]),
            _head(context, tr('Find and plan')),
            _grid([
              _tile(context, AppIcons.search, tr('Search'), tr('Cases, library, drugs and calculators'), () => const SearchScreen(), key: const Key('tool_search')),
              _tile(context, AppIcons.plan, tr('Rotation hub'), tr('Topics, procedures and targets for your rotation'), () => const RotationHubScreen()),
              _tile(context, Ph.calendarDots, tr('Calendar'), tr('Cases by day'), () => const CalendarScreen()),
              _tile(context, AppIcons.translate, tr('Medical terms'), tr('English → Arabic'), () => const DictionaryScreen()),
            ]),
            _head(context, tr('My progress')),
            _grid([
              _tile(context, Ph.chartLineUp, tr('Portfolio'), tr('Reports, goals and sign-off'), () => const PortfolioScreen(), key: const Key('tool_portfolio')),
              _tile(context, AppIcons.settings, tr('Settings'), tr('Language, theme, backup, AI'), () => const SettingsScreen(), key: const Key('tool_settings')),
            ]),
          ],
        ),
      ),
    );
  }
}
