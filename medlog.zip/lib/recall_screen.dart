import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'ai/voice_input.dart' show VoiceInputButton;
import 'app_icons.dart';
import 'data.dart' show nowIso;
import 'i18n.dart';
import 'library.dart';
import 'screens_article.dart' show ArticleScreen;
import 'study_tools.dart';
import 'ui.dart';
import 'widgets.dart';

/// "Write what you remember": after reading, the person writes (or dictates) everything they remember without looking,
/// then sees the points of the article they covered and the ones they missed. The comparison is on the words, on the
/// phone: no AI and nothing is sent. Missed points can be added to the knowledge gaps, one by one.
class RecallScreen extends StatefulWidget {
  final String packId;
  final int index;
  const RecallScreen({super.key, required this.packId, required this.index});
  @override
  State<RecallScreen> createState() => _RecallScreenState();
}

class _RecallScreenState extends State<RecallScreen> {
  final _text = TextEditingController();
  LibArticle? _a;
  String _body = '';
  RecallResult? _res;
  final Set<String> _added = {};

  String get _draftKey => 'recall_${widget.packId}_${widget.index}';
  Timer? _save;

  @override
  void initState() {
    super.initState();
    // what was written before is still there (the screen may have been left half way)
    final d = Resume.read(_draftKey);
    if (d != null && '${d['text']}'.isNotEmpty) _text.text = '${d['text']}';
    _text.addListener(_keepDraft);
    _load();
  }

  void _keepDraft() {
    _save?.cancel();
    _save = Timer(const Duration(milliseconds: 700), () => _flushDraft());
  }

  Future<void> _flushDraft() async {
    if (_res != null) return; // compared: nothing to keep
    if (_text.text.trim().isEmpty) {
      await Resume.clear(_draftKey);
    } else {
      await Resume.write(_draftKey, {'text': _text.text, 'at': nowIso()});
    }
  }

  @override
  void dispose() {
    _save?.cancel();
    _flushDraft(); // the last words are kept too
    _text.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final a = await library.read(widget.packId, widget.index);
    if (!mounted || a == null) return;
    setState(() {
      _a = a;
      _body = [for (final s in a.sections) s.text].join('\n');
    });
  }

  void _compare() {
    setState(() => _res = compareRecall(_body, _text.text));
    Resume.clear(_draftKey); // compared: the draft is not needed any more
  }

  Future<void> _gap(RecallPoint p) async {
    await KnowledgeGaps.add(p.text.length > 160 ? '${p.text.substring(0, 160)}…' : p.text, source: stripSource(_a?.title ?? ''));
    if (mounted) setState(() => _added.add(p.text));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final r = _res;
    return Scaffold(
      appBar: AppBar(title: Text('Write what I remember')),
      body: _a == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
              m.Text(stripSource(_a!.title), style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              if (r == null) ...[
                Text('Without looking at the article, write everything you remember: the definition, the causes, the key numbers, the treatment. Short phrases are enough.', style: theme.textTheme.bodyMedium),
                const SizedBox(height: 10),
                TextField(
                  key: const ValueKey('recall_text'),
                  controller: _text,
                  minLines: 8,
                  maxLines: 16,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(hintText: tr('What I remember…'), suffixIcon: VoiceInputButton(controller: _text, onChanged: () => setState(() {}))),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(key: const ValueKey('recall_compare'), onPressed: _text.text.trim().length < 15 ? null : _compare, icon: const Icon(AppIcons.check), label: Text('Compare with the article')),
              ] else ...[
                AppCard(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      SizedBox(
                        width: 64,
                        height: 64,
                        child: Stack(alignment: Alignment.center, children: [
                          CircularProgressIndicator(value: r.ratio, strokeWidth: 7, backgroundColor: cs.surfaceContainerHighest),
                          m.Text('${(r.ratio * 100).round()}%', key: const ValueKey('recall_pct'), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ]),
                      ),
                      const SizedBox(width: 16),
                      Expanded(child: m.Text(trp('You covered {a} of {b} key points.', {'a': r.covered, 'b': r.points.length}), style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
                    ]),
                  ),
                ),
                if (r.points.isEmpty)
                  Padding(padding: const EdgeInsets.all(12), child: Text('This article has too little text to compare.'))
                else ...[
                  if (r.missed.isNotEmpty) ...[
                    SectionHeader(tr('Missed')),
                    for (final p in r.missed)
                      AppCard(
                        child: ListTile(
                          key: ValueKey('missed_${r.missed.indexOf(p)}'),
                          leading: Icon(AppIcons.warn, color: cs.tertiary),
                          title: m.Text(p.text, style: const TextStyle(height: 1.35)),
                          trailing: _added.contains(p.text)
                              ? Icon(AppIcons.check, color: cs.primary)
                              : IconButton(tooltip: tr('Add to my knowledge gaps'), icon: const Icon(AppIcons.add), onPressed: () => _gap(p)),
                        ),
                      ),
                  ],
                  if (r.covered > 0) ...[
                    SectionHeader(tr('Remembered')),
                    for (final p in r.points.where((p) => p.covered))
                      AppCard(child: ListTile(leading: Icon(AppIcons.check, color: cs.primary), title: m.Text(p.text, style: const TextStyle(height: 1.35)))),
                  ],
                ],
                const SizedBox(height: 10),
                Wrap(spacing: 8, children: [
                  OutlinedButton.icon(onPressed: () => setState(() => _res = null), icon: const Icon(AppIcons.undo), label: Text('Write again')),
                  FilledButton.tonalIcon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ArticleScreen(packId: widget.packId, index: widget.index))),
                    icon: const Icon(AppIcons.library),
                    label: Text('Open the article'),
                  ),
                ]),
              ],
            ]),
    );
  }
}
