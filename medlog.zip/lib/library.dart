import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'search_index.dart' show normText;

/// Offline medical library.
///
/// A pack is two files in the library folder:
///   <id>.idx   gzip(JSON): {"meta":{...},"t":[titles],"l":[lead snippets],"o":[offsets],"n":[lengths]}
///   <id>.bin   the articles, one independent gzip member each, so any article can
///              be read without loading the rest.
/// Article JSON: {"t": title, "u": source url, "s": [{"h": heading, "t": text}]}
/// Text only: no images and no tables, so a whole course is a few megabytes.

const String kLibraryCatalogUrl = 'https://raw.githubusercontent.com/syounis212004-sys/Medlog/main/library/catalog.json';

/// Where the course list is read from (tests point this at a local server).
String libraryCatalogUrl = kLibraryCatalogUrl;

class PackMeta {
  final String id;
  final String title;
  final String course;
  final int count;
  final int bytes;
  final String date;
  final String license;
  final String source;
  final String kind; // wiki | medline | user
  final String desc;
  const PackMeta({
    required this.id,
    required this.title,
    this.course = '',
    this.count = 0,
    this.bytes = 0,
    this.date = '',
    this.license = '',
    this.source = '',
    this.kind = 'wiki',
    this.desc = '',
  });

  factory PackMeta.fromJson(Map<String, dynamic> j) => PackMeta(
        id: '${j['id']}',
        title: '${j['title'] ?? j['id']}',
        course: '${j['course'] ?? ''}',
        count: (j['count'] as num?)?.toInt() ?? 0,
        bytes: (j['bytes'] as num?)?.toInt() ?? 0,
        date: '${j['date'] ?? ''}',
        license: '${j['license'] ?? ''}',
        source: '${j['source'] ?? ''}',
        kind: '${j['kind'] ?? 'wiki'}',
        desc: '${j['desc'] ?? ''}',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'course': course,
        'count': count,
        'bytes': bytes,
        'date': date,
        'license': license,
        'source': source,
        'kind': kind,
        'desc': desc,
      };
}

class CatalogEntry {
  final PackMeta meta;
  final String idxUrl;
  final String binUrl;
  final String sha256Bin;
  final String sha256Idx;
  const CatalogEntry(this.meta, this.idxUrl, this.binUrl, this.sha256Bin, this.sha256Idx);
}

class LibSection {
  final String heading;
  final String text;
  const LibSection(this.heading, this.text);
}

class LibArticle {
  final String title;
  final String url;
  final List<LibSection> sections;
  const LibArticle(this.title, this.url, this.sections);

  Map<String, dynamic> toJson() => {
        't': title,
        'u': url,
        's': [
          for (final s in sections) {'h': s.heading, 't': s.text}
        ],
      };

  factory LibArticle.fromJson(Map<String, dynamic> j) => LibArticle(
        '${j['t'] ?? ''}',
        '${j['u'] ?? ''}',
        [
          for (final s in (j['s'] as List? ?? const [])) LibSection('${(s as Map)['h'] ?? ''}', '${s['t'] ?? ''}'),
        ],
      );
}

class LibHit {
  final String packId;
  final int index;
  final String title;
  final String lead;
  final int score;
  const LibHit(this.packId, this.index, this.title, this.lead, this.score);
}

class _Idx {
  final List<String> titles;
  final List<String> leads;
  final List<int> offsets;
  final List<int> lengths;
  final List<String> normTitles;
  final List<String> normLeads;
  _Idx(this.titles, this.leads, this.offsets, this.lengths)
      : normTitles = [for (final t in titles) normText(t)],
        normLeads = [for (final l in leads) normText(l)];
}

Map<String, dynamic> _decodeIdx(Uint8List gz) => jsonDecode(utf8.decode(gzip.decode(gz))) as Map<String, dynamic>;

class LibraryStore extends ChangeNotifier {
  Directory? _dir;
  final List<PackMeta> packs = [];
  final Map<String, _Idx> _idx = {};
  bool ready = false;

  Directory get dir => _dir!;
  int get totalCount => packs.fold(0, (a, p) => a + p.count);
  int get totalBytes => packs.fold(0, (a, p) => a + p.bytes);

  Future<void> init(Directory base, {List<String> bundled = const []}) async {
    _dir = Directory('${base.path}/library')..createSync(recursive: true);
    _idx.clear();
    packs.clear();
    final f = File('${dir.path}/installed.json');
    if (f.existsSync()) {
      try {
        for (final j in jsonDecode(await f.readAsString()) as List) {
          final m = PackMeta.fromJson(j as Map<String, dynamic>);
          if (File('${dir.path}/${m.id}.bin').existsSync() && File('${dir.path}/${m.id}.idx').existsSync()) packs.add(m);
        }
      } catch (_) {}
    }
    for (final id in bundled) {
      if (packs.any((p) => p.id == id)) continue;
      try {
        final idx = (await rootBundle.load('assets/library/$id.idx')).buffer.asUint8List();
        final bin = (await rootBundle.load('assets/library/$id.bin')).buffer.asUint8List();
        await File('${dir.path}/$id.idx').writeAsBytes(idx, flush: true);
        await File('${dir.path}/$id.bin').writeAsBytes(bin, flush: true);
        final meta = PackMeta.fromJson((_decodeIdx(idx)['meta'] as Map).cast<String, dynamic>());
        packs.add(PackMeta.fromJson({...meta.toJson(), 'bytes': idx.length + bin.length}));
      } catch (_) {}
    }
    await _saveInstalled();
    ready = true;
    notifyListeners();
  }

  Future<void> _saveInstalled() async {
    final f = File('${dir.path}/installed.json');
    final tmp = File('${f.path}.tmp');
    await tmp.writeAsString(jsonEncode([for (final p in packs) p.toJson()]), flush: true);
    await tmp.rename(f.path);
  }

  PackMeta? pack(String id) {
    for (final p in packs) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<_Idx> _index(String id) async {
    final hit = _idx[id];
    if (hit != null) return hit;
    final bytes = await File('${dir.path}/$id.idx').readAsBytes();
    final j = await compute(_decodeIdx, bytes);
    final x = _Idx(
      (j['t'] as List).cast<String>(),
      (j['l'] as List).cast<String>(),
      (j['o'] as List).cast<int>(),
      (j['n'] as List).cast<int>(),
    );
    _idx[id] = x;
    return x;
  }

  Future<List<String>> titlesOf(String id) async => (await _index(id)).titles;
  Future<List<String>> leadsOf(String id) async => (await _index(id)).leads;

  Future<LibArticle?> read(String id, int i) async {
    try {
      final x = await _index(id);
      if (i < 0 || i >= x.offsets.length) return null;
      final raf = await File('${dir.path}/$id.bin').open();
      try {
        await raf.setPosition(x.offsets[i]);
        final bytes = await raf.read(x.lengths[i]);
        return LibArticle.fromJson(jsonDecode(utf8.decode(gzip.decode(bytes))) as Map<String, dynamic>);
      } finally {
        await raf.close();
      }
    } catch (_) {
      return null;
    }
  }

  /// Every word must appear in the title or the first lines. Titles count more.
  Future<List<LibHit>> search(String query, {String? packId, int limit = 60}) async {
    final words = normText(query).split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return const [];
    final whole = words.join(' ');
    final hits = <LibHit>[];
    for (final p in packs) {
      if (packId != null && p.id != packId) continue;
      final x = await _index(p.id);
      for (var i = 0; i < x.normTitles.length; i++) {
        final t = x.normTitles[i];
        var score = 0;
        var ok = true;
        for (final w in words) {
          if (t.contains(w)) {
            score += 20;
          } else if (x.normLeads[i].contains(w)) {
            score += 4;
          } else {
            ok = false;
            break;
          }
        }
        if (!ok) continue;
        if (t == whole) {
          score += 200;
        } else if (t.startsWith(whole)) {
          score += 80;
        }
        score -= t.length ~/ 12; // shorter titles first
        hits.add(LibHit(p.id, i, x.titles[i], x.leads[i], score));
      }
    }
    hits.sort((a, b) => b.score.compareTo(a.score));
    return hits.length > limit ? hits.sublist(0, limit) : hits;
  }

  // ------------------------------------------------------------ writing packs

  /// Writes a pack from articles already in memory (used for the user's own files).
  Future<PackMeta> writePack(PackMeta meta, List<LibArticle> articles) async {
    final sorted = [...articles]..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    final bin = BytesBuilder(copy: false);
    final titles = <String>[], leads = <String>[], offsets = <int>[], lengths = <int>[];
    for (final a in sorted) {
      final member = gzip.encode(utf8.encode(jsonEncode(a.toJson())));
      titles.add(a.title);
      leads.add(_lead(a));
      offsets.add(bin.length);
      lengths.add(member.length);
      bin.add(member);
    }
    final binBytes = bin.takeBytes();
    final full = PackMeta.fromJson({...meta.toJson(), 'count': sorted.length});
    final idxBytes = gzip.encode(utf8.encode(jsonEncode({'meta': full.toJson(), 't': titles, 'l': leads, 'o': offsets, 'n': lengths})));
    await File('${dir.path}/${meta.id}.bin').writeAsBytes(binBytes, flush: true);
    await File('${dir.path}/${meta.id}.idx').writeAsBytes(idxBytes, flush: true);
    final done = PackMeta.fromJson({...full.toJson(), 'bytes': binBytes.length + idxBytes.length});
    _idx.remove(meta.id);
    packs.removeWhere((p) => p.id == meta.id);
    packs.add(done);
    await _saveInstalled();
    notifyListeners();
    return done;
  }

  static String _lead(LibArticle a) {
    for (final s in a.sections) {
      final t = s.text.replaceAll('\n', ' ').trim();
      if (t.isNotEmpty) return t.length > 180 ? '${t.substring(0, 180)}…' : t;
    }
    return '';
  }

  static const String userPackId = 'user_files';

  /// Turns the user's own text / markdown files into articles of one pack ("My files").
  Future<int> importTextFiles(List<String> paths) async {
    final articles = <LibArticle>[];
    final existing = pack(userPackId);
    if (existing != null) {
      final x = await _index(userPackId);
      for (var i = 0; i < x.titles.length; i++) {
        final a = await read(userPackId, i);
        if (a != null) articles.add(a);
      }
    }
    var added = 0;
    for (final p in paths) {
      try {
        final text = utf8.decode(await File(p).readAsBytes(), allowMalformed: true);
        final name = p.split(Platform.pathSeparator).last.replaceAll(RegExp(r'\.[^.]*$'), '');
        articles.removeWhere((a) => a.title == name);
        articles.add(LibArticle(name, '', parseSections(text)));
        added++;
      } catch (_) {}
    }
    if (added > 0) {
      await writePack(
        PackMeta(id: userPackId, title: 'My files', kind: 'user', date: DateTime.now().toIso8601String().substring(0, 10), source: 'Imported by you', license: 'Your own files'),
        articles,
      );
    }
    return added;
  }

  /// Markdown-style headings (# ...) start a new section; anything else is body text.
  static List<LibSection> parseSections(String text) {
    final out = <LibSection>[];
    var head = '';
    final buf = <String>[];
    void flush() {
      final t = buf.join('\n').trim();
      if (t.isNotEmpty) out.add(LibSection(head, t));
      buf.clear();
    }

    for (final line in text.replaceAll('\r', '').split('\n')) {
      final m = RegExp(r'^\s{0,3}#{1,4}\s+(.*)$').firstMatch(line);
      if (m != null) {
        flush();
        head = m.group(1)!.trim();
      } else {
        buf.add(line);
      }
    }
    flush();
    return out;
  }

  Future<void> remove(String id) async {
    for (final ext in ['idx', 'bin']) {
      final f = File('${dir.path}/$id.$ext');
      if (f.existsSync()) await f.delete();
    }
    _idx.remove(id);
    packs.removeWhere((p) => p.id == id);
    await _saveInstalled();
    notifyListeners();
  }

  // ------------------------------------------------------------ catalog + download

  Future<List<CatalogEntry>> fetchCatalog({String? catalogUrl}) async {
    final url = catalogUrl ?? libraryCatalogUrl;
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await c.getUrl(Uri.parse(url));
      req.headers.set('User-Agent', 'MedLog');
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) throw HttpException('HTTP ${res.statusCode}');
      final j = jsonDecode(await res.transform(utf8.decoder).join()) as Map<String, dynamic>;
      final base = url.substring(0, url.lastIndexOf('/') + 1);
      String abs(String s) => s.startsWith('http') ? s : '$base$s';
      return [
        for (final e in (j['packs'] as List))
          CatalogEntry(
            PackMeta.fromJson((e as Map).cast<String, dynamic>()),
            abs('${e['idx'] ?? '${e['id']}.idx'}'),
            abs('${e['bin'] ?? '${e['id']}.bin'}'),
            '${e['sha256_bin'] ?? ''}',
            '${e['sha256_idx'] ?? ''}',
          ),
      ];
    } finally {
      c.close(force: true);
    }
  }

  /// True when the catalog has a newer date than the installed copy.
  bool hasUpdate(CatalogEntry e) {
    final p = pack(e.meta.id);
    return p != null && e.meta.date.compareTo(p.date) > 0;
  }

  Future<String> _download(String url, File to, void Function(int) onBytes) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await c.getUrl(Uri.parse(url));
      req.headers.set('User-Agent', 'MedLog');
      final res = await req.close().timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) throw HttpException('HTTP ${res.statusCode}');
      final sink = to.openWrite();
      final out = AccumulatorSink<Digest>();
      final hasher = sha256.startChunkedConversion(out);
      try {
        await for (final chunk in res) {
          sink.add(chunk);
          hasher.add(chunk);
          onBytes(chunk.length);
        }
      } finally {
        await sink.close();
      }
      hasher.close();
      return out.events.single.toString();
    } finally {
      c.close(force: true);
    }
  }

  /// Downloads, verifies and installs a pack. [onProgress] gets 0..1.
  Future<void> install(CatalogEntry e, {void Function(double)? onProgress}) async {
    final id = e.meta.id;
    final binPart = File('${dir.path}/$id.bin.part');
    final idxPart = File('${dir.path}/$id.idx.part');
    final total = e.meta.bytes <= 0 ? 1 : e.meta.bytes;
    var got = 0;
    void tick(int n) {
      got += n;
      onProgress?.call((got / total).clamp(0.0, 0.99));
    }

    try {
      final hIdx = await _download(e.idxUrl, idxPart, tick);
      final hBin = await _download(e.binUrl, binPart, tick);
      if (e.sha256Idx.isNotEmpty && e.sha256Idx != hIdx) throw const FormatException('Index checksum mismatch');
      if (e.sha256Bin.isNotEmpty && e.sha256Bin != hBin) throw const FormatException('Pack checksum mismatch');
      // check the index really decodes before replacing a working copy
      _decodeIdx(await idxPart.readAsBytes());
      await binPart.rename('${dir.path}/$id.bin');
      await idxPart.rename('${dir.path}/$id.idx');
    } catch (_) {
      for (final f in [binPart, idxPart]) {
        if (f.existsSync()) await f.delete();
      }
      rethrow;
    }
    _idx.remove(id);
    final size = File('${dir.path}/$id.bin').lengthSync() + File('${dir.path}/$id.idx').lengthSync();
    packs.removeWhere((p) => p.id == id);
    packs.add(PackMeta.fromJson({...e.meta.toJson(), 'bytes': size}));
    await _saveInstalled();
    onProgress?.call(1);
    notifyListeners();
  }
}

/// Collects the single digest of a chunked hash.
class AccumulatorSink<T> implements Sink<T> {
  final List<T> events = [];
  @override
  void add(T data) => events.add(data);
  @override
  void close() {}
}

final LibraryStore library = LibraryStore();

String fmtBytes(int b) {
  // wrapped as a left-to-right isolate so "76 MB" never flips inside Arabic text
  String wrap(String x) => '\u2066$x\u2069';
  if (b >= 1024 * 1024) return wrap('${(b / 1024 / 1024).toStringAsFixed(b >= 10 * 1024 * 1024 ? 0 : 1)} MB');
  if (b >= 1024) return wrap('${(b / 1024).round()} KB');
  return wrap('$b B');
}
