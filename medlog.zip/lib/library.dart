import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'lib_text.dart';
import 'search_index.dart' show normText;

/// Offline medical library.
///
/// A pack is two files in the library folder:
///   <id>.idx   gzip(JSON): {"meta":{...},"t":[titles],"l":[lead snippets],"o":[offsets],"n":[lengths]}
///   <id>.bin   the articles, one independent gzip member each, so any article can
///              be read without loading the rest.
/// Article JSON: {"t": title, "u": source url, "s": [{"h": heading, "t": text}]}
/// Text only: no images and no tables, so a whole course is a few megabytes.

const String kLibraryCatalogUrl = 'https://raw.githubusercontent.com/syounis212004-sys/Medlog/main/library/catalog.json';

/// Where the course list is read from (tests point this at a local server).
String libraryCatalogUrl = kLibraryCatalogUrl;

class PackMeta {
  final String id;
  final String title;
  final String course;
  final int count;
  final int bytes;
  final String date;
  final String license;
  final String source;
  final String kind; // wiki | medline | user
  final String desc;
  final String forId; // image packs: the text pack they belong to
  const PackMeta({
    required this.id,
    required this.title,
    this.course = '',
    this.count = 0,
    this.bytes = 0,
    this.date = '',
    this.license = '',
    this.source = '',
    this.kind = 'wiki',
    this.desc = '',
    this.forId = '',
  });

  factory PackMeta.fromJson(Map<String, dynamic> j) => PackMeta(
        id: '${j['id']}',
        title: '${j['title'] ?? j['id']}',
        course: '${j['course'] ?? ''}',
        count: (j['count'] as num?)?.toInt() ?? 0,
        bytes: (j['bytes'] as num?)?.toInt() ?? 0,
        date: '${j['date'] ?? ''}',
        license: '${j['license'] ?? ''}',
        source: '${j['source'] ?? ''}',
        kind: '${j['kind'] ?? 'wiki'}',
        desc: '${j['desc'] ?? ''}',
        forId: '${j['for'] ?? ''}',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'course': course,
        'count': count,
        'bytes': bytes,
        'date': date,
        'license': license,
        'source': source,
        'kind': kind,
        'desc': desc,
        'for': forId,
      };
}

class CatalogEntry {
  final PackMeta meta;
  final String idxUrl;
  final String binUrl;
  final String sha256Bin;
  final String sha256Idx;
  const CatalogEntry(this.meta, this.idxUrl, this.binUrl, this.sha256Bin, this.sha256Idx);
}

class LibTable {
  final String caption;
  final List<List<String>> rows; // first row is the header
  const LibTable(this.caption, this.rows);
  int get columns => rows.isEmpty ? 0 : rows.map((r) => r.length).reduce((a, b) => a > b ? a : b);

  Map<String, dynamic> toJson() => {'c': caption, 'r': rows};

  static LibTable? fromJson(Object? j) {
    if (j is! Map) return null;
    final rows = <List<String>>[
      for (final r in (j['r'] as List? ?? const []))
        if (r is List) [for (final c in r) '${c ?? ''}'],
    ];
    if (rows.length < 2) return null;
    return LibTable('${j['c'] ?? ''}', rows);
  }
}

class LibSection {
  final String heading;
  final String text;
  final List<LibTable> tables;
  const LibSection(this.heading, this.text, [this.tables = const []]);
}

class LibArticle {
  final String title;
  final String url;
  final List<LibSection> sections;
  /// Optional per-article source line (set by packs that mix sources): name, license, authors, date.
  final String source;
  final String license;
  final String authors;
  final String date;
  const LibArticle(this.title, this.url, this.sections, {this.source = '', this.license = '', this.authors = '', this.date = ''});

  Map<String, dynamic> toJson() => {
        't': title,
        'u': url,
        's': [
          for (final s in sections) {'h': s.heading, 't': s.text, if (s.tables.isNotEmpty) 'tb': [for (final t in s.tables) t.toJson()]}
        ],
        if (source.isNotEmpty) 'src': source,
        if (license.isNotEmpty) 'lic': license,
        if (authors.isNotEmpty) 'au': authors,
        if (date.isNotEmpty) 'dt': date,
      };

  factory LibArticle.fromJson(Map<String, dynamic> j) => LibArticle(
        '${j['t'] ?? ''}',
        '${j['u'] ?? ''}',
        [
          for (final s in (j['s'] as List? ?? const []))
            LibSection('${(s as Map)['h'] ?? ''}', '${s['t'] ?? ''}', [
              for (final t in (s['tb'] as List? ?? const []))
                if (LibTable.fromJson(t) != null) LibTable.fromJson(t)!,
            ]),
        ],
        source: '${j['src'] ?? ''}',
        license: '${j['lic'] ?? ''}',
        authors: '${j['au'] ?? ''}',
        date: '${j['dt'] ?? ''}',
      );
}

class LibHit {
  final String packId;
  final int index;
  final String title;
  final String lead;
  final int score;
  const LibHit(this.packId, this.index, this.title, this.lead, this.score);
}

/// normText with a fast path: plain ASCII text only needs lower-casing (same result, no regex work).
String fastNorm(String s) {
  for (var i = 0; i < s.length; i++) {
    if (s.codeUnitAt(i) >= 0x80) return normText(s);
  }
  return s.toLowerCase();
}

final RegExp _sourceSuffix = RegExp(r'\s+—\s+(WikEM|Wikipedia|CDC|NCI|Project Tulip|MedlinePlus)$');

/// The source named at the end of an article title ("Sepsis — WikEM" -> "WikEM"), or null.
String? titleSource(String title) {
  final i = title.lastIndexOf(' — ');
  if (i < 0) return null;
  final m = _sourceSuffix.firstMatch(title.substring(i));
  return m?.group(1);
}

/// The title without its " — WikEM" style suffix.
String stripSource(String title) {
  final i = title.lastIndexOf(' — ');
  if (i < 0 || titleSource(title) == null) return title;
  return title.substring(0, i);
}

/// Sources a result can come from, in the order the filter chips show them.
const List<String> kSources = ['WikEM', 'CDC', 'NCI', 'Project Tulip', 'Wikipedia', 'MedlinePlus'];

/// Id of the concise high-yield pack (gets a small ranking bonus).
const String kEssentialsPackId = 'clinical-essentials';

class _Idx {
  final List<String> titles;
  final List<String> leads;
  final List<int> offsets;
  final List<int> lengths;
  final List<String> normLeads;
  /// Normalised titles without the " — Source" suffix (used for matching and exact-match ranking).
  final List<String> normBase;
  final Map<String, int> pos;
  _Idx(this.titles, this.leads, this.offsets, this.lengths, List<String>? nb, List<String>? nl)
      : normBase = nb ?? [for (final t in titles) fastNorm(stripSource(t))],
        normLeads = nl ?? [for (final l in leads) fastNorm(l)],
        pos = {for (var i = 0; i < titles.length; i++) titles[i]: i};
}

class _ImgEntry {
  final int o, n;
  final String section, caption, file, credit;
  const _ImgEntry(this.o, this.n, this.section, this.caption, this.file, this.credit);
}

/// Image pack index. Version 2 keeps several pictures per article (with the section and caption
/// each belongs to); version 1 has one picture per article.
class _ImgIdx {
  final List<String> titles;
  final List<List<_ImgEntry>> arts;
  final Map<String, int> pos;
  _ImgIdx(this.titles, this.arts) : pos = {for (var i = 0; i < titles.length; i++) titles[i]: i};
}

class LibImage {
  final Uint8List bytes;
  final String credit;
  final String file;
  final bool online;
  final String caption;
  final String section;
  const LibImage(this.bytes, this.credit, this.file, this.online, {this.caption = '', this.section = ''});
  String get filePage => 'https://commons.wikimedia.org/wiki/File:${Uri.encodeComponent(file.replaceAll(' ', '_'))}';
}

Map<String, dynamic> _decodeIdx(Uint8List gz) => jsonDecode(utf8.decode(gzip.decode(gz))) as Map<String, dynamic>;

/// Decodes a text-pack index and normalises titles and leads in the same background isolate.
Map<String, dynamic> _decodeIdxFull(Uint8List gz) {
  final j = _decodeIdx(gz);
  final t = List<String>.from(j['t'] as List), l = List<String>.from(j['l'] as List);
  return {
    't': t,
    'l': l,
    'o': List<int>.from(j['o'] as List),
    'n': List<int>.from(j['n'] as List),
    'nb': [for (final x in t) fastNorm(stripSource(x))],
    'nl': [for (final x in l) fastNorm(x)],
  };
}

// ---------------------------------------------------------------- network seam

enum NetKind { wifi, mobile, none, unknown }

Future<NetKind> _realNetKind() async {
  try {
    final r = await Connectivity().checkConnectivity();
    if (r.contains(ConnectivityResult.wifi) || r.contains(ConnectivityResult.ethernet)) return NetKind.wifi;
    if (r.contains(ConnectivityResult.mobile)) return NetKind.mobile;
    if (r.isEmpty || r.every((e) => e == ConnectivityResult.none)) return NetKind.none;
    return NetKind.unknown; // vpn, bluetooth, other
  } catch (_) {
    return NetKind.unknown; // plugin missing or failing: never block the download
  }
}

/// What kind of network the phone is on. Tests replace this function.
Future<NetKind> Function() netKindProvider = _realNetKind;

/// Safe wrapper: a throwing provider counts as "unknown".
Future<NetKind> currentNetKind() async {
  try {
    return await netKindProvider();
  } catch (_) {
    return NetKind.unknown;
  }
}

/// Downloads of at least this size (or any picture pack) honour the Wi-Fi-only setting.
const int kBigDownloadBytes = 20 * 1024 * 1024;

/// How often "Wait for Wi-Fi" looks again (tests shorten it).
Duration wifiPollEvery = const Duration(seconds: 4);

/// Polls until the phone is on Wi-Fi / ethernet (true) or [cancelled] says stop (false).
Future<bool> waitForWifi({Duration? every, bool Function()? cancelled}) async {
  final gap = every ?? wifiPollEvery;
  while (true) {
    if (cancelled != null && cancelled()) return false;
    final k = await currentNetKind();
    if (k == NetKind.wifi || k == NetKind.unknown) return true;
    await Future<void>.delayed(gap);
  }
}

class LibraryStore extends ChangeNotifier {
  Directory? _dir;
  final List<PackMeta> packs = [];
  final Map<String, _Idx> _idx = {};
  bool ready = false;

  Directory get dir => _dir!;
  /// Text packs (articles). Image packs are listed separately.
  List<PackMeta> get textPacks => [for (final p in packs) if (p.kind != 'images') p];
  List<PackMeta> get imagePacks => [for (final p in packs) if (p.kind == 'images') p];
  int get totalCount => textPacks.fold(0, (a, p) => a + p.count);
  int get totalBytes => packs.fold(0, (a, p) => a + p.bytes);
  PackMeta? imagePackFor(String textPackId) {
    for (final p in imagePacks) {
      if (p.forId == textPackId) return p;
    }
    return null;
  }

  Future<void> init(Directory base, {List<String> bundled = const []}) async {
    _dir = Directory('${base.path}/library')..createSync(recursive: true);
    _idx.clear();
    packs.clear();
    final f = File('${dir.path}/installed.json');
    if (f.existsSync()) {
      try {
        for (final j in jsonDecode(await f.readAsString()) as List) {
          final m = PackMeta.fromJson(j as Map<String, dynamic>);
          if (File('${dir.path}/${m.id}.bin').existsSync() && File('${dir.path}/${m.id}.idx').existsSync()) packs.add(m);
        }
      } catch (_) {}
    }
    for (final id in bundled) {
      if (packs.any((p) => p.id == id)) continue;
      try {
        final idx = (await rootBundle.load('assets/library/$id.idx')).buffer.asUint8List();
        final bin = (await rootBundle.load('assets/library/$id.bin')).buffer.asUint8List();
        await File('${dir.path}/$id.idx').writeAsBytes(idx, flush: true);
        await File('${dir.path}/$id.bin').writeAsBytes(bin, flush: true);
        final meta = PackMeta.fromJson((_decodeIdx(idx)['meta'] as Map).cast<String, dynamic>());
        packs.add(PackMeta.fromJson({...meta.toJson(), 'bytes': idx.length + bin.length}));
      } catch (_) {}
    }
    await _saveInstalled();
    ready = true;
    notifyListeners();
  }

  Future<void> _saveInstalled() async {
    final f = File('${dir.path}/installed.json');
    final tmp = File('${f.path}.tmp');
    await tmp.writeAsString(jsonEncode([for (final p in packs) p.toJson()]), flush: true);
    await tmp.rename(f.path);
  }

  PackMeta? pack(String id) {
    for (final p in packs) {
      if (p.id == id) return p;
    }
    return null;
  }

  final Map<String, Future<_Idx>> _loading = {};

  Future<_Idx> _index(String id) {
    final hit = _idx[id];
    if (hit != null) return Future.value(hit);
    return _loading[id] ??= _loadIndex(id).whenComplete(() {
      _loading.remove(id);
    });
  }

  Future<_Idx> _loadIndex(String id) async {
    final bytes = await File('${dir.path}/$id.idx').readAsBytes();
    final j = await compute(_decodeIdxFull, bytes);
    final x = _Idx(
      (j['t'] as List).cast<String>(),
      (j['l'] as List).cast<String>(),
      (j['o'] as List).cast<int>(),
      (j['n'] as List).cast<int>(),
      (j['nb'] as List).cast<String>(),
      (j['nl'] as List).cast<String>(),
    );
    _idx[id] = x;
    return x;
  }

  /// Loads the indexes of all text packs at the same time (first search / quiz).
  Future<void> warmUp([List<PackMeta>? only]) async {
    final ids = [for (final p in only ?? textPacks) if (!_idx.containsKey(p.id)) p.id];
    // a few background isolates at a time: fast, without a memory spike on small phones
    const width = 3;
    for (var i = 0; i < ids.length; i += width) {
      await Future.wait([for (final id in ids.skip(i).take(width)) _index(id)]);
    }
  }

  /// Where an article comes from: WikEM / CDC / NCI / Project Tulip / Wikipedia / MedlinePlus / My files.
  String sourceOf(String packId, String title) {
    final s = titleSource(title);
    if (s != null) return s;
    final p = pack(packId);
    if (p == null) return 'Wikipedia';
    if (p.kind == 'medline') return 'MedlinePlus';
    if (p.kind == 'user') return 'My files';
    return 'Wikipedia';
  }

  /// Sources that exist in the installed packs (for the filter chips), in [kSources] order.
  List<String> availableSources() {
    final out = <String>{};
    for (final p in textPacks) {
      if (p.id == kEssentialsPackId) {
        out.addAll(['WikEM', 'CDC', 'NCI', 'Project Tulip', 'Wikipedia']);
      } else if (p.kind == 'medline') {
        out.add('MedlinePlus');
      } else if (p.kind == 'wiki') {
        out.add('Wikipedia');
      }
    }
    return [for (final s in kSources) if (out.contains(s)) s];
  }

  Future<List<String>> titlesOf(String id) async => (await _index(id)).titles;
  Future<List<String>> leadsOf(String id) async => (await _index(id)).leads;

  Future<LibArticle?> read(String id, int i) async {
    try {
      final x = await _index(id);
      if (i < 0 || i >= x.offsets.length) return null;
      final raf = await File('${dir.path}/$id.bin').open();
      try {
        await raf.setPosition(x.offsets[i]);
        final bytes = await raf.read(x.lengths[i]);
        return LibArticle.fromJson(jsonDecode(utf8.decode(gzip.decode(bytes))) as Map<String, dynamic>);
      } finally {
        await raf.close();
      }
    } catch (_) {
      return null;
    }
  }

  /// Every word must appear in the title or the first lines. Titles count more.
  Future<List<LibHit>> search(String query, {String? packId, int limit = 60, String? source}) async {
    final words = normText(query).split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return const [];
    final whole = words.join(' ');
    final hits = <LibHit>[];
    final packsToSearch = [for (final p in textPacks) if (packId == null || p.id == packId) p];
    if (packsToSearch.length > 1) await warmUp(packsToSearch);
    for (final p in packsToSearch) {
      final x = await _index(p.id);
      final bonus = p.id == kEssentialsPackId ? 6 : 0; // concise high-yield article beats a long encyclopedia one on a tie
      final fixed = p.id == kEssentialsPackId ? null : sourceOf(p.id, '');
      if (source != null && fixed != null && fixed != source) continue;
      for (var i = 0; i < x.normBase.length; i++) {
        if (source != null && fixed == null && titleSource(x.titles[i]) != source) continue;
        final t = x.normBase[i];
        var score = 0;
        var ok = true;
        for (final w in words) {
          // very short words (OA, MI) must start a word, so "oa" does not match "throat"
          final short = w.length <= 3;
          if (short ? ' $t'.contains(' $w') : t.contains(w)) {
            score += 20;
          } else if (short ? ' ${x.normLeads[i]}'.contains(' $w') : x.normLeads[i].contains(w)) {
            score += 4;
          } else {
            ok = false;
            break;
          }
        }
        if (!ok) continue;
        if (t == whole) {
          score += 200;
        } else if (t.startsWith(whole)) {
          score += 80;
        }
        score -= t.length ~/ 12; // shorter titles first
        score += bonus;
        hits.add(LibHit(p.id, i, x.titles[i], x.leads[i], score));
      }
    }
    hits.sort((a, b) => b.score.compareTo(a.score));
    return hits.length > limit ? hits.sublist(0, limit) : hits;
  }

  // ------------------------------------------------------------ search helpers

  Map<String, int>? _vocab;

  Future<Map<String, int>> _vocabulary() async {
    final v = _vocab;
    if (v != null) return v;
    final m = <String, int>{};
    for (final p in textPacks) {
      final x = await _index(p.id);
      for (final t in x.normBase) {
        for (final w in t.split(RegExp(r'[^a-z0-9]+'))) {
          if (w.length >= 4) m[w] = (m[w] ?? 0) + 1;
        }
      }
    }
    return _vocab = m;
  }

  /// Same as [search] but also understands abbreviations (OA, MI, DVT...).
  Future<List<LibHit>> searchEx(String query, {String? packId, int limit = 60, String? source}) async {
    final seen = <String>{};
    final all = <LibHit>[];
    final variants = expandAbbrev(query);
    for (var vi = 0; vi < variants.length; vi++) {
      for (final h in await search(variants[vi], packId: packId, limit: limit, source: source)) {
        // what an abbreviation stands for comes before accidental matches of the letters
        if (seen.add('${h.packId}|${h.index}')) all.add(vi == 0 ? h : LibHit(h.packId, h.index, h.title, h.lead, h.score + 150));
      }
    }
    all.sort((a, b) => b.score.compareTo(a.score));
    return all.length > limit ? all.sublist(0, limit) : all;
  }

  /// A corrected query when a word looks like a typo of a known title word, else null.
  Future<String?> didYouMean(String query) async {
    final vocab = await _vocabulary();
    if (vocab.isEmpty) return null;
    var changed = false;
    final out = <String>[];
    for (final w in normText(query).split(RegExp(r'\s+')).where((w) => w.isNotEmpty)) {
      if (w.length < 5 || vocab.containsKey(w) || kLibAbbrev.containsKey(w)) {
        out.add(w);
        continue;
      }
      final maxD = w.length <= 7 ? 1 : 2;
      String? best;
      var bd = maxD + 1, bc = 0;
      for (final e in vocab.entries) {
        final c = e.key;
        if ((c.length - w.length).abs() > maxD || c[0] != w[0]) continue;
        final d = editDistance(w, c, max: maxD);
        if (d < bd || (d == bd && e.value > bc)) {
          best = c;
          bd = d;
          bc = e.value;
        }
      }
      if (best != null && bd <= maxD) {
        out.add(best);
        changed = true;
      } else {
        out.add(w);
      }
    }
    return changed ? out.join(' ') : null;
  }

  Future<int?> indexOfTitle(String packId, String title) async => (await _index(packId)).pos[title];

  /// Other articles of the same course that share the main words of this title.
  Future<List<LibHit>> related(String packId, int index, {int limit = 6}) async {
    final x = await _index(packId);
    if (index < 0 || index >= x.titles.length) return const [];
    const stop = {'with', 'from', 'disease', 'syndrome', 'disorder', 'type', 'acute', 'chronic', 'and', 'the', 'of', 'in'};
    final words = x.normBase[index].split(RegExp(r'[^a-z0-9]+')).where((w) => w.length >= 4 && !stop.contains(w)).toList();
    if (words.isEmpty) return const [];
    final hits = <LibHit>[];
    for (var i = 0; i < x.normBase.length; i++) {
      if (i == index) continue;
      var sc = 0;
      for (final w in words) {
        if (x.normBase[i].contains(w)) {
          sc += 10;
        } else if (x.normLeads[i].contains(w)) {
          sc += 1;
        }
      }
      if (sc >= 10) hits.add(LibHit(packId, i, x.titles[i], x.leads[i], sc));
    }
    hits.sort((a, b) => b.score.compareTo(a.score));
    return hits.take(limit).toList();
  }

  /// Article count and one deterministic pick per day for [packId] (e.g. "topic of the day").
  Future<int?> dailyPick(String packId, String seed) async {
    final x = await _index(packId);
    if (x.titles.isEmpty) return null;
    final good = [for (var i = 0; i < x.leads.length; i++) if (x.leads[i].length > 120) i];
    if (good.isEmpty) return null;
    final h = md5.convert(utf8.encode('$seed|$packId')).bytes;
    final n = (h[0] << 16) | (h[1] << 8) | h[2];
    return good[n % good.length];
  }

  // ------------------------------------------------------------ images

  final Map<String, _ImgIdx> _imgIdx = {};

  Future<_ImgIdx?> _imageIndex(String id) async {
    final hit = _imgIdx[id];
    if (hit != null) return hit;
    try {
      final j = await compute(_decodeIdx, await File('${dir.path}/$id.idx').readAsBytes());
      final t = (j['t'] as List).cast<String>();
      final arts = <List<_ImgEntry>>[];
      if (j['v'] == 2) {
        for (final a in (j['a'] as List)) {
          arts.add([
            for (final e in (a as List))
              _ImgEntry((e['o'] as num).toInt(), (e['n'] as num).toInt(), '${e['s'] ?? ''}', '${e['c'] ?? ''}', '${e['f'] ?? ''}', '${e['u'] ?? 'Wikimedia Commons'}'),
          ]);
        }
      } else {
        final o = (j['o'] as List).cast<int>(), n = (j['n'] as List).cast<int>(), c = (j['c'] as List).cast<String>(), f = (j['f'] as List).cast<String>();
        for (var i = 0; i < t.length; i++) {
          arts.add([_ImgEntry(o[i], n[i], '', '', f[i], c[i])]);
        }
      }
      return _imgIdx[id] = _ImgIdx(t, arts);
    } catch (_) {
      return null;
    }
  }

  /// All downloaded pictures of an article (each with its section, caption and credit).
  Future<List<LibImage>> imagesFor(String title) async {
    final out = <LibImage>[];
    for (final p in imagePacks) {
      final x = await _imageIndex(p.id);
      final i = x?.pos[title];
      if (x == null || i == null) continue;
      final raf = await File('${dir.path}/${p.id}.bin').open();
      try {
        for (final e in x.arts[i]) {
          await raf.setPosition(e.o);
          final bytes = await raf.read(e.n);
          out.add(LibImage(Uint8List.fromList(bytes), e.credit, e.file, false, caption: e.caption, section: e.section));
        }
      } finally {
        await raf.close();
      }
    }
    return out;
  }

  /// The first downloaded picture for an article title, if an image pack has one.
  Future<LibImage?> imageFor(String title) async {
    final l = await imagesFor(title);
    return l.isEmpty ? null : l.first;
  }

  /// Pictures of an article from Wikipedia when online (up to [max], cached on the phone afterwards).
  Future<List<LibImage>> onlineImagesFor(String title, {int max = 8}) async {
    final key = md5.convert(utf8.encode(title)).toString();
    final cache = Directory('${dir.path}/imgcache')..createSync(recursive: true);
    final fMeta = File('${cache.path}/$key.json');
    if (fMeta.existsSync()) {
      try {
        final m = jsonDecode(await fMeta.readAsString()) as List;
        final out = <LibImage>[];
        for (var i = 0; i < m.length; i++) {
          final f = File('${cache.path}/${key}_$i.img');
          if (f.existsSync()) {
            final e = m[i] as Map;
            out.add(LibImage(await f.readAsBytes(), '${e['credit']}', '${e['file']}', true, caption: '${e['caption'] ?? ''}'));
          }
        }
        return out;
      } catch (_) {}
    }
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      Future<HttpClientResponse> get(String url) async {
        final req = await c.getUrl(Uri.parse(url));
        req.headers.set('User-Agent', 'MedLog/1.6 (offline medical logbook)');
        return req.close().timeout(const Duration(seconds: 15));
      }

      final res = await get('https://en.wikipedia.org/api/rest_v1/page/media-list/${Uri.encodeComponent(title.replaceAll(' ', '_'))}');
      if (res.statusCode != 200) return const [];
      final j = jsonDecode(await res.transform(utf8.decoder).join()) as Map<String, dynamic>;
      final out = <LibImage>[];
      final meta = <Map<String, String>>[];
      const credit = 'Wikimedia Commons — author and license on the file page';
      for (final it in (j['items'] as List? ?? const [])) {
        if (out.length >= max) break;
        if (it is! Map || it['type'] != 'image' || it['showInGallery'] == false) continue;
        final srcset = it['srcset'] as List?;
        if (srcset == null || srcset.isEmpty) continue;
        var src = '${(srcset.first as Map)['src']}';
        if (src.startsWith('//')) src = 'https:$src';
        if (src.toLowerCase().contains('.svg')) continue;
        final r2 = await get(src);
        if (r2.statusCode != 200) continue;
        final b = BytesBuilder(copy: false);
        var tooBig = false;
        await for (final ch in r2) {
          b.add(ch);
          if (b.length > 500 * 1024) {
            tooBig = true;
            break;
          }
        }
        if (tooBig) continue;
        final bytes = b.takeBytes();
        final file = '${it['title'] ?? ''}'.replaceFirst(RegExp(r'^File:'), '');
        final cap = '${(it['caption'] as Map?)?['text'] ?? ''}';
        await File('${cache.path}/${key}_${out.length}.img').writeAsBytes(bytes, flush: true);
        meta.add({'credit': credit, 'file': file, 'caption': cap});
        out.add(LibImage(bytes, credit, file, true, caption: cap));
      }
      await fMeta.writeAsString(jsonEncode(meta));
      return out;
    } catch (_) {
      return const [];
    } finally {
      c.close(force: true);
    }
  }

  Future<int> imageCacheBytes() async {
    final d = Directory('${dir.path}/imgcache');
    if (!d.existsSync()) return 0;
    var n = 0;
    for (final f in d.listSync()) {
      if (f is File) n += f.lengthSync();
    }
    return n;
  }

  Future<void> clearImageCache() async {
    final d = Directory('${dir.path}/imgcache');
    if (d.existsSync()) await d.delete(recursive: true);
  }

  // ------------------------------------------------------------ writing packs

  /// Writes a pack from articles already in memory (used for the user's own files).
  Future<PackMeta> writePack(PackMeta meta, List<LibArticle> articles) async {
    final sorted = [...articles]..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    final bin = BytesBuilder(copy: false);
    final titles = <String>[], leads = <String>[], offsets = <int>[], lengths = <int>[];
    for (final a in sorted) {
      final member = gzip.encode(utf8.encode(jsonEncode(a.toJson())));
      titles.add(a.title);
      leads.add(_lead(a));
      offsets.add(bin.length);
      lengths.add(member.length);
      bin.add(member);
    }
    final binBytes = bin.takeBytes();
    final full = PackMeta.fromJson({...meta.toJson(), 'count': sorted.length});
    final idxBytes = gzip.encode(utf8.encode(jsonEncode({'meta': full.toJson(), 't': titles, 'l': leads, 'o': offsets, 'n': lengths})));
    await File('${dir.path}/${meta.id}.bin').writeAsBytes(binBytes, flush: true);
    await File('${dir.path}/${meta.id}.idx').writeAsBytes(idxBytes, flush: true);
    final done = PackMeta.fromJson({...full.toJson(), 'bytes': binBytes.length + idxBytes.length});
    _idx.remove(meta.id);
    _vocab = null;
    packs.removeWhere((p) => p.id == meta.id);
    packs.add(done);
    await _saveInstalled();
    notifyListeners();
    return done;
  }

  static String _lead(LibArticle a) {
    for (final s in a.sections) {
      final t = s.text.replaceAll('\n', ' ').trim();
      if (t.isNotEmpty) return t.length > 180 ? '${t.substring(0, 180)}…' : t;
    }
    return '';
  }

  static const String userPackId = 'user_files';

  /// Turns the user's own text / markdown files into articles of one pack ("My files").
  Future<int> importTextFiles(List<String> paths) async {
    final articles = <LibArticle>[];
    final existing = pack(userPackId);
    if (existing != null) {
      final x = await _index(userPackId);
      for (var i = 0; i < x.titles.length; i++) {
        final a = await read(userPackId, i);
        if (a != null) articles.add(a);
      }
    }
    var added = 0;
    for (final p in paths) {
      try {
        final text = utf8.decode(await File(p).readAsBytes(), allowMalformed: true);
        final name = p.split(Platform.pathSeparator).last.replaceAll(RegExp(r'\.[^.]*$'), '');
        articles.removeWhere((a) => a.title == name);
        articles.add(LibArticle(name, '', parseSections(text)));
        added++;
      } catch (_) {}
    }
    if (added > 0) {
      await writePack(
        PackMeta(id: userPackId, title: 'My files', kind: 'user', date: DateTime.now().toIso8601String().substring(0, 10), source: 'Imported by you', license: 'Your own files'),
        articles,
      );
    }
    return added;
  }

  /// Markdown-style headings (# ...) start a new section; anything else is body text.
  static List<LibSection> parseSections(String text) {
    final out = <LibSection>[];
    var head = '';
    final buf = <String>[];
    void flush() {
      final t = buf.join('\n').trim();
      if (t.isNotEmpty) out.add(LibSection(head, t));
      buf.clear();
    }

    for (final line in text.replaceAll('\r', '').split('\n')) {
      final m = RegExp(r'^\s{0,3}#{1,4}\s+(.*)$').firstMatch(line);
      if (m != null) {
        flush();
        head = m.group(1)!.trim();
      } else {
        buf.add(line);
      }
    }
    flush();
    return out;
  }

  Future<void> remove(String id) async {
    for (final ext in ['idx', 'bin', 'qw']) {
      final f = File('${dir.path}/$id.$ext');
      if (f.existsSync()) await f.delete();
    }
    _idx.remove(id);
    _imgIdx.remove(id);
    _vocab = null;
    packs.removeWhere((p) => p.id == id);
    await _saveInstalled();
    notifyListeners();
  }

  // ------------------------------------------------------------ catalog + download

  Future<List<CatalogEntry>> fetchCatalog({String? catalogUrl}) async {
    final url = catalogUrl ?? libraryCatalogUrl;
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await c.getUrl(Uri.parse(url));
      req.headers.set('User-Agent', 'MedLog');
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) throw HttpException('HTTP ${res.statusCode}');
      final j = jsonDecode(await res.transform(utf8.decoder).join()) as Map<String, dynamic>;
      final base = url.substring(0, url.lastIndexOf('/') + 1);
      String abs(String s) => s.startsWith('http') ? s : '$base$s';
      return [
        for (final e in (j['packs'] as List))
          CatalogEntry(
            PackMeta.fromJson((e as Map).cast<String, dynamic>()),
            abs('${e['imx'] ?? e['idx'] ?? '${e['id']}.idx'}'),
            abs('${e['img'] ?? e['bin'] ?? '${e['id']}.bin'}'),
            '${e['sha256_bin'] ?? ''}',
            '${e['sha256_idx'] ?? ''}',
          ),
      ];
    } finally {
      c.close(force: true);
    }
  }

  /// True when the catalog has a newer date than the installed copy.
  bool hasUpdate(CatalogEntry e) {
    final p = pack(e.meta.id);
    return p != null && e.meta.date.compareTo(p.date) > 0;
  }

  Future<String> _download(String url, File to, void Function(int) onBytes) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final req = await c.getUrl(Uri.parse(url));
      req.headers.set('User-Agent', 'MedLog');
      final res = await req.close().timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) throw HttpException('HTTP ${res.statusCode}');
      final sink = to.openWrite();
      final out = AccumulatorSink<Digest>();
      final hasher = sha256.startChunkedConversion(out);
      try {
        await for (final chunk in res) {
          sink.add(chunk);
          hasher.add(chunk);
          onBytes(chunk.length);
        }
      } finally {
        await sink.close();
      }
      hasher.close();
      return out.events.single.toString();
    } finally {
      c.close(force: true);
    }
  }

  /// Downloads, verifies and installs a pack. [onProgress] gets 0..1.
  Future<void> install(CatalogEntry e, {void Function(double)? onProgress}) async {
    final id = e.meta.id;
    final binPart = File('${dir.path}/$id.bin.part');
    final idxPart = File('${dir.path}/$id.idx.part');
    final total = e.meta.bytes <= 0 ? 1 : e.meta.bytes;
    var got = 0;
    void tick(int n) {
      got += n;
      onProgress?.call((got / total).clamp(0.0, 0.99));
    }

    try {
      final hIdx = await _download(e.idxUrl, idxPart, tick);
      final hBin = await _download(e.binUrl, binPart, tick);
      if (e.sha256Idx.isNotEmpty && e.sha256Idx != hIdx) throw const FormatException('Index checksum mismatch');
      if (e.sha256Bin.isNotEmpty && e.sha256Bin != hBin) throw const FormatException('Pack checksum mismatch');
      // check the index really decodes before replacing a working copy
      _decodeIdx(await idxPart.readAsBytes());
      await binPart.rename('${dir.path}/$id.bin');
      await idxPart.rename('${dir.path}/$id.idx');
    } catch (_) {
      for (final f in [binPart, idxPart]) {
        if (f.existsSync()) await f.delete();
      }
      rethrow;
    }
    _idx.remove(id);
    _imgIdx.remove(id);
    _vocab = null;
    final size = File('${dir.path}/$id.bin').lengthSync() + File('${dir.path}/$id.idx').lengthSync();
    packs.removeWhere((p) => p.id == id);
    packs.add(PackMeta.fromJson({...e.meta.toJson(), 'bytes': size}));
    await _saveInstalled();
    onProgress?.call(1);
    notifyListeners();
  }
}

/// Collects the single digest of a chunked hash.
class AccumulatorSink<T> implements Sink<T> {
  final List<T> events = [];
  @override
  void add(T data) => events.add(data);
  @override
  void close() {}
}

final LibraryStore library = LibraryStore();

String fmtBytes(int b) {
  // wrapped as a left-to-right isolate so "76 MB" never flips inside Arabic text
  String wrap(String x) => '\u2066$x\u2069';
  if (b >= 1024 * 1024) return wrap('${(b / 1024 / 1024).toStringAsFixed(b >= 10 * 1024 * 1024 ? 0 : 1)} MB');
  if (b >= 1024) return wrap('${(b / 1024).round()} KB');
  return wrap('$b B');
}
