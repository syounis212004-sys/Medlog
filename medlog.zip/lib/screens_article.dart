import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/rendering.dart' show SelectedContent;

import 'data.dart';
import 'i18n.dart';
import 'lib_glance.dart';
import 'lib_text.dart';
import 'lib_user.dart';
import 'library.dart';
import 'screens_cases.dart';
import 'screens_library.dart';
import 'screens_quiz.dart';
import 'ui.dart';
import 'widgets.dart';

/// Reader for one library article: picture, definition, jump chips, foldable sections,
/// your own notes, related articles and your cases about the same subject.
class ArticleScreen extends StatefulWidget {
  final String packId;
  final int index;
  const ArticleScreen({super.key, required this.packId, required this.index});
  @override
  State<ArticleScreen> createState() => _ArticleScreenState();
}

class _Sec {
  final int orig;
  final LibSection s;
  final SecKind kind;
  const _Sec(this.orig, this.s, this.kind);
}

class _ArticleScreenState extends State<ArticleScreen> {
  LibArticle? _a;
  bool _missing = false;
  final _scroll = ScrollController();
  final Set<int> _open = {};
  final Map<int, GlobalKey> _keys = {};
  List<LibImage> _imgList = const [];
  List<LibHit> _related = const [];
  late final TextEditingController _note = TextEditingController();
  Timer? _noteTimer;
  String _selected = '';
  List<_Sec> _secs = const [];

  @override
  void initState() {
    super.initState();
    library.read(widget.packId, widget.index).then((a) {
      if (!mounted) return;
      if (a == null) {
        setState(() => _missing = true);
        return;
      }
      noteRecent(widget.packId, a.title);
      _note.text = noteFor(widget.packId, a.title);
      final secs = <_Sec>[for (var i = 1; i < a.sections.length; i++) _Sec(i, a.sections[i], secKind(a.sections[i].heading))];
      int rank(SecKind k) {
        switch (k) {
          case SecKind.symptoms:
            return 0;
          case SecKind.causes:
            return 1;
          case SecKind.diagnosis:
            return 2;
          case SecKind.treatment:
            return 3;
          case SecKind.prevention:
            return 4;
          case SecKind.other:
            return 5;
          case SecKind.epidemiology:
            return 6;
          default:
            return 7;
        }
      }

      final idx = {for (var i = 0; i < secs.length; i++) secs[i].orig: i};
      secs.sort((x, y) {
        final c = rank(x.kind).compareTo(rank(y.kind));
        return c != 0 ? c : idx[x.orig]!.compareTo(idx[y.orig]!);
      });
      setState(() {
        _a = a;
        _secs = secs;
        _loadImages(a.title).then((l) {
          if (mounted) setState(() => _imgList = l);
        });
      });
      library.related(widget.packId, widget.index).then((r) {
        if (mounted) setState(() => _related = r);
      });
    });
  }

  @override
  void dispose() {
    _noteTimer?.cancel();
    _scroll.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<List<LibImage>> _loadImages(String title) async {
    // only Wikipedia course articles have pictures: your own files and MedlinePlus never go online
    if (library.pack(widget.packId)?.kind != 'wiki') return const [];
    if (store.libShowImages) {
      final l = await library.imagesFor(title);
      if (l.isNotEmpty) return l;
    }
    if (store.libOnlineImages) return library.onlineImagesFor(title);
    return const [];
  }

  bool get _quick => store.settings['libQuick'] != false;

  /// Tables of a section in the full article (quick view lists them all after the key points); needs 'Show tables' on.
  List<Widget> _tablesOf(LibSection s, double scale) {
    if (_quick || !store.libShowTables || s.tables.isEmpty) return const [];  // quick view lists all tables after the key points
    return [for (final t in s.tables) _TableCard(table: t, scale: scale)];
  }

  void _jump(int secIndex) {
    setState(() => _open.add(secIndex));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final c = _keys[secIndex]?.currentContext;
      if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 320), curve: Curves.easeOut, alignment: 0.04);
    });
  }

  void _onNote(String v) {
    _noteTimer?.cancel();
    _noteTimer = Timer(const Duration(milliseconds: 600), () => saveNote(widget.packId, _a!.title, v));
  }

  Future<void> _addDefinitionCard(LibArticle a) async {
    final lead = sentences(a.sections.first.text).take(2).join(' ');
    final ok = await addLibraryCard(
      front: '${tr('What is')} ${a.title}?',
      back: lead,
      source: a.title,
      packId: widget.packId,
      title: a.title,
    );
    if (mounted) snack(context, ok ? tr('Added to your review cards.') : tr('Already in your review cards.'));
  }

  Future<void> _saveSelection(LibArticle a, {required bool asPearl}) async {
    final t = _selected.trim();
    if (t.isEmpty) return;
    if (asPearl) {
      await store.upsertExtra('pearls', {'id': newId('pl'), 'date': todayStr(), 'text': t, 'topic': a.title});
      if (mounted) snack(context, tr('Saved as a pearl.'));
    } else {
      final ok = await addLibraryCard(
        front: '${a.title}\n${tr('What do you remember about this?')}',
        back: t,
        source: a.title,
        packId: widget.packId,
        title: a.title,
      );
      if (mounted) snack(context, ok ? tr('Added to your review cards.') : tr('Already in your review cards.'));
    }
  }

  Widget _menuFor(BuildContext ctx, SelectableRegionState state, LibArticle a) {
    return AdaptiveTextSelectionToolbar.buttonItems(
      anchors: state.contextMenuAnchors,
      buttonItems: [
        ...state.contextMenuButtonItems,
        ContextMenuButtonItem(
          label: tr('Save as pearl'),
          onPressed: () {
            ContextMenuController.removeAny();
            _saveSelection(a, asPearl: true);
          },
        ),
        ContextMenuButtonItem(
          label: tr('Add to review'),
          onPressed: () {
            ContextMenuController.removeAny();
            _saveSelection(a, asPearl: false);
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final a = _a;
    final p = library.pack(widget.packId);
    final fav = a != null && isFavorite(widget.packId, a.title);
    return Scaffold(
      appBar: AppBar(
        title: Text(a?.title ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          if (a != null)
            IconButton(
              tooltip: tr('Favorite'),
              icon: Icon(fav ? Icons.star : Icons.star_border, color: fav ? Colors.amber : null),
              onPressed: () async {
                await toggleFavorite(widget.packId, a.title);
                if (mounted) setState(() {});
              },
            ),
          if (a != null)
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'card') {
                  await _addDefinitionCard(a);
                } else if (v == 'ref') {
                  final dup = store.listOf('evidence').any((e) => e['title'] == a.title && e['source'] == (p?.source ?? ''));
                  if (!dup) {
                    await store.upsertExtra('evidence', {
                      'id': newId('ev'),
                      'title': a.title,
                      'source': p?.source ?? '',
                      'year': '${DateTime.now().year}',
                      'level': 'Expert opinion / textbook',
                      'link': a.url,
                      'topic': p?.title ?? '',
                      'note': '',
                      'saved': todayStr(),
                      'reviewed': todayStr(),
                    });
                  }
                  if (mounted) snack(context, dup ? tr('Already in your references.') : tr('Saved to your references.'));
                } else if (v == 'quiz') {
                  final word = _cleanForQuiz(a.title);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(packId: widget.packId, query: word, autoStart: true)));
                } else if (v == 'online') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(title: a.title, url: a.url)));
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'quiz', child: Text('Test myself on this topic')),
                PopupMenuItem(value: 'card', child: Text('Add to review cards')),
                PopupMenuItem(value: 'ref', child: Text('Save to my references')),
                if (a.url.startsWith('https://en.wikipedia.org/')) PopupMenuItem(value: 'online', child: Text('Open the full online page')),
              ],
            ),
        ],
      ),
      body: _missing
          ? Center(child: Text('Could not open this article.'))
          : a == null
              ? const Center(child: CircularProgressIndicator())
              : SelectionArea(
                  onSelectionChanged: (SelectedContent? c) => _selected = c?.plainText ?? '',
                  contextMenuBuilder: (ctx, state) => _menuFor(ctx, state, a),
                  child: ListView(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
                    children: _children(context, a, p, theme),
                  ),
                ),
    );
  }

  String _cleanForQuiz(String t) {
    final base = t.replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();
    final words = base.split(RegExp(r'\s+')).where((w) => w.length >= 5).toList();
    return words.isEmpty ? base : words.first;
  }

  List<Widget> _children(BuildContext context, LibArticle a, PackMeta? p, ThemeData theme) {
    final cs = theme.colorScheme;
    final lead = a.sections.first;
    final sents = sentences(lead.text);
    final definition = sents.isEmpty ? '' : sents.first;
    final rest = sents.length > 1 ? sents.skip(1).join(' ') : '';
    final words = a.sections.fold<int>(0, (n, s) => n + s.text.split(RegExp(r'\s+')).length);
    final minutes = (words / 200).ceil().clamp(1, 60);
    final kinds = <SecKind>[];
    for (final s in _secs) {
      if (s.kind != SecKind.other && !kinds.contains(s.kind)) kinds.add(s.kind);
    }
    final scale = store.libFontScale;
    final cases = casesAbout(a.title);
    // pictures: in quick view all of them are at the top; in the full article the ones that belong to a
    // section are shown inside that section
    final heads = {for (final x in _secs) x.s.heading.trim().toLowerCase()};
    bool placed(LibImage im) => im.section.trim().isNotEmpty && heads.contains(im.section.trim().toLowerCase());
    final topImages = _quick ? _imgList : [for (final im in _imgList) if (!placed(im)) im];
    final glance = buildGlance(a);
    return [
      if (topImages.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: _ImgStrip(images: topImages, all: _imgList, height: _quick ? 190 : 170),
        ),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(a.title, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, height: 1.25)),
        ),
      ),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 4, children: [
        if (p != null) Chip(visualDensity: VisualDensity.compact, avatar: const Icon(Icons.school_outlined, size: 16), label: Text(p.title)),
        Chip(visualDensity: VisualDensity.compact, avatar: const Icon(Icons.schedule, size: 16), label: Text(trp('{n} min read', {'n': minutes}))),
      ]),
      if (definition.isNotEmpty)
        Container(
          margin: const EdgeInsets.only(top: 10, bottom: 6),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cs.primaryContainer.withAlpha(110),
            borderRadius: BorderRadius.circular(16),
            border: Border(left: BorderSide(color: cs.primary, width: 4)),
          ),
          child: _Para(definition, scale: scale * 1.05, bold: true),
        ),
      Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 4),
        child: SegmentedButton<bool>(
          showSelectedIcon: false,
          segments: [
            ButtonSegment(value: true, icon: const Icon(Icons.bolt, size: 18), label: Text('Quick view')),
            ButtonSegment(value: false, icon: const Icon(Icons.article_outlined, size: 18), label: Text('Full article')),
          ],
          selected: {_quick},
          onSelectionChanged: (v) {
            store.settings['libQuick'] = v.first;
            store.saveSettings();
            setState(() {});
          },
        ),
      ),
      if (_quick) ...[
        for (final g in glance)
          AppCard(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(secIcon(g.kind), size: 20, color: cs.primary),
                  const SizedBox(width: 8),
                  Directionality(textDirection: TextDirection.ltr, child: Text(secLabel(g.kind), style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
                ]),
                const SizedBox(height: 6),
                for (final pt in g.points)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Padding(padding: const EdgeInsets.only(top: 7, right: 8), child: Container(width: 6, height: 6, decoration: BoxDecoration(color: cs.primary, shape: BoxShape.circle))),
                        Expanded(child: Text(pt, textAlign: TextAlign.left, style: theme.textTheme.bodyMedium?.copyWith(height: 1.5, fontSize: (theme.textTheme.bodyMedium?.fontSize ?? 14) * scale))),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
        if (glance.isEmpty && rest.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: _Body(rest, scale: scale)),
        if (store.libShowTables)
          for (final sec in a.sections)
            for (final t in sec.tables) _TableCard(table: t, scale: scale),
        const SizedBox(height: 4),
        Wrap(spacing: 8, runSpacing: 4, children: [
          ActionChip(
            avatar: const Icon(Icons.quiz_outlined, size: 18),
            label: Text('Test myself on this topic'),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(packId: widget.packId, query: _cleanForQuiz(a.title), autoStart: true))),
          ),
          ActionChip(avatar: const Icon(Icons.style_outlined, size: 18), label: Text('Add to review cards'), onPressed: () => _addDefinitionCard(a)),
          ActionChip(
            avatar: const Icon(Icons.article_outlined, size: 18),
            label: Text('Read the full article'),
            onPressed: () {
              store.settings['libQuick'] = false;
              store.saveSettings();
              setState(() {});
            },
          ),
        ]),
      ],
      if (!_quick && kinds.isNotEmpty) ...[
        const SizedBox(height: 12),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final k in kinds)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ActionChip(
                    avatar: Icon(secIcon(k), size: 18),
                    label: Directionality(textDirection: TextDirection.ltr, child: Text(secLabel(k))),
                    onPressed: () => _jump(_secs.indexWhere((s) => s.kind == k)),
                  ),
                ),
            ],
          ),
        ),
      ],
      if (!_quick && rest.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: _Body(rest, scale: scale)),
      if (lead.heading.isNotEmpty && definition.isEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: _Body(lead.text, scale: scale)),
      ..._tablesOf(lead, scale),
      if (!_quick && _secs.isNotEmpty)
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: TextButton.icon(
            onPressed: () => setState(() {
              if (_open.length == _secs.length) {
                _open.clear();
              } else {
                _open.addAll([for (var i = 0; i < _secs.length; i++) i]);
              }
            }),
            icon: Icon(_open.length == _secs.length ? Icons.unfold_less : Icons.unfold_more),
            label: Text(_open.length == _secs.length ? 'Collapse all' : 'Expand all'),
          ),
        ),
      if (!_quick)
      for (var i = 0; i < _secs.length; i++)
        _SecCard(
          key: _keys.putIfAbsent(i, () => GlobalKey()),
          title: _secs[i].s.heading.isEmpty ? tr('More') : _secs[i].s.heading,
          icon: secIcon(_secs[i].kind),
          open: _open.contains(i),
          onToggle: () => setState(() => _open.contains(i) ? _open.remove(i) : _open.add(i)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            if (_imgList.any((im) => im.section.trim().toLowerCase() == _secs[i].s.heading.trim().toLowerCase() && im.section.isNotEmpty))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _ImgStrip(
                  images: [for (final im in _imgList) if (im.section.trim().toLowerCase() == _secs[i].s.heading.trim().toLowerCase()) im],
                  all: _imgList,
                  height: 150,
                ),
              ),
            _Body(_secs[i].s.text, scale: scale),
            ..._tablesOf(_secs[i].s, scale),
          ]),
        ),
      const SizedBox(height: 8),
      Fold(
        id: 'art_notes',
        title: tr('My notes on this article'),
        icon: Icons.edit_note,
        initiallyOpen: _note.text.isNotEmpty,
        children: [
          TextField(
            controller: _note,
            minLines: 3,
            maxLines: 8,
            onChanged: _onNote,
            decoration: InputDecoration(labelText: tr('Your notes (kept on this phone)')),
          ),
        ],
      ),
      if (cases.isNotEmpty)
        Fold(
          id: 'art_cases',
          title: tr('My cases about this'),
          subtitle: countLabel(cases.length, 'case'),
          icon: Icons.folder_copy_outlined,
          children: [
            for (final c in cases.take(8))
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.folder_outlined, size: 20),
                title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(c.s('code')),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: c))),
              ),
          ],
        ),
      if (_related.isNotEmpty)
        Fold(
          id: 'art_related',
          title: tr('Related articles'),
          icon: Icons.hub_outlined,
          initiallyOpen: true,
          children: [
            for (final r in _related)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.article_outlined, size: 20),
                title: Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ArticleScreen(packId: r.packId, index: r.index))),
              ),
          ],
        ),
      const SizedBox(height: 8),
      AppCard(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Source and license', style: theme.textTheme.labelLarge),
            const SizedBox(height: 4),
            Directionality(
              textDirection: TextDirection.ltr,
              child: SizedBox(width: double.infinity, child: m.Text(_sourceLine(a, p), textAlign: TextAlign.left, style: theme.textTheme.bodySmall)),
            ),
            const SizedBox(height: 6),
            Text(
                a.sections.any((s) => s.tables.isNotEmpty) && store.libShowTables
                    ? 'For learning. It may be out of date and it does not replace your hospital protocols. Images are not included and long tables are shortened.'
                    : 'For learning. It may be out of date and it does not replace your hospital protocols. Images and tables are not included.',
                style: theme.textTheme.bodySmall?.copyWith(color: cs.outline)),
          ]),
        ),
      ),
    ];
  }

  /// Per-article source and license when the article carries them, otherwise the pack's.
  String _sourceLine(LibArticle a, PackMeta? p) {
    final src = a.source.isNotEmpty ? a.source : (p?.source ?? '');
    final lic = a.license.isNotEmpty ? a.license : (p?.license ?? '');
    final lines = <String>[
      if (src.isNotEmpty) src,
      if (lic.isNotEmpty) lic,
      if (a.authors.isNotEmpty) '${tr('Authors')}: ${a.authors}',
      if (a.url.isNotEmpty) a.url,
      '${tr('Downloaded')}: ${a.date.isNotEmpty ? a.date : (p?.date ?? '')}',
    ];
    return lines.join('\n');
  }
}

/// A table from the article: caption, foldable, horizontally scrollable grid, full screen for wide ones.
class _TableCard extends StatefulWidget {
  final LibTable table;
  final double scale;
  const _TableCard({required this.table, required this.scale});
  @override
  State<_TableCard> createState() => _TableCardState();
}

class _TableCardState extends State<_TableCard> {
  bool _open = true;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final t = widget.table;
    final big = t.columns > 4;
    return Container(
      margin: const EdgeInsets.only(top: 6, bottom: 8),
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cs.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        InkWell(
          onTap: () => setState(() => _open = !_open),
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(12, 4, 4, 4),
            child: Row(children: [
              Icon(Icons.table_chart_outlined, size: 18, color: cs.primary),
              const SizedBox(width: 8),
              Expanded(
                child: t.caption.isEmpty
                    ? Text('Table', style: theme.textTheme.labelLarge)
                    : Directionality(
                        textDirection: TextDirection.ltr,
                        child: m.Text(t.caption, maxLines: _open ? 3 : 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelLarge),
                      ),
              ),
              if (big)
                IconButton(
                  tooltip: tr('Full screen'),
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.fullscreen),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TableViewerScreen(table: t))),
                ),
              AnimatedRotation(turns: _open ? 0.5 : 0, duration: const Duration(milliseconds: 200), child: const Padding(padding: EdgeInsets.all(8), child: Icon(Icons.expand_more))),
            ]),
          ),
        ),
        if (_open)
          Directionality(
            textDirection: TextDirection.ltr,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: TableGrid(table: t, scale: widget.scale),
            ),
          ),
      ]),
    );
  }
}

/// The grid itself: header row styled, striped rows, cells left-to-right unless they start with Arabic.
class TableGrid extends StatelessWidget {
  final LibTable table;
  final double scale;
  final double maxCell;
  const TableGrid({super.key, required this.table, this.scale = 1, this.maxCell = 220});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final base = theme.textTheme.bodySmall;
    final fs = (base?.fontSize ?? 12) * scale;
    final cols = table.columns;
    Widget cell(String txt, bool head) {
      final dir = textDirectionFor(txt) ?? TextDirection.ltr;
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: 56, maxWidth: maxCell),
          child: m.Text(
            txt,
            textDirection: dir,
            textAlign: dir == TextDirection.rtl ? TextAlign.right : TextAlign.left,
            style: base?.copyWith(fontSize: fs, height: 1.35, fontWeight: head ? FontWeight.w800 : null, color: head ? cs.onPrimaryContainer : null),
          ),
        ),
      );
    }

    return Table(
      defaultColumnWidth: const IntrinsicColumnWidth(),
      defaultVerticalAlignment: TableCellVerticalAlignment.top,
      border: TableBorder(horizontalInside: BorderSide(color: cs.outlineVariant.withAlpha(140)), verticalInside: BorderSide(color: cs.outlineVariant.withAlpha(90))),
      children: [
        for (var r = 0; r < table.rows.length; r++)
          TableRow(
            decoration: BoxDecoration(color: r == 0 ? cs.primaryContainer : (r.isEven ? cs.surfaceContainerLow : null)),
            children: [
              for (var c = 0; c < cols; c++) cell(c < table.rows[r].length ? table.rows[r][c] : '', r == 0),
            ],
          ),
      ],
    );
  }
}

/// Full-screen table: pinch to zoom, drag to move around.
class TableViewerScreen extends StatelessWidget {
  final LibTable table;
  const TableViewerScreen({super.key, required this.table});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: table.caption.isEmpty ? Text('Table') : m.Text(table.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: SafeArea(
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: InteractiveViewer(
            constrained: false,
            minScale: 0.4,
            maxScale: 4,
            boundaryMargin: const EdgeInsets.all(120),
            child: Padding(padding: const EdgeInsets.all(8), child: SelectionArea(child: TableGrid(table: table, maxCell: 320))),
          ),
        ),
      ),
    );
  }
}

class _SecCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool open;
  final VoidCallback onToggle;
  final Widget child;
  const _SecCard({super.key, required this.title, required this.icon, required this.open, required this.onToggle, required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 4),
      color: cs.surfaceContainerLow,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: open ? cs.primary.withAlpha(120) : cs.outlineVariant)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        InkWell(
          onTap: onToggle,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Icon(icon, size: 20, color: cs.primary),
              const SizedBox(width: 10),
              Expanded(child: Text(title, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
              AnimatedRotation(turns: open ? 0.5 : 0, duration: const Duration(milliseconds: 200), child: const Icon(Icons.expand_more)),
            ]),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
          alignment: Alignment.topCenter,
          child: open ? Padding(padding: const EdgeInsets.fromLTRB(14, 0, 14, 14), child: child) : const SizedBox(width: double.infinity),
        ),
      ]),
    );
  }
}

/// One paragraph of English article text (always left-to-right).
class _Para extends StatelessWidget {
  final String text;
  final double scale;
  final bool bold;
  const _Para(this.text, {required this.scale, this.bold = false});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final base = theme.textTheme.bodyMedium;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Align(
        alignment: AlignmentDirectional.centerStart,
        child: Text(
          text,
          textAlign: TextAlign.left,
          style: base?.copyWith(fontSize: (base.fontSize ?? 14) * scale, height: 1.6, fontWeight: bold ? FontWeight.w600 : null),
        ),
      ),
    );
  }
}

/// Article text: paragraphs with space between them, bullets with a hanging indent.
class _Body extends StatelessWidget {
  final String text;
  final double scale;
  const _Body(this.text, {required this.scale});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final base = theme.textTheme.bodyMedium;
    final fs = (base?.fontSize ?? 14) * scale;
    // long paragraphs are cut into shorter blocks (about three sentences each) so they are easier to read
    final paras = <String>[];
    for (final raw in text.split('\n').where((e) => e.trim().isNotEmpty)) {
      if (raw.startsWith('• ') || raw.length < 420) {
        paras.add(raw);
        continue;
      }
      var cur = '';
      for (final snt in sentences(raw)) {
        if (cur.isNotEmpty && cur.length + snt.length > 300) {
          paras.add(cur);
          cur = snt;
        } else {
          cur = cur.isEmpty ? snt : '$cur $snt';
        }
      }
      if (cur.isNotEmpty) paras.add(cur);
    }
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final t in paras)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: t.startsWith('• ')
                  ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Padding(
                        padding: EdgeInsets.only(top: fs * 0.55, right: 10, left: 4),
                        child: Container(width: 6, height: 6, decoration: BoxDecoration(color: theme.colorScheme.primary, shape: BoxShape.circle)),
                      ),
                      Expanded(child: Text(t.substring(2), textAlign: TextAlign.left, style: base?.copyWith(fontSize: fs, height: 1.55))),
                    ])
                  : Text(t, textAlign: TextAlign.left, style: base?.copyWith(fontSize: fs, height: 1.6)),
            ),
        ],
      ),
    );
  }
}


/// Horizontal strip of pictures (tap one to open it full screen).
class _ImgStrip extends StatelessWidget {
  final List<LibImage> images;
  final List<LibImage> all;
  final double height;
  const _ImgStrip({required this.images, required this.all, required this.height});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return SizedBox(
      height: height + 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: images.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final im = images[i];
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ImageViewerScreen(images: all, index: all.indexOf(im).clamp(0, all.length - 1)))),
            child: SizedBox(
              width: height * 1.25,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  height: height,
                  width: double.infinity,
                  decoration: BoxDecoration(color: cs.surfaceContainerHighest.withAlpha(100), borderRadius: BorderRadius.circular(14)),
                  clipBehavior: Clip.antiAlias,
                  child: Image.memory(im.bytes, fit: BoxFit.contain, gaplessPlayback: true),
                ),
                const SizedBox(height: 4),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(im.caption.isEmpty ? im.file : im.caption, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelSmall?.copyWith(color: cs.outline)),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }
}

/// Full-screen picture viewer: swipe between the article's pictures, pinch to zoom.
class ImageViewerScreen extends StatefulWidget {
  final List<LibImage> images;
  final int index;
  const ImageViewerScreen({super.key, required this.images, required this.index});
  @override
  State<ImageViewerScreen> createState() => _ImageViewerScreenState();
}

class _ImageViewerScreenState extends State<ImageViewerScreen> {
  late final PageController _pc = PageController(initialPage: widget.index);
  late int _i = widget.index;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final im = widget.images[_i];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('${_i + 1} / ${widget.images.length}'),
        actions: [
          IconButton(
            tooltip: tr('Image details'),
            icon: const Icon(Icons.open_in_new),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(title: im.file, url: im.filePage))),
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: PageView.builder(
            controller: _pc,
            itemCount: widget.images.length,
            onPageChanged: (v) => setState(() => _i = v),
            itemBuilder: (context, k) => InteractiveViewer(minScale: 1, maxScale: 6, child: Center(child: Image.memory(widget.images[k].bytes, fit: BoxFit.contain))),
          ),
        ),
        Container(
          width: double.infinity,
          color: Colors.black,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              if (im.caption.isNotEmpty) Text(im.caption, style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white)),
              const SizedBox(height: 4),
              Text('${im.file} — ${im.credit}', style: theme.textTheme.labelSmall?.copyWith(color: Colors.white70)),
            ]),
          ),
        ),
      ]),
    );
  }
}
