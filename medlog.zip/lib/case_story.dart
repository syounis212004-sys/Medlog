import 'case_extras.dart';
import 'case_narrative.dart';
import 'case_scores.dart';
import 'data.dart';

/// The clinical text of a case report, written as sentences from what the user recorded. Nothing is inferred: an empty
/// field says nothing, a denial is written only when it was recorded, and "requested", "resulted", "suggested",
/// "ordered" and "given" keep their own meaning.

String _s(Object? v) => '${v ?? ''}'.trim();

const Map<String, String> kPlaceOfSetting = {
  'ER': 'the emergency department',
  'Clinic': 'the clinic',
  'Ward': 'the ward',
  'ICU': 'the intensive care unit',
  'OR': 'the operating room',
};

/// "Foot swelling for 1day" -> ("foot swelling", "1-day"). The duration is only taken out of text that says it in the
/// "for N unit" form; anything else stays in the complaint as written.
({String complaint, String duration}) splitComplaint(String cc) {
  final t = cc.trim().replaceAll(RegExp(r'\s+'), ' ');
  final m = RegExp(r'^(.*?)[\s,;]+(?:for|x|since|over the (?:last|past))\s+(\d+(?:\.\d+)?)\s*[- ]?(hours?|hrs?|h|days?|d|weeks?|wks?|months?|mos?|years?|yrs?|y)\.?$', caseSensitive: false).firstMatch(t);
  if (m == null || m.group(1)!.trim().isEmpty) return (complaint: t, duration: '');
  final unit = switch (m.group(3)!.toLowerCase()) {
    'h' || 'hr' || 'hrs' || 'hour' || 'hours' => 'hour',
    'd' || 'day' || 'days' => 'day',
    'wk' || 'wks' || 'week' || 'weeks' => 'week',
    'mo' || 'mos' || 'month' || 'months' => 'month',
    _ => 'year',
  };
  return (complaint: m.group(1)!.trim(), duration: '${m.group(2)}-$unit');
}

/// The opening sentence of the history: "The patient presented to the emergency department with a 12-hour history of
/// abdominal pain." Where the visit took place is only mentioned when it was recorded.
String hpiOpening(CaseRec c) {
  final cc = _s(c.s('cc'));
  if (cc.isEmpty) return '';
  final lines = cc.split(RegExp(r'[\n;]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  final place = kPlaceOfSetting[c.s('setting')] ?? '';
  final to = place.isEmpty ? '' : ' to $place';
  if (lines.length > 1) return 'The patient presented$to with ${joinList([for (final l in lines) lcFirst(l)])}.';
  final p = splitComplaint(cc);
  final what = lcFirst(p.complaint);
  if (p.duration.isEmpty) return 'The patient presented$to with $what.';
  final art = article(p.duration);
  return 'The patient presented$to with $art ${p.duration} history of $what.';
}

// ------------------------------------------------------------------------------------------------------ history

String pastHistory(CaseRec c, String key) {
  final t = c.s(key).trim();
  if (t.isEmpty) return '';
  // the heading already names the section: short items are joined, text written as sentences stays as written
  return switch (key) {
    'pmh' || 'psh' => listSentence('', t).trim(),
    'drugs' => listSentence('', t, sep: '; ').trim(),
    _ => t,
  };
}

// ------------------------------------------------------------------------------------------------------ examination

const Map<String, String> _vitalPhrase = {
  'v_bp': 'BP {v} mmHg',
  'v_hr': 'HR {v} bpm',
  'v_temp': 'temperature {v} °C',
  'v_rr': 'RR {v}/min',
  'v_spo2': 'SpO2 {v}%',
  'v_rbs': 'RBS {v} mg/dL',
  'v_wt': 'weight {v} kg',
};

const Map<String, String> _vitalShort = {'v_bp': 'BP', 'v_hr': 'HR', 'v_temp': 'temperature', 'v_rr': 'RR', 'v_spo2': 'SpO2', 'v_rbs': 'RBS', 'v_wt': 'weight'};

String vitalsSentence(CaseRec c) {
  final keys = [for (final k in _vitalPhrase.keys) if (c.s(k).trim().isNotEmpty) k];
  if (keys.isEmpty) return '';
  final adult = c.s('ageGroup') == 'Adult';
  final parts = [for (final k in keys) _vitalPhrase[k]!.replaceAll('{v}', c.s(k).trim())];
  final bad = [for (final k in keys) if (vitalAbnormal(k, c.s(k), adult)) _vitalShort[k]!];
  final first = 'Vital signs were ${joinList(parts)}.';
  if (bad.isEmpty) return first;
  return '$first ${ucFirst(joinList(bad))} ${bad.length == 1 ? 'was' : 'were'} outside the expected range.';
}

/// Systems by state: the normal ones in one sentence, then each abnormal one with what was noted, then the ones not
/// examined or unknown. A system with no state at all is left out.
String systemsSentences(CaseRec c) {
  final sys = c.d['sys'];
  if (sys is! Map) return '';
  final normal = <String>[], normalNoted = <String>[], abnormal = <String>[], notDone = <String>[], unknown = <String>[], full = <String>[];
  for (final e in sys.entries) {
    final v = e.value;
    if (v is! Map) continue;
    final st = _s(v['s']), note = _s(v['n']);
    final name = '${e.key}';
    if (_s(v['full']).isNotEmpty) {
      full.add(_s(v['full']));
      continue;
    }
    switch (st) {
      case 'Normal':
        if (note.isEmpty) {
          normal.add(name);
        } else {
          normalNoted.add('$name examination was normal ($note).');
        }
      case 'Abnormal':
        abnormal.add(note.isEmpty ? '$name examination was abnormal; no description was recorded.' : '$name examination was abnormal: ${note.replaceFirst(RegExp(r'[.!?]$'), '')}.');
      case 'Not examined':
        notDone.add(name);
      case 'Unknown':
        unknown.add(name);
      default:
        if (note.isNotEmpty) abnormal.add('$name: ${note.replaceFirst(RegExp(r'[.!?]$'), '')}.');
    }
  }
  return [
    ...full,
    if (normal.isNotEmpty) '${joinList(normal)} ${normal.length == 1 ? 'examination was' : 'examinations were'} normal.',
    ...normalNoted,
    ...abnormal,
    if (notDone.isNotEmpty) '${joinList(notDone)} ${notDone.length == 1 ? 'was' : 'were'} not examined.',
    if (unknown.isNotEmpty) 'The findings for ${joinList(unknown)} were recorded as unknown.',
  ].join(' ');
}

// ------------------------------------------------------------------------------------------------------ investigations

/// Tests by status: what was requested (with a note that no result was available when that status was recorded), what
/// is pending, what resulted with its result, what was only considered.
String investigationSentences(CaseRec c, {required bool Function(J inv) hasPhoto}) {
  final inv = c.lst('inv');
  if (inv.isEmpty) return '';
  final out = <String>[];
  String named(J i) => _s(i['name']);
  final requested = [for (final i in inv) if (const {'Requested', 'Ordered'}.contains(_s(i['status'])) && named(i).isNotEmpty) i];
  final pending = [for (final i in inv) if (_s(i['status']) == 'Pending' && named(i).isNotEmpty) i];
  final considered = [for (final i in inv) if (_s(i['status']) == 'Considered' && named(i).isNotEmpty) i];
  final done = [for (final i in inv) if (const {'Resulted', 'Reviewed'}.contains(_s(i['status'])) && named(i).isNotEmpty) i];
  final other = [for (final i in inv) if (_s(i['status']).isEmpty && named(i).isNotEmpty) i];
  String list(List<J> l, {bool articles = true}) => joinList([for (final i in l) articles ? '${article(named(i))} ${lcAcr(named(i))}' : lcAcr(named(i))]);

  if (requested.isNotEmpty) {
    out.add('${ucFirst(list(requested))} ${requested.length == 1 ? 'was' : 'were'} requested.');
  }
  if (pending.isNotEmpty) out.add('${ucFirst(list(pending))} ${pending.length == 1 ? 'was' : 'were'} requested and ${pending.length == 1 ? 'is' : 'are'} pending.');
  if (requested.isNotEmpty || pending.isNotEmpty) {
    final n = requested.length + pending.length;
    out.add(n == 1 ? 'No result was available at the time of documentation.' : 'No results were available at the time of documentation.');
  }
  if (considered.isNotEmpty) out.add('${ucFirst(list(considered, articles: false))} ${considered.length == 1 ? 'was' : 'were'} considered.');
  for (final i in done) {
    final r = _s(i['result']), it = _s(i['interpretation']);
    final n = named(i);
    final reviewed = _s(i['status']) == 'Reviewed' ? ' and was reviewed' : '';
    if (r.isEmpty && it.isEmpty) {
      out.add(hasPhoto(i) ? '$n resulted$reviewed (see photo below).' : '$n resulted$reviewed; no result was entered.');
    } else {
      out.add('$n resulted$reviewed${r.isEmpty ? '' : ': ${r.replaceFirst(RegExp(r'[.!?]$'), '')}'}${it.isEmpty ? '' : '${r.isEmpty ? ':' : '.'} Interpretation: ${it.replaceFirst(RegExp(r'[.!?]$'), '')}'}.');
    }
  }
  for (final i in other) {
    final r = _s(i['result']);
    out.add('${named(i)}${r.isEmpty ? ' was recorded.' : ': ${r.replaceFirst(RegExp(r'[.!?]$'), '')}.'}');
  }
  return out.join(' ');
}

/// A test name inside a sentence: acronyms keep their capitals, other names start small.
String lcAcr(String n) => lcFirst(n);

// ------------------------------------------------------------------------------------------------------ assessment

String differentialSentence(CaseRec c) => c.s('ddx').trim().isEmpty ? '' : listSentence('The differential diagnosis included', c.s('ddx'));

String diagnosisSentences(CaseRec c) {
  final w = c.s('workingDx').trim(), f = c.s('finalDx').trim();
  return [
    if (w.isNotEmpty) 'The working diagnosis was ${w.replaceFirst(RegExp(r'[.!?]$'), '')}.',
    if (f.isNotEmpty) 'The final diagnosis was ${f.replaceFirst(RegExp(r'[.!?]$'), '')}.',
  ].join(' ');
}

String problemSentence(CaseRec c) {
  final pl = problemsSorted(c);
  if (pl.isEmpty) return c.s('problems').trim().isEmpty ? '' : listSentence('Problems identified:', c.s('problems'), sep: '; ');
  final act = [for (final p in pl) if (_s(p['status']) != 'resolved' && _s(p['text']).isNotEmpty) _s(p['text'])];
  final res = [for (final p in pl) if (_s(p['status']) == 'resolved' && _s(p['text']).isNotEmpty) _s(p['text'])];
  return [
    if (act.isNotEmpty) 'Active problems: ${act.join('; ')}.',
    if (res.isNotEmpty) 'Resolved problems: ${res.join('; ')}.',
  ].join(' ');
}

String scoreSentences(CaseRec c) {
  final sc = scoresOf(c);
  if (sc.isEmpty) return '';
  return [
    for (final x in sc) '${x.name}: ${x.value}${x.meaning.trim().isEmpty ? '' : ' (${x.meaning.trim()})'}${x.items.isEmpty ? '' : '; chosen: ${x.items.join(', ')}'}.'
  ].join(' ');
}

// ------------------------------------------------------------------------------------------------------ management

const Map<String, String> _planVerb = {
  'Suggested': 'was suggested',
  'Ordered': 'was ordered',
  'Given': 'was given',
  'Stopped': 'was stopped',
  'Prescribed': 'was prescribed',
};

String planSentence(J m) {
  var text = _s(m['text']);
  if (text.isEmpty) return '';
  final cat = _s(m['category']);
  final dose = _s(m['dose']);
  final state = _s(m['state']);
  final by = _s(m['by']);
  if (cat == 'Consult / referral' && !RegExp(r'consult|referr', caseSensitive: false).hasMatch(text)) text = 'Consultation with $text';
  final verb = _planVerb[state] ?? '';
  final detail = dose.isEmpty ? '' : ' ($dose)';
  final who = by.isEmpty ? '' : ' by ${lcFirst(by)}';
  return verb.isEmpty ? '${ucFirst(text)}$detail${by.isEmpty ? '' : ', ${lcFirst(by)}'}.' : '${ucFirst(text)}$detail $verb$who.';
}

String planSentences(List<J> items) => [for (final m in items) planSentence(m)].where((s) => s.isNotEmpty).join(' ');

// ------------------------------------------------------------------------------------------------------ outcome

String dispositionSentence(CaseRec c) {
  final d = c.s('disposition').trim();
  if (d.isEmpty) return '';
  return switch (d) {
    'Admitted' => 'The patient was admitted.',
    'Discharged' => 'The patient was discharged.',
    'Transferred' => 'The patient was transferred.',
    'Referred' => 'The patient was referred.',
    'Deceased' => 'The patient died.',
    _ => 'Disposition: ${lcFirst(d)}.',
  };
}
