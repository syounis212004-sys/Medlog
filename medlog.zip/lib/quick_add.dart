import 'package:flutter/material.dart' hide Text;

import 'data.dart';
import 'i18n.dart';
import 'screens_cases.dart';
import 'ui.dart';

/// The "+" button: a 30-second way to log a case now and finish it later.
Future<void> showQuickAdd(BuildContext context, {String? date}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => _QuickAddSheet(date: date),
  );
}

class _QuickAddSheet extends StatefulWidget {
  final String? date;
  const _QuickAddSheet({this.date});

  @override
  State<_QuickAddSheet> createState() => _QuickAddSheetState();
}

class _QuickAddSheetState extends State<_QuickAddSheet> {
  late String _spec;
  String _age = '';
  String _setting = '';
  final TextEditingController _cc = TextEditingController();

  @override
  void initState() {
    super.initState();
    final rot = store.currentRotation();
    final name = rot == null ? '' : (rot['name'] ?? '').toString();
    _spec = kSpecialtyNames.contains(name) ? name : 'Internal Medicine';
  }

  @override
  void dispose() {
    _cc.dispose();
    super.dispose();
  }

  CaseRec _build() {
    final c = store.newCase();
    c.set('specialty', _spec);
    c.set('code', store.nextCode(prefixFor(_spec)));
    if (_age.isNotEmpty) c.set('ageGroup', _age);
    if (_setting.isNotEmpty) c.set('setting', _setting);
    if (_cc.text.trim().isNotEmpty) c.set('cc', _cc.text.trim());
    if (widget.date != null) c.set('date', widget.date);
    return c;
  }

  Future<void> _save() async {
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final c = _build();
    await store.saveCase(c);
    nav.pop();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(trp('Saved as draft • {code}', {'code': c.s('code')})),
          action: SnackBarAction(
            label: tr('Open case'),
            onPressed: () => nav.push(MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: c))),
          ),
        ),
      );
  }

  void _full() {
    final nav = Navigator.of(context);
    final c = _build();
    nav.pop();
    nav.push(MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: c)));
  }

  Widget _label(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s, style: Theme.of(context).textTheme.labelLarge),
      );

  Widget _chips(List<String> options, String value, ValueChanged<String> onPick) {
    return Wrap(
      spacing: 8,
      runSpacing: 6,
      children: [
        for (final o in options)
          ChoiceChip(
            label: Text(o),
            selected: value == o,
            onSelected: (_) => onPick(value == o ? '' : o),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Quick log', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text('Write the minimum now. Finish the rest after the shift.',
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            _label('Specialty'),
            SizedBox(
              height: 92,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final s in kSpecialtyNames)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() => _spec = s),
                        child: Container(
                          width: 84,
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _spec == s ? theme.colorScheme.primaryContainer : null,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: _spec == s ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
                              width: _spec == s ? 1.6 : 1,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SpecialtyAvatar(s, size: 34),
                              const SizedBox(height: 4),
                              Text(s,
                                  maxLines: 2,
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.labelSmall),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            _label('Age group'),
            _chips(const ['Child', 'Adult'], _age, (v) => setState(() => _age = v)),
            _label('Setting'),
            _chips(const ['ER', 'Clinic', 'Ward', 'ICU', 'OR'], _setting, (v) => setState(() => _setting = v)),
            const SizedBox(height: 14),
            TextField(
              controller: _cc,
              autofocus: false,
              minLines: 2,
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: tr('Chief complaint or diagnosis'),
                hintText: tr('e.g. Chest pain 2 days'),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: OutlinedButton.icon(
                    onPressed: _full,
                    icon: const Icon(Icons.edit_note),
                    label: Text('Full form'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 4,
                  child: FilledButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.bolt),
                    label: Text('Save quick log'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
