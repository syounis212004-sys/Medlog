import 'dart:math';

import 'data.dart';
import 'lib_plan.dart';
import 'quiz_gate.dart' show QuizQ, QKind, QuizLevel;

/// The data behind the study tools: focus sessions, knowledge gaps, the mistake notebook, the comparison of what the
/// reader remembers with an article, and a plain reading of the exam plan. Everything stays on the phone and goes into
/// the encrypted backup with the rest of the logbook. Nothing here asks the AI for anything.

// ============================================================ focus sessions

class StudyLog {
  StudyLog._();
  static const String list = 'studysessions';

  static List<J> all() => store.listOf(list);

  /// Keeps one finished focus session: [minutes] of real work on [title] (a topic, chapter or "Free study").
  static Future<void> add({required int minutes, String title = '', String ref = '', int interruptions = 0, DateTime? at}) async {
    if (minutes <= 0) return;
    final t = at ?? DateTime.now();
    await store.upsertExtra(list, {
      'id': newId('fs'),
      'date': fmtDate(t),
      'at': t.toUtc().toIso8601String(),
      'mins': minutes,
      'title': title.trim(),
      'ref': ref,
      'int': interruptions,
    });
    final l = store.listOf(list);
    if (l.length > 600) {
      l.removeRange(0, l.length - 600);
      await store.saveExtra(list);
    }
  }

  /// Minutes of focus on each of the last [days] days, oldest first (the last entry is [now]'s day).
  static List<(String, int)> minutesByDay(DateTime now, {int days = 7}) {
    final byDate = <String, int>{};
    for (final s in all()) {
      byDate['${s['date']}'] = (byDate['${s['date']}'] ?? 0) + ((s['mins'] as num?)?.toInt() ?? 0);
    }
    return [
      for (var k = days - 1; k >= 0; k--)
        (() {
          final d = fmtDate(DateTime(now.year, now.month, now.day).subtract(Duration(days: k)));
          return (d, byDate[d] ?? 0);
        })()
    ];
  }

  /// Total minutes and the topics that took most of them, over the last [days] days.
  static (int, List<(String, int)>) summary(DateTime now, {int days = 7}) {
    final from = fmtDate(DateTime(now.year, now.month, now.day).subtract(Duration(days: days - 1)));
    var total = 0;
    final by = <String, int>{};
    for (final s in all()) {
      if ('${s['date']}'.compareTo(from) < 0) continue;
      final m = (s['mins'] as num?)?.toInt() ?? 0;
      total += m;
      final t = '${s['title']}'.isEmpty ? '' : '${s['title']}';
      if (t.isNotEmpty) by[t] = (by[t] ?? 0) + m;
    }
    final top = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return (total, [for (final e in top.take(5)) (e.key, e.value)]);
  }

  static int sessionsIn(DateTime now, {int days = 7}) {
    final from = fmtDate(DateTime(now.year, now.month, now.day).subtract(Duration(days: days - 1)));
    return all().where((s) => '${s['date']}'.compareTo(from) >= 0).length;
  }

  static int interruptionsIn(DateTime now, {int days = 7}) {
    final from = fmtDate(DateTime(now.year, now.month, now.day).subtract(Duration(days: days - 1)));
    return all().where((s) => '${s['date']}'.compareTo(from) >= 0).fold<int>(0, (a, s) => a + ((s['int'] as num?)?.toInt() ?? 0));
  }

  static int get workMinutes => _pref('focusWork', 25, 5, 120);
  static int get breakMinutes => _pref('focusBreak', 5, 1, 30);
  static Future<void> setWork(int m) async {
    store.settings['focusWork'] = m;
    await store.saveSettings();
  }

  static Future<void> setBreak(int m) async {
    store.settings['focusBreak'] = m;
    await store.saveSettings();
  }

  static int _pref(String k, int d, int lo, int hi) {
    final v = store.settings[k];
    return v is num ? v.toInt().clamp(lo, hi) : d;
  }
}

// ============================================================ knowledge gaps

/// "What I did not know": one line after a case or a shift, kept until the person has studied it.
class KnowledgeGaps {
  KnowledgeGaps._();
  static const String list = 'studygaps';

  static List<J> all({bool? done}) {
    final l = [...store.listOf(list)];
    l.sort((a, b) => '${b['date']}${b['id']}'.compareTo('${a['date']}${a['id']}'));
    return done == null ? l : [for (final g in l) if ((g['done'] == true) == done) g];
  }

  static int get openCount => all(done: false).length;

  static Future<void> add(String text, {String caseCode = '', String source = ''}) async {
    final t = text.trim();
    if (t.isEmpty) return;
    if (store.listOf(list).any((g) => '${g['text']}'.toLowerCase() == t.toLowerCase() && g['done'] != true)) return;
    await store.upsertExtra(list, {'id': newId('kg'), 'date': todayStr(), 'text': t, 'case': caseCode, 'src': source, 'done': false});
  }

  static Future<void> setDone(String id, bool done) async {
    final l = store.listOf(list);
    final i = l.indexWhere((g) => g['id'] == id);
    if (i < 0) return;
    l[i]['done'] = done;
    if (done) {
      l[i]['doneOn'] = todayStr();
    } else {
      l[i].remove('doneOn');
    }
    await store.saveExtra(list);
  }

  static Future<void> remove(String id) => store.removeExtra(list, id);
}

// ============================================================ the mistake notebook

enum MistakeReason { knowledge, rushed, misread, guess }

String mistakeReasonLabel(MistakeReason r) => switch (r) {
      MistakeReason.knowledge => 'I did not know it',
      MistakeReason.rushed => 'I rushed',
      MistakeReason.misread => 'I misread the question',
      MistakeReason.guess => 'It was a guess',
    };

class MistakeBook {
  MistakeBook._();
  static const String list = 'quizmistakes';

  static List<J> all() {
    final l = [...store.listOf(list)];
    l.sort((a, b) => '${b['date']}${b['id']}'.compareTo('${a['date']}${a['id']}'));
    return l;
  }

  static String? idOf(QuizQ q) {
    for (final m in store.listOf(list)) {
      if (m['h'] == q.hash) return '${m['id']}';
    }
    return null;
  }

  /// A missed question goes in once (the same question again only refreshes its date). Returns its id.
  static Future<String> add(QuizQ q, {MistakeReason? reason}) async {
    final old = idOf(q);
    final id = old ?? newId('mk');
    final prev = old == null ? null : store.listOf(list).firstWhere((m) => m['id'] == old);
    await store.upsertExtra(list, {
      'id': id,
      'h': q.hash,
      'date': todayStr(),
      'p': q.packId,
      'i': q.index,
      't': q.shownTitle,
      'g': q.group,
      'stem': q.stem,
      'correct': q.correct,
      'expl': q.explanation,
      'reason': reason?.name ?? (prev == null ? '' : '${prev['reason'] ?? ''}'),
      'n': ((prev?['n'] as num?)?.toInt() ?? 0) + 1,
    });
    final l = store.listOf(list);
    if (l.length > 400) {
      l.removeRange(0, l.length - 400);
      await store.saveExtra(list);
    }
    return id;
  }

  static Future<void> setReason(String id, MistakeReason? r) async {
    final l = store.listOf(list);
    final i = l.indexWhere((m) => m['id'] == id);
    if (i < 0) return;
    l[i]['reason'] = r?.name ?? '';
    await store.saveExtra(list);
  }

  static Future<void> remove(String id) => store.removeExtra(list, id);

  /// How many mistakes have each reason ('' = not tagged yet).
  static Map<String, int> byReason() {
    final out = <String, int>{};
    for (final m in store.listOf(list)) {
      final r = '${m['reason'] ?? ''}';
      out[r] = (out[r] ?? 0) + 1;
    }
    return out;
  }
}

// ============================================================ what I remember vs the article

class RecallPoint {
  final String text;
  final bool covered;
  const RecallPoint(this.text, this.covered);
}

class RecallResult {
  final List<RecallPoint> points;
  const RecallResult(this.points);
  int get covered => points.where((p) => p.covered).length;
  double get ratio => points.isEmpty ? 0 : covered / points.length;
  List<RecallPoint> get missed => [for (final p in points) if (!p.covered) p];
}

const Set<String> _stop = {
  'that', 'this', 'with', 'from', 'have', 'been', 'were', 'which', 'their', 'there', 'than', 'then', 'they', 'them', 'also', 'such', 'into',
  'over', 'only', 'more', 'most', 'some', 'when', 'where', 'while', 'these', 'those', 'will', 'should', 'would', 'could', 'about', 'after',
  'before', 'because', 'between', 'during', 'often', 'usually', 'common', 'commonly', 'patients', 'patient', 'include', 'includes', 'including',
};

/// The content words of a sentence: 4 letters or more without the filler words, and every number.
Set<String> recallTerms(String s) {
  final out = <String>{};
  for (final m in RegExp(r'[A-Za-z؀-ۿ]{4,}|\d+(?:[.,]\d+)?').allMatches(s.toLowerCase())) {
    final w = m.group(0)!;
    if (_stop.contains(w)) continue;
    out.add(w);
  }
  return out;
}

bool _termSeen(String t, Set<String> have) {
  if (have.contains(t)) return true;
  if (t.length >= 6) {
    final stem = t.substring(0, t.length - 2);
    return have.any((h) => h.startsWith(stem) || (h.length >= 5 && t.startsWith(h.substring(0, h.length - 1))));
  }
  return false;
}

/// The points of an article worth remembering: bullets and sentences with numbers or many content words, at most [max],
/// in the order of the article.
List<String> articlePoints(String text, {int max = 20}) {
  final raw = <(String, bool)>[];
  for (final line in text.replaceAll('\r', '').split('\n')) {
    final t = line.trim();
    if (t.isEmpty) continue;
    final bullet = RegExp(r'^[•\-\*]\s+').hasMatch(t) || RegExp(r'^\d{1,2}[.)]\s').hasMatch(t);
    final body = t.replaceFirst(RegExp(r'^(?:[•\-\*]|\d{1,2}[.)])\s+'), '');
    for (final s in body.split(RegExp(r'(?<=[.!?])\s+'))) {
      final x = s.trim();
      if (x.length < 25 || x.length > 240) continue;
      if (RegExp(r'https?://|retrieved|copyright', caseSensitive: false).hasMatch(x)) continue;
      raw.add((x, bullet));
    }
  }
  final scored = <(int, int, String)>[];
  for (var i = 0; i < raw.length; i++) {
    final (x, bullet) = raw[i];
    final terms = recallTerms(x);
    if (terms.length < 3) continue;
    final sc = (RegExp(r'\d').hasMatch(x) ? 2 : 0) + (terms.length >= 6 ? 1 : 0) + (bullet ? 1 : 0);
    scored.add((sc, i, x));
  }
  scored.sort((a, b) {
    final c = b.$1.compareTo(a.$1);
    return c != 0 ? c : a.$2.compareTo(b.$2);
  });
  final top = scored.take(max).toList()..sort((a, b) => a.$2.compareTo(b.$2));
  return [for (final t in top) t.$3];
}

/// A point counts as remembered when at least 60% of its content words are in what the reader wrote.
RecallResult compareRecall(String articleText, String recall, {int max = 20}) {
  final have = recallTerms(recall);
  final out = <RecallPoint>[];
  for (final p in articlePoints(articleText, max: max)) {
    final terms = recallTerms(p);
    if (terms.isEmpty) continue;
    final seen = terms.where((t) => _termSeen(t, have)).length;
    out.add(RecallPoint(p, seen / terms.length >= 0.6));
  }
  return RecallResult(out);
}

// ============================================================ exam readiness

enum ReadinessState { none, ahead, onTrack, behind }

class Readiness {
  final ReadinessState state;
  final int done, total, daysLeft, perDayNeeded;
  final double perDayRecent;
  const Readiness(this.state, this.done, this.total, this.daysLeft, this.perDayNeeded, this.perDayRecent);
  double get coverage => total == 0 ? 0 : done / total;
}

/// What the exam plan says about the time left: items done, the pace needed from today and the pace of the last 7 days.
/// It is a reading of the plan, not a prediction of the result.
Readiness examReadiness({DateTime? now}) {
  final n = now ?? DateTime.now();
  final p = examPlan();
  if (p == null || p.items.isEmpty) return const Readiness(ReadinessState.none, 0, 0, 0, 0, 0);
  final total = p.items.length;
  final done = p.items.where((i) => p.done.contains(i.key)).length;
  final left = max(1, examDaysLeft(p.date, now: n));
  final remaining = total - done;
  final need = (remaining / left).ceil();
  final from = fmtDate(DateTime(n.year, n.month, n.day).subtract(const Duration(days: 6)));
  final recent = p.doneOn.values.where((d) => d.compareTo(from) >= 0).length / 7;
  final st = remaining == 0
      ? ReadinessState.ahead
      : (recent >= need * 1.1 ? ReadinessState.ahead : (recent >= need * 0.8 ? ReadinessState.onTrack : ReadinessState.behind));
  return Readiness(st, done, total, left, need, recent);
}


// ============================================================ resume what was left half way

/// A question as stored: enough to bring a test or an exam back exactly as it was.
Map<String, dynamic> quizQToJson(QuizQ q) => {
      'k': q.kind.name,
      's': q.stem,
      'o': q.options,
      'a': q.answer,
      'e': q.explanation,
      'p': q.packId,
      't': q.title,
      'i': q.index,
      'pr': q.prompt,
      'lv': q.level.name,
      'sec': q.section,
      'g': q.group,
    };

QuizQ quizQFromJson(Map j) => QuizQ(
      kind: QKind.values.firstWhere((e) => e.name == '${j['k']}', orElse: () => QKind.definition),
      stem: '${j['s']}',
      options: [for (final o in (j['o'] as List? ?? const [])) '$o'],
      answer: (j['a'] as num?)?.toInt() ?? 0,
      explanation: '${j['e'] ?? ''}',
      packId: '${j['p'] ?? ''}',
      title: '${j['t'] ?? ''}',
      index: (j['i'] as num?)?.toInt() ?? 0,
      prompt: '${j['pr'] ?? ''}',
      level: QuizLevel.values.firstWhere((e) => e.name == '${j['lv']}', orElse: () => QuizLevel.medium),
      section: '${j['sec'] ?? ''}',
      group: '${j['g'] ?? ''}',
    );

/// One slot per kind of work (a test, an exam, a draft) in the settings: written after every step, removed when the
/// work is finished or thrown away.
class Resume {
  Resume._();

  static Map<String, dynamic>? read(String key) {
    final v = store.settings['resume_$key'];
    return v is Map ? Map<String, dynamic>.from(v) : null;
  }

  static Future<void> write(String key, Map<String, dynamic> data) async {
    store.settings['resume_$key'] = data;
    await store.saveSettings();
  }

  static Future<void> clear(String key) async {
    if (store.settings.remove('resume_$key') != null) await store.saveSettings();
  }
}
