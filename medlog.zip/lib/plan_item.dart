import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'dosing.dart';
import 'i18n.dart';
import 'ph.dart';

/// One plan item of a case, written the way it is charted: for a drug the name, route, amount, frequency and duration;
/// for a procedure, a consult, monitoring or safety-netting the fields that kind needs. Every item says where it
/// happens: given in hospital, or taken home. The structured parts are kept under 'x'; `text` (the headline) and
/// `dose` (the detail line) are composed from them, so everything that already reads plan items keeps working.

const List<String> kPlanCategories = [
  'Initial / ER',
  'Medications & fluids',
  'Procedure / surgery',
  'Consult / referral',
  'Monitoring',
  'Safety-netting',
];

const String kInHospital = 'Hospital';
const String kTakeHome = 'Take-home';

const List<String> kRoutes = ['PO', 'IV', 'IM', 'SC', 'SL', 'PR', 'Inhaled', 'Nebulised', 'Topical', 'Eye', 'Ear', 'Nasal'];
const List<String> kFreqs = ['STAT', 'Once', 'OD', 'BD', 'TDS', 'QID', 'q4h', 'q6h', 'q8h', 'q12h', 'PRN', 'Nocte', 'Continuous'];
const List<String> kUnits = ['mg', 'g', 'mcg', 'mL', 'units', 'L', 'tab', 'puff'];

/// Which fields a category shows.
enum PlanKind { drug, procedure, consult, monitoring, safety }

PlanKind planKindOf(String category, String setting) {
  if (setting == kTakeHome) return PlanKind.drug;
  switch (category) {
    case 'Procedure / surgery':
      return PlanKind.procedure;
    case 'Consult / referral':
      return PlanKind.consult;
    case 'Monitoring':
      return PlanKind.monitoring;
    case 'Safety-netting':
      return PlanKind.safety;
    default:
      return PlanKind.drug;
  }
}

String _s(Object? v) => '${v ?? ''}'.trim();

/// The detail line of a drug: "1 g IV STAT", "500 mg PO TDS x 5 days".
String composeDrugLine(Map x) {
  final amount = _s(x['amount']);
  final unit = _s(x['unit']);
  final parts = [
    [amount, if (amount.isNotEmpty) unit].where((e) => e.isNotEmpty).join(' '),
    _s(x['route']),
    _s(x['freq']),
  ].where((e) => e.isNotEmpty).join(' ');
  final days = _s(x['days']);
  final dur = days.isEmpty ? '' : ' x $days ${days == '1' ? 'day' : 'days'}';
  return '$parts$dur'.trim();
}

/// Headline and detail line of an item from its structured parts (what the lists, PDF and exports show).
({String text, String dose}) composePlan(PlanKind kind, Map x, {String fallbackText = ''}) {
  switch (kind) {
    case PlanKind.drug:
      var line = composeDrugLine(x);
      final note = _s(x['note']);
      if (note.isNotEmpty) line = line.isEmpty ? note : '$line; $note';
      return (text: _s(x['drug']).isEmpty ? fallbackText : _s(x['drug']), dose: line);
    case PlanKind.procedure:
      final bits = [_s(x['site']), if (_s(x['consent']).isNotEmpty) '${_s(x['consent'])} consent', _s(x['outcome'])].where((e) => e.isNotEmpty).join('; ');
      return (text: _s(x['procedure']).isEmpty ? fallbackText : _s(x['procedure']), dose: bits);
    case PlanKind.consult:
      final bits = [_s(x['urgency']), _s(x['question'])].where((e) => e.isNotEmpty).join('; ');
      return (text: _s(x['specialty']).isEmpty ? fallbackText : _s(x['specialty']), dose: bits);
    case PlanKind.monitoring:
      final bits = [_s(x['freq']), _s(x['note'])].where((e) => e.isNotEmpty).join('; ');
      return (text: _s(x['parameter']).isEmpty ? fallbackText : _s(x['parameter']), dose: bits);
    case PlanKind.safety:
      final told = (x['told'] is List) ? [for (final e in x['told'] as List) '$e'] : const <String>[];
      final bits = [if (told.isNotEmpty) told.join(', '), if (_s(x['return']).isNotEmpty) 'return ${_s(x['return'])}'].join('; ');
      return (text: told.isEmpty ? (fallbackText.isEmpty ? 'Safety-netting' : fallbackText) : 'Safety-netting', dose: bits);
  }
}

const List<String> kSafetyTold = [
  'Return if worse',
  'Fever',
  'Persistent vomiting',
  'Chest pain',
  'Breathlessness',
  'Bleeding',
  'Severe pain',
  'Confusion or drowsiness',
  'Cannot pass urine',
  'Wound redness or discharge',
  'Reduced fluids or urine',
  'Medication side effects',
];

/// Plan items that happen in hospital and the ones taken home, in the order they were added.
List<J> planInHospital(CaseRec c) => [for (final m in c.lst('mgmt')) if (_s(m['setting']) != kTakeHome) m];
List<J> planTakeHome(CaseRec c) => [for (final m in c.lst('mgmt')) if (_s(m['setting']) == kTakeHome) m];

/// Names of the drugs in the loaded drug files that match what is typed (up to [limit]).
List<String> drugSuggestions(String q, {int limit = 8}) {
  final t = q.trim();
  if (t.length < 2) return const [];
  final seen = <String>{};
  final out = <String>[];
  for (final d in dosing.searchFormulary(t)) {
    if (seen.add(d.name.toLowerCase())) out.add(d.name);
    if (out.length >= limit) return out;
  }
  final w = t.toLowerCase();
  for (final d in dosing.drugs) {
    if (d.name.toLowerCase().contains(w) && seen.add(d.name.toLowerCase())) out.add(d.name);
    if (out.length >= limit) break;
  }
  return out;
}

/// Opens the plan item sheet. [initial] is an existing item (edit) or a starting point (new). Returns the saved item,
/// `{'__delete': true}` or null.
Future<J?> showPlanItemSheet(BuildContext context, {J? initial, String setting = kInHospital, bool canDelete = false}) {
  return showModalBottomSheet<J>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => PlanItemSheet(initial: initial, setting: setting, canDelete: canDelete),
  );
}

class PlanItemSheet extends StatefulWidget {
  final J? initial;
  final String setting;
  final bool canDelete;
  const PlanItemSheet({super.key, this.initial, this.setting = kInHospital, this.canDelete = false});
  @override
  State<PlanItemSheet> createState() => _PlanItemSheetState();
}

class _PlanItemSheetState extends State<PlanItemSheet> {
  late final J _d;
  late final Map<String, dynamic> _x;
  late String _setting;
  late String _category;
  final _drug = TextEditingController();
  final _amount = TextEditingController();
  final _days = TextEditingController();
  final _note = TextEditingController();
  final _free = TextEditingController();
  final _site = TextEditingController();
  final _procedure = TextEditingController();
  final _specialty = TextEditingController();
  final _question = TextEditingController();
  final _parameter = TextEditingController();
  List<String> _suggest = const [];

  @override
  void initState() {
    super.initState();
    _d = J.from(widget.initial ?? <String, dynamic>{});
    _d.putIfAbsent('id', () => newId('m'));
    _x = Map<String, dynamic>.from((_d['x'] as Map?) ?? const {});
    _setting = _s(_d['setting']).isEmpty ? widget.setting : _s(_d['setting']);
    _category = _s(_d['category']).isEmpty ? 'Medications & fluids' : _s(_d['category']);
    if (_s(_d['state']).isEmpty) _d['state'] = _setting == kTakeHome ? 'Prescribed' : 'Ordered';
    if (_s(_d['by']).isEmpty) _d['by'] = 'Team decision';
    final legacy = _x.isEmpty;
    // an item written before this sheet: its text is the drug / procedure name, its dose line is kept as a note
    _drug.text = _s(_x['drug']).isNotEmpty ? _s(_x['drug']) : (legacy ? _s(_d['text']) : '');
    _amount.text = _s(_x['amount']);
    _days.text = _s(_x['days']);
    _note.text = _s(_x['note']).isNotEmpty ? _s(_x['note']) : (legacy ? _s(_d['dose']) : '');
    _site.text = _s(_x['site']);
    _procedure.text = _s(_x['procedure']).isNotEmpty ? _s(_x['procedure']) : (legacy ? _s(_d['text']) : '');
    _specialty.text = _s(_x['specialty']).isNotEmpty ? _s(_x['specialty']) : (legacy ? _s(_d['text']) : '');
    _question.text = _s(_x['question']);
    _parameter.text = _s(_x['parameter']).isNotEmpty ? _s(_x['parameter']) : (legacy ? _s(_d['text']) : '');
    _free.text = legacy ? _s(_d['text']) : '';
    _x.putIfAbsent('unit', () => 'mg');
  }

  @override
  void dispose() {
    for (final c in [_drug, _amount, _days, _note, _free, _site, _procedure, _specialty, _question, _parameter]) {
      c.dispose();
    }
    super.dispose();
  }

  PlanKind get _kind => planKindOf(_category, _setting);

  void _pick(String key, String v) => setState(() => _x[key] = _x[key] == v ? '' : v);

  Widget _row(String label, List<String> options, String Function() current, void Function(String) onTap, String key, {bool translate = false}) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (final o in options)
              ChoiceChip(
                key: ValueKey('plan_${key}_$o'),
                label: translate ? Text(o) : m.Text(o),
                selected: current() == o,
                onSelected: (_) => onTap(o),
                visualDensity: VisualDensity.compact,
              ),
          ]),
        ]),
      );

  Widget _chips(String label, List<String> options, String key, {bool translate = false}) =>
      _row(label, options, () => _s(_x[key]), (v) => _pick(key, v), key, translate: translate);

  Widget _field(String label, TextEditingController c, {String? key, int lines = 1, TextInputType? type, String hint = '', ValueChanged<String>? onChanged}) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: TextField(
          key: key == null ? null : ValueKey(key),
          controller: c,
          minLines: lines,
          maxLines: lines == 1 ? 1 : 4,
          keyboardType: type,
          onChanged: onChanged,
          decoration: InputDecoration(labelText: tr(label), hintText: hint.isEmpty ? null : hint),
        ),
      );

  void _save() {
    final k = _kind;
    final x = <String, dynamic>{..._x};
    x['drug'] = _drug.text.trim();
    x['amount'] = _amount.text.trim();
    x['days'] = _days.text.trim();
    x['note'] = _note.text.trim();
    x['site'] = _site.text.trim();
    x['procedure'] = _procedure.text.trim();
    x['specialty'] = _specialty.text.trim();
    x['question'] = _question.text.trim();
    x['parameter'] = _parameter.text.trim();
    final c = composePlan(k, x, fallbackText: _free.text.trim());
    final out = J.from(_d);
    out['setting'] = _setting;
    out['category'] = _category;
    out['x'] = x;
    out['text'] = c.text;
    out['dose'] = c.dose;
    if (c.text.isEmpty && c.dose.isEmpty) {
      Navigator.pop(context);
      return;
    }
    Navigator.pop(context, out);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final k = _kind;
    final take = _setting == kTakeHome;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(child: Text(widget.initial == null ? 'New plan item' : 'Plan item', style: theme.textTheme.titleLarge)),
            if (widget.canDelete)
              IconButton(tooltip: tr('Delete'), 
                key: const ValueKey('plan_delete'),
                icon: const Icon(AppIcons.delete),
                onPressed: () => Navigator.pop(context, <String, dynamic>{'__delete': true}),
              ),
          ]),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            key: const ValueKey('plan_setting'),
            segments: [
              ButtonSegment(value: kInHospital, label: Text('Given in hospital'), icon: const Icon(Ph.hospital)),
              ButtonSegment(value: kTakeHome, label: Text('Take-home'), icon: const Icon(Ph.house)),
            ],
            selected: {_setting},
            onSelectionChanged: (s) => setState(() {
              _setting = s.first;
              final st = _s(_d['state']);
              if (_setting == kTakeHome && (st == 'Ordered' || st == 'Given' || st == 'Suggested')) _d['state'] = 'Prescribed';
              if (_setting == kInHospital && st == 'Prescribed') _d['state'] = 'Ordered';
            }),
          ),
          if (!take) _row('Category', kPlanCategories, () => _category, (v) => setState(() => _category = v), 'category', translate: true),
          if (k == PlanKind.drug) ...[
            _field(take ? 'Drug to take home' : 'Drug / fluid', _drug, key: 'plan_drug', onChanged: (v) => setState(() => _suggest = drugSuggestions(v))),
            if (_suggest.isNotEmpty && _drug.text.trim().isNotEmpty && !_suggest.contains(_drug.text.trim()))
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Wrap(spacing: 6, runSpacing: 4, children: [
                  for (final n in _suggest)
                    ActionChip(
                      key: ValueKey('plan_sug_$n'),
                      label: m.Text(n),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setState(() {
                        _drug.text = n;
                        _suggest = const [];
                      }),
                    ),
                ]),
              ),
            _chips('Route', kRoutes, 'route'),
            _field('Dose', _amount, key: 'plan_amount', type: const TextInputType.numberWithOptions(decimal: true)),
            _chips('Unit', kUnits, 'unit'),
            _chips('Frequency', kFreqs, 'freq'),
            _field(take ? 'Days to take' : 'Duration (days, optional)', _days, key: 'plan_days', type: TextInputType.number),
            _field(take ? 'Instructions for the patient' : 'Note', _note, key: 'plan_note', lines: 2),
          ],
          if (k == PlanKind.procedure) ...[
            _field('Procedure', _procedure, key: 'plan_procedure'),
            _field('Site / side', _site, key: 'plan_site'),
            _chips('Consent', const ['Verbal', 'Written', 'Emergency (implied)'], 'consent'),
            _chips('Result', const ['Uncomplicated', 'Complication', 'Unsuccessful'], 'outcome'),
          ],
          if (k == PlanKind.consult) ...[
            _field('Specialty', _specialty, key: 'plan_specialty'),
            _chips('Urgency', const ['Immediate', 'Urgent', 'Same day', 'Routine'], 'urgency'),
            _field('Question asked', _question, key: 'plan_question', lines: 2),
          ],
          if (k == PlanKind.monitoring) ...[
            _field('What is monitored', _parameter, key: 'plan_parameter', hint: 'BP, GCS, urine output...'),
            _chips('How often', const ['Continuous', 'q15min', 'q30min', 'Hourly', 'q4h', 'q6h', 'Daily'], 'freq'),
            _field('Note', _note, key: 'plan_note', lines: 2),
          ],
          if (k == PlanKind.safety) ...[
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Warning signs explained to the patient', style: theme.textTheme.labelLarge),
                const SizedBox(height: 4),
                Wrap(spacing: 6, runSpacing: 4, children: [
                  for (final o in kSafetyTold)
                    FilterChip(
                      key: ValueKey('plan_told_$o'),
                      label: m.Text(o),
                      selected: ((_x['told'] as List?) ?? const []).contains(o),
                      visualDensity: VisualDensity.compact,
                      onSelected: (v) => setState(() {
                        final l = [for (final e in (_x['told'] as List?) ?? const []) '$e'];
                        v ? l.add(o) : l.remove(o);
                        _x['told'] = l;
                      }),
                    ),
                ]),
              ]),
            ),
            _chips('Come back in', const ['24 hours', '48 hours', '3 days', '1 week', '2 weeks', 'If worse'], 'return'),
          ],
          _row('Status', take ? const ['Prescribed', 'Suggested', 'Stopped'] : const ['Suggested', 'Ordered', 'Given', 'Stopped'], () => _s(_d['state']), (v) => setState(() => _d['state'] = v), 'state', translate: true),
          _row('Who decided', const ['Suggested by me', 'Team decision', 'Supervisor changed'], () => _s(_d['by']), (v) => setState(() => _d['by'] = v), 'by', translate: true),
          const SizedBox(height: 16),
          FilledButton(key: const ValueKey('plan_save'), onPressed: _save, child: Text('Save')),
        ]),
      ),
    );
  }
}
