import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'data.dart';
import 'i18n.dart';
import 'library.dart';
import 'screens_library.dart';
import 'screens_learn.dart' show ExamPlannerSection;
import 'screens_cases.dart' show CaseTile;
import 'ui.dart';
import 'motion.dart' show AnimatedBar;
import 'widgets.dart';

/// A reading plan for one of the person's books: the chapters are spread over the dates they chose, bigger chapters
/// get more days, and whatever is not done yet is spread again over the days that are left.

class BookChapter {
  final int number;
  final String title;
  final int weight; // relative size (bytes of the chapter's text)
  final bool done;
  const BookChapter(this.number, this.title, this.weight, this.done);
}

class BookPlanSchedule {
  /// Weekdays (1 = Monday ... 7 = Sunday) used for [perWeek] study days a week.
  static Set<int> studyWeekdays(int perWeek) => switch (perWeek.clamp(1, 7)) {
        1 => {6},
        2 => {2, 5},
        3 => {1, 3, 5},
        4 => {1, 2, 4, 6},
        5 => {1, 2, 3, 4, 5},
        6 => {1, 2, 3, 4, 5, 6},
        _ => {1, 2, 3, 4, 5, 6, 7},
      };

  static DateTime _d(DateTime t) => DateTime(t.year, t.month, t.day);

  /// The study days from [from] to [end] (both included) that fall on one of [weekdays].
  static List<DateTime> days(DateTime from, DateTime end, Set<int> weekdays) {
    final out = <DateTime>[];
    for (var d = _d(from); !d.isAfter(_d(end)); d = d.add(const Duration(days: 1))) {
      if (weekdays.contains(d.weekday)) out.add(d);
    }
    return out;
  }

  /// Gives every chapter that is not done a study day. Chapters keep their order; the cumulative size decides the day,
  /// so a big chapter takes a day of its own and small ones share a day. With no day left, everything lands on [today].
  static Map<int, DateTime> assign(List<BookChapter> chapters, DateTime start, DateTime end, int perWeek, DateTime today) {
    final todo = [for (final c in chapters) if (!c.done) c];
    if (todo.isEmpty) return {};
    final from = _d(today).isAfter(_d(start)) ? _d(today) : _d(start);
    var slots = days(from, end, studyWeekdays(perWeek));
    if (slots.isEmpty) slots = [_d(today)];
    final total = todo.fold<int>(0, (a, c) => a + (c.weight <= 0 ? 1 : c.weight));
    final out = <int, DateTime>{};
    var acc = 0;
    for (final c in todo) {
      final w = c.weight <= 0 ? 1 : c.weight;
      final mid = acc + w / 2;
      final i = (mid / total * slots.length).floor().clamp(0, slots.length - 1);
      out[c.number] = slots[i];
      acc += w;
    }
    return out;
  }
}

class BookPlanStore {
  static const _k = 'bookPlans';

  static List<Map<String, dynamic>> all() {
    final v = store.settings[_k];
    return v is List ? [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)] : <Map<String, dynamic>>[];
  }

  static Future<void> save(List<Map<String, dynamic>> l) async {
    store.settings[_k] = l;
    await store.saveSettings();
    store.refresh();
  }

  static Future<void> upsert(Map<String, dynamic> p) async {
    final l = all();
    final i = l.indexWhere((e) => e['id'] == p['id']);
    if (i >= 0) {
      l[i] = p;
    } else {
      l.add(p);
    }
    await save(l);
  }

  static Future<void> remove(String id) => save(all()..removeWhere((e) => e['id'] == id));

  static Set<int> doneOf(Map<String, dynamic> p) => {for (final e in (p['done'] as List? ?? const [])) if (e is int) e};

  static Future<List<BookChapter>> chaptersFor(Map<String, dynamic> p) async {
    final id = '${p['packId']}';
    final chs = await library.chaptersOf(id);
    final nums = await library.chapterNumbersOf(id);
    final lens = await library.lengthsOf(id);
    final w = <int, int>{};
    for (var i = 0; i < nums.length && i < lens.length; i++) {
      w[nums[i]] = (w[nums[i]] ?? 0) + lens[i];
    }
    final done = doneOf(p);
    if (chs.isEmpty) {
      return [for (final n in (w.keys.toList()..sort())) BookChapter(n, '${tr('Chapter')} $n', w[n] ?? 1, done.contains(n))];
    }
    return [for (final c in chs) BookChapter(c.number, c.title, w[c.number] ?? 1, done.contains(c.number))];
  }
}

Future<void> openBookChapter(BuildContext context, String packId, int chapter) async {
  final nums = await library.chapterNumbersOf(packId);
  final i = nums.indexOf(chapter);
  if (i >= 0 && context.mounted) openArticle(context, packId, i);
}

/// "My plan": today's chapter of each book plan, with a way to open it, mark it done or see the whole plan.
class BookPlanCard extends StatelessWidget {
  const BookPlanCard({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final plans = BookPlanStore.all();
        return AppCard(
          key: const ValueKey('bookPlanCard'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(AppIcons.plan, color: theme.colorScheme.primary),
                const SizedBox(width: 10),
                Expanded(child: Text('My plan', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
                TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const BookPlanScreen())), child: Text(plans.isEmpty ? 'Create' : 'All plans')),
              ]),
              if (plans.isEmpty)
                Text('Pick one of your books, the dates and how many days a week. The app splits its chapters for you.', style: theme.textTheme.bodySmall)
              else
                for (final p in plans.take(3)) _PlanToday(plan: p),
            ]),
          ),
        );
      },
    );
  }
}

class _PlanToday extends StatelessWidget {
  final Map<String, dynamic> plan;
  const _PlanToday({required this.plan});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureBuilder<List<BookChapter>>(
      future: BookPlanStore.chaptersFor(plan),
      builder: (context, snap) {
        final chs = snap.data;
        if (chs == null) return const SizedBox(height: 40);
        final start = parseDate('${plan['start']}') ?? DateTime.now();
        final end = parseDate('${plan['end']}') ?? start.add(const Duration(days: 30));
        final today = DateTime.now();
        final sched = BookPlanSchedule.assign(chs, start, end, (plan['perWeek'] as int?) ?? 3, today);
        final t = DateTime(today.year, today.month, today.day);
        final todays = [for (final c in chs) if (!c.done && sched[c.number] != null && !sched[c.number]!.isAfter(t)) c];
        final next = [for (final c in chs) if (!c.done) c];
        final doneN = chs.where((c) => c.done).length;
        final show = todays.isNotEmpty ? todays.first : (next.isEmpty ? null : next.first);
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            m.Text('${plan['title']}  •  $doneN / ${chs.length}', style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.outline)),
            if (show == null)
              Text('All chapters done')
            else
              ListTile(
                key: ValueKey('plan_today_${plan['id']}'),
                contentPadding: EdgeInsets.zero,
                dense: true,
                title: m.Text('${todays.isNotEmpty ? tr('Today') : tr('Next')}: ${show.title}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: m.Text(trp('{n} min', {'n': (plan['minutes'] as int?) ?? 30})),
                trailing: IconButton(
                  tooltip: tr('Mark as done'),
                  icon: Icon(AppIcons.done),
                  onPressed: () async {
                    final d = BookPlanStore.doneOf(plan)..add(show.number);
                    await BookPlanStore.upsert({...plan, 'done': d.toList()});
                  },
                ),
                onTap: () => openBookChapter(context, '${plan['packId']}', show.number),
              ),
          ]),
        );
      },
    );
  }
}

class BookPlanScreen extends StatelessWidget {
  const BookPlanScreen({super.key});

  Future<void> _create(BuildContext context) async {
    final books = [for (final p in library.packs) if (p.kind == 'book' || p.kind == 'user') p];
    if (books.isEmpty) {
      snack(context, 'Add a book to your library first.');
      return;
    }
    final res = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _NewPlanSheet(books: books),
    );
    if (res != null) await BookPlanStore.upsert(res);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My plan')),
      floatingActionButton: FloatingActionButton.extended(key: const ValueKey('plan_new'), onPressed: () => _create(context), icon: Icon(AppIcons.add), label: Text('New plan')),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final plans = BookPlanStore.all();
          final flagged = store.casesSorted().where((c) => c.review).toList();
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 96), children: [
            if (plans.isEmpty)
              Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text('No plans yet. Pick one of your books and the dates; the app splits its chapters over the days.', textAlign: TextAlign.center)),
            for (final p in plans) _PlanDetail(plan: p),
            const ExamPlannerSection(),
            if (flagged.isNotEmpty) ...[
              const SectionHeader('Cases flagged for review'),
              for (final c in flagged) CaseTile(c),
            ],
          ]);
        },
      ),
    );
  }
}

class _PlanDetail extends StatelessWidget {
  final Map<String, dynamic> plan;
  const _PlanDetail({required this.plan});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureBuilder<List<BookChapter>>(
      future: BookPlanStore.chaptersFor(plan),
      builder: (context, snap) {
        final chs = snap.data ?? const <BookChapter>[];
        final start = parseDate('${plan['start']}') ?? DateTime.now();
        final end = parseDate('${plan['end']}') ?? start;
        final sched = BookPlanSchedule.assign(chs, start, end, (plan['perWeek'] as int?) ?? 3, DateTime.now());
        final doneN = chs.where((c) => c.done).length;
        return AppCard(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: m.Text('${plan['title']}', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
                IconButton(
                  tooltip: tr('Delete'),
                  icon: Icon(AppIcons.delete, color: theme.colorScheme.error),
                  onPressed: () async {
                    if (await confirmDialog(context, 'Delete this plan?', action: 'Delete')) await BookPlanStore.remove('${plan['id']}');
                  },
                ),
              ]),
              m.Text('${plan['start']} → ${plan['end']}  •  ${trp('{n} days a week', {'n': (plan['perWeek'] as int?) ?? 3})}  •  ${trp('{n} min', {'n': (plan['minutes'] as int?) ?? 30})}', style: theme.textTheme.bodySmall),
              const SizedBox(height: 8),
              AnimatedBar(chs.isEmpty ? 0 : doneN / chs.length, height: 6),
              const SizedBox(height: 6),
              for (final c in chs)
                CheckboxListTile(
                  key: ValueKey('plan_ch_${plan['id']}_${c.number}'),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  controlAffinity: ListTileControlAffinity.leading,
                  value: c.done,
                  title: m.Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: c.done || sched[c.number] == null ? null : m.Text(prettyDate(fmtDate(sched[c.number]!))),
                  secondary: IconButton(icon: Icon(AppIcons.read, size: 20), tooltip: tr('Open'), onPressed: () => openBookChapter(context, '${plan['packId']}', c.number)),
                  onChanged: (v) async {
                    final d = BookPlanStore.doneOf(plan);
                    if (v == true) {
                      d.add(c.number);
                    } else {
                      d.remove(c.number);
                    }
                    await BookPlanStore.upsert({...plan, 'done': d.toList()});
                  },
                ),
            ]),
          ),
        );
      },
    );
  }
}

class _NewPlanSheet extends StatefulWidget {
  final List<PackMeta> books;
  const _NewPlanSheet({required this.books});
  @override
  State<_NewPlanSheet> createState() => _NewPlanSheetState();
}

class _NewPlanSheetState extends State<_NewPlanSheet> {
  late PackMeta _book = widget.books.first;
  DateTime _start = DateTime.now();
  DateTime _end = DateTime.now().add(const Duration(days: 30));
  int _perWeek = 4;
  int _minutes = 45;

  Future<void> _pick(bool isStart) async {
    final d = await showDatePicker(context: context, initialDate: isStart ? _start : _end, firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (d == null) return;
    setState(() {
      if (isStart) {
        _start = d;
        if (_end.isBefore(_start)) _end = _start.add(const Duration(days: 7));
      } else {
        _end = d.isBefore(_start) ? _start : d;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('New study plan', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: const ValueKey('plan_book'),
              initialValue: _book.id,
              isExpanded: true,
              decoration: InputDecoration(labelText: tr('Book')),
              items: [for (final b in widget.books) DropdownMenuItem(value: b.id, child: m.Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis))],
              onChanged: (v) => setState(() => _book = widget.books.firstWhere((b) => b.id == v)),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(true), icon: Icon(AppIcons.calendar, size: 18), label: m.Text('${tr('Start')}: ${fmtDate(_start)}'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(false), icon: Icon(AppIcons.calendar, size: 18), label: m.Text('${tr('End')}: ${fmtDate(_end)}'))),
            ]),
            const SizedBox(height: 12),
            m.Text(tr('Study days per week'), style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [for (var i = 1; i <= 7; i++) ButtonSegment(value: i, label: m.Text('$i'))],
              selected: {_perWeek},
              onSelectionChanged: (v) => setState(() => _perWeek = v.first),
            ),
            const SizedBox(height: 12),
            m.Text(tr('Minutes per study day'), style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [for (final v in const [15, 30, 45, 60, 90]) ButtonSegment(value: v, label: m.Text('$v'))],
              selected: {_minutes},
              onSelectionChanged: (v) => setState(() => _minutes = v.first),
            ),
            const SizedBox(height: 16),
            FilledButton(
              key: const ValueKey('plan_save'),
              onPressed: () => Navigator.pop(context, <String, dynamic>{
                'id': newId('bp'),
                'packId': _book.id,
                'title': _book.title,
                'start': fmtDate(_start),
                'end': fmtDate(_end),
                'perWeek': _perWeek,
                'minutes': _minutes,
                'done': <int>[],
              }),
              child: Text('Create plan'),
            ),
          ]),
        ),
      ),
    );
  }
}
