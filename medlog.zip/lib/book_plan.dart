import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'day_planner.dart';
import 'ai/ai_study.dart' show reviewBookPlan;
import 'screens_ai_study.dart' show failureText;
import 'ai/ai_api.dart' show Ai;
import 'data.dart';
import 'i18n.dart';
import 'library.dart';
import 'screens_library.dart';
import 'screens_learn.dart' show ExamPlannerSection;
import 'screens_cases.dart' show CaseTile;
import 'ui.dart';
import 'motion.dart' show AnimatedBar;
import 'widgets.dart';

/// A reading plan for one of the person's books: the chapters are spread over the dates they chose, bigger chapters
/// get more days, and whatever is not done yet is spread again over the days that are left.

class BookChapter {
  final int number;
  final String title;
  final int weight; // relative size (bytes of the chapter's text)
  final bool done;
  final String priority; // '' | high | medium | low (from the AI review the person applied)
  final String focus;
  const BookChapter(this.number, this.title, this.weight, this.done, {this.priority = '', this.focus = ''});

  /// Size times importance: an important chapter gets more of the days, a minor one less.
  int get effort => (weight * (priority == 'high' ? 1.6 : (priority == 'low' ? 0.5 : 1.0))).round();
}

class BookPlanSchedule {
  /// Weekdays (1 = Monday ... 7 = Sunday) used for [perWeek] study days a week.
  static Set<int> studyWeekdays(int perWeek) => switch (perWeek.clamp(1, 7)) {
        1 => {6},
        2 => {2, 5},
        3 => {1, 3, 5},
        4 => {1, 2, 4, 6},
        5 => {1, 2, 3, 4, 5},
        6 => {1, 2, 3, 4, 5, 6},
        _ => {1, 2, 3, 4, 5, 6, 7},
      };

  static DateTime _d(DateTime t) => DateTime(t.year, t.month, t.day);

  /// The study days from [from] to [end] (both included) that fall on one of [weekdays].
  static List<DateTime> days(DateTime from, DateTime end, Set<int> weekdays) {
    final out = <DateTime>[];
    for (var d = _d(from); !d.isAfter(_d(end)); d = d.add(const Duration(days: 1))) {
      if (weekdays.contains(d.weekday)) out.add(d);
    }
    return out;
  }

  /// Gives every chapter that is not done a study day. Chapters keep their order; the cumulative size decides the day,
  /// so a big chapter takes a day of its own and small ones share a day. With no day left, everything lands on [today].
  static Map<int, DateTime> assign(List<BookChapter> chapters, DateTime start, DateTime end, int perWeek, DateTime today) {
    final todo = [for (final c in chapters) if (!c.done) c];
    if (todo.isEmpty) return {};
    final from = _d(today).isAfter(_d(start)) ? _d(today) : _d(start);
    var slots = days(from, end, studyWeekdays(perWeek));
    if (slots.isEmpty) slots = [_d(today)];
    final total = todo.fold<int>(0, (a, c) => a + (c.effort <= 0 ? 1 : c.effort));
    final out = <int, DateTime>{};
    var acc = 0;
    for (final c in todo) {
      final w = c.effort <= 0 ? 1 : c.effort;
      final mid = acc + w / 2;
      final i = (mid / total * slots.length).floor().clamp(0, slots.length - 1);
      out[c.number] = slots[i];
      acc += w;
    }
    return out;
  }
}

class BookPlanStore {
  static const _k = 'bookPlans';

  static List<Map<String, dynamic>> all() {
    final v = store.settings[_k];
    return v is List ? [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)] : <Map<String, dynamic>>[];
  }

  static Future<void> save(List<Map<String, dynamic>> l) async {
    store.settings[_k] = l;
    await store.saveSettings();
    store.refresh();
  }

  static Future<void> upsert(Map<String, dynamic> p) async {
    final l = all();
    final i = l.indexWhere((e) => e['id'] == p['id']);
    if (i >= 0) {
      l[i] = p;
    } else {
      l.add(p);
    }
    await save(l);
  }

  static Future<void> remove(String id) => save(all()..removeWhere((e) => e['id'] == id));

  /// Ticks or unticks one chapter and remembers the day it was ticked (the day planner shows what was done today).
  static Future<void> setChapterDone(String planId, int number, bool done) async {
    final p = all().firstWhere((e) => e['id'] == planId, orElse: () => <String, dynamic>{});
    if (p.isEmpty) return;
    final d = doneOf(p);
    final on = p['doneOn'] is Map ? Map<String, dynamic>.from(p['doneOn'] as Map) : <String, dynamic>{};
    if (done) {
      d.add(number);
      on['$number'] = todayStr();
    } else {
      d.remove(number);
      on.remove('$number');
    }
    await upsert({...p, 'done': d.toList(), 'doneOn': on});
  }

  static Set<int> doneOf(Map<String, dynamic> p) => {for (final e in (p['done'] as List? ?? const [])) if (e is int) e};

  static Future<List<BookChapter>> chaptersFor(Map<String, dynamic> p) async {
    final id = '${p['packId']}';
    final chs = await library.chaptersOf(id);
    final nums = await library.chapterNumbersOf(id);
    final lens = await library.lengthsOf(id);
    final w = <int, int>{};
    for (var i = 0; i < nums.length && i < lens.length; i++) {
      w[nums[i]] = (w[nums[i]] ?? 0) + lens[i];
    }
    final done = doneOf(p);
    final ai = p['ai'] is Map ? Map<String, dynamic>.from(p['ai'] as Map) : <String, dynamic>{};
    BookChapter mk(int n, String title) {
      final note = ai['$n'] is Map ? Map<String, dynamic>.from(ai['$n'] as Map) : const <String, dynamic>{};
      return BookChapter(n, title, w[n] ?? 1, done.contains(n), priority: '${note['p'] ?? ''}', focus: '${note['f'] ?? ''}');
    }
    if (chs.isEmpty && w.isEmpty) {
      // a book with no chapter list: every entry is a chapter of its own, in the order of the book
      final titles = await library.titlesOf(id);
      for (var i = 0; i < lens.length && i < titles.length; i++) {
        w[i + 1] = lens[i];
      }
      return [for (var i = 0; i < titles.length; i++) mk(i + 1, titles[i])];
    }
    if (chs.isEmpty) {
      return [for (final n in (w.keys.toList()..sort())) mk(n, '${tr('Chapter')} $n')];
    }
    return [for (final c in chs) mk(c.number, c.title)];
  }
}

Future<void> openBookChapter(BuildContext context, String packId, int chapter) async {
  final nums = await library.chapterNumbersOf(packId);
  // with no chapter list the number is the place of the entry in the book (1-based)
  final i = nums.isEmpty ? chapter - 1 : nums.indexOf(chapter);
  if (i >= 0 && context.mounted) openArticle(context, packId, i);
}

/// "My plan": today's chapter of each book plan, with a way to open it, mark it done or see the whole plan.
class BookPlanCard extends StatelessWidget {
  const BookPlanCard({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final plans = BookPlanStore.all();
        return AppCard(
          key: const ValueKey('bookPlanCard'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(AppIcons.plan, color: theme.colorScheme.primary),
                const SizedBox(width: 10),
                Expanded(child: Text('My plan', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
                TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const BookPlanScreen())), child: Text(plans.isEmpty ? 'Create' : 'All plans')),
              ]),
              if (plans.isEmpty)
                Text('Pick one of your books, the dates and how many days a week. The app splits its chapters for you.', style: theme.textTheme.bodySmall)
              else
                for (final p in plans.take(3)) _PlanToday(plan: p),
            ]),
          ),
        );
      },
    );
  }
}

class _PlanToday extends StatelessWidget {
  final Map<String, dynamic> plan;
  const _PlanToday({required this.plan});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureBuilder<List<BookChapter>>(
      future: BookPlanStore.chaptersFor(plan),
      builder: (context, snap) {
        final chs = snap.data;
        if (chs == null) return const SizedBox(height: 40);
        final start = parseDate('${plan['start']}') ?? DateTime.now();
        final end = parseDate('${plan['end']}') ?? start.add(const Duration(days: 30));
        final today = DateTime.now();
        final sched = BookPlanSchedule.assign(chs, start, end, (plan['perWeek'] as int?) ?? 3, today);
        final t = DateTime(today.year, today.month, today.day);
        final todays = [for (final c in chs) if (!c.done && sched[c.number] != null && !sched[c.number]!.isAfter(t)) c];
        final next = [for (final c in chs) if (!c.done) c];
        final doneN = chs.where((c) => c.done).length;
        final show = todays.isNotEmpty ? todays.first : (next.isEmpty ? null : next.first);
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            m.Text('${plan['title']}  •  $doneN / ${chs.length}', style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.outline)),
            if (show == null)
              Text('All chapters done')
            else
              ListTile(
                key: ValueKey('plan_today_${plan['id']}'),
                contentPadding: EdgeInsets.zero,
                dense: true,
                title: m.Text('${todays.isNotEmpty ? tr('Today') : tr('Next')}: ${show.title}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: m.Text(trp('{n} min', {'n': (plan['minutes'] as int?) ?? 30})),
                trailing: IconButton(
                  tooltip: tr('Mark as done'),
                  icon: Icon(AppIcons.done),
                  onPressed: () => BookPlanStore.setChapterDone('${plan['id']}', show.number, true),
                ),
                onTap: () => openBookChapter(context, '${plan['packId']}', show.number),
              ),
          ]),
        );
      },
    );
  }
}

class BookPlanScreen extends StatelessWidget {
  const BookPlanScreen({super.key});

  Future<void> _create(BuildContext context) async {
    final books = [for (final p in library.packs) if (p.kind == 'book' || p.kind == 'user') p];
    if (books.isEmpty) {
      snack(context, 'Add a book to your library first.');
      return;
    }
    final res = await showModalBottomSheet<List<Map<String, dynamic>>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _NewPlanSheet(books: books),
    );
    // one plan for each book chosen, with the same dates; they belong together (same group)
    if (res != null) {
      for (final p in res) {
        await BookPlanStore.upsert(p);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My plan'), actions: [IconButton(key: const ValueKey('plan_today'), tooltip: tr('Today'), icon: Icon(AppIcons.done), onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const DayPlannerScreen())))]),
      floatingActionButton: FloatingActionButton.extended(key: const ValueKey('plan_new'), onPressed: () => _create(context), icon: Icon(AppIcons.add), label: Text('New plan')),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final plans = BookPlanStore.all();
          final flagged = store.casesSorted().where((c) => c.review).toList();
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 96), children: [
            if (plans.isEmpty)
              Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text('No plans yet. Pick one of your books and the dates; the app splits its chapters over the days.', textAlign: TextAlign.center)),
            for (final p in plans) _PlanDetail(plan: p),
            const ExamPlannerSection(),
            if (flagged.isNotEmpty) ...[
              const SectionHeader('Cases flagged for review'),
              for (final c in flagged) CaseTile(c),
            ],
          ]);
        },
      ),
    );
  }
}

class _PlanDetail extends StatelessWidget {
  final Map<String, dynamic> plan;
  const _PlanDetail({required this.plan});

  /// Asks the AI (with a web look-up) how important each chapter is for the exam, shows it, and applies it only on "Apply".
  String _examGoal() {
    final e = store.settings['examPlan'];
    return e is Map ? '${e['name'] ?? ''}' : '';
  }

  Future<void> _review(BuildContext context, List<BookChapter> chs) async {
    if (!Ai.enabled) {
      snack(context, 'AI is off. Turn it on in Settings.');
      return;
    }
    final plans = _examGoal();
    if (!context.mounted) return;
    snack(context, 'Asking the AI…');
    final (rev, f) = await reviewBookPlan('${plan['title']}', [for (final c in chs) (c.number, c.title)], goal: plans);
    if (!context.mounted) return;
    if (rev == null) {
      snack(context, failureText(f));
      return;
    }
    final high = rev.notes.values.where((n) => n.priority == 'high').length;
    final low = rev.notes.values.where((n) => n.priority == 'low').length;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Chapter importance'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            m.Text(trp('{a} important, {b} minor chapters. Important ones get more of your days, minor ones fewer.', {'a': high, 'b': low})),
            if (rev.basis.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: m.Text(rev.basis, style: Theme.of(ctx).textTheme.bodySmall)),
            const SizedBox(height: 8),
            Text('AI suggestion: check it against your own exam syllabus.', style: Theme.of(ctx).textTheme.bodySmall),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
          FilledButton(key: const ValueKey('plan_ai_apply'), onPressed: () => Navigator.pop(ctx, true), child: Text('Apply')),
        ],
      ),
    );
    if (ok == true) {
      await BookPlanStore.upsert({...plan, 'ai': {for (final e in rev.notes.entries) '${e.key}': e.value.toJson()}});
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureBuilder<List<BookChapter>>(
      future: BookPlanStore.chaptersFor(plan),
      builder: (context, snap) {
        final chs = snap.data ?? const <BookChapter>[];
        final start = parseDate('${plan['start']}') ?? DateTime.now();
        final end = parseDate('${plan['end']}') ?? start;
        final sched = BookPlanSchedule.assign(chs, start, end, (plan['perWeek'] as int?) ?? 3, DateTime.now());
        final doneN = chs.where((c) => c.done).length;
        return AppCard(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: m.Text('${plan['title']}', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
                IconButton(
                  tooltip: tr('Delete'),
                  icon: Icon(AppIcons.delete, color: theme.colorScheme.error),
                  onPressed: () async {
                    if (await confirmDialog(context, 'Delete this plan?', action: 'Delete')) await BookPlanStore.remove('${plan['id']}');
                  },
                ),
              ]),
              m.Text('${plan['start']} → ${plan['end']}  •  ${trp('{n} days a week', {'n': (plan['perWeek'] as int?) ?? 3})}  •  ${trp('{n} min', {'n': (plan['minutes'] as int?) ?? 30})}', style: theme.textTheme.bodySmall),
              const SizedBox(height: 8),
              AnimatedBar(chs.isEmpty ? 0 : doneN / chs.length, height: 6),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  key: ValueKey('plan_ai_${plan['id']}'),
                  onPressed: chs.isEmpty ? null : () => _review(context, chs),
                  icon: Icon(AppIcons.ai, size: 18),
                  label: Text(plan['ai'] == null ? 'Ask AI which chapters matter' : 'Ask AI again'),
                ),
              ),
              const SizedBox(height: 6),
              for (final c in chs)
                CheckboxListTile(
                  key: ValueKey('plan_ch_${plan['id']}_${c.number}'),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  controlAffinity: ListTileControlAffinity.leading,
                  value: c.done,
                  title: m.Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: c.done || sched[c.number] == null
                      ? null
                      : m.Text([prettyDate(fmtDate(sched[c.number]!)), if (c.priority.isNotEmpty) tr(c.priority == 'high' ? 'Important' : (c.priority == 'low' ? 'Minor' : 'Medium')), if (c.focus.isNotEmpty) c.focus].join(' • '), maxLines: 3, overflow: TextOverflow.ellipsis),
                  secondary: IconButton(icon: Icon(AppIcons.read, size: 20), tooltip: tr('Open'), onPressed: () => openBookChapter(context, '${plan['packId']}', c.number)),
                  onChanged: (v) => BookPlanStore.setChapterDone('${plan['id']}', c.number, v == true),
                ),
            ]),
          ),
        );
      },
    );
  }
}

class _NewPlanSheet extends StatefulWidget {
  final List<PackMeta> books;
  const _NewPlanSheet({required this.books});
  @override
  State<_NewPlanSheet> createState() => _NewPlanSheetState();
}

class _NewPlanSheetState extends State<_NewPlanSheet> {
  late final Set<String> _chosen = {widget.books.first.id};
  DateTime _start = DateTime.now();
  DateTime _end = DateTime.now().add(const Duration(days: 30));
  int _perWeek = 4;
  int _minutes = 45;

  Future<void> _pick(bool isStart) async {
    final d = await showDatePicker(context: context, initialDate: isStart ? _start : _end, firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (d == null) return;
    setState(() {
      if (isStart) {
        _start = d;
        if (_end.isBefore(_start)) _end = _start.add(const Duration(days: 7));
      } else {
        _end = d.isBefore(_start) ? _start : d;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('New study plan', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            m.Text(tr('Books (you can choose more than one)'), style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 4, children: [
              for (final b in widget.books)
                FilterChip(
                  key: ValueKey('plan_book_${b.id}'),
                  label: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 260), child: m.Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
                  selected: _chosen.contains(b.id),
                  onSelected: (v) => setState(() {
                    if (v) {
                      _chosen.add(b.id);
                    } else if (_chosen.length > 1) {
                      _chosen.remove(b.id);
                    }
                  }),
                ),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(true), icon: Icon(AppIcons.calendar, size: 18), label: m.Text('${tr('Start')}: ${fmtDate(_start)}'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(false), icon: Icon(AppIcons.calendar, size: 18), label: m.Text('${tr('End')}: ${fmtDate(_end)}'))),
            ]),
            const SizedBox(height: 12),
            m.Text(tr('Study days per week'), style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [for (var i = 1; i <= 7; i++) ButtonSegment(value: i, label: m.Text('$i'))],
              selected: {_perWeek},
              onSelectionChanged: (v) => setState(() => _perWeek = v.first),
            ),
            const SizedBox(height: 12),
            m.Text(tr('Minutes per study day'), style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [for (final v in const [15, 30, 45, 60, 90]) ButtonSegment(value: v, label: m.Text('$v'))],
              selected: {_minutes},
              onSelectionChanged: (v) => setState(() => _minutes = v.first),
            ),
            const SizedBox(height: 16),
            FilledButton(
              key: const ValueKey('plan_save'),
              onPressed: () {
                final group = newId('bg');
                Navigator.pop(context, <Map<String, dynamic>>[
                  for (final b in widget.books)
                    if (_chosen.contains(b.id))
                      <String, dynamic>{
                        'id': newId('bp'),
                        'group': group,
                        'packId': b.id,
                        'title': b.title,
                        'start': fmtDate(_start),
                        'end': fmtDate(_end),
                        'perWeek': _perWeek,
                        'minutes': _minutes,
                        'done': <int>[],
                      }
                ]);
              },
              child: Text('Create plan'),
            ),
          ]),
        ),
      ),
    );
  }
}
