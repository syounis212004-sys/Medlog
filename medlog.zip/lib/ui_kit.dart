import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'i18n.dart';
import 'ph.dart';

/// Spacing and shape used everywhere, so screens line up with each other.
class Tk {
  static const double s1 = 4, s2 = 8, s3 = 12, s4 = 16, s5 = 24;
  static const double rCard = 18, rField = 28, rChip = 12;
}

/// The one search field of the app: library, cases, calculators, doses, questions all look and behave the same.
/// The filter button (when given) opens a sheet; the number says how many filters are on.
class AppSearchBox extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final VoidCallback? onFilter;
  final int filterCount;
  final bool autofocus;
  final Widget? leading;

  const AppSearchBox({
    super.key,
    required this.controller,
    required this.hint,
    this.onChanged,
    this.onSubmitted,
    this.onFilter,
    this.filterCount = 0,
    this.autofocus = false,
    this.leading,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: controller,
      builder: (context, v, _) => TextField(
        key: const Key('app_search'),
        controller: controller,
        autofocus: autofocus,
        textInputAction: TextInputAction.search,
        onChanged: onChanged,
        onSubmitted: onSubmitted,
        decoration: InputDecoration(
          hintText: hint,
          isDense: true,
          filled: true,
          fillColor: cs.surfaceContainerHigh,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          prefixIcon: leading ?? Icon(AppIcons.search, size: 22, color: cs.onSurfaceVariant),
          suffixIconConstraints: const BoxConstraints(minHeight: 44),
          suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [
            if (v.text.isNotEmpty)
              IconButton(
                tooltip: tr('Clear'),
                icon: const Icon(Ph.x, size: 20),
                onPressed: () {
                  controller.clear();
                  onChanged?.call('');
                },
              ),
            if (onFilter != null)
              IconButton(
                key: const Key('app_search_filter'),
                tooltip: tr('Filter'),
                onPressed: onFilter,
                icon: Badge(isLabelVisible: filterCount > 0, label: m.Text('$filterCount'), child: Icon(AppIcons.filter, size: 22)),
              ),
          ]),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(Tk.rField), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(Tk.rField), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(Tk.rField), borderSide: BorderSide(color: cs.primary, width: 1.5)),
        ),
      ),
    );
  }
}

/// A grid of specialties, each with its picture. One tile can be chosen (or many with [multi]).
class SpecialtyGrid extends StatelessWidget {
  final List<String> names;
  final Set<String> selected;
  final ValueChanged<String> onTap;

  const SpecialtyGrid({super.key, required this.names, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return LayoutBuilder(builder: (context, c) {
      final cols = c.maxWidth >= 560 ? 4 : 3;
      const gap = 8.0;
      final w = (c.maxWidth - gap * (cols - 1)) / cols;
      return Wrap(spacing: gap, runSpacing: gap, children: [
        for (final n in names)
          SizedBox(
            width: w,
            child: Material(
              key: ValueKey('spec_$n'),
              color: selected.contains(n) ? cs.primaryContainer : cs.surfaceContainerLow,
              borderRadius: BorderRadius.circular(Tk.rCard),
              child: InkWell(
                borderRadius: BorderRadius.circular(Tk.rCard),
                onTap: () => onTap(n),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(specialtyIcon(n), size: 28, color: selected.contains(n) ? cs.onPrimaryContainer : cs.primary),
                    const SizedBox(height: 6),
                    m.Text(tr(n), maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, fontWeight: selected.contains(n) ? FontWeight.w800 : FontWeight.w600, color: selected.contains(n) ? cs.onPrimaryContainer : cs.onSurface)),
                  ]),
                ),
              ),
            ),
          ),
      ]);
    });
  }
}
