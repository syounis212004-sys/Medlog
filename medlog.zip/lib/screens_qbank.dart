import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';

import 'case_ui.dart';
import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'ph.dart';
import 'qbank.dart';
import 'sem.dart';
import 'widgets.dart';

// ================================================================================================ the list of banks

/// The question bank: the sets of questions the user imported, with progress, and the way to import more.
class QuestionBankScreen extends StatefulWidget {
  const QuestionBankScreen({super.key});

  @override
  State<QuestionBankScreen> createState() => _QuestionBankScreenState();
}

class _QuestionBankScreenState extends State<QuestionBankScreen> {
  bool _loading = !QuestionBank.loaded;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (_loading) {
      QuestionBank.load().then((_) {
        if (mounted) setState(() => _loading = false);
      });
    }
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any);
    if (r == null) return;
    final paths = [for (final f in r.files) if (f.path != null) f.path!];
    setState(() => _busy = true);
    try {
      final rep = await QuestionBank.importFiles(paths);
      if (!mounted) return;
      setState(() => _busy = false);
      if (rep.skipped == 0) {
        snack(context, trp('{n} questions added.', {'n': rep.questions}));
      } else {
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('Imported with some questions left out'),
            content: SingleChildScrollView(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                m.Text(trp('{a} questions added, {b} left out because they could not be used:', {'a': rep.questions, 'b': rep.skipped})),
                const SizedBox(height: 8),
                for (final p in rep.problems.take(12)) m.Text('• $p', style: Theme.of(ctx).textTheme.bodySmall),
                if (rep.problems.length > 12) m.Text('…', style: Theme.of(ctx).textTheme.bodySmall),
              ]),
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Close'))],
          ),
        );
      }
    } on QbFormatException catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('This file could not be imported'),
          content: m.Text(e.message),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Close'))],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      snack(context, '${tr('Import failed')}: $e');
    }
    if (mounted) setState(() {});
  }

  Future<void> _copyPrompt() async {
    await Clipboard.setData(const ClipboardData(text: kQbankAiPrompt));
    if (mounted) snack(context, tr('Prompt copied. Give it to the AI together with the PDF of the questions.'));
  }

  Future<void> _open(QbBank b) async {
    final setup = await showModalBottomSheet<QbSetup>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => QbSetupSheet(bank: b),
    );
    if (setup == null || !mounted) return;
    final qs = pickQuestions(b, setup);
    if (qs.isEmpty) {
      snack(context, tr('No question matches these choices.'));
      return;
    }
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => QbSessionScreen(bank: b, questions: qs, setup: setup)));
    if (mounted) setState(() {});
  }

  Future<void> _delete(QbBank b) async {
    final ok = await confirmDialog(context, trp('Delete the bank "{t}" and your progress in it?', {'t': b.title}), action: 'Delete');
    if (!ok) return;
    await QuestionBank.delete(b.id);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final banks = QuestionBank.banks;
    return Scaffold(
      appBar: AppBar(
        title: Text('Question bank'),
        actions: [
          IconButton(key: const Key('qb_import'), tooltip: tr('Import questions'), icon: const Icon(Ph.uploadSimple), onPressed: _busy ? null : _import),
          IconButton(key: const Key('qb_prompt'), tooltip: tr('Copy the AI prompt'), icon: const Icon(Ph.sparkle), onPressed: _copyPrompt),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : banks.isEmpty
              ? ListView(padding: const EdgeInsets.fromLTRB(24, 48, 24, 24), children: [
                  const Center(child: IconBadge(Ph.listChecks, size: 96)),
                  const SizedBox(height: 18),
                  Center(child: Text('No questions yet', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
                  const SizedBox(height: 8),
                  Text(
                    'Import a .zip (or .json) of questions with their options and answers, the same way you import a book. Practise them by topic, in learn mode or against the clock.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(key: const Key('qb_import_big'), onPressed: _busy ? null : _import, icon: const Icon(Ph.uploadSimple), label: Text('Import questions')),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(onPressed: _copyPrompt, icon: const Icon(Ph.sparkle), label: Text('Copy the AI prompt that converts a PDF')),
                  const SizedBox(height: 10),
                  Text('The prompt tells an AI (ChatGPT, Gemini) how to turn a PDF of questions into the file this screen reads.', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
                ])
              : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
                  if (_busy) const LinearProgressIndicator(),
                  for (var i = 0; i < banks.length; i++) FadeSlideIn(index: i, child: _bankCard(banks[i], cs)),
                ]),
    );
  }

  Widget _bankCard(QbBank b, ColorScheme cs) {
    final s = QbProgress.summary(b);
    final pctDone = s.total == 0 ? 0.0 : s.answered / s.total;
    return PressScale(
      child: Card(
        key: ValueKey('bank_${b.id}'),
        margin: const EdgeInsets.symmetric(vertical: 6),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _open(b),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const IconBadge(Ph.listChecks, size: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    m.Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: textDirectionFor(b.title), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    if (b.source.isNotEmpty) m.Text(b.source, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
                  ]),
                ),
                IconButton(tooltip: tr('Delete'), icon: const Icon(Ph.trash), onPressed: () => _delete(b)),
              ]),
              const SizedBox(height: 12),
              AnimatedBar(pctDone, height: 8),
              const SizedBox(height: 8),
              Wrap(spacing: 14, runSpacing: 4, children: [
                m.Text(trp('{n} questions', {'n': b.usable}), style: const TextStyle(fontWeight: FontWeight.w700)),
                m.Text(trp('{a} answered', {'a': s.answered}), style: TextStyle(color: cs.onSurfaceVariant)),
                if (s.answered > 0) m.Text(trp('{r} right at the last try', {'r': s.right}), style: const TextStyle(color: Sem.success, fontWeight: FontWeight.w600)),
                if (b.needReview > 0) m.Text(trp('{n} without an answer key', {'n': b.needReview}), style: const TextStyle(color: Sem.warning, fontWeight: FontWeight.w600)),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

// ================================================================================================ setup sheet

class QbSetupSheet extends StatefulWidget {
  final QbBank bank;
  const QbSetupSheet({super.key, required this.bank});

  @override
  State<QbSetupSheet> createState() => _QbSetupSheetState();
}

class _QbSetupSheetState extends State<QbSetupSheet> {
  QbMode _mode = QbMode.learn;
  final Set<String> _topics = {};
  String _which = 'all';
  int _count = 20;
  int _spq = 90; // seconds per question in exam mode; 0 = no timer

  QbSetup get _setup => QbSetup(mode: _mode, topics: _topics, which: _which, count: _count, secondsPerQuestion: _mode == QbMode.exam ? _spq : 0);

  @override
  Widget build(BuildContext context) {
    final b = widget.bank;
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final available = countMatching(b, _setup);
    final n = _count == 0 ? available : (available < _count ? available : _count);
    final total = n * _spq;
    Widget title(String s) => Padding(padding: const EdgeInsets.only(top: 18, bottom: 8), child: Text(s, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800)));
    Widget chips<T>(List<(T, String)> items, bool Function(T) sel, void Function(T) on) => Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [for (final it in items) ChoiceChip(label: m.Text(it.$2), selected: sel(it.$1), onSelected: (_) => setState(() => on(it.$1)))],
        );
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          m.Text(b.title, textDirection: textDirectionFor(b.title), style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          PillSegments(
            selected: _mode == QbMode.learn ? 0 : 1,
            items: [PillItem(Ph.lightbulb, tr('Learn'), key: const Key('qb_mode_learn')), PillItem(Ph.timer, tr('Exam'), key: const Key('qb_mode_exam'))],
            onSelected: (i) => setState(() => _mode = i == 0 ? QbMode.learn : QbMode.exam),
          ),
          const SizedBox(height: 8),
          Text(_mode == QbMode.learn ? 'The answer and the explanation show after each question.' : 'Answers and explanations show at the end, like a real exam. You can go back and change an answer.', style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
          if (b.topics.length > 1) ...[
            title(tr('Topics')),
            Wrap(spacing: 8, runSpacing: 4, children: [
              FilterChip(label: Text('All'), selected: _topics.isEmpty, onSelected: (_) => setState(_topics.clear)),
              for (final t in b.topics)
                FilterChip(
                  label: m.Text(t),
                  selected: _topics.contains(t),
                  onSelected: (v) => setState(() => v ? _topics.add(t) : _topics.remove(t)),
                ),
            ]),
          ],
          title(tr('Questions')),
          chips<String>([('all', tr('All')), ('new', tr('Not yet answered')), ('wrong', tr('Wrong last time')), ('flagged', tr('Flagged'))], (v) => _which == v, (v) => _which = v),
          title(tr('How many')),
          chips<int>([(10, '10'), (20, '20'), (40, '40'), (0, tr('All'))], (v) => _count == v, (v) => _count = v),
          if (_mode == QbMode.exam) ...[
            title(tr('Timer')),
            chips<int>([(0, tr('No timer')), (60, tr('1 min per question')), (90, tr('1.5 min')), (120, tr('2 min'))], (v) => _spq == v, (v) => _spq = v),
            if (_spq > 0 && n > 0) Padding(padding: const EdgeInsets.only(top: 6), child: Text(trp('{n} questions in {t} minutes. The timer starts when you press Start.', {'n': n, 't': (total / 60).ceil()}), style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant))),
          ],
          const SizedBox(height: 22),
          FilledButton.icon(
            key: const Key('qb_start'),
            onPressed: n == 0 ? null : () => Navigator.pop(context, _setup),
            icon: const Icon(Ph.play),
            label: m.Text(n == 0 ? tr('No question matches') : trp('Start ({n} questions)', {'n': n})),
          ),
        ]),
      ),
    );
  }
}

// ================================================================================================ the session

String _clock(int secs) {
  final s = secs < 0 ? 0 : secs;
  return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
}

class QbSessionScreen extends StatefulWidget {
  final QbBank bank;
  final List<QbQuestion> questions;
  final QbSetup setup;

  /// Review of a finished session: the answers given are shown with the correct ones, nothing can be changed.
  final QbResult? review;
  const QbSessionScreen({super.key, required this.bank, required this.questions, required this.setup, this.review});

  @override
  State<QbSessionScreen> createState() => _QbSessionScreenState();
}

class _QbSessionScreenState extends State<QbSessionScreen> {
  int _i = 0;
  final Map<String, Set<String>> _chosen = {};
  final Set<String> _checked = {};
  final Map<String, Set<String>> _struck = {};
  late final Set<String> _flagged;
  int _elapsed = 0;
  Timer? _timer;
  bool _finishing = false;
  double _font = 1.0;

  bool get _review => widget.review != null;
  bool get _exam => widget.setup.mode == QbMode.exam && !_review;
  int get _limit => _exam ? widget.setup.secondsPerQuestion * widget.questions.length : 0;
  QbQuestion get _q => widget.questions[_i];

  @override
  void initState() {
    super.initState();
    _flagged = {for (final q in widget.questions) if (QbProgress.flagged(widget.bank.id, q.id)) q.id};
    final f = store.settings['qbFont'];
    if (f is num) _font = f.toDouble().clamp(0.9, 1.5);
    final r = widget.review;
    if (r != null) {
      for (final row in r.rows) {
        _chosen[row.qid] = {...row.chosen};
        _checked.add(row.qid);
      }
    } else {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || _finishing) return;
        setState(() => _elapsed++);
        if (_limit > 0 && _elapsed >= _limit) _finish(timedOut: true);
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  bool _isChecked(QbQuestion q) => _checked.contains(q.id);
  Set<String> _sel(QbQuestion q) => _chosen[q.id] ?? <String>{};

  void _toggle(QbQuestion q, String key) {
    if (_review || (!_exam && _isChecked(q))) return;
    setState(() {
      final s = {..._sel(q)};
      if (q.multi) {
        s.contains(key) ? s.remove(key) : s.add(key);
      } else {
        s
          ..clear()
          ..add(key);
      }
      _chosen[q.id] = s;
    });
  }

  Future<void> _check() async {
    final q = _q;
    if (_sel(q).isEmpty) return;
    setState(() => _checked.add(q.id));
    // in learn mode the progress is kept at once, so leaving half way loses nothing
    await QbProgress.record(widget.bank.id, q.id, q.isCorrect(_sel(q)));
  }

  Future<void> _flag() async {
    final q = _q;
    final v = !_flagged.contains(q.id);
    setState(() => v ? _flagged.add(q.id) : _flagged.remove(q.id));
    await QbProgress.setFlag(widget.bank.id, q.id, v);
  }

  Future<void> _note() async {
    final q = _q;
    final t = await askText(context, 'Note on this question', hint: 'Write anything you want to remember');
    if (t == null) return;
    await QbProgress.setNote(widget.bank.id, q.id, t);
    if (mounted) setState(() {});
  }

  void _go(int to) {
    if (to < 0 || to >= widget.questions.length) return;
    setState(() => _i = to);
  }

  Future<void> _fontSheet() async {
    var v = _font;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              const Icon(Ph.textAa, size: 18),
              Expanded(
                child: Slider(
                  value: v,
                  min: 0.9,
                  max: 1.5,
                  divisions: 6,
                  onChanged: (x) {
                    set(() => v = x);
                    setState(() => _font = x);
                  },
                ),
              ),
              const Icon(Ph.textAa, size: 28),
            ]),
          ]),
        ),
      ),
    );
    store.settings['qbFont'] = _font;
    await store.saveSettings();
  }

  Future<void> _navigator() async {
    final to = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) {
        final cs = Theme.of(ctx).colorScheme;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 14, runSpacing: 4, children: [
                _legend(cs.primaryContainer, tr('Answered')),
                _legend(cs.surfaceContainerHighest, tr('Not answered')),
                _legend(Sem.star, tr('Flagged')),
              ]),
              const SizedBox(height: 12),
              Flexible(
                child: SingleChildScrollView(
                  child: Wrap(spacing: 8, runSpacing: 8, children: [
                    for (var k = 0; k < widget.questions.length; k++)
                      InkWell(
                        key: ValueKey('qb_nav_$k'),
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => Navigator.pop(ctx, k),
                        child: Container(
                          width: 46,
                          height: 46,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: _sel(widget.questions[k]).isNotEmpty ? cs.primaryContainer : cs.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: k == _i ? cs.primary : (_flagged.contains(widget.questions[k].id) ? Sem.star : Colors.transparent), width: 2),
                          ),
                          child: m.Text('${k + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        ),
                      ),
                  ]),
                ),
              ),
            ]),
          ),
        );
      },
    );
    if (to != null) _go(to);
  }

  Widget _legend(Color c, String label) => Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 14, height: 14, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(4))),
        const SizedBox(width: 6),
        m.Text(label, style: const TextStyle(fontSize: 12.5)),
      ]);

  Future<void> _finish({bool timedOut = false}) async {
    if (_finishing || _review) return;
    if (!timedOut) {
      final open = widget.questions.where((q) => _sel(q).isEmpty).length;
      final msg = open > 0 ? trp('{n} questions have no answer. Finish anyway?', {'n': open}) : tr('Finish and see the result?');
      final ok = await confirmDialog(context, msg, action: 'Finish');
      if (!ok || !mounted) return;
    }
    _finishing = true;
    _timer?.cancel();
    final rows = [
      for (final q in widget.questions) QbAnswerRow(q.id, q.topic.trim(), _sel(q), q.isCorrect(_sel(q)), _flagged.contains(q.id)),
    ];
    final r = QbResult(widget.bank, widget.setup.mode, widget.questions, rows, _elapsed, _limit);
    // learn mode already kept the progress question by question; exam mode keeps it now
    await saveQbSession(r, progress: widget.setup.mode == QbMode.exam);
    if (!mounted) return;
    if (timedOut) snack(context, tr('Time is up.'));
    Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => QbResultScreen(result: r)));
  }

  Future<bool> _confirmLeave() async {
    if (_review || _finishing) return true;
    if (_chosen.values.every((s) => s.isEmpty)) return true;
    return confirmDialog(context, _exam ? tr('Leave the exam? Your answers will not be saved.') : tr('Leave? The questions you checked are already saved.'), action: 'Leave');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final q = _q;
    final n = widget.questions.length;
    final answered = widget.questions.where((x) => _sel(x).isNotEmpty).length;
    final showResult = _review || (!_exam && _isChecked(q));
    final left = _limit - _elapsed;
    return PopScope(
      canPop: _review || _finishing || _chosen.values.every((s) => s.isEmpty),
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final ok = await _confirmLeave();
        if (ok && mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: m.Text('${_i + 1} / $n', style: const TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            if (_exam && _limit > 0)
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 4),
                child: Chip(
                  key: const Key('qb_timer'),
                  visualDensity: VisualDensity.compact,
                  avatar: Icon(Ph.timer, size: 16, color: left < _limit * 0.2 ? Sem.danger : cs.onSurfaceVariant),
                  label: m.Text(_clock(left), style: TextStyle(fontWeight: FontWeight.w800, color: left < _limit * 0.2 ? Sem.danger : null)),
                ),
              ),
            IconButton(key: const Key('qb_flag'), tooltip: tr('Flag for review'), icon: Icon(_flagged.contains(q.id) ? PhFill.flag : Ph.flag, color: _flagged.contains(q.id) ? Sem.star : null), onPressed: _flag),
            PopupMenuButton<String>(
              key: const Key('qb_menu'),
              icon: const Icon(Ph.dotsThreeVertical),
              onSelected: (v) {
                switch (v) {
                  case 'note':
                    _note();
                  case 'font':
                    _fontSheet();
                  case 'list':
                    _navigator();
                  case 'finish':
                    _finish();
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'note', child: Text('Note')),
                PopupMenuItem(value: 'font', child: Text('Text size')),
                PopupMenuItem(value: 'list', child: Text('All questions')),
                if (!_review) PopupMenuItem(value: 'finish', child: Text('Finish')),
              ],
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(6),
            child: Column(children: [
              LinearProgressIndicator(value: n == 0 ? 0 : answered / n, minHeight: 3, backgroundColor: cs.surfaceContainerHighest),
              if (_exam && _limit > 0)
                LinearProgressIndicator(value: (left / _limit).clamp(0.0, 1.0), minHeight: 3, color: left < _limit * 0.2 ? Sem.danger : cs.tertiary, backgroundColor: cs.surfaceContainerHighest)
              else
                const SizedBox(height: 3),
            ]),
          ),
        ),
        body: ListView(
          key: ValueKey('qb_q_${q.id}'),
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
          children: [
            if (q.topic.trim().isNotEmpty)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: Chip(visualDensity: VisualDensity.compact, label: m.Text(q.topic, style: const TextStyle(fontSize: 12.5)), avatar: const Icon(Ph.tag, size: 14)),
              ),
            const SizedBox(height: 6),
            _stem(q),
            if (q.image.isNotEmpty && File(QuestionBank.imagePath(widget.bank.id, q.image)).existsSync())
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: ClipRRect(borderRadius: BorderRadius.circular(12), child: InteractiveViewer(child: Image.file(File(QuestionBank.imagePath(widget.bank.id, q.image))))),
              ),
            if (q.multi)
              Padding(padding: const EdgeInsets.only(top: 10), child: Text('Select all that apply.', style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700))),
            const SizedBox(height: 12),
            for (final o in q.options) _option(q, o, showResult),
            if (showResult) _explanation(q),
            if (QbProgress.note(widget.bank.id, q.id).isNotEmpty) _noteCard(q),
          ],
        ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Row(children: [
              if (_i > 0 && (_exam || _review || _isChecked(q)))
                Padding(padding: const EdgeInsetsDirectional.only(end: 8), child: OutlinedButton(key: const Key('qb_prev'), onPressed: () => _go(_i - 1), child: const Icon(Ph.caretLeft))),
              Expanded(child: _primary(q, n)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _primary(QbQuestion q, int n) {
    final last = _i == n - 1;
    if (_review) {
      return FilledButton(key: const Key('qb_next'), onPressed: last ? () => Navigator.pop(context) : () => _go(_i + 1), child: Text(last ? 'Done' : 'Next'));
    }
    if (_exam) {
      return FilledButton(key: const Key('qb_next'), onPressed: last ? _finish : () => _go(_i + 1), child: Text(last ? 'Finish' : 'Next'));
    }
    if (!_isChecked(q)) {
      return FilledButton(key: const Key('qb_check'), onPressed: _sel(q).isEmpty ? null : _check, child: Text('Check answer'));
    }
    return FilledButton(key: const Key('qb_next'), onPressed: last ? _finish : () => _go(_i + 1), child: Text(last ? 'Finish' : 'Next'));
  }

  Widget _stem(QbQuestion q) {
    final dir = textDirectionFor(q.text) ?? TextDirection.ltr;
    return Directionality(
      textDirection: dir,
      child: SelectableText(q.text, textAlign: TextAlign.start, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontSize: 17 * _font, height: 1.5, fontWeight: FontWeight.w600)),
    );
  }

  Widget _option(QbQuestion q, QbOption o, bool showResult) {
    final cs = Theme.of(context).colorScheme;
    final sel = _sel(q).contains(o.key);
    final struck = (_struck[q.id] ?? const <String>{}).contains(o.key);
    final correct = q.answer.contains(o.key);
    Color border = cs.outlineVariant;
    Color? fill;
    IconData? mark;
    Color? markColor;
    if (showResult) {
      if (correct) {
        border = Sem.success;
        fill = Sem.success.withAlpha(30);
        mark = PhFill.checkCircle;
        markColor = Sem.success;
      } else if (sel) {
        border = Sem.danger;
        fill = Sem.danger.withAlpha(30);
        mark = PhFill.xCircle;
        markColor = Sem.danger;
      }
    } else if (sel) {
      border = cs.primary;
      fill = cs.primaryContainer.withAlpha(150);
    }
    final dir = textDirectionFor(o.text) ?? TextDirection.ltr;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 150),
        opacity: struck && !showResult ? 0.45 : 1,
        child: Material(
          color: fill ?? cs.surfaceContainerLow,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: border, width: sel || (showResult && correct) ? 2 : 1)),
          child: InkWell(
            key: ValueKey('qb_opt_${o.key}'),
            borderRadius: BorderRadius.circular(16),
            onTap: () => _toggle(q, o.key),
            onLongPress: _review || showResult ? null : () => setState(() => ((_struck[q.id] ??= <String>{}).contains(o.key)) ? _struck[q.id]!.remove(o.key) : _struck[q.id]!.add(o.key)),
            child: Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(12, 10, 6, 10),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: q.multi ? BoxShape.rectangle : BoxShape.circle, borderRadius: q.multi ? BorderRadius.circular(8) : null, color: sel ? cs.primary : cs.surfaceContainerHighest),
                  child: m.Text(o.key, style: TextStyle(fontWeight: FontWeight.w800, color: sel ? cs.onPrimary : cs.onSurface)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Directionality(
                    textDirection: dir,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: m.Text(o.text, style: TextStyle(fontSize: 16 * _font, height: 1.4, decoration: struck && !showResult ? TextDecoration.lineThrough : null)),
                    ),
                  ),
                ),
                if (mark != null) Padding(padding: const EdgeInsets.only(top: 3, left: 4, right: 4), child: Icon(mark, color: markColor, size: 24)),
                if (!showResult && !_review)
                  IconButton(
                    tooltip: tr('Cross out'),
                    visualDensity: VisualDensity.compact,
                    icon: Icon(Ph.textStrikethrough, size: 18, color: struck ? cs.primary : cs.onSurfaceVariant),
                    onPressed: () => setState(() => ((_struck[q.id] ??= <String>{}).contains(o.key)) ? _struck[q.id]!.remove(o.key) : _struck[q.id]!.add(o.key)),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _explanation(QbQuestion q) {
    final cs = Theme.of(context).colorScheme;
    final ok = q.isCorrect(_sel(q));
    final answered = _sel(q).isNotEmpty;
    final dir = textDirectionFor(q.explanation) ?? TextDirection.ltr;
    return Container(
      key: const Key('qb_explanation'),
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: cs.surfaceContainerHigh, borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(!answered ? Ph.minusCircle : (ok ? PhFill.checkCircle : PhFill.xCircle), color: !answered ? cs.onSurfaceVariant : (ok ? Sem.success : Sem.danger)),
          const SizedBox(width: 8),
          Expanded(child: m.Text(!answered ? tr('Not answered') : (ok ? tr('Correct') : tr('Not correct')), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          m.Text('${tr('Answer')}: ${q.answer.join(', ')}', style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 10),
        if (q.explanation.isEmpty)
          Text('There is no explanation in the file for this question.', style: TextStyle(color: cs.onSurfaceVariant))
        else
          Directionality(textDirection: dir, child: SelectableText(q.explanation, style: TextStyle(fontSize: 15.5 * _font, height: 1.5))),
      ]),
    );
  }

  Widget _noteCard(QbQuestion q) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: cs.tertiaryContainer.withAlpha(120), borderRadius: BorderRadius.circular(14)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Ph.notePencil, size: 18),
        const SizedBox(width: 8),
        Expanded(child: m.Text(QbProgress.note(widget.bank.id, q.id))),
      ]),
    );
  }
}

// ================================================================================================ the result

class QbResultScreen extends StatelessWidget {
  final QbResult result;
  const QbResultScreen({super.key, required this.result});

  void _review(BuildContext context, {required bool onlyMistakes}) {
    final rows = [for (final r in result.rows) if (!onlyMistakes || !r.correct) r];
    final qs = [for (final r in rows) result.questions.firstWhere((q) => q.id == r.qid)];
    if (qs.isEmpty) return;
    final sub = QbResult(result.bank, result.mode, qs, rows, result.seconds, result.limitSeconds);
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => QbSessionScreen(bank: result.bank, questions: qs, setup: QbSetup(mode: result.mode), review: sub)));
  }

  void _again(BuildContext context) {
    final qs = [for (final r in result.rows) if (!r.correct) result.questions.firstWhere((q) => q.id == r.qid)];
    if (qs.isEmpty) return;
    Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => QbSessionScreen(bank: result.bank, questions: qs, setup: const QbSetup(mode: QbMode.learn))));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final pct = result.percent;
    final good = pct >= 70;
    final topics = result.byTopic.entries.toList()..sort((a, b) => (a.value[1] / a.value[0]).compareTo(b.value[1] / b.value[0]));
    return Scaffold(
      appBar: AppBar(title: Text('Result'), automaticallyImplyLeading: false),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 32), children: [
        Center(
          child: AnimatedRing(
            result.total == 0 ? 0 : result.right / result.total,
            size: 150,
            color: good ? Sem.success : (pct >= 50 ? Sem.warning : Sem.danger),
            center: Column(mainAxisSize: MainAxisSize.min, children: [
              m.Text('${pct.round()}%', style: tt.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
              m.Text('${result.right} / ${result.total}', style: TextStyle(color: cs.onSurfaceVariant)),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        Row(children: [
          _stat(context, Ph.checkCircle, tr('Right'), '${result.right}', Sem.success),
          _stat(context, Ph.xCircle, tr('Wrong'), '${result.wrong}', Sem.danger),
          _stat(context, Ph.minusCircle, tr('Not answered'), '${result.omitted}', cs.onSurfaceVariant),
          _stat(context, Ph.timer, tr('Time'), _clock(result.seconds), cs.primary),
        ]),
        if (result.timedOut)
          Padding(padding: const EdgeInsets.only(top: 10), child: Text('The time ran out before you finished.', textAlign: TextAlign.center, style: TextStyle(color: Sem.warning, fontWeight: FontWeight.w700))),
        if (topics.length > 1) ...[
          const SizedBox(height: 22),
          Text('By topic', style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final t in topics)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: m.Text(t.key, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: textDirectionFor(t.key), style: const TextStyle(fontWeight: FontWeight.w600))),
                  m.Text('${t.value[1]} / ${t.value[0]}', style: TextStyle(color: cs.onSurfaceVariant)),
                ]),
                const SizedBox(height: 4),
                AnimatedBar(t.value[1] / t.value[0], height: 7, color: t.value[1] / t.value[0] >= 0.7 ? Sem.success : (t.value[1] / t.value[0] >= 0.5 ? Sem.warning : Sem.danger)),
              ]),
            ),
        ],
        const SizedBox(height: 24),
        if (result.right < result.total) ...[
          FilledButton.icon(key: const Key('qb_review_wrong'), onPressed: () => _review(context, onlyMistakes: true), icon: const Icon(Ph.eye), label: Text('Review the mistakes')),
          const SizedBox(height: 8),
          OutlinedButton.icon(key: const Key('qb_again'), onPressed: () => _again(context), icon: const Icon(Ph.arrowsClockwise), label: Text('Practise the wrong ones again')),
          const SizedBox(height: 8),
        ],
        OutlinedButton.icon(key: const Key('qb_review_all'), onPressed: () => _review(context, onlyMistakes: false), icon: const Icon(Ph.listMagnifyingGlass), label: Text('Review all questions')),
        const SizedBox(height: 8),
        TextButton(key: const Key('qb_done'), onPressed: () => Navigator.pop(context), child: Text('Done')),
      ]),
    );
  }

  Widget _stat(BuildContext context, IconData icon, String label, String value, Color color) => Expanded(
        child: Column(children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(height: 4),
          m.Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          m.Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
      );
}
