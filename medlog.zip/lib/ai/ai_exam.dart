import 'dart:math';

import '../library.dart';
import '../plan_scope.dart';
import '../quiz_gate.dart';
import 'ai_api.dart';
import 'ai_quiz.dart';

/// The mock exam is written by the AI from the person's own library: from the books chosen, from the plan, or from what
/// a typed name finds. The questions are checked like every AI question (they must quote the text, a second look checks
/// the key) and are kept in the AI question bank. Offline, or with the AI off, only questions already saved in the bank
/// can be used.

class ExamScope {
  /// Books / courses chosen (pack ids).
  final Set<String> packIds;

  /// The books of the running plans.
  final bool plan;

  /// A name or topic typed by the person: the library is searched for it.
  final String query;
  const ExamScope({this.packIds = const {}, this.plan = false, this.query = ''});

  bool get isEmpty => packIds.isEmpty && !plan && query.trim().isEmpty;
}

class ExamBuild {
  final List<QuizQ> qs;

  /// 'ok' | 'aiOff' | 'offline' | 'capped' | 'none' (nothing to write questions from) | 'few'.
  final String status;

  /// Some or all of the questions came from the saved AI bank.
  final bool fromBank;
  const ExamBuild(this.qs, this.status, {this.fromBank = false});
}

/// An AI question as a mock-exam question (multiple choice only).
QuizQ? examQuestionOf(AiQ q) {
  if (q.isShort || q.options.length < 2) return null;
  return QuizQ(
    kind: q.isTf ? QKind.trueFalse : QKind.definition,
    stem: q.stem,
    options: q.options,
    answer: q.answer.clamp(0, q.options.length - 1),
    explanation: [q.explanation, if (q.quote.isNotEmpty) '“${q.quote}”'].where((e) => e.trim().isNotEmpty).join('\n\n'),
    packId: q.packId,
    title: q.title,
    index: q.index,
    section: q.section,
    group: q.group,
  );
}

bool _inScope(AiQ q, ExamScope sc, Set<String> planBooks) {
  if (sc.isEmpty) return true;
  if (sc.plan && planBooks.contains(q.packId)) return true;
  if (sc.packIds.contains(q.packId)) return true;
  final n = aiNorm(sc.query);
  return n.isNotEmpty && (aiNorm(q.topic).contains(n) || aiNorm(q.title).contains(n) || aiNorm(q.stem).contains(n));
}

/// The articles questions can be written from, the most wanted first: what a typed name finds, the chapters due in the
/// plan, then the chosen books (articles mixed). With nothing chosen: the books and files of the person.
Future<List<AiTarget>> examTargets(ExamScope sc, {Random? rnd}) async {
  final r = rnd ?? Random();
  final out = <AiTarget>[];
  final seen = <String>{};
  void add(String packId, int index, String title) {
    if (seen.add('$packId|$index')) out.add(AiTarget(packId, index, title));
  }

  final q = sc.query.trim();
  if (q.isNotEmpty) {
    final hits = await library.searchEx(q, limit: 24, concise: true);
    for (final h in hits) {
      if (sc.packIds.isNotEmpty && !sc.packIds.contains(h.packId) && !sc.plan) continue;
      add(h.packId, h.index, h.title);
    }
  }
  if (sc.plan) {
    final ps = await currentPlanScope();
    for (final a in await planArticles(ps)) {
      add(a.packId, a.index, a.title);
    }
  }
  var packs = sc.packIds.toList();
  if (sc.isEmpty) {
    packs = [for (final p in library.textPacks) if (p.kind == 'book' || p.kind == 'user') p.id];
    if (packs.isEmpty) packs = [for (final p in library.textPacks) p.id];
  }
  // the chosen books: their articles mixed, so the exam is not about one chapter only
  final lists = <List<(String, int, String)>>[];
  for (final id in packs) {
    final titles = await library.titlesOf(id);
    final idx = List<int>.generate(titles.length, (i) => i)..shuffle(r);
    lists.add([for (final i in idx.take(40)) (id, i, titles[i])]);
  }
  for (var k = 0; k < 40; k++) {
    for (final l in lists) {
      if (k < l.length) add(l[k].$1, l[k].$2, l[k].$3);
    }
  }
  return out;
}

/// Writes the exam: [count] multiple-choice questions. [progress] is told (done, wanted) after each request.
Future<ExamBuild> buildAiExam({required int count, required ExamScope scope, AiRunner? runner, void Function(int done, int wanted)? progress, Random? rnd}) async {
  final planBooks = scope.plan ? (await currentPlanScope()).packIds.toSet() : <String>{};
  List<QuizQ> fromBank() {
    final bank = [for (final q in aiBank()) if (_inScope(q, scope, planBooks)) q]..shuffle(rnd ?? Random());
    return [for (final q in bank) examQuestionOf(q)].whereType<QuizQ>().take(count).toList();
  }

  final aiOn = Ai.enabled || runner != null;
  if (!aiOn) {
    final b = fromBank();
    return ExamBuild(b, b.length >= 5 ? 'ok' : 'aiOff', fromBank: b.isNotEmpty);
  }
  final run = runner ?? ((r) => Ai.run(r));
  final targets = await examTargets(scope, rnd: rnd);
  if (targets.isEmpty) return ExamBuild(const [], 'none');
  final got = <QuizQ>[];
  final used = <String>{};
  var status = 'ok';
  var tries = 0;
  final per = count <= 10 ? count : 10;
  for (final t in targets) {
    if (got.length >= count || tries >= 8) break;
    if (aiRequestsToday() >= aiDailyCap()) {
      status = 'capped';
      break;
    }
    final art = await library.read(t.packId, t.index);
    if (art == null) continue;
    final chars = art.sections.fold<int>(0, (n, s) => n + s.text.length);
    if (chars < 1500 || chars > 30000) continue;
    tries++;
    final ps = await passagesOf(t.packId, t.index);
    final rep = await generateFromPassages(ps, count: min(per, count - got.length + 2), runner: run);
    if (rep.offline) {
      status = 'offline';
      break;
    }
    for (final q in rep.added) {
      final eq = examQuestionOf(q);
      if (eq != null && used.add(eq.hash)) got.add(eq);
    }
    progress?.call(min(got.length, count), count);
  }
  if (got.length < count && (status == 'offline' || status == 'capped' || got.length < 5)) {
    // the saved AI questions fill what the AI could not write now
    for (final q in fromBank()) {
      if (got.length >= count) break;
      if (used.add(q.hash)) got.add(q);
    }
    if (got.isNotEmpty && status == 'ok') status = got.length >= 5 ? 'ok' : 'few';
  }
  if (got.length < 5 && status == 'ok') status = 'few';
  got.shuffle(rnd ?? Random());
  return ExamBuild(got.take(count).toList(), status, fromBank: false);
}
