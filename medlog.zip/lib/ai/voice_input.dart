import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:speech_to_text/speech_recognition_error.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../i18n.dart';
import '../med_terms.dart' show kMedTerms;
import '../ref_data.dart';
import 'ai_api.dart';
import '../widgets.dart' show snack;

/// Voice dictation (optional convenience, works on-device or through the phone's recogniser; nothing here uses
/// MedLog's AI provider). Use [VoiceInputButton] next to any TextField:
///
///     VoiceInputButton(controller: _answer)
///
/// The text recognised so far is written into [controller] while the user speaks (partial results). If the
/// recogniser is missing, offline without a language pack, or the microphone permission is denied, the button
/// shows a short message and the keyboard keeps working: nothing else depends on it.
///
/// Tests replace [VoiceInput.engine] with a fake [VoiceEngine].
abstract class VoiceEngine {
  /// True when recognition can start (recogniser exists and the permission was granted).
  Future<bool> init({void Function(String error)? onError, void Function(String status)? onStatus});
  Future<List<String>> locales();
  Future<void> start({required String localeId, required void Function(String text, bool isFinal) onText});
  Future<void> stop();
  bool get listening;
}

class SttEngine implements VoiceEngine {
  final SpeechToText _stt = SpeechToText();
  bool _ready = false;

  @override
  Future<bool> init({void Function(String error)? onError, void Function(String status)? onStatus}) async {
    try {
      _ready = await _stt.initialize(
        onError: (SpeechRecognitionError e) => onError?.call(e.errorMsg),
        onStatus: (s) => onStatus?.call(s),
      );
    } catch (_) {
      _ready = false;
    }
    return _ready;
  }

  @override
  Future<List<String>> locales() async {
    try {
      return [for (final l in await _stt.locales()) l.localeId];
    } catch (_) {
      return const [];
    }
  }

  @override
  Future<void> start({required String localeId, required void Function(String text, bool isFinal) onText}) async {
    await _stt.listen(
      onResult: (SpeechRecognitionResult r) => onText(VoiceInput.bestAlternate([r.recognizedWords, for (final a in r.alternates) a.recognizedWords]), r.finalResult),
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: ListenMode.dictation,
        localeId: localeId,
        pauseFor: const Duration(seconds: 6),
        listenFor: const Duration(minutes: 2),
      ),
    );
  }

  @override
  Future<void> stop() async {
    try {
      await _stt.stop();
    } catch (_) {}
  }

  @override
  bool get listening => _stt.isListening;
}

class VoiceInput {
  /// Replaceable in tests.
  static VoiceEngine engine = SttEngine();

  static Set<String> _vocab = {for (final k in kMedTerms.keys) ...k.toLowerCase().split(RegExp(r'[^a-z]+')).where((w) => w.length > 3)};
  static bool _vocabLoaded = false;

  /// Adds the words of the reviewed glossary to the list of medical words (best effort, once).
  static Future<void> loadVocab() async {
    if (_vocabLoaded) return;
    _vocabLoaded = true;
    try {
      for (final t in await RefData.glossary()) {
        for (final w in '${t['en']}'.toLowerCase().split(RegExp(r'[^a-z]+'))) {
          if (w.length > 3) _vocab.add(w);
        }
      }
    } catch (_) {}
  }

  /// How many words of [text] are known medical words.
  static int medScore(String text, [Set<String>? vocab]) {
    final v = vocab ?? _vocab;
    var n = 0;
    for (final w in text.toLowerCase().split(RegExp(r'[^a-z]+'))) {
      if (w.length > 3 && v.contains(w)) n++;
    }
    return n;
  }

  /// The recogniser gives its best guess first and other guesses after it. The first stays unless another guess
  /// contains clearly more medical words (e.g. "hypertension" instead of "hyper tension").
  static String bestAlternate(List<String> alts, {Set<String>? vocab}) {
    final list = [for (final a in alts) if (a.trim().isNotEmpty) a];
    if (list.isEmpty) return '';
    var best = list.first;
    var top = medScore(best, vocab);
    for (final a in list.skip(1)) {
      final sc = medScore(a, vocab);
      if (sc > top) {
        best = a;
        top = sc;
      }
    }
    return best;
  }

  /// Asks the AI to correct misheard medical words in a dictated text, without adding or removing content.
  /// Returns null when AI is off / offline / failed.
  static Future<String?> fixMedicalTerms(String text) async {
    if (text.trim().isEmpty || !Ai.enabled) return null;
    final r = await Ai.run(AiRequest(
      feature: 'voice_fix',
      system: 'You correct speech-recognition mistakes in a doctor\'s dictated note. Fix only misheard or split medical terms, drug names and abbreviations. Do NOT add, remove, summarise or reorder anything, keep the language and the line breaks. Return ONLY the corrected text.',
      prompt: text,
      level: AiLevel.none,
      maxTokens: 900,
      temperature: 0.0,
    ));
    if (!r.ok) return null;
    final t = r.text.trim();
    return t.isEmpty ? null : t;
  }

  /// 'ar-JO' for the Arabic app, 'en-US' otherwise, matched against what the device offers
  /// (Android lists 'ar_JO', iOS 'ar-JO'; any Arabic / English variant is accepted when the exact one is missing).
  static String pickLocale(List<String> available, {bool? arabic}) {
    final ar = arabic ?? isAr;
    final want = ar ? 'ar-JO' : 'en-US';
    final lang = ar ? 'ar' : 'en';
    String n(String s) => s.replaceAll('_', '-').toLowerCase();
    for (final l in available) {
      if (n(l) == want.toLowerCase()) return l;
    }
    for (final l in available) {
      if (n(l).startsWith('$lang-') || n(l) == lang) return l;
    }
    return want.replaceAll('-', '_');
  }

  /// Message for an error code of the recogniser (permission, no network, nothing heard...).
  static String messageFor(String error) {
    final e = error.toLowerCase();
    if (e.contains('permission')) return tr('Microphone permission was denied. You can allow it in the phone settings, or type instead.');
    if (e.contains('no_match') || e.contains('speech_timeout')) return tr('Nothing was heard. Try again, or type instead.');
    if (e.contains('network')) return tr('Voice input needs a language pack or internet on this phone. You can type instead.');
    return tr('Voice input is not available right now. You can type instead.');
  }
}

class VoiceInputButton extends StatefulWidget {
  final TextEditingController controller;

  /// Called after the text changed because of dictation (so the screen can enable its Send button).
  final VoidCallback? onChanged;

  /// Force the dictation language (default: follows the app language).
  final bool? arabic;
  final double size;
  const VoiceInputButton({super.key, required this.controller, this.onChanged, this.arabic, this.size = 24});

  @override
  State<VoiceInputButton> createState() => _VoiceInputButtonState();
}

class _VoiceInputButtonState extends State<VoiceInputButton> {
  bool _on = false;
  bool _busy = false;
  bool _dictated = false;
  bool _fixing = false;
  String _base = '';

  Future<void> _fix() async {
    setState(() => _fixing = true);
    final fixed = await VoiceInput.fixMedicalTerms(widget.controller.text);
    if (!mounted) return;
    setState(() => _fixing = false);
    if (fixed == null) {
      snack(context, tr('The AI could not help now.'));
      return;
    }
    widget.controller.value = TextEditingValue(text: fixed, selection: TextSelection.collapsed(offset: fixed.length));
    widget.onChanged?.call();
    snack(context, tr('Medical terms checked.'));
  }

  @override
  void dispose() {
    if (_on) VoiceInput.engine.stop();
    super.dispose();
  }

  void _fail(String error) {
    if (!mounted) return;
    setState(() {
      _on = false;
      _busy = false;
    });
    snack(context, VoiceInput.messageFor(error));
  }

  Future<void> _toggle() async {
    if (_busy) return;
    final eng = VoiceInput.engine;
    if (_on) {
      await eng.stop();
      if (mounted) setState(() => _on = false);
      return;
    }
    setState(() => _busy = true);
    String? err;
    bool ok = false;
    try {
      ok = await eng.init(onError: (e) => err = e, onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && mounted && _on) setState(() => _on = false);
      });
    } catch (e) {
      ok = false;
    }
    if (!mounted) return;
    if (!ok) {
      _fail(err ?? 'unavailable');
      return;
    }
    VoiceInput.loadVocab();
    final loc = VoiceInput.pickLocale(await eng.locales(), arabic: widget.arabic);
    _base = widget.controller.text;
    try {
      await eng.start(
        localeId: loc,
        onText: (text, isFinal) {
          if (!mounted) return;
          final sep = _base.isEmpty || _base.endsWith(' ') || _base.endsWith('\n') ? '' : ' ';
          final t = '$_base$sep$text';
          widget.controller.value = TextEditingValue(text: t, selection: TextSelection.collapsed(offset: t.length));
          widget.onChanged?.call();
          if (isFinal) {
            _base = t;
            setState(() {
              _on = false;
              _dictated = true;
            });
          }
        },
      );
    } catch (_) {
      _fail('unavailable');
      return;
    }
    if (mounted) {
      setState(() {
        _busy = false;
        _on = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final mic = IconButton(
      key: const ValueKey('voiceInput'),
      tooltip: _on ? tr('Stop dictation') : tr('Dictate with your voice'),
      iconSize: widget.size,
      color: _on ? cs.error : null,
      icon: Icon(_on ? Icons.mic : Icons.mic_none),
      onPressed: _busy ? null : _toggle,
    );
    if (!_dictated || _on) return mic;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      IconButton(
        key: const ValueKey('voiceFix'),
        tooltip: tr('Fix medical terms'),
        iconSize: widget.size,
        icon: _fixing ? SizedBox(width: widget.size - 6, height: widget.size - 6, child: const CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.spellcheck),
        onPressed: _fixing ? null : _fix,
      ),
      mic,
    ]);
  }
}
