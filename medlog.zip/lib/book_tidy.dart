import 'library.dart';

/// Repairs, for display, what the PDF extraction of a book leaves in an article: a list that was cut by a table (its
/// rest ends up in a "Key facts and margin notes" section), the same section twice, and margin notes repeated. Nothing
/// is invented or translated: lines are only moved, joined or left out when an identical line is already there.

const String kMarginHeading = 'Key facts and margin notes';

String _norm(String s) => s.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();

String _headKey(String h) {
  final words = _norm(h).split(' ');
  if (words.isEmpty) return '';
  final last = words.last;
  if (last.length > 3 && last.endsWith('s') && !last.endsWith('ss')) words[words.length - 1] = last.substring(0, last.length - 1);
  return words.join(' ');
}

bool _isBullet(String l) => l.trimLeft().startsWith('•');
bool _isMarker(String l) {
  final t = l.trimLeft();
  return t.startsWith('KEY FACT') || t.startsWith('MNEMONIC');
}

bool _isMargin(LibSection s) => _norm(s.heading) == _norm(kMarginHeading);

/// Joins [extra] to [base], leaving out the lines of [extra] that [base] already has.
String _mergeText(String base, String extra) {
  final have = {for (final l in base.split('\n')) if (_norm(l).isNotEmpty) _norm(l)};
  final add = <String>[];
  for (final l in extra.split('\n')) {
    final n = _norm(l);
    if (n.isEmpty) continue;
    // short bullets can repeat legitimately inside different lists; only long lines and whole-paragraph repeats are dropped
    if (have.contains(n) && n.length > 24) continue;
    add.add(l);
  }
  if (add.isEmpty) return base;
  return base.trimRight().isEmpty ? add.join('\n') : '${base.trimRight()}\n${add.join('\n')}';
}

/// Share of the non-empty lines of [b] that [a] already has.
double _overlap(String a, String b) {
  final have = {for (final l in a.split('\n')) if (_norm(l).isNotEmpty) _norm(l)};
  final lines = [for (final l in b.split('\n')) if (_norm(l).isNotEmpty) _norm(l)];
  if (lines.isEmpty) return 1;
  return lines.where(have.contains).length / lines.length;
}

List<LibTable> _mergeTables(List<LibTable> a, List<LibTable> b) {
  final out = [...a];
  for (final t in b) {
    if (!out.any((e) => _norm(e.caption) == _norm(t.caption) && e.rows.length == t.rows.length)) out.add(t);
  }
  return out;
}

/// The bullets (with their wrapped lines) that open a margin-notes block after a case question: the rest of the list the
/// table interrupted. Returns (list lines, remaining lines) or null when the block does not look like one.
({List<String> list, List<String> rest})? _splitInterruptedList(String text) {
  final lines = text.split('\n');
  var i = 0;
  // the case question (no bullets) comes first
  while (i < lines.length && !_isBullet(lines[i]) && !_isMarker(lines[i])) {
    i++;
  }
  if (i >= lines.length || !_isBullet(lines[i])) return null;
  final head = lines.sublist(0, i);
  final list = <String>[];
  var j = i;
  while (j < lines.length) {
    final l = lines[j];
    if (_isBullet(l)) {
      list.add(l);
    } else if (_isMarker(l)) {
      break;
    } else if (list.isNotEmpty && RegExp(r'^\s*[a-z(]').hasMatch(l)) {
      list.add(l); // a wrapped line of the bullet above
    } else {
      break;
    }
    j++;
  }
  if (list.isEmpty) return null;
  return (list: list, rest: [...head, ...lines.sublist(j)]);
}

List<LibSection> tidyBookSections(List<LibSection> src) {
  var secs = [...src];

  // 1. a list cut by a table: list section, table section, margin notes whose first bullets continue the list
  for (var k = 2; k < secs.length; k++) {
    final cur = secs[k];
    final tab = secs[k - 1];
    final prev = secs[k - 2];
    if (!_isMargin(cur) || tab.tables.isEmpty || tab.text.trim().isNotEmpty) continue;
    final lastLine = prev.text.trimRight().split('\n').last;
    if (!_isBullet(lastLine) && !RegExp(r'^\s{2,}\S').hasMatch(lastLine)) continue;
    final sp = _splitInterruptedList(cur.text);
    if (sp == null) continue;
    secs[k - 2] = LibSection(prev.heading, '${prev.text.trimRight()}\n${sp.list.join('\n')}', prev.tables);
    final rest = sp.rest.join('\n').trim();
    secs[k] = LibSection(cur.heading, rest, cur.tables);
  }
  secs = [for (final s in secs) if (!(_isMargin(s) && s.text.trim().isEmpty && s.tables.isEmpty)) s];

  // 2. the same section twice: joined at the first place when they sit side by side or repeat most of each other
  //    (two "Differential" sections of two different diseases are not the same section and stay apart)
  final out = <LibSection>[];
  final at = <String, int>{};
  for (final s in secs) {
    final key = _headKey(s.heading);
    if (key.isEmpty || s.heading.trim().toLowerCase().startsWith('table ') || _isMargin(s)) {
      out.add(s);
      continue;
    }
    final i = at[key];
    final adjacent = out.isNotEmpty && _headKey(out.last.heading) == key;
    if (i != null && (adjacent || _overlap(out[i].text, s.text) >= 0.5)) {
      final f = out[i];
      out[i] = LibSection(f.heading, _mergeText(f.text, s.text), _mergeTables(f.tables, s.tables));
    } else {
      at[key] = out.length;
      out.add(s);
    }
  }

  // 3. margin notes: a line that an earlier margin-notes section of the article already shows is not shown again
  final seen = <String>{};
  final fin = <LibSection>[];
  for (final s in out) {
    if (!_isMargin(s)) {
      fin.add(s);
      continue;
    }
    final keep = <String>[];
    for (final l in s.text.split('\n')) {
      final n = _norm(l);
      if (n.isEmpty) continue;
      if (n.length > 24 && !seen.add(n)) continue;
      keep.add(l);
    }
    if (keep.isEmpty && s.tables.isEmpty) continue;
    fin.add(LibSection(s.heading, keep.join('\n'), s.tables));
  }
  return fin;
}

LibArticle tidyBookArticle(LibArticle a) => LibArticle(a.title, a.url, tidyBookSections(a.sections),
    source: a.source, license: a.license, authors: a.authors, date: a.date, chapter: a.chapter);
