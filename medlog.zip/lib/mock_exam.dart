import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'ai/ai_exam.dart';
import 'ai/ai_widgets.dart' show AiBuilder;
import 'app_icons.dart';
import 'data.dart';
import 'i18n.dart';
import 'lib_quiz.dart';
import 'library.dart';
import 'plan_scope.dart';
import 'screens_article.dart' show ArticleScreen;
import 'focus_pill.dart';
import 'study_tools.dart';
import 'ui.dart';
import 'widgets.dart';

/// A mock exam: a set number of questions from your own courses against the clock. Nothing is shown as right or wrong
/// until the end; questions can be flagged and revisited. The report gives the score, the time, the result by topic,
/// the slowest questions and everything to review. Wrong answers go into the mistake notebook and the weak topics.

/// What the exam produced, computed from the answers (pure, so it can be tested).
class MockResult {
  final List<QuizQ> qs;
  final List<int?> answers;
  final List<int> seconds; // time spent on each question
  final Set<int> flagged;
  final int usedSeconds;
  const MockResult(this.qs, this.answers, this.seconds, this.flagged, this.usedSeconds);

  int get answered => answers.where((a) => a != null).length;
  int get right => [for (var i = 0; i < qs.length; i++) if (answers[i] == qs[i].answer) 1].length;
  int get wrong => answered - right;
  int get skipped => qs.length - answered;
  double get ratio => qs.isEmpty ? 0 : right / qs.length;
  double get avgSeconds => answered == 0 ? 0 : seconds.fold<int>(0, (a, b) => a + b) / answered;

  /// topic -> (right, asked)
  Map<String, (int, int)> get byGroup {
    final out = <String, (int, int)>{};
    for (var i = 0; i < qs.length; i++) {
      final g = qs[i].group.isEmpty ? qs[i].shownTitle : qs[i].group;
      final c = out[g] ?? (0, 0);
      out[g] = (c.$1 + (answers[i] == qs[i].answer ? 1 : 0), c.$2 + 1);
    }
    return out;
  }

  /// The questions answered wrong or not at all, in exam order.
  List<int> get toReview => [for (var i = 0; i < qs.length; i++) if (answers[i] != qs[i].answer) i];

  List<int> get slowest {
    final idx = [for (var i = 0; i < qs.length; i++) if (answers[i] != null) i]..sort((a, b) => seconds[b].compareTo(seconds[a]));
    return idx.take(3).toList();
  }
}

class MockExamScreen extends StatefulWidget {
  static DateTime Function() clock = DateTime.now;

  /// Writes the questions (the AI, from the chosen sources). A seam for tests.
  static Future<ExamBuild> Function(int count, ExamScope scope, void Function(int, int) progress) generator =
      (count, scope, progress) => buildAiExam(count: count, scope: scope, progress: progress);

  /// Questions given instead of making them from the library (tests).
  final List<QuizQ>? preset;
  const MockExamScreen({super.key, this.preset});
  @override
  State<MockExamScreen> createState() => _MockExamScreenState();
}

enum _MPhase { setup, loading, running, report }

class _MockExamScreenState extends State<MockExamScreen> {
  _MPhase _phase = _MPhase.setup;
  int _count = 20, _secPer = 72;
  final Set<String> _packs = {};
  bool _plan = false;
  final _query = TextEditingController();
  int _doneQs = 0;
  String _msg = '';
  List<QuizQ> _qs = const [];
  List<int?> _ans = [];
  List<int> _spent = [];
  final Set<int> _flag = {};
  int _i = 0;
  DateTime? _qSince, _start;
  Timer? _tick;
  MockResult? _res;

  DateTime get _now => MockExamScreen.clock();
  int get _totalSec => _qs.length * _secPer;
  int get _left {
    final s = _start;
    if (s == null) return _totalSec;
    return (_totalSec - _now.difference(s).inSeconds).clamp(0, _totalSec);
  }

  Map<String, dynamic>? _saved; // an exam that was left half way

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => FocusPill.suppress.value++);
    if (widget.preset == null) _saved = Resume.read('mock');
    _plan = runningPlans().isNotEmpty;
  }

  /// After every step the exam is written down, so leaving the screen (or the app) does not lose it. The clock keeps
  /// running, as in a real exam: coming back after the time is up submits what was answered.
  void _persist() {
    if (_phase != _MPhase.running || _start == null) return;
    Resume.write('mock', {
      'qs': [for (final q in _qs) quizQToJson(q)],
      'ans': _ans,
      'spent': _spent,
      'flags': _flag.toList(),
      'i': _i,
      'start': _start!.toIso8601String(),
      'secPer': _secPer,
    });
  }

  int get _savedLeft {
    final m = _saved;
    if (m == null) return 0;
    final n = ((m['qs'] as List?) ?? const []).length;
    final start = DateTime.tryParse('${m['start']}') ?? _now;
    return (n * ((m['secPer'] as num?)?.toInt() ?? 72) - _now.difference(start).inSeconds).clamp(0, 1 << 30);
  }

  Future<void> _resume() async {
    final m = _saved;
    if (m == null) return;
    final qs = [for (final q in (m['qs'] as List? ?? const [])) if (q is Map) quizQFromJson(q)];
    if (qs.isEmpty) return _discard();
    setState(() {
      _qs = qs;
      _secPer = (m['secPer'] as num?)?.toInt() ?? 72;
      _ans = [for (final a in (m['ans'] as List? ?? const [])) a is num ? a.toInt() : null];
      while (_ans.length < qs.length) {
        _ans.add(null);
      }
      _spent = [for (final x in (m['spent'] as List? ?? const [])) (x as num?)?.toInt() ?? 0];
      while (_spent.length < qs.length) {
        _spent.add(0);
      }
      _flag
        ..clear()
        ..addAll([for (final f in (m['flags'] as List? ?? const [])) (f as num).toInt()]);
      _i = ((m['i'] as num?)?.toInt() ?? 0).clamp(0, qs.length - 1);
      _start = DateTime.tryParse('${m['start']}') ?? _now;
      _qSince = _now;
      _saved = null;
      _phase = _MPhase.running;
    });
    if (_left <= 0) return _submit();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_left <= 0) {
        _submit();
      } else {
        setState(() {});
      }
    });
  }

  Future<void> _discard() async {
    await Resume.clear('mock');
    if (mounted) setState(() => _saved = null);
  }

  @override
  void dispose() {
    _tick?.cancel();
    _query.dispose();
    WidgetsBinding.instance.addPostFrameCallback((_) => FocusPill.suppress.value--);
    super.dispose();
  }

  Future<void> _begin() async {
    setState(() {
      _phase = _MPhase.loading;
      _msg = '';
      _doneQs = 0;
    });
    List<QuizQ> qs;
    var note = '';
    if (widget.preset != null) {
      qs = widget.preset!;
    } else {
      final scope = ExamScope(packIds: {..._packs}, plan: _plan, query: _query.text.trim());
      final b = await MockExamScreen.generator(_count, scope, (d, w) {
        if (mounted) setState(() => _doneQs = d);
      });
      qs = b.qs;
      note = switch (b.status) {
        'aiOff' => tr('The exam is written by the AI. Turn the AI on in Settings (and connect to the internet) to start it.'),
        'offline' => tr('You are offline, so the AI could not write the exam. Connect to the internet and try again.'),
        'capped' => tr('The daily limit of AI requests is reached. Try again tomorrow, or choose fewer questions.'),
        'none' => tr('Nothing to write questions from. Add a book to your library, or choose another source.'),
        _ => tr('The AI could not write enough questions from this choice. Choose another book or fewer questions.'),
      };
    }
    if (!mounted) return;
    if (qs.length < 5) {
      setState(() {
        _phase = _MPhase.setup;
        _msg = note.isEmpty ? tr('Not enough questions could be made from your courses for this choice. Try "All my courses" or fewer questions.') : note;
      });
      return;
    }
    setState(() {
      _qs = qs;
      _ans = List<int?>.filled(qs.length, null);
      _spent = List<int>.filled(qs.length, 0);
      _flag.clear();
      _i = 0;
      _start = _now;
      _qSince = _now;
      _phase = _MPhase.running;
    });
    _persist();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_left <= 0) {
        _submit();
      } else {
        setState(() {});
      }
    });
  }

  void _leaveQuestion() {
    final s = _qSince;
    if (s != null) _spent[_i] += _now.difference(s).inSeconds;
    _qSince = _now;
  }

  void _go(int k) {
    if (k < 0 || k >= _qs.length) return;
    _leaveQuestion();
    setState(() => _i = k);
    _persist();
  }

  Future<void> _confirmSubmit() async {
    final open = _ans.where((a) => a == null).length;
    if (open == 0 && _flag.isEmpty) return _submit();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Submit the exam?'),
        content: m.Text([if (open > 0) trp('{n} questions are not answered.', {'n': open}), if (_flag.isNotEmpty) trp('{n} are flagged for review.', {'n': _flag.length})].join('\n')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Keep going')), FilledButton(key: const ValueKey('mock_confirm'), onPressed: () => Navigator.pop(ctx, true), child: Text('Submit'))],
      ),
    );
    if (ok == true) await _submit();
  }

  Future<void> _submit() async {
    if (_phase != _MPhase.running) return;
    _tick?.cancel();
    await Resume.clear('mock');
    _leaveQuestion();
    final used = _start == null ? 0 : _now.difference(_start!).inSeconds.clamp(0, _totalSec);
    final r = MockResult(_qs, _ans, _spent, {..._flag}, used);
    setState(() {
      _res = r;
      _phase = _MPhase.report;
    });
    // the result is kept like any other test: weak topics, the mistake notebook and the study time
    await store.upsertExtra('quizlog', {
      'id': newId('qz'),
      'date': nowIso(),
      'pack': '',
      'query': '',
      'n': r.qs.length,
      'correct': r.right,
      'wrong': [for (var i = 0; i < r.qs.length; i++) if (r.answers[i] != null && r.answers[i] != r.qs[i].answer) r.qs[i].title],
      'items': [for (var i = 0; i < r.qs.length; i++) if (r.answers[i] != null) {'p': r.qs[i].packId, 't': r.qs[i].title, 'ok': r.answers[i] == r.qs[i].answer, 'g': r.qs[i].group, 'k': r.qs[i].kind.name}],
      'source': 'mock',
      'level': 'medium',
    });
    for (var i = 0; i < r.qs.length; i++) {
      if (r.answers[i] != null && r.answers[i] != r.qs[i].answer) await MistakeBook.add(r.qs[i]);
    }
    await StudyLog.add(minutes: (r.usedSeconds / 60).round(), title: tr('Mock exam'), at: _now);
  }

  String _mmss(int s) => '${two(s ~/ 60)}:${two(s % 60)}';

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _phase != _MPhase.running,
      onPopInvokedWithResult: (did, _) async {
        if (did) return;
        final leave = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('Leave the exam?'),
            content: Text('Your answers are saved. The clock keeps running: you can come back until the time is up.'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Stay')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Leave'))],
          ),
        );
        if (leave == true && context.mounted) {
          _tick?.cancel();
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text('Mock exam')),
        body: switch (_phase) {
          _MPhase.setup => _setup(),
          _MPhase.loading => Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                m.Text(widget.preset != null ? '' : trp('The AI is writing the questions… {a} of {b}', {'a': _doneQs, 'b': _count}), key: const ValueKey('mock_writing')),
              ]),
            ),
          _MPhase.running => _running(),
          _MPhase.report => _report(),
        },
      ),
    );
  }

  Widget _setup() {
    final theme = Theme.of(context);
    Widget row(String label, List<Widget> chips) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: chips),
          const SizedBox(height: 16),
        ]);
    final left = _savedLeft;
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_saved != null)
        AppCard(
          key: const ValueKey('mock_resume'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('An exam is waiting for you', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              m.Text(left > 0 ? trp('{a} of {b} answered • {t} left', {'a': (_saved!['ans'] as List).where((a) => a != null).length, 'b': (_saved!['qs'] as List).length, 't': _mmss(left)}) : tr('The time is up: your answers will be submitted.'), style: theme.textTheme.bodySmall),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                FilledButton(key: const ValueKey('mock_continue'), onPressed: _resume, child: Text(left > 0 ? 'Continue the exam' : 'See the result')),
                TextButton(key: const ValueKey('mock_discard'), onPressed: _discard, child: Text('Discard it')),
              ]),
            ]),
          ),
        ),
      Text('The AI writes the questions from your own books and courses, against the clock. You see the answers only at the end.', style: theme.textTheme.bodyMedium),
      AiBuilder(builder: (context, enabled, online) {
        if (enabled && online) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: m.Text(enabled ? tr('You are offline: only questions the AI saved before can be used.') : tr('The AI is off: only questions the AI saved before can be used. Turn it on in Settings to write a new exam.'), key: const ValueKey('mock_ai_note'), style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.primary)),
        );
      }),
      const SizedBox(height: 16),
      row('Questions', [for (final n in const [10, 20, 30, 40]) ChoiceChip(key: ValueKey('mock_n_$n'), label: m.Text('$n'), selected: _count == n, onSelected: (_) => setState(() => _count = n))]),
      row('Time per question', [
        for (final (s, l) in const [(90, 'Relaxed (90 s)'), (72, 'Exam (72 s)'), (60, 'Tight (60 s)')]) ChoiceChip(key: ValueKey('mock_s_$s'), label: Text(l), selected: _secPer == s, onSelected: (_) => setState(() => _secPer = s)),
      ]),
      Text('Where the questions come from', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 4),
      Text('Choose one or more books, your plan, or type a name or a topic. With nothing chosen: all your books.', style: theme.textTheme.bodySmall),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 6, children: [
        if (runningPlans().isNotEmpty) FilterChip(key: const ValueKey('mock_src_plan'), avatar: Icon(AppIcons.plan, size: 18), label: Text('My plan'), selected: _plan, onSelected: (v) => setState(() => _plan = v)),
        for (final p in library.textPacks)
          if (p.kind == 'book' || p.kind == 'user')
            FilterChip(
              key: ValueKey('mock_pack_${p.id}'),
              label: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 260), child: m.Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
              selected: _packs.contains(p.id),
              onSelected: (v) => setState(() => v ? _packs.add(p.id) : _packs.remove(p.id)),
            ),
        for (final p in library.textPacks)
          if (p.kind != 'book' && p.kind != 'user')
            FilterChip(
              key: ValueKey('mock_pack_${p.id}'),
              label: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 260), child: m.Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
              selected: _packs.contains(p.id),
              onSelected: (v) => setState(() => v ? _packs.add(p.id) : _packs.remove(p.id)),
            ),
      ]),
      const SizedBox(height: 10),
      TextField(key: const ValueKey('mock_query'), controller: _query, decoration: InputDecoration(isDense: true, prefixIcon: const Icon(AppIcons.search), labelText: tr('A book name or a topic (optional)'))),
      const SizedBox(height: 16),
      m.Text(trp('Total time: {t} minutes', {'t': (_count * _secPer / 60).round()}), key: const ValueKey('mock_total'), style: theme.textTheme.labelLarge),
      if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: m.Text(_msg, style: TextStyle(color: theme.colorScheme.error))),
      const SizedBox(height: 16),
      FilledButton.icon(key: const ValueKey('mock_start'), onPressed: _begin, icon: const Icon(AppIcons.quiz), label: Text('Start the exam')),
    ]);
  }

  Widget _running() {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final q = _qs[_i];
    final left = _left;
    final low = left <= 60;
    final answered = _ans.where((a) => a != null).length;
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Row(children: [
            Directionality(textDirection: TextDirection.ltr, child: m.Text(_mmss(left), key: const ValueKey('mock_time'), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: low ? cs.error : null, fontFeatures: const [FontFeature.tabularFigures()]))),
            const SizedBox(width: 12),
            Expanded(child: m.Text('${_i + 1} / ${_qs.length} • ${trp('{n} answered', {'n': answered})}', style: theme.textTheme.bodySmall)),
            IconButton(key: const ValueKey('mock_flag'), tooltip: tr('Flag for review'), icon: Icon(_flag.contains(_i) ? AppIcons.flag : Icons.outlined_flag, color: _flag.contains(_i) ? cs.tertiary : null), onPressed: () {
              setState(() => _flag.contains(_i) ? _flag.remove(_i) : _flag.add(_i));
              _persist();
            }),
          ]),
        ),
        LinearProgressIndicator(value: 1 - left / _totalSec, minHeight: 3, color: low ? cs.error : null),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Directionality(textDirection: TextDirection.ltr, child: m.Text(q.stem, style: theme.textTheme.titleMedium?.copyWith(height: 1.4, fontWeight: FontWeight.w700))),
            const SizedBox(height: 14),
            for (var k = 0; k < q.options.length; k++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: _ans[_i] == k ? cs.primaryContainer : cs.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(14),
                  child: InkWell(
                    key: ValueKey('mock_opt_$k'),
                    borderRadius: BorderRadius.circular(14),
                    onTap: () {
                      setState(() => _ans[_i] = _ans[_i] == k ? null : k);
                      _persist();
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Directionality(textDirection: TextDirection.ltr, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Icon(_ans[_i] == k ? Icons.radio_button_checked : Icons.radio_button_unchecked, size: 20, color: _ans[_i] == k ? cs.primary : cs.outline),
                        const SizedBox(width: 10),
                        Expanded(child: m.Text(q.options[k], style: const TextStyle(height: 1.35))),
                      ])),
                    ),
                  ),
                ),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Row(children: [
            IconButton(key: const ValueKey('mock_prev'), onPressed: _i == 0 ? null : () => _go(_i - 1), icon: const Icon(Icons.chevron_left)),
            Expanded(child: TextButton(key: const ValueKey('mock_list'), onPressed: _openList, child: FittedBox(fit: BoxFit.scaleDown, child: Text('Questions')))),
            IconButton(key: const ValueKey('mock_next'), onPressed: _i + 1 >= _qs.length ? null : () => _go(_i + 1), icon: const Icon(AppIcons.chevronRight)),
            const SizedBox(width: 4),
            FilledButton(key: const ValueKey('mock_submit'), onPressed: _confirmSubmit, child: Text('Submit')),
          ]),
        ),
      ]),
    );
  }

  Future<void> _openList() async {
    final k = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        final cs = Theme.of(ctx).colorScheme;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (var j = 0; j < _qs.length; j++)
                InkWell(
                  onTap: () => Navigator.pop(ctx, j),
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: _ans[j] != null ? cs.primaryContainer : cs.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(10),
                      border: _flag.contains(j) ? Border.all(color: cs.tertiary, width: 2) : (j == _i ? Border.all(color: cs.primary) : null),
                    ),
                    child: m.Text('${j + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
            ]),
          ),
        );
      },
    );
    if (k != null) _go(k);
  }

  Widget _report() {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final r = _res!;
    final groups = r.byGroup.entries.toList()..sort((a, b) => (a.value.$1 / a.value.$2).compareTo(b.value.$1 / b.value.$2));
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
      AppCard(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(children: [
            m.Text('${(r.ratio * 100).round()}%', key: const ValueKey('mock_score'), style: theme.textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w900, color: cs.primary)),
            m.Text(trp('{a} of {b} right', {'a': r.right, 'b': r.qs.length}), style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
            m.Text([
              trp('Time used: {t}', {'t': _mmss(r.usedSeconds)}),
              if (r.answered > 0) trp('{s} s per answered question', {'s': r.avgSeconds.round()}),
              if (r.skipped > 0) trp('{n} not answered', {'n': r.skipped}),
            ].join(' • '), textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
          ]),
        ),
      ),
      SectionHeader(tr('Results by topic')),
      for (final e in groups)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: m.Text(e.key)), m.Text('${e.value.$1} / ${e.value.$2}', style: theme.textTheme.labelLarge)]),
            const SizedBox(height: 3),
            LinearProgressIndicator(value: e.value.$1 / e.value.$2, minHeight: 6, color: e.value.$1 == e.value.$2 ? Colors.green : (e.value.$1 / e.value.$2 < 0.5 ? Colors.red : cs.primary), borderRadius: BorderRadius.circular(6)),
          ]),
        ),
      if (r.slowest.isNotEmpty) ...[
        SectionHeader(tr('Slowest questions')),
        for (final i in r.slowest) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: m.Text(r.qs[i].stem, maxLines: 2, overflow: TextOverflow.ellipsis), trailing: m.Text('${r.seconds[i]} s', style: const TextStyle(fontWeight: FontWeight.w700))),
      ],
      SectionHeader(tr('To review')),
      if (r.toReview.isEmpty) Text('Everything right. Well done.'),
      for (final i in r.toReview)
        AppCard(
          key: ValueKey('mock_rev_$i'),
          child: ExpansionTile(
            leading: Icon(r.answers[i] == null ? Icons.remove_circle_outline : AppIcons.error, color: r.answers[i] == null ? cs.outline : cs.error),
            title: m.Text(r.qs[i].stem, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, height: 1.35)),
            subtitle: m.Text([if (r.flagged.contains(i)) tr('Flagged'), r.answers[i] == null ? tr('Not answered') : '${tr('Your answer')}: ${r.qs[i].options[r.answers[i]!]}'].join(' • '), maxLines: 2, overflow: TextOverflow.ellipsis),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              m.Text('${tr('Answer')}: ${r.qs[i].correct}', style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary)),
              if (r.qs[i].explanation.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: m.Text(r.qs[i].explanation, style: const TextStyle(height: 1.4))),
              TextButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ArticleScreen(packId: r.qs[i].packId, index: r.qs[i].index))),
                icon: const Icon(AppIcons.library, size: 18),
                label: Text('Open the article'),
              ),
            ],
          ),
        ),
      const SizedBox(height: 8),
      Text('Your wrong answers are in the mistake notebook and count in your weak topics.', style: theme.textTheme.bodySmall),
      const SizedBox(height: 8),
      FilledButton(onPressed: () => setState(() => _phase = _MPhase.setup), child: Text('Another exam')),
    ]);
  }
}
