import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

import 'app_icons.dart';
import 'data.dart';
import 'i18n.dart';

/// Updating from inside the app: it looks for a newer release on GitHub, shows what changed, downloads the APK, checks
/// its SHA-256 against the one GitHub publishes for the file, and hands it to Android's installer (installed over the old
/// version, so the cases stay). The phone's own "install unknown apps" permission is asked for once.
///
/// What it cannot do: tell you while the app is closed. The check runs when the app starts (at most once a day) and when
/// you press "Check for updates".

const String kRepo = 'syounis212004-sys/Medlog';
const String kReleaseApi = 'https://api.github.com/repos/$kRepo/releases/latest';
const String kWhatsNewUrl = 'https://raw.githubusercontent.com/$kRepo/main/library/whatsnew.json';

class AppUpdate {
  final String version;
  final String apkUrl;
  final String sha256;
  final int size;

  /// Notes of every version newer than the installed one, newest first: version -> lines.
  final Map<String, List<String>> notes;
  const AppUpdate({required this.version, required this.apkUrl, this.sha256 = '', this.size = 0, this.notes = const {}});
}

/// -1 older, 0 same, 1 newer.
int versionCompare(String a, String b) {
  final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  final y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0;
    final q = i < y.length ? y[i] : 0;
    if (p != q) return p < q ? -1 : 1;
  }
  return 0;
}

/// Seams for tests: the bodies of the two files, and the download.
Future<String?> Function(String url) updateFetch = _fetchText;
Future<File?> Function(AppUpdate u, File to, void Function(int got, int total) onProgress) updateDownload = _download;
const MethodChannel _channel = MethodChannel('medlog/update');
MethodChannel updateChannel = _channel;
bool Function() isAndroid = () => Platform.isAndroid;

Future<String?> _fetchText(String url) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await c.getUrl(Uri.parse(url));
    req.headers.set('User-Agent', 'MedLog (offline medical logbook)');
    req.headers.set('Accept', 'application/vnd.github+json, application/json');
    final res = await req.close().timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return null;
    final body = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 12));
    return body.length > 400000 ? null : body;
  } catch (_) {
    return null;
  } finally {
    c.close(force: true);
  }
}

/// The notes of the versions newer than [current] from whatsnew.json ({"4.5.0": {"en": [...], "ar": [...]}, ...}).
Map<String, List<String>> notesFrom(String? body, String current, String lang) {
  if (body == null) return const {};
  try {
    final j = jsonDecode(body);
    if (j is! Map) return const {};
    final vs = [for (final k in j.keys) '$k']..sort((a, b) => versionCompare(b, a));
    final out = <String, List<String>>{};
    for (final v in vs) {
      if (versionCompare(v, current) <= 0) continue;
      final e = j[v];
      if (e is! Map) continue;
      final l = e[lang] ?? e['en'];
      if (l is List) out[v] = [for (final x in l) '$x'];
      if (out.length >= 5) break;
    }
    return out;
  } catch (_) {
    return const {};
  }
}

/// The latest release when it is newer than the installed version; null when there is none or it cannot be read.
Future<AppUpdate?> findUpdate({String? current, String? lang}) async {
  final cur = current ?? kAppVersion;
  final body = await updateFetch(kReleaseApi);
  if (body == null) return null;
  try {
    final j = jsonDecode(body) as Map;
    final name = '${j['name'] ?? ''} ${j['tag_name'] ?? ''}';
    final v = RegExp(r'\d+\.\d+\.\d+').firstMatch(name)?.group(0);
    if (v == null || versionCompare(cur, v) >= 0) return null;
    Map? apk;
    for (final a in (j['assets'] as List? ?? const [])) {
      if (a is Map && '${a['name']}'.toLowerCase().endsWith('.apk')) apk = a;
    }
    if (apk == null) return null;
    final digest = '${apk['digest'] ?? ''}';
    final notes = notesFrom(await updateFetch(kWhatsNewUrl), cur, lang ?? langCode);
    return AppUpdate(
      version: v,
      apkUrl: '${apk['browser_download_url']}',
      sha256: digest.startsWith('sha256:') ? digest.substring(7).toLowerCase() : '',
      size: (apk['size'] as num?)?.toInt() ?? 0,
      notes: notes,
    );
  } catch (_) {
    return null;
  }
}

Future<File?> _download(AppUpdate u, File to, void Function(int got, int total) onProgress) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 12);
  try {
    final req = await c.getUrl(Uri.parse(u.apkUrl));
    req.headers.set('User-Agent', 'MedLog (offline medical logbook)');
    final res = await req.close();
    if (res.statusCode != 200) return null;
    final total = res.contentLength > 0 ? res.contentLength : u.size;
    await to.parent.create(recursive: true);
    final sink = to.openWrite();
    var got = 0;
    try {
      await for (final chunk in res) {
        sink.add(chunk);
        got += chunk.length;
        onProgress(got, total);
      }
    } finally {
      await sink.close();
    }
    return to;
  } catch (_) {
    return null;
  } finally {
    c.close(force: true);
  }
}

/// True when the file's SHA-256 is [expected] (when GitHub gave none, only the size is checked by the caller).
Future<bool> sha256Matches(File f, String expected) async {
  if (expected.isEmpty) return true;
  final d = await crypto.sha256.bind(f.openRead()).first;
  return d.toString().toLowerCase() == expected.toLowerCase();
}

enum UpdateResult { installerOpened, needPermission, downloadFailed, checksumFailed, unsupported }

/// Downloads the update into the cache folder, checks it and opens Android's installer.
Future<UpdateResult> downloadAndInstall(AppUpdate u, {void Function(int got, int total)? onProgress, Directory? cacheDir}) async {
  if (!isAndroid()) return UpdateResult.unsupported;
  try {
    final ok = await updateChannel.invokeMethod<bool>('canInstall') ?? false;
    if (!ok) {
      await updateChannel.invokeMethod('openInstallSettings');
      return UpdateResult.needPermission;
    }
  } catch (_) {
    return UpdateResult.unsupported;
  }
  final dir = cacheDir ?? await getTemporaryDirectory();
  final file = File('${dir.path}/update/MedLog-${u.version}.apk');
  final got = await updateDownload(u, file, onProgress ?? (_, __) {});
  if (got == null) return UpdateResult.downloadFailed;
  if (u.size > 0 && await got.length() != u.size) {
    await got.delete().catchError((_) => got);
    return UpdateResult.downloadFailed;
  }
  if (!await sha256Matches(got, u.sha256)) {
    await got.delete().catchError((_) => got);
    return UpdateResult.checksumFailed;
  }
  try {
    await updateChannel.invokeMethod('install', {'path': got.path});
    return UpdateResult.installerOpened;
  } catch (_) {
    return UpdateResult.unsupported;
  }
}

String _mb(int bytes) => (bytes / 1048576).toStringAsFixed(0);

/// The sheet that shows what is new and does the update. Returns after it closes.
Future<void> showUpdateDialog(BuildContext context, AppUpdate u, {bool manual = false}) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) => _UpdateDialog(update: u),
  );
}

class _UpdateDialog extends StatefulWidget {
  final AppUpdate update;
  const _UpdateDialog({required this.update});
  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  double? _progress;
  String _msg = '';
  bool _busy = false;

  Future<void> _go() async {
    setState(() {
      _busy = true;
      _msg = '';
      _progress = 0;
    });
    final r = await downloadAndInstall(widget.update, onProgress: (g, t) {
      if (mounted && t > 0) setState(() => _progress = g / t);
    });
    if (!mounted) return;
    setState(() {
      _busy = false;
      _progress = null;
      switch (r) {
        case UpdateResult.installerOpened:
          _msg = tr('The installer is open. Confirm it, and the app restarts with your cases.');
        case UpdateResult.needPermission:
          _msg = tr('Allow MedLog to install updates in the screen that opened, then come back and press Update again.');
        case UpdateResult.downloadFailed:
          _msg = tr('The download did not finish. Check the connection and try again.');
        case UpdateResult.checksumFailed:
          _msg = tr('The downloaded file did not match the published one, so it was deleted. Try again.');
        case UpdateResult.unsupported:
          _msg = tr('This phone cannot install from inside the app. Open the download page instead.');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.update;
    final theme = Theme.of(context);
    return AlertDialog(
      icon: const Icon(Icons.system_update_alt),
      title: Text('A new version is available'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            m.Text('${tr('Version')} ${u.version}${u.size > 0 ? '  •  ${_mb(u.size)} MB' : ''}', style: theme.textTheme.titleSmall),
            const SizedBox(height: 8),
            Text('Your cases stay on the phone when you install it over this one.', style: theme.textTheme.bodySmall),
            if (u.notes.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text("What's new", style: theme.textTheme.titleSmall),
              for (final e in u.notes.entries) ...[
                const SizedBox(height: 6),
                if (u.notes.length > 1) m.Text(e.key, style: theme.textTheme.labelLarge?.copyWith(color: theme.colorScheme.primary)),
                for (final l in e.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Padding(padding: EdgeInsets.only(top: 6), child: Icon(AppIcons.dot, size: 8)),
                      const SizedBox(width: 8),
                      Expanded(child: m.Text(l, style: theme.textTheme.bodyMedium)),
                    ]),
                  ),
              ],
            ],
            if (_progress != null) ...[
              const SizedBox(height: 14),
              LinearProgressIndicator(key: const ValueKey('update_progress'), value: _progress),
              const SizedBox(height: 4),
              m.Text('${((_progress ?? 0) * 100).round()}%', style: theme.textTheme.bodySmall),
            ],
            if (_msg.isNotEmpty) ...[
              const SizedBox(height: 12),
              m.Text(_msg, key: const ValueKey('update_msg'), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.primary)),
            ],
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: Text('Later')),
        FilledButton(key: const ValueKey('update_now'), onPressed: _busy ? null : _go, child: Text('Update now')),
      ],
    );
  }
}

/// The yearly rhythm of the automatic check: at most once a day, and a version the user put off is not offered again for
/// three days.
bool updateCheckDue({DateTime? now}) {
  if (store.settings['updateAuto'] == false) return false;
  final n = now ?? DateTime.now();
  final last = DateTime.tryParse('${store.settings['updateAutoChecked'] ?? ''}');
  return last == null || n.difference(last).inHours >= 20;
}

Future<void> autoCheckForUpdate(BuildContext Function() context, {bool Function()? busy}) async {
  if (!updateCheckDue()) return;
  final u = await findUpdate();
  store.settings['updateAutoChecked'] = DateTime.now().toIso8601String();
  store.saveSettings();
  if (u == null) return;
  final putOff = DateTime.tryParse('${store.settings['updatePutOff_${u.version}'] ?? ''}');
  if (putOff != null && DateTime.now().difference(putOff).inHours < 72) return;
  if (busy != null && busy()) return;
  final c = context();
  if (!c.mounted) return;
  await showUpdateDialog(c, u);
  store.settings['updatePutOff_${u.version}'] = DateTime.now().toIso8601String();
  store.saveSettings();
}
