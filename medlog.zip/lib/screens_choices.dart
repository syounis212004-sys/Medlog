import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'choices_engine.dart';
import 'data.dart';
import 'i18n.dart';

Widget _en(String s, {TextStyle? style}) => Directionality(textDirection: TextDirection.ltr, child: m.Text(s, style: style));

/// The quick choices of one case tab (History, Examination, Investigations, Assessment or Management).
/// Every step starts empty; choosing nothing documents nothing.
class ChoicesSection extends StatefulWidget {
  final CaseRec rec;
  final String section;
  final VoidCallback onChanged;
  const ChoicesSection({super.key, required this.rec, required this.section, required this.onChanged});
  @override
  State<ChoicesSection> createState() => _ChoicesSectionState();
}

class _ChoicesSectionState extends State<ChoicesSection> {
  @override
  void initState() {
    super.initState();
    if (!ChoicesRepo.loaded) {
      ChoicesRepo.load().then((_) {
        if (mounted) setState(() {});
      }, onError: (_) {});
    }
  }

  void _changed() {
    widget.onChanged();
    setState(() {});
  }

  Future<bool> _confirmReplace() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Replace your other choices?'),
        content: Text('This option cannot be combined with the others. They will be removed from this step.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Replace')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _tap(CaseChoices cc, ChTemplate t, ChStep s, List<ChOption> options, String v) async {
    if (!cc.toggle(t, s, options, v)) {
      if (!await _confirmReplace()) return;
      cc.toggle(t, s, options, v, confirmed: true);
    }
    _changed();
  }

  @override
  Widget build(BuildContext context) {
    if (!ChoicesRepo.loaded) return const SizedBox.shrink();
    final cc = CaseChoices(widget.rec);
    final t = cc.template();
    if (t == null) return const SizedBox.shrink();
    final resolved = cc.resolve(t);
    final steps = [for (final s in t.steps) if (s.section == widget.section) s];
    if (steps.isEmpty) return const SizedBox.shrink();
    final shown = <ChStep>[];
    var hidden = 0;
    for (final s in steps) {
      final has = cc.pick(s.id).v.isNotEmpty || cc.pick(s.id).details.isNotEmpty;
      if (cc.enabled(t, s) || has) {
        shown.add(s);
      } else {
        hidden++;
      }
    }
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        key: PageStorageKey('choices_${t.id}_${widget.section}'),
        initiallyExpanded: true,
        leading: const Icon(Icons.touch_app_outlined),
        title: Text('Quick choices', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: _en(t.specialty, style: theme.textTheme.bodySmall),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final s in shown) _stepView(cc, t, s, resolved[s.id] ?? s.options),
          if (hidden > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('More questions appear as you choose.', style: theme.textTheme.bodySmall),
            ),
          const SizedBox(height: 6),
          Text('Choices record what you found or decided. Nothing is filled in for you, and an empty step means not documented.',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        ],
      ),
    );
  }

  Widget _stepView(CaseChoices cc, ChTemplate t, ChStep s, List<ChOption> options) {
    final theme = Theme.of(context);
    final p = cc.pick(s.id);
    final stale = cc.stale(s, options);
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _en(s.label, style: theme.textTheme.labelLarge),
        const SizedBox(height: 4),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Wrap(spacing: 6, runSpacing: 4, children: [
            for (final o in options)
              s.multi
                  ? FilterChip(
                      label: m.Text(o.v),
                      selected: p.v.contains(o.v),
                      visualDensity: VisualDensity.compact,
                      onSelected: (_) => _tap(cc, t, s, options, o.v),
                    )
                  : ChoiceChip(
                      label: m.Text(o.v),
                      selected: p.v.contains(o.v),
                      visualDensity: VisualDensity.compact,
                      onSelected: (_) => _tap(cc, t, s, options, o.v),
                    ),
          ]),
        ),
        if (stale.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text('No longer in this list after you changed an earlier answer. Tap to remove or keep as it is.',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.error)),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Wrap(spacing: 6, children: [
              for (final v in stale)
                InputChip(
                  avatar: const Icon(Icons.warning_amber_rounded, size: 16),
                  label: m.Text(v),
                  visualDensity: VisualDensity.compact,
                  onDeleted: () {
                    cc.setValues(t, s.id, [for (final x in p.v) if (x != v) x]);
                    _changed();
                  },
                ),
            ]),
          ),
        ],
        if (p.v.contains('Other'))
          _DetailField(
            key: ValueKey('${s.id}_other'),
            label: tr('Other: details'),
            initial: p.optionDetails['Other'] ?? '',
            onChanged: (x) {
              cc.setOptionDetails(t, s.id, 'Other', x);
              widget.onChanged();
            },
          ),
        _DetailsToggle(
          key: ValueKey('${s.id}_d'),
          label: s.detailsLabel,
          initial: p.details,
          onChanged: (x) {
            cc.setDetails(t, s.id, x);
            widget.onChanged();
          },
        ),
      ]),
    );
  }
}

class _DetailsToggle extends StatefulWidget {
  final String label, initial;
  final ValueChanged<String> onChanged;
  const _DetailsToggle({super.key, required this.label, required this.initial, required this.onChanged});
  @override
  State<_DetailsToggle> createState() => _DetailsToggleState();
}

class _DetailsToggleState extends State<_DetailsToggle> {
  late bool _open = widget.initial.isNotEmpty;
  @override
  Widget build(BuildContext context) {
    if (!_open) {
      return Align(
        alignment: AlignmentDirectional.centerStart,
        child: TextButton.icon(
          style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
          onPressed: () => setState(() => _open = true),
          icon: const Icon(Icons.add, size: 16),
          label: Text('Add details'),
        ),
      );
    }
    return _DetailField(label: tr('Details'), initial: widget.initial, onChanged: widget.onChanged);
  }
}

class _DetailField extends StatefulWidget {
  final String label, initial;
  final ValueChanged<String> onChanged;
  const _DetailField({super.key, required this.label, required this.initial, required this.onChanged});
  @override
  State<_DetailField> createState() => _DetailFieldState();
}

class _DetailFieldState extends State<_DetailField> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 6),
        child: TextField(
          controller: _c,
          minLines: 1,
          maxLines: 3,
          decoration: InputDecoration(labelText: widget.label, isDense: true),
          onChanged: widget.onChanged,
        ),
      );
}
