import 'package:flutter/material.dart';
import 'package:icon_animated/icon_animated.dart';

import 'motion.dart' show motionOn;

/// Small animated outline icons (package icon_animated, MIT licence): the icon draws itself when it appears.
/// They respect both the phone's "remove animations" setting and the app's own animation switch.
class AnimIcon extends StatelessWidget {
  final IconType type;
  final double size;
  final Color? color;
  final bool active;
  const AnimIcon(this.type, {super.key, this.size = 22, this.color, this.active = true});

  @override
  Widget build(BuildContext context) => IconAnimated(
        active: active,
        size: size,
        iconType: type,
        color: color,
        strokeWidth: size >= 28 ? 2.4 : 2.0,
        duration: motionOn ? const Duration(milliseconds: 650) : Duration.zero,
      );
}

enum SnackKind { info, success, error }

final RegExp _errWords = RegExp(r"(fail|error|could not|couldn't|cannot|can't|unable|denied|invalid|wrong|not allowed|no internet|offline|فشل|خطأ|تعذر|لا يمكن|غير صالح)", caseSensitive: false);
final RegExp _okWords = RegExp(r"(saved|done|exported|restored|copied|added|created|deleted|removed|updated|backed up|shared|sent|imported|installed|marked|تم|حُفظ|نُسخ|أُضيف|حُذف)", caseSensitive: false);

/// The kind of a message when the caller did not say: by its words (English and Arabic).
SnackKind snackKindOf(String msg) {
  if (_errWords.hasMatch(msg)) return SnackKind.error;
  if (_okWords.hasMatch(msg)) return SnackKind.success;
  return SnackKind.info;
}

/// The content of a snack bar: an animated icon (check for success, alert for a problem) and the message.
Widget snackContent(BuildContext context, String msg, SnackKind kind) {
  if (kind == SnackKind.info) return Text(msg);
  final cs = Theme.of(context).colorScheme;
  final ok = kind == SnackKind.success;
  return Row(children: [
    AnimIcon(ok ? IconType.check : IconType.alert, size: 22, color: ok ? const Color(0xFF7FD6A0) : cs.errorContainer),
    const SizedBox(width: 12),
    Expanded(child: Text(msg)),
  ]);
}
