import 'dart:async';
import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;

import 'ai/ai_context.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import 'access.dart';
import 'data.dart';
import 'i18n.dart';
import 'widgets.dart';
import 'ph.dart';

// Gate, request screen, administrator tools and the "Access & members" settings rows.

/// Seams (tests replace them).
Future<void> Function(String text) accessShareText = (t) async {
  await Share.share(t);
};

/// Encrypted backup of the user's own data: never blocked by the gate.
Future<void> Function(BuildContext context) accessExportMyData = _exportMyData;

Future<void> _exportMyData(BuildContext context) async {
  final pw = await askPassword(context, 'Backup password',
      confirm: true,
      note: 'The backup is encrypted. If you forget this password nobody can open it. Write it down somewhere safe.');
  if (pw == null) return;
  try {
    final f = await store.exportBackup(pw);
    await Share.shareXFiles([XFile(f.path)], text: 'SharqMed backup');
  } catch (e) {
    if (context.mounted) snack(context, '${tr('Export failed')}: $e');
  }
}

/// The code inside a pasted message (WhatsApp adds text around it): "MLREQ1..." or "MLA1...".
String? extractAccessCode(String text, String prefix) {
  final m = RegExp('$prefix\\.[A-Za-z0-9_\\-\\.]+').firstMatch(text);
  return m?.group(0);
}

/// What is in the clipboard now (empty when there is nothing readable).
Future<String> _clipText() async {
  try {
    return (await Clipboard.getData(Clipboard.kTextPlain))?.text ?? '';
  } catch (_) {
    return '';
  }
}

String fmtDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)}';
}

// ---------------------------------------------------------------- the gate

/// Full-screen gate. Lives above the app content (and below the app-lock cover). Hosts its own
/// Navigator so dialogs and text selection work there.
class AccessGate extends StatelessWidget {
  const AccessGate({super.key});

  @override
  Widget build(BuildContext context) {
    // own Navigator: it must not share the app's HeroController
    return HeroControllerScope.none(
      child: Navigator(
        onGenerateRoute: (_) => MaterialPageRoute<void>(builder: (_) => const GateScreen()),
      ),
    );
  }
}

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});

  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> with WidgetsBindingObserver {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _note = TextEditingController();
  final _paste = TextEditingController();
  String _msg = '';
  bool _busy = false;
  bool _sent = false;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    final p = access.pending;
    _sent = p != null && p['sent'] == true;
    final a = access.approval;
    _name.text = '${p?['name'] ?? a?.name ?? ''}';
    _email.text = '${p?['email'] ?? a?.email ?? ''}';
    _note.text = '${p?['note'] ?? ''}';
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _scanClipboard());
    if (_sent) _startPolling();
  }

  /// While the request waits, the mailbox is looked at every few seconds: the moment the administrator approves, the
  /// app opens by itself (the gate disappears when the approval is accepted).
  void _startPolling() {
    _poll?.cancel();
    _checkReply();
    _poll = Timer.periodic(const Duration(seconds: 8), (_) => _checkReply());
  }

  Future<void> _checkReply() async {
    if (!mounted || access.pending == null) return;
    await access.checkReply();
  }

  @override
  void dispose() {
    _poll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    for (final c in [_name, _email, _note, _paste]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _scanClipboard();
      if (_sent) _checkReply();
    }
  }

  String _tried = '';

  /// The approval code was copied from WhatsApp: when the app is opened it is found and used, nothing to paste.
  Future<void> _scanClipboard() async {
    if (access.pending == null) return;
    final code = extractAccessCode(await _clipText(), 'MLA1');
    if (code == null || code == _tried || !mounted) return;
    _tried = code;
    _paste.text = code;
    await _activate();
  }

  Future<void> _pasteNow() async {
    final t = await _clipText();
    final code = extractAccessCode(t, 'MLA1') ?? t.trim();
    if (!mounted) return;
    setState(() => _paste.text = code);
    if (code.isNotEmpty) await _activate();
  }

  /// Sends the request through the relay: nothing to copy. Only when the relay cannot be reached the old way is offered
  /// (the share sheet with the code).
  Future<void> _sendRequest() async {
    await _create();
    if (_msg.isNotEmpty || access.pending == null) return;
    setState(() => _busy = true);
    final ok = await access.sendRequestOnline();
    if (!mounted) return;
    if (ok) {
      await access.markRequestSent();
      setState(() {
        _busy = false;
        _sent = true;
        _msg = '';
      });
      _startPolling();
    } else {
      setState(() {
        _busy = false;
        _msg = tr('Could not reach the relay. Send the code below to the administrator instead.');
      });
      final c = access.pending?['code'] as String?;
      if (c != null) await accessShareText(c);
    }
  }

  Future<void> _create() async {
    if (_name.text.trim().isEmpty || !_email.text.contains('@')) {
      setState(() => _msg = tr('Enter your full name and a valid email.'));
      return;
    }
    await access.createRequest(_name.text, _email.text, _note.text);
    setState(() => _msg = '');
  }

  Future<void> _activate() async {
    final r = await access.redeem(extractAccessCode(_paste.text, 'MLA1') ?? _paste.text);
    if (!mounted) return;
    final m = {
      RedeemResult.ok: '',
      RedeemResult.invalid: 'This code is not valid for this phone. Check that you pasted the whole code you received for the request made on THIS phone.',
      RedeemResult.expired: 'This approval has already expired. Ask the administrator for a new one.',
      RedeemResult.revoked: 'This approval was withdrawn by the administrator.',
      RedeemResult.noKey: 'The administrator key is not known yet. Connect to the internet once and press "Check again".',
    }[r]!;
    setState(() => _msg = m.isEmpty ? '' : tr(m));
  }

  Future<void> _retry() async {
    setState(() => _busy = true);
    await access.refresh(force: true);
    if (mounted) {
      setState(() {
        _busy = false;
        _msg = access.lastFetch == null ? tr('Could not reach the server. Check the connection.') : '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return AnimatedBuilder(
      animation: access,
      builder: (context, _) {
        final st = access.check.status;
        final title = st == AccessStatus.expired
            ? 'Your access has expired'
            : st == AccessStatus.revoked
                ? 'Your access was withdrawn'
                : 'Access required';
        final code = access.pending?['code'] as String?;
        return Scaffold(
          body: SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
                  children: [
                    Icon(st == AccessStatus.expired ? Ph.hourglassLow : AppIcons.privacy,
                        size: 48, color: cs.primary),
                    const SizedBox(height: 12),
                    Text(title, style: tt.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(st == AccessStatus.expired
                        ? 'Ask the administrator to renew you: send a new request code below.'
                        : 'SharqMed is for approved users only. Press the button below: the administrator gets your request and the app opens by itself once approved. Your logbook stays on this phone and nothing about patients is sent.'),
                    if (access.adminName.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text('${tr('Administrator')}: ${access.adminName}', style: tt.bodySmall),
                    ],
                    const SizedBox(height: 20),
                    Text('Request access', style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    TextField(
                        controller: _name,
                        textCapitalization: TextCapitalization.words,
                        decoration: InputDecoration(labelText: tr('Full name'), border: const OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(labelText: tr('Email'), border: const OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(
                        controller: _note,
                        decoration: InputDecoration(labelText: tr('Note (optional)'), border: const OutlineInputBorder())),
                    const SizedBox(height: 10),
                    FilledButton.icon(
                        key: const Key('gate_send'),
                        onPressed: _busy ? null : _sendRequest,
                        icon: const Icon(Ph.paperPlaneTilt),
                        label: Text(_sent ? 'Send the request again' : 'Send request to the administrator')),
                    const SizedBox(height: 6),
                    Text('The request goes through a free public relay (ntfy.sh): your name, email and note. Nothing about patients.', style: tt.bodySmall),
                    if (_sent) ...[
                      const SizedBox(height: 14),
                      Container(
                        key: const Key('gate_waiting'),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(16)),
                        child: Row(children: [
                          const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)),
                          const SizedBox(width: 12),
                          Expanded(child: Text('Request sent. When the administrator approves it, the app opens by itself. You can leave this screen open.', style: TextStyle(color: cs.onPrimaryContainer))),
                        ]),
                      ),
                    ],
                    const SizedBox(height: 18),
                    // the old way stays for when there is no internet: a code sent by WhatsApp or email
                    Fold(
                      id: 'gate_manual',
                      title: 'No internet, or you received a code?',
                      children: [
                        if (code != null) ...[
                          Text('Send this code to the administrator by WhatsApp or email:', style: tt.bodySmall),
                          const SizedBox(height: 6),
                          CodeBox(text: code, shareSubject: tr('SharqMed access request')),
                          const SizedBox(height: 14),
                        ],
                        Text('Paste the approval code', style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        TextField(
                            controller: _paste,
                            minLines: 2,
                            maxLines: 4,
                            decoration: InputDecoration(
                                labelText: tr('Approval code'),
                                border: const OutlineInputBorder(),
                                alignLabelWithHint: true,
                                suffixIcon: IconButton(key: const Key('gate_paste'), tooltip: tr('Paste'), icon: const Icon(Ph.clipboardText), onPressed: _pasteNow))),
                        const SizedBox(height: 10),
                        FilledButton.tonalIcon(onPressed: _activate, icon: const Icon(AppIcons.done), label: Text('Activate')),
                      ],
                    ),
                    if (_msg.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      m_Message(_msg, cs.error),
                    ],
                    if (access.keyWarning) ...[
                      const SizedBox(height: 10),
                      m_Message(
                          tr('The published administrator key changed without a valid signature, so it was ignored.'), cs.error),
                    ],
                    const SizedBox(height: 8),
                    TextButton.icon(
                        onPressed: _busy ? null : _retry,
                        icon: const Icon(AppIcons.refresh),
                        label: Text('Check again (online)')),
                    const Divider(height: 32),
                    Text('Your data is yours. You can always save a copy of it, even without approval.', style: tt.bodySmall),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                        onPressed: () => accessExportMyData(context),
                        icon: const Icon(Ph.cloudArrowUp),
                        label: Text('Export my data')),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ignore: non_constant_identifier_names
Widget m_Message(String s, Color c) => Text(s, style: TextStyle(color: c, fontWeight: FontWeight.w600));

/// A selectable code with Copy and Share buttons.
class CodeBox extends StatelessWidget {
  final String text;
  final String shareSubject;
  const CodeBox({super.key, required this.text, this.shareSubject = ''});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(10)),
        child: SelectableText(text,
            maxLines: 5,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
            textDirection: TextDirection.ltr),
      ),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 4, children: [
        OutlinedButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: text));
              if (context.mounted) snack(context, tr('Copied'));
            },
            icon: const Icon(Ph.copy, size: 18),
            label: Text('Copy')),
        OutlinedButton.icon(
            onPressed: () => accessShareText(text),
            icon: const Icon(Ph.shareNetwork, size: 18),
            label: Text('Share')),
      ]),
    ]);
  }
}

// ---------------------------------------------------------------- settings rows

class AccessSettingsSection extends StatelessWidget {
  const AccessSettingsSection({super.key});

  void _open(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: access,
      builder: (context, _) {
        final a = access.approval;
        final left = access.daysLeft;
        final soon = left != null && left <= 14;
        final rows = <Widget>[];
        if (access.isAdmin) {
          rows.add(ListTile(
              leading: const Icon(Ph.shieldCheck),
              title: Text('You are the administrator'),
              subtitle: Text('Approve requests, see members, publish the key'),
              trailing: const Icon(AppIcons.chevronRight),
              onTap: () => _open(context, const AdminHomeScreen())));
        } else {
          rows.add(ListTile(
            leading: Icon(!access.gateOn ? Ph.lockOpen : AppIcons.privacy),
            title: Text(!access.gateOn
                ? 'Open access'
                : a == null
                    ? 'Not approved'
                    : 'Approved'),
            subtitle: Text(!access.gateOn
                ? 'No administrator has turned access control on.'
                : a == null
                    ? 'Open the app again to request access.'
                    : '${tr('Approved by')} ${access.adminName.isEmpty ? tr('the administrator') : access.adminName}\n'
                        '${a.name}  ·  ${fmtDate(a.expires)}'
                        '${left == null ? '' : '  ·  ${trp('expires in {n} days', {'n': left})}'}'),
            isThreeLine: a != null,
            iconColor: soon ? Theme.of(context).colorScheme.error : null,
          ));
          if (a != null) {
            rows.add(ListTile(
                leading: const Icon(Ph.signOut),
                title: Text('Sign out'),
                subtitle: Text('Removes the approval from this phone. Your data stays.'),
                onTap: () async {
                  final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                            title: Text('Sign out?'),
                            content: Text('You will need a new approval code to open the app again. Your data is not deleted.'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
                              TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Sign out')),
                            ],
                          ));
                  if (ok == true) await access.signOut();
                }));
          }
        }
        rows.add(ListTile(
            leading: const Icon(AppIcons.refresh),
            title: Text('Check administrator list now'),
            subtitle: Text(access.lastFetch == null ? 'Never checked' : '${tr('Last check')}: ${fmtDate(access.lastFetch!)}'),
            onTap: () async {
              await access.refresh(force: true);
              if (context.mounted) snack(context, tr(access.gateOn ? 'Checked.' : 'No administrator key is published.'));
            }));
        if (!access.isAdmin) {
          rows.add(ListTile(
              leading: const Icon(Ph.key),
              title: Text('Administrator tools'),
              subtitle: Text('Only for the person who approves the members'),
              trailing: const Icon(AppIcons.chevronRight),
              onTap: () => _open(context, const AdminSetupScreen())));
        }
        return Column(children: rows);
      },
    );
  }
}

// ---------------------------------------------------------------- administrator

class AdminSetupScreen extends StatefulWidget {
  const AdminSetupScreen({super.key});

  @override
  State<AdminSetupScreen> createState() => _AdminSetupScreenState();
}

class _AdminSetupScreenState extends State<AdminSetupScreen> {
  final _name = TextEditingController();
  final _backup = TextEditingController();
  final _pass = TextEditingController();
  String _msg = '';

  @override
  void dispose() {
    _name.dispose();
    _backup.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _setup() async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text('Set up as administrator?'),
              content: Text(
                  'A secret signing key is created and kept ONLY on this phone. Anyone with this phone unlocked can approve members. If you lose the phone without the encrypted key backup you will not be able to approve anyone again. Do this only on the phone you will keep.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Create key')),
              ],
            ));
    if (ok != true) return;
    await access.setupAdmin(name: _name.text.trim());
    if (mounted) Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => const AdminHomeScreen()));
  }

  Future<void> _restore() async {
    final good = await access.restoreAdmin(_backup.text, _pass.text);
    if (!mounted) return;
    if (good) {
      Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => const AdminHomeScreen()));
    } else {
      setState(() => _msg = tr('Wrong passphrase, or the backup text is damaged.'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AiContextScope(ctx: const AiScreenContext(kind: 'admin', title: 'Administration'), child: Scaffold(
      appBar: AppBar(title: Text('Administrator')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('Make this phone the administrator', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Text('The administrator approves who can use SharqMed. No server is involved: approvals are signed codes you send by WhatsApp or email.'),
        const SizedBox(height: 12),
        TextField(
            controller: _name,
            decoration: InputDecoration(labelText: tr('Name shown to members'), border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: _setup, icon: const Icon(Ph.shieldCheck), label: Text('Set up as administrator')),
        const Divider(height: 32),
        Text('Restore on a new phone', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        TextField(
            controller: _backup,
            minLines: 2,
            maxLines: 4,
            decoration: InputDecoration(labelText: tr('Encrypted key backup'), border: const OutlineInputBorder(), alignLabelWithHint: true)),
        const SizedBox(height: 10),
        TextField(
            controller: _pass,
            obscureText: true,
            decoration: InputDecoration(labelText: tr('Passphrase'), border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: _restore, icon: const Icon(Ph.clockCounterClockwise), label: Text('Restore administrator key')),
        if (_msg.isNotEmpty) ...[const SizedBox(height: 10), m_Message(_msg, Theme.of(context).colorScheme.error)],
      ]),
    ));
  }
}

class AdminHomeScreen extends StatelessWidget {
  const AdminHomeScreen({super.key});

  void _open(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));

  Future<void> _backup(BuildContext context) async {
    final pw = await askPassword(context, 'Passphrase for the key backup',
        confirm: true,
        note: 'The key backup is encrypted with this passphrase. Without the backup AND the passphrase a lost phone means nobody can be approved any more. Keep both safe, in different places.');
    if (pw == null) return;
    final t = await access.exportAdminBackup(pw);
    if (context.mounted) {
      await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
                title: Text('Encrypted key backup'),
                content: SingleChildScrollView(child: CodeBox(text: t)),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Close'))],
              ));
    }
  }

  Future<void> _rotate(BuildContext context) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text('Rotate the key?'),
              content: Text(
                  'Creates a new key signed by the old one. Publish the new admin.json; phones that already trust you follow it automatically. Do it only if you must.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Rotate')),
              ],
            ));
    if (ok != true) return;
    final j = await access.rotateKey();
    if (context.mounted) {
      await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
                title: Text('New admin.json'),
                content: SingleChildScrollView(child: CodeBox(text: j)),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Close'))],
              ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: access,
      builder: (context, _) => AiContextScope(ctx: const AiScreenContext(kind: 'admin', title: 'Administration'), child: Scaffold(
        appBar: AppBar(title: Text('Administrator')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text('1. Publish your key', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          Text('Commit this text as library/admin.json in the repository. Until it is published the app is open to everybody.'),
          const SizedBox(height: 8),
          CodeBox(text: access.adminJson()),
          const Divider(height: 28),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Ph.tray),
              title: Text('Access requests'),
              subtitle: Text('Paste a request code to approve or reject'),
              trailing: const Icon(AppIcons.chevronRight),
              onTap: () => _open(context, const AccessRequestsScreen())),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Ph.users),
              title: Text('Members'),
              subtitle: Text(trp('{n} approved', {'n': access.members.length})),
              trailing: const Icon(AppIcons.chevronRight),
              onTap: () => _open(context, const MembersScreen())),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Ph.downloadSimple),
              title: Text('Back up the secret key'),
              subtitle: Text('Encrypted with a passphrase; needed to restore on a new phone'),
              onTap: () => _backup(context)),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Ph.arrowsClockwise),
              title: Text('Rotate the key'),
              onTap: () => _rotate(context)),
        ]),
      )),
    );
  }
}

const List<int> kValidityDays = [30, 90, 180, 365];

class AccessRequestsScreen extends StatefulWidget {
  const AccessRequestsScreen({super.key});

  @override
  State<AccessRequestsScreen> createState() => _AccessRequestsScreenState();
}

class _AccessRequestsScreenState extends State<AccessRequestsScreen> {
  final _paste = TextEditingController();
  AccessRequest? _req;
  int _days = 90;
  String _code = '';
  String _msg = '';
  List<AccessRequest> _waiting = const [];
  bool _loading = false;
  String _sentNote = '';

  Future<void> _load() async {
    setState(() => _loading = true);
    final l = await access.fetchRequests();
    if (!mounted) return;
    setState(() {
      _waiting = [for (final r in l) if (!access.isCurrentMember(r)) r];
      _loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
    // a request copied from WhatsApp is already waiting here: read at once
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final code = extractAccessCode(await _clipText(), 'MLREQ1');
      if (code == null || !mounted || _paste.text.isNotEmpty) return;
      _paste.text = code;
      _read();
    });
  }

  @override
  void dispose() {
    _paste.dispose();
    super.dispose();
  }

  void _read() {
    final r = AccessRequest.parse(extractAccessCode(_paste.text, 'MLREQ1') ?? _paste.text);
    setState(() {
      _req = r;
      _code = '';
      _msg = r == null ? tr('This is not a valid request code.') : '';
    });
  }

  void _pick(AccessRequest r) => setState(() {
        _req = r;
        _code = '';
        _sentNote = '';
        _msg = '';
      });

  Future<void> _approve() async {
    final req = _req!;
    final c = await access.approve(req, _days);
    setState(() => _code = c);
    // the member's phone is looking in its mailbox: the approval goes there, nothing to copy or send
    final ok = await access.sendApprovalOnline(req.id, c);
    if (!mounted) return;
    if (ok) {
      setState(() {
        _sentNote = trp('Approved. The approval was sent to {name}; their app opens by itself.', {'name': req.name.isEmpty ? req.email : req.name});
        _waiting = [for (final r in _waiting) if (r.id != req.id) r];
      });
    } else {
      // no internet: the old way
      await accessShareText(c);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = _req;
    return AiContextScope(ctx: const AiScreenContext(kind: 'admin', title: 'Administration'), child: Scaffold(
      appBar: AppBar(title: Text('Access requests')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: Text('Waiting requests', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
          IconButton(key: const Key('req_refresh'), tooltip: tr('Refresh'), onPressed: _loading ? null : _load, icon: _loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Ph.arrowsClockwise)),
        ]),
        if (_waiting.isEmpty)
          Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_loading ? 'Looking for requests…' : 'No request is waiting. Requests sent from the app appear here by themselves.', style: Theme.of(context).textTheme.bodySmall))
        else
          for (final w in _waiting)
            Card(
              child: ListTile(
                key: ValueKey('req_${w.id.substring(0, 8)}'),
                leading: const Icon(Ph.userPlus),
                title: Text(w.name.isEmpty ? '-' : w.name),
                subtitle: Text('${w.email}\n${fmtDate(w.ts)}'),
                isThreeLine: true,
                trailing: const Icon(Ph.caretRight),
                selected: _req?.id == w.id,
                onTap: () => _pick(w),
              ),
            ),
        const SizedBox(height: 8),
        Fold(
          id: 'req_manual',
          title: 'A request code sent by WhatsApp or email',
          children: [
            TextField(
                controller: _paste,
                minLines: 2,
                maxLines: 4,
                decoration: InputDecoration(labelText: tr('Paste request code'), border: const OutlineInputBorder(), alignLabelWithHint: true)),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: _read, icon: const Icon(AppIcons.search), label: Text('Read request')),
          ],
        ),
        if (_msg.isNotEmpty) ...[const SizedBox(height: 10), m_Message(_msg, Theme.of(context).colorScheme.error)],
        if (r != null) ...[
          const SizedBox(height: 16),
          Card(
              child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r.name.isEmpty ? '-' : r.name, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(r.email),
              if (r.note.isNotEmpty) ...[const SizedBox(height: 4), Text(r.note)],
              const SizedBox(height: 4),
              Text('${tr('Requested')}: ${fmtDate(r.ts)}', style: Theme.of(context).textTheme.bodySmall),
              Text('${tr('Phone ID')}: ${r.id.substring(0, 8)}', style: Theme.of(context).textTheme.bodySmall),
            ]),
          )),
          const SizedBox(height: 8),
          Text('Role: Member', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          Text('Valid for'),
          Wrap(spacing: 8, children: [
            for (final d in kValidityDays)
              ChoiceChip(label: Text(trp('{n} days', {'n': d})), selected: _days == d, onSelected: (_) => setState(() => _days = d)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: _approve, icon: const Icon(AppIcons.check), label: Text('Approve'))),
            const SizedBox(width: 8),
            Expanded(
                child: OutlinedButton.icon(
                    onPressed: () => setState(() {
                          _req = null;
                          _code = '';
                          _paste.clear();
                        }),
                    icon: const Icon(AppIcons.close),
                    label: Text('Reject'))),
          ]),
          if (_sentNote.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              key: const Key('req_sent'),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                const Icon(Ph.checkCircle),
                const SizedBox(width: 10),
                Expanded(child: Text(_sentNote)),
              ]),
            ),
          ] else if (_code.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Send this approval code back to the member:', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            CodeBox(text: _code),
          ],
        ],
      ]),
    ));
  }
}

class MembersScreen extends StatefulWidget {
  const MembersScreen({super.key});

  @override
  State<MembersScreen> createState() => _MembersScreenState();
}

class _MembersScreenState extends State<MembersScreen> {
  Future<void> _renew(Map<String, dynamic> m) async {
    var days = 90;
    final d = await showDialog<int>(
        context: context,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, set) => AlertDialog(
                  title: Text('Renew'),
                  content: Wrap(spacing: 8, children: [
                    for (final v in kValidityDays)
                      ChoiceChip(label: Text(trp('{n} days', {'n': v})), selected: days == v, onSelected: (_) => set(() => days = v)),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, days), child: Text('Renew')),
                  ],
                )));
    if (d == null) return;
    final code = await access.renew('${m['id']}', d);
    if (code != null && mounted) {
      await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
                title: Text('New approval code'),
                content: SingleChildScrollView(child: CodeBox(text: code)),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Close'))],
              ));
    }
  }

  Future<void> _revoke(Map<String, dynamic> m) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text('Revoke this member?'),
              content: Text(
                  'Publish the updated admin.json (shown below the list) so that the phone is blocked the next time it is online.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Revoke')),
              ],
            ));
    if (ok == true) await access.revoke('${m['id']}');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return AnimatedBuilder(
      animation: access,
      builder: (context, _) {
        final now = access.clock();
        return AiContextScope(ctx: const AiScreenContext(kind: 'admin', title: 'Administration'), child: Scaffold(
          appBar: AppBar(title: Text('Members')),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            if (access.members.isEmpty) Text('Nobody is approved yet.'),
            for (final m in access.members)
              Builder(builder: (_) {
                final exp = DateTime.fromMillisecondsSinceEpoch((m['exp'] as int) * 1000);
                final rev = m['revoked'] == true;
                final expired = !now.isBefore(exp);
                final status = rev ? 'Revoked' : expired ? 'Expired' : 'Active';
                return Card(
                    child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${m['name']}', style: Theme.of(context).textTheme.titleSmall),
                    Text('${m['email']}'),
                    Text('${tr(status)}  ·  ${fmtDate(exp)}',
                        style: TextStyle(color: rev || expired ? cs.error : cs.primary, fontWeight: FontWeight.w700)),
                    Wrap(spacing: 8, children: [
                      if (!rev) TextButton(onPressed: () => _renew(m), child: Text('Renew')),
                      if (!rev) TextButton(onPressed: () => _revoke(m), child: Text('Revoke')),
                    ]),
                  ]),
                ));
              }),
            const SizedBox(height: 12),
            Text('admin.json to publish', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 6),
            CodeBox(text: access.adminJson()),
          ]),
        ));
      },
    );
  }
}
