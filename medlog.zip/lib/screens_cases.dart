import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';

import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'quick_add.dart';
import 'templates.dart';
import 'ui.dart';
import 'widgets.dart';

void openNewCase(BuildContext context, {String? date}) {
  final c = store.newCase();
  if (date != null) c.set('date', date);
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: c)),
  );
}

void openCase(BuildContext context, CaseRec c) {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: c)),
  );
}

// ================================================================ cases list

class CaseTile extends StatelessWidget {
  final CaseRec c;
  final bool selected;
  final bool selecting;
  final VoidCallback? onToggle;
  const CaseTile(this.c, {super.key, this.selected = false, this.selecting = false, this.onToggle});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final spec = c.s('specialty');
    final age = c.s('ageGroup');
    final initials = store.useInitials && c.s('initials').isNotEmpty ? c.s('initials') : '';
    final head = [c.s('code'), if (initials.isNotEmpty) initials, if (age.isNotEmpty) tr(age)].join(' • ');
    final sub = [tr(spec), tr(c.s('setting'))].where((e) => e.isNotEmpty).join(' • ');
    final tags = c.tags;
    final by = c.shared && c.s('author').isNotEmpty ? trp('by {name}', {'name': c.s('author')}) : '';
    return AppCard(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      color: selected ? theme.colorScheme.primaryContainer : null,
      child: InkWell(
        onTap: selecting ? onToggle : () => openCase(context, c),
        onLongPress: onToggle,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SpecialtyAvatar(spec, selected: selected),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(head, style: theme.textTheme.labelLarge),
                    const SizedBox(height: 2),
                    Text(c.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyLarge),
                    if (sub.isNotEmpty || by.isNotEmpty)
                      Text([sub, by].where((e) => e.isNotEmpty).join(' • '),
                          style: theme.textTheme.bodySmall),
                    if (tags.isNotEmpty)
                      Text(tags.map(tagLabel).join('  '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: theme.colorScheme.primary)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (c.shared) const Icon(Icons.people_alt_outlined, size: 16),
                      if (c.starred) const Icon(Icons.star, size: 18, color: Colors.amber),
                      if (c.review) const Icon(Icons.bookmark, size: 18),
                    ],
                  ),
                  const SizedBox(height: 4),
                  StatusDot(c.s('status')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CasesScreen extends StatefulWidget {
  const CasesScreen({super.key});

  @override
  State<CasesScreen> createState() => _CasesScreenState();
}

class _CasesScreenState extends State<CasesScreen> {
  String _q = '';
  String _status = '';
  String _rotation = '';
  bool _starred = false;
  bool _review = false;
  bool _others = false;
  final Set<String> _sel = {};
  bool _busy = false;
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  List<CaseRec> _filtered() {
    return store.casesSorted().where((c) {
      if (_status.isNotEmpty && c.s('status') != _status) return false;
      if (_rotation.isNotEmpty && c.s('rotationId') != _rotation) return false;
      if (_starred && !c.starred) return false;
      if (_review && !c.review) return false;
      if (_others && !c.shared) return false;
      return matchesQuery(c, _q);
    }).toList();
  }

  Widget _row(List<Widget> items) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          for (final w in items) Padding(padding: const EdgeInsets.only(right: 8), child: w),
        ],
      ),
    );
  }

  void _toggle(String id) {
    setState(() {
      if (!_sel.remove(id)) _sel.add(id);
    });
  }

  Future<void> _sharePack() async {
    final chosen = _sel.map((id) => store.cases[id]).whereType<CaseRec>().toList();
    if (chosen.isEmpty) return;
    final opt = await askPackOptions(context, chosen.length);
    if (opt == null) return;
    setState(() => _busy = true);
    try {
      final f = await store.exportPack(chosen, opt.password,
          images: opt.images, learning: opt.learning);
      await Share.shareXFiles([XFile(f.path)], text: 'MedLog cases');
      if (mounted) setState(() => _sel.clear());
    } catch (e) {
      if (mounted) snack(context, '${tr('Could not share')}: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  void _help() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Search codes', style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 8),
            const Text('Write several words: all of them must match.\n'
                'Use _ for a space, and a minus to exclude.'),
            const SizedBox(height: 12),
            Directionality(
              textDirection: TextDirection.ltr,
              child: m.Text(
                'dx:pneumonia          diagnosis / DDx\n'
                'dx:heart_failure\n'
                '#rare   or   tag:rare\n'
                'spec:MED   spec:peds\n'
                'status:active   role:independent\n'
                'date:2026-10   (month)   date:2026-10-21\n'
                'cc:chest_pain   code:MED-00\n'
                'age:child   setting:er\n'
                'by:ahmad   (cases shared by someone)\n'
                'has:image  has:pending  has:allergy\n'
                'has:question  has:plan  has:progress\n'
                'is:starred  is:review  is:shared  is:draft\n'
                'learn:word\n\n'
                'Examples:\n'
                'spec:MED dx:pneumonia has:image\n'
                'is:review -status:draft\n'
                '#rare date:2026-10',
                style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = _filtered();
        final perDay = <String, int>{};
        for (final c in list) {
          perDay[c.s('date')] = (perDay[c.s('date')] ?? 0) + 1;
        }
        // flat list of items: String = day header, CaseRec = case
        final items = <Object>[];
        String lastDate = '';
        for (final c in list) {
          final d = c.s('date');
          if (d != lastDate) {
            lastDate = d;
            items.add(d);
          }
          items.add(c);
        }
        final selecting = _sel.isNotEmpty;
        return Scaffold(
          appBar: AppBar(
            title: Text(selecting
                ? trp('{n} selected', {'n': _sel.length})
                : '${tr('Cases')} (${list.length})'),
            leading: selecting
                ? IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _sel.clear()),
                  )
                : null,
            actions: [
              if (selecting) ...[
                IconButton(
                  tooltip: 'Select all shown',
                  icon: const Icon(Icons.select_all),
                  onPressed: () => setState(() {
                    for (final c in list) {
                      _sel.add(c.id);
                    }
                  }),
                ),
                IconButton(
                  tooltip: 'Share with colleagues',
                  icon: const Icon(Icons.ios_share),
                  onPressed: _busy ? null : _sharePack,
                ),
              ] else
                IconButton(
                  tooltip: 'Search help',
                  icon: const Icon(Icons.help_outline),
                  onPressed: _help,
                ),
            ],
          ),
          body: Column(
            children: [
              if (_busy) const LinearProgressIndicator(),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: tr('Search… try  spec:MED dx:pneumonia #rare'),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(28),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(28),
                      borderSide: BorderSide.none,
                    ),
                    isDense: true,
                  ),
                  onChanged: (v) {
                    _debounce?.cancel();
                    _debounce = Timer(const Duration(milliseconds: 180), () {
                      if (mounted) setState(() => _q = v);
                    });
                  },
                ),
              ),
              _row([
                FilterChip(
                  label: const Text('Starred'),
                  selected: _starred,
                  onSelected: (v) => setState(() => _starred = v),
                ),
                FilterChip(
                  label: const Text('To review'),
                  selected: _review,
                  onSelected: (v) => setState(() => _review = v),
                ),
                FilterChip(
                  label: const Text('From others'),
                  selected: _others,
                  onSelected: (v) => setState(() => _others = v),
                ),
                for (final s in const ['Draft', 'Active', 'Discharged', 'Referred', 'Completed'])
                  ChoiceChip(
                    label: Text(s),
                    selected: _status == s,
                    onSelected: (v) => setState(() => _status = v ? s : ''),
                  ),
              ]),
              if (store.rotations.isNotEmpty)
                _row([
                  for (final r in store.rotations)
                    ChoiceChip(
                      label: Text(store.rotationLabel(r)),
                      selected: _rotation == r['id'],
                      onSelected: (v) =>
                          setState(() => _rotation = v ? r['id'].toString() : ''),
                    ),
                ]),
              Expanded(
                child: items.isEmpty
                    ? (store.cases.isEmpty
                        ? EmptyState(
                            kind: EmptyKind.cases,
                            title: 'No cases yet',
                            message: 'Tap + to log your first case.',
                            action: FilledButton.icon(
                              onPressed: () => showQuickAdd(context),
                              icon: const Icon(Icons.add),
                              label: Text('New case'),
                            ),
                          )
                        : const EmptyState(
                            kind: EmptyKind.search,
                            title: 'No cases found',
                            message: 'Try fewer filters or a different search.',
                          ))
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 88),
                        itemCount: items.length,
                        itemBuilder: (context, i) {
                          final it = items[i];
                          if (it is String) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                              child: Text(
                                '${prettyDate(it)} • ${countLabel(perDay[it] ?? 0, 'case')}',
                                style: Theme.of(context).textTheme.labelLarge,
                              ),
                            );
                          }
                          final c = it as CaseRec;
                          return FadeSlideIn(
                            key: ValueKey(c.id),
                            index: i > 8 ? 0 : i,
                            child: CaseTile(
                              c,
                              selecting: selecting,
                              selected: _sel.contains(c.id),
                              onToggle: () => _toggle(c.id),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ case editor

class CaseEditorScreen extends StatefulWidget {
  final CaseRec rec;
  const CaseEditorScreen({super.key, required this.rec});

  @override
  State<CaseEditorScreen> createState() => _CaseEditorScreenState();
}

class _CaseEditorScreenState extends State<CaseEditorScreen> {
  final Map<String, TextEditingController> _ctl = {};
  Timer? _timer;
  bool _dirty = false;
  bool _warnedImages = false;

  CaseRec get rec => widget.rec;

  TextEditingController _tc(String key) =>
      _ctl.putIfAbsent(key, () => TextEditingController(text: rec.s(key)));

  bool _touched = false;

  void _changed({bool rebuild = true}) {
    _dirty = true;
    _touched = true;
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 700), _flush);
    if (rebuild && mounted) setState(() {});
  }

  Future<void> _flush() async {
    _timer?.cancel();
    if (!_dirty) return;
    _dirty = false;
    await store.saveCase(rec, notify: false);
  }

  @override
  void dispose() {
    _timer?.cancel();
    final touched = _touched;
    Future<void> done;
    if (_dirty) {
      _dirty = false;
      done = store.saveCase(rec, notify: false);
    } else {
      done = Future<void>.value();
    }
    if (touched) {
      done.then((_) => store.refresh());
    }
    for (final c in _ctl.values) {
      c.dispose();
    }
    super.dispose();
  }

  // ------------------------------------------------------------ builders

  Widget _tf(String key, String label,
      {int lines = 1, String hint = '', TextInputType? kt}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: _tc(key),
        minLines: lines,
        maxLines: lines == 1 ? 1 : null,
        keyboardType: lines > 1 ? TextInputType.multiline : kt,
        textCapitalization: TextCapitalization.sentences,
        decoration: InputDecoration(
          labelText: tr(label),
          hintText: hint.isEmpty ? null : tr(hint),
          alignLabelWithHint: true,
        ),
        onChanged: (v) {
          final wasEmpty = rec.s(key).isEmpty;
          rec.set(key, v);
          _changed(rebuild: wasEmpty != v.isEmpty || key == 'allergies');
        },
      ),
    );
  }

  Widget _choice(String key, String label, List<String> options,
      {void Function(String)? onPick}) {
    final cur = rec.s(key);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final o in options)
                ChoiceChip(
                  label: Text(o),
                  selected: cur == o,
                  onSelected: (_) {
                    final v = cur == o ? '' : o;
                    rec.set(key, v);
                    if (onPick != null) onPick(v);
                    _changed();
                  },
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _quick(String key, List<String> items) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Wrap(
        spacing: 6,
        children: [
          for (final t in items)
            ActionChip(
              label: Text(t),
              visualDensity: VisualDensity.compact,
              onPressed: () {
                final c = _tc(key);
                final cur = c.text.trim();
                c.text = cur.isEmpty ? t : '$cur; $t';
                rec.set(key, c.text);
                _changed();
              },
            ),
        ],
      ),
    );
  }

  Widget _banner(String text, {IconData icon = Icons.shield_outlined}) {
    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon),
            const SizedBox(width: 12),
            Expanded(child: Text(text, style: Theme.of(context).textTheme.bodySmall)),
          ],
        ),
      ),
    );
  }

  Widget _dateTile(String key, String label) {
    final cur = rec.s(key);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      subtitle: Text(cur.isEmpty ? '—' : prettyDate(cur)),
      trailing: const Icon(Icons.calendar_today_outlined),
      onTap: () async {
        final d = await showDatePicker(
          context: context,
          initialDate: parseDate(cur) ?? DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (d != null) {
          rec.set(key, fmtDate(d));
          _changed();
        }
      },
    );
  }

  /// Guides the flow: one tap to the next section.
  Widget _next(int from) {
    const names = [
      'Info', 'History', 'Exam', 'Investigations', 'Assessment', 'Management', 'Progress', 'Learning'
    ];
    if (from >= names.length - 1) return const SizedBox(height: 24);
    return Builder(builder: (ctx) {
      return Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 24),
        child: Align(
          alignment: AlignmentDirectional.centerEnd,
          child: FilledButton.tonalIcon(
            onPressed: () => DefaultTabController.of(ctx).animateTo(from + 1),
            icon: const Icon(Icons.arrow_forward),
            iconAlignment: IconAlignment.end,
            label: Text('${tr('Next')}: ${tr(names[from + 1])}'),
          ),
        ),
      );
    });
  }

  /// Optional fields live in a collapsible block so the screen stays short.
  Widget _more(String title, List<Widget> children, {bool open = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          initiallyExpanded: open,
          tilePadding: const EdgeInsets.symmetric(horizontal: 12),
          childrenPadding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          backgroundColor: Theme.of(context).colorScheme.surfaceContainerLow,
          collapsedBackgroundColor: Theme.of(context).colorScheme.surfaceContainerLow,
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          children: children,
        ),
      ),
    );
  }

  // ------------------------------------------------------------ tabs

  Widget _info() {
    final tags = rec.tags;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _banner(store.useInitials
            ? tr('Initials only (e.g. M.K.). No names, ID numbers or exact ages. '
                'Cover any name on photos before taking them.')
            : tr('No names, initials, ID numbers or exact ages are stored. '
                'Use the case code to recognise a patient. Cover any name on photos.')),
        if (rec.shared)
          _banner(
              '${rec.s('author').isEmpty ? tr('Shared with you.') : trp('Shared with you by {name}.', {'name': rec.s('author')})} '
              '${tr('You can add your own notes. A newer version from the sender replaces this copy.')}',
              icon: Icons.people_alt_outlined),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(rec.s('code'), style: Theme.of(context).textTheme.headlineSmall),
          subtitle: const Text('Case code (automatic)'),
        ),
        if (store.useInitials) _tf('initials', 'Patient initials (stays on this phone)', hint: 'M.K.'),
        _choice('ageGroup', 'Age group', const ['Child', 'Adult']),
        _choice('sex', 'Sex (only if clinically relevant)', const ['M', 'F']),
        _choice('specialty', 'Specialty', kSpecialtyNames, onPick: (v) {
          if (v.isNotEmpty) {
            final p = prefixFor(v);
            if (!rec.s('code').startsWith('$p-')) {
              rec.set('code', store.nextCode(p));
            }
          }
        }),
        if (store.rotations.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Rotation', style: Theme.of(context).textTheme.labelLarge),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final r in store.rotations)
                      ChoiceChip(
                        label: Text(store.rotationLabel(r)),
                        selected: rec.s('rotationId') == r['id'],
                        onSelected: (sel) {
                          rec.set('rotationId', sel ? r['id'].toString() : '');
                          _changed();
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
        _dateTile('date', 'Case date'),
        _choice('status', 'Status',
            const ['Draft', 'Active', 'Discharged', 'Referred', 'Completed']),
        _choice('role', 'My role',
            const ['Observed', 'Assisted', 'Supervised', 'Independent']),
        _more(
          'More details',
          [
            _choice('setting', 'Setting', const ['ER', 'Clinic', 'Ward', 'ICU', 'OR']),
            _choice('encounter', 'Encounter',
                const ['New admission', 'Follow-up', 'Consultation']),
          ],
          open: rec.s('setting').isNotEmpty || rec.s('encounter').isNotEmpty,
        ),
        const SectionHeader('Tags'),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final t in tags)
              InputChip(
                label: Text(tagLabel(t)),
                onDeleted: () {
                  final l = rec.tags;
                  l.remove(t);
                  rec.tags = l;
                  _changed();
                },
              ),
            ActionChip(
              avatar: const Icon(Icons.add, size: 18),
              label: const Text('Tag'),
              onPressed: () async {
                final t = await askText(context, 'New tag', hint: 'e.g. rare');
                if (t != null && t.trim().isNotEmpty) {
                  final l = rec.tags;
                  final clean = t.trim().replaceAll('#', '').replaceAll(' ', '_');
                  if (!l.contains(clean)) l.add(clean);
                  rec.tags = l;
                  _changed();
                }
              },
            ),
          ],
        ),
        Wrap(
          spacing: 6,
          children: [
            for (final t in const ['interesting', 'rare', 'exam_case', 'to_present'])
              if (!tags.contains(t))
                ActionChip(
                  label: Text(tagLabel(t)),
                  visualDensity: VisualDensity.compact,
                  onPressed: () {
                    final l = rec.tags;
                    l.add(t);
                    rec.tags = l;
                    _changed();
                  },
                ),
          ],
        ),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Starred'),
          value: rec.starred,
          onChanged: (v) {
            rec.set('starred', v);
            _changed();
          },
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('To review later'),
          value: rec.review,
          onChanged: (v) {
            rec.set('review', v);
            _changed();
          },
        ),
        _next(0),
      ],
    );
  }

  Widget _history() {
    final al = rec.s('allergies').trim().toLowerCase();
    final hasAllergy = al.isNotEmpty && !const ['nkda', 'none', 'no', 'nka'].contains(al);
    final extra = kSpecialtyFields[rec.s('specialty')];
    final tpls = templatesFor(rec.s('specialty'));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (tpls.isNotEmpty) ...[
          Text('Quick templates', style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Wrap(
            spacing: 6,
            runSpacing: 0,
            children: [
              for (final t in tpls)
                ActionChip(
                  avatar: const Icon(Icons.auto_fix_high, size: 16),
                  label: Text(t.label),
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _applyTemplate(t),
                ),
            ],
          ),
          const SizedBox(height: 12),
        ],
        _tf('cc', 'Chief complaint + duration', lines: 2),
        _tf('hpi', 'History of presenting illness', lines: 6),
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Wrap(
            spacing: 6,
            children: [
              ActionChip(
                label: const Text('SOCRATES template'),
                visualDensity: VisualDensity.compact,
                onPressed: () {
                  final c = _tc('hpi');
                  const tpl = 'Site: \nOnset: \nCharacter: \nRadiation: \n'
                      'Associations: \nTime course: \nExacerbating/relieving: \nSeverity: \n';
                  c.text = c.text.trim().isEmpty ? tpl : '${c.text}\n$tpl';
                  rec.set('hpi', c.text);
                  _changed();
                },
              ),
              ActionChip(
                label: const Text('Pertinent negatives'),
                visualDensity: VisualDensity.compact,
                onPressed: () {
                  final c = _tc('hpi');
                  c.text = '${c.text.trim()}\nPertinent negatives: '.trim();
                  rec.set('hpi', c.text);
                  _changed();
                },
              ),
            ],
          ),
        ),
        _tf('pmh', 'Past medical history', lines: 2),
        _tf('drugs', 'Drug history (name, dose)', lines: 2),
        _tf('allergies', 'Allergies', hint: 'NKDA or list'),
        if (hasAllergy)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(
              children: [
                const Icon(Icons.warning_amber_rounded, color: Colors.red),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${tr('ALLERGY')}: ${rec.s('allergies')}',
                    style: const TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        _more(
          'More history',
          [
            _tf('psh', 'Past surgical history', lines: 2),
            _tf('family', 'Family history', lines: 2),
            _tf('social', 'Social history (smoking, occupation...)', lines: 2),
            _tf('ros', 'Review of systems', lines: 3),
            _quick('ros', const [
              'ROS negative except as above', 'Fever', 'Weight loss', 'Cough', 'SOB',
              'Chest pain', 'Palpitations', 'Nausea/vomiting', 'Diarrhea',
              'Constipation', 'Dysuria', 'Headache',
            ]),
          ],
          open: ['psh', 'family', 'social', 'ros'].any((k) => rec.s(k).isNotEmpty),
        ),
        if (extra != null) ...[
          SectionHeader('${tr(rec.s('specialty'))} • ${tr('specific')}'),
          for (final f in extra) _tf(f[0], f[1], lines: 2),
        ],
        _next(1),
      ],
    );
  }

  void _applyTemplate(CaseTemplate t) {
    void put(String key, String text) {
      if (text.isEmpty) return;
      final c = _tc(key);
      c.text = c.text.trim().isEmpty ? text : '${c.text.trim()}\n$text';
      rec.set(key, c.text);
    }

    put('hpi', t.hpi);
    put('examSystemic', t.exam);
    _changed();
    snack(context, trp('Template added: {name}', {'name': tr(t.label)}));
  }

  Widget _exam() {
    final adult = rec.s('ageGroup') == 'Adult';
    const vitals = [
      ['v_bp', 'BP', '120/80'],
      ['v_hr', 'HR', 'bpm'],
      ['v_temp', 'Temp', '°C'],
      ['v_rr', 'RR', '/min'],
      ['v_spo2', 'SpO2', '%'],
      ['v_rbs', 'RBS', 'mg/dL'],
      ['v_wt', 'Weight', 'kg'],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Vital signs', style: Theme.of(context).textTheme.titleMedium),
        if (!adult)
          Text('Abnormal-value highlighting works for Adult only (set age group in Info).',
              style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final v in vitals)
              SizedBox(
                width: 104,
                child: TextField(
                  controller: _tc(v[0]),
                  keyboardType: v[0] == 'v_bp'
                      ? TextInputType.text
                      : const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: tr(v[1]),
                    hintText: v[2],
                    isDense: true,
                    enabledBorder: vitalAbnormal(v[0], rec.s(v[0]), adult)
                        ? OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Colors.red, width: 2))
                        : null,
                  ),
                  onChanged: (t) {
                    rec.set(v[0], t);
                    _changed();
                  },
                ),
              ),
          ],
        ),
        const SizedBox(height: 16),
        _tf('examGeneral', 'General examination', lines: 3),
        _obs('obsGeneral', 'examGeneral'),
        _quick('examGeneral', const [
          'Conscious, alert, oriented', 'Not pale', 'Not jaundiced', 'No cyanosis',
          'No clubbing', 'No edema', 'No lymphadenopathy', 'Well hydrated',
        ]),
        _tf('examSystemic', 'Systemic examination (CVS / Resp / Abd / CNS / MSK)',
            lines: 6),
        _obs('obsSystemic', 'examSystemic'),
        _quick('examSystemic', const [
          'S1 S2 normal, no murmurs', 'Chest clear bilaterally', 'Soft & lax abdomen',
          'No tenderness', 'Bowel sounds present', 'GCS 15/15', 'Neck supple',
          'Power 5/5 all limbs', 'Reflexes normal',
        ]),
        _tf('examFocused', 'Focused examination / positive findings', lines: 3),
        _obs('obsFocused', 'examFocused'),
        _next(2),
      ],
    );
  }

  /// Who actually examined? Keeps the log honest.
  Widget _obs(String key, String textKey) {
    final missing = rec.s(textKey).trim().isNotEmpty && rec.s(key).isEmpty;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _choice(key, 'Source of these findings',
              const ['Examined by me', 'Reported by team', 'Not examined']),
          if (missing)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('Tip: mark whether you examined this yourself.',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: Colors.orange)),
            ),
        ],
      ),
    );
  }

  Future<void> _editInv([J? inv]) async {
    final res = await showFormSheet(
      context,
      title: inv == null ? 'New investigation' : 'Investigation',
      specs: const [
        FieldSpec('name', 'Test / study', hint: 'CBC, CXR, ECG...'),
        FieldSpec('indication', 'Indication'),
        FieldSpec('requestedBy', 'Requested by',
            type: FT.choice, options: ['Me', 'Team', 'Supervisor']),
        FieldSpec('status', 'Status',
            type: FT.choice, options: ['Pending', 'Resulted', 'Reviewed']),
        FieldSpec('result', 'Result', type: FT.multi),
        FieldSpec('interpretation', 'My interpretation', type: FT.multi),
      ],
      initial: inv ??
          <String, dynamic>{
            'id': newId('i'),
            'status': 'Pending',
            'requestedBy': 'Me',
            'date': todayStr(),
          },
      canDelete: inv != null,
    );
    if (res == null) return;
    final list = rec.lst('inv');
    if (res['__delete'] == true) {
      list.removeWhere((e) => e['id'] == inv!['id']);
    } else {
      final i = list.indexWhere((e) => e['id'] == res['id']);
      if (i >= 0) {
        list[i] = res;
      } else {
        list.add(res);
      }
    }
    _changed();
  }

  void _quickInv(String name) {
    rec.lst('inv').add(<String, dynamic>{
      'id': newId('i'),
      'name': name,
      'status': 'Pending',
      'requestedBy': 'Me',
      'date': todayStr(),
    });
    _changed();
  }

  static const List<String> _imgTypes = [
    'X-ray', 'CT', 'MRI', 'Ultrasound', 'ECG', 'Lab report', 'Skin / wound',
    'Pathology', 'Other',
  ];

  Future<void> _addImage() async {
    if (!_warnedImages) {
      final ok = await confirmDialog(
        context,
        'Before adding an image: make sure no patient name, ID number or hospital '
        'file number is visible. Cover it before taking the photo.',
        action: 'Continue',
      );
      if (!ok) return;
      _warnedImages = true;
    }
    if (!mounted) return;
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Camera'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Gallery'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    final type = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('What is this image?', style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('Sets the quality: ECG and lab reports keep small print readable.',
                  style: Theme.of(ctx).textTheme.bodySmall),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final t in _imgTypes)
                    ActionChip(label: Text(t), onPressed: () => Navigator.pop(ctx, t)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (type == null) return;
    int quality = 75;
    double width = 1800;
    if (type == 'ECG' || type == 'Lab report') {
      quality = 92;
      width = 2600;
    } else if (const ['X-ray', 'CT', 'MRI', 'Ultrasound', 'Pathology'].contains(type)) {
      quality = 85;
      width = 2200;
    }
    final x = await ImagePicker()
        .pickImage(source: src, imageQuality: quality, maxWidth: width);
    if (x == null) return;
    final name = await store.importImage(x.path, rec.s('code'));
    if (!mounted) return;
    final meta = await showFormSheet(
      context,
      title: 'Image details',
      specs: const [
        FieldSpec('type', 'Type', type: FT.choice, options: _imgTypes),
        FieldSpec('view', 'View', hint: 'AP, lateral, axial...'),
        FieldSpec('caption', 'Caption'),
        FieldSpec('interpretation', 'My interpretation', type: FT.multi),
      ],
      initial: <String, dynamic>{'file': name, 'date': todayStr(), 'type': type},
    );
    rec.lst('images').add(
        meta ?? <String, dynamic>{'file': name, 'date': todayStr(), 'type': type});
    _changed();
  }

  Future<void> _viewImage(J img) async {
    final act = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => ImageViewer(img: img)),
    );
    if (act == 'edit') {
      if (!mounted) return;
      final res = await showFormSheet(
        context,
        title: 'Image details',
        specs: const [
          FieldSpec('type', 'Type',
              type: FT.choice,
              options: ['X-ray', 'CT', 'MRI', 'Ultrasound', 'ECG', 'Lab report',
                'Skin / wound', 'Pathology', 'Other']),
          FieldSpec('view', 'View'),
          FieldSpec('caption', 'Caption'),
          FieldSpec('interpretation', 'My interpretation', type: FT.multi),
        ],
        initial: img,
      );
      if (res != null) {
        final l = rec.lst('images');
        final i = l.indexWhere((e) => e['file'] == img['file']);
        if (i >= 0) l[i] = res;
        _changed();
      }
    } else if (act == 'delete') {
      if (!mounted) return;
      final ok = await confirmDialog(context, 'Delete this image?');
      if (ok) {
        rec.lst('images').removeWhere((e) => e['file'] == img['file']);
        await store.deleteImageFile(img['file'].toString());
        _changed();
      }
    }
  }

  Widget _inv() {
    final list = rec.lst('inv');
    final images = rec.lst('images');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Quick add (as requested / pending)',
            style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          children: [
            for (final n in const [
              'CBC', 'KFT', 'LFT', 'Electrolytes', 'ABG', 'CRP', 'Troponin',
              'Coagulation', 'Urinalysis', 'ECG', 'CXR', 'Ultrasound', 'CT', 'MRI',
            ])
              ActionChip(
                label: Text(n),
                visualDensity: VisualDensity.compact,
                onPressed: () => _quickInv(n),
              ),
          ],
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => _editInv(),
          icon: const Icon(Icons.add),
          label: const Text('Add custom investigation'),
        ),
        const SizedBox(height: 8),
        if (list.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text('No investigations yet.'),
          ),
        for (final i in list)
          AppCard(
            child: ListTile(
              onTap: () => _editInv(i),
              title: Text((i['name'] ?? '').toString()),
              subtitle: Text(
                [
                  '${tr((i['status'] ?? '').toString())} • ${tr('by')} ${tr((i['requestedBy'] ?? '').toString())}',
                  if ((i['result'] ?? '').toString().isNotEmpty) '${i['result']}',
                ].join('\n'),
              ),
              isThreeLine: (i['result'] ?? '').toString().isNotEmpty,
              trailing: Icon(
                i['status'] == 'Pending'
                    ? Icons.hourglass_empty
                    : Icons.check_circle_outline,
              ),
            ),
          ),
        SectionHeader(
          '${tr('Images')} (${images.length})',
          trailing: TextButton.icon(
            onPressed: _addImage,
            icon: const Icon(Icons.add_a_photo_outlined),
            label: const Text('Add'),
          ),
        ),
        if (images.isNotEmpty)
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: [
              for (final img in images)
                InkWell(
                  onTap: () => _viewImage(img),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(
                          File(store.imagePath(img['file'].toString())),
                          fit: BoxFit.cover,
                          cacheWidth: 400,
                          errorBuilder: (_, __, ___) =>
                              const Center(child: Icon(Icons.broken_image_outlined)),
                        ),
                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            color: Colors.black54,
                            padding: const EdgeInsets.all(3),
                            child: Text(
                              [(img['type'] ?? '').toString(), (img['view'] ?? '').toString()]
                                  .where((e) => e.isNotEmpty)
                                  .join(' '),
                              style: const TextStyle(color: Colors.white, fontSize: 11),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        _next(3),
      ],
    );
  }

  Widget _assess() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _tf('problems', 'Problem list', lines: 3),
        _tf('ddx', 'Differential diagnosis (most likely first)', lines: 4),
        _tf('workingDx', 'Working / provisional diagnosis', lines: 2),
        _tf('finalDx', 'Final diagnosis', lines: 2),
        _tf('redFlags', 'Red flags', lines: 2),
        _tf('reasoning', 'Clinical reasoning: what supports / argues against?', lines: 5),
        SectionHeader(
          'Diagnostic evolution',
          trailing: TextButton.icon(
            onPressed: () => _editEvo(),
            icon: const Icon(Icons.add),
            label: const Text('Step'),
          ),
        ),
        if (rec.lst('evo').isEmpty)
          Text('Track how your thinking changed: first impression, new findings, final diagnosis.',
              style: Theme.of(context).textTheme.bodySmall),
        for (final e in rec.lst('evo'))
          AppCard(
            child: ListTile(
              onTap: () => _editEvo(e),
              leading: const Icon(Icons.timeline),
              title: Text(tr('${e['step'] ?? ''}')),
              subtitle: Text([
                prettyDate((e['date'] ?? '').toString()),
                (e['text'] ?? '').toString(),
                if ((e['evidence'] ?? '').toString().isNotEmpty)
                  '${tr('Because')}: ${e['evidence']}',
              ].where((x) => x.isNotEmpty).join('\n')),
            ),
          ),
        _next(4),
      ],
    );
  }

  Future<void> _editEvo([J? e]) async {
    final res = await showFormSheet(
      context,
      title: e == null ? 'New step' : 'Step',
      specs: const [
        FieldSpec('step', 'Step',
            type: FT.choice,
            options: ['Initial DDx', 'New finding', 'Updated DDx', 'Final diagnosis']),
        FieldSpec('date', 'Date', type: FT.date),
        FieldSpec('text', 'Diagnosis / thinking at this point', type: FT.multi),
        FieldSpec('evidence', 'What made me think so (finding / result)', type: FT.multi),
      ],
      initial: e ?? <String, dynamic>{'id': newId('e'), 'date': todayStr(), 'step': 'Initial DDx'},
      canDelete: e != null,
    );
    if (res == null) return;
    final list = rec.lst('evo');
    if (res['__delete'] == true) {
      list.removeWhere((x) => x['id'] == e!['id']);
    } else {
      final i = list.indexWhere((x) => x['id'] == res['id']);
      if (i >= 0) {
        list[i] = res;
      } else {
        list.add(res);
      }
      list.sort((a, b) => (a['date'] ?? '').toString().compareTo((b['date'] ?? '').toString()));
    }
    _changed();
  }

  Future<void> _editMgmt([J? m]) async {
    final res = await showFormSheet(
      context,
      title: m == null ? 'New plan item' : 'Plan item',
      specs: const [
        FieldSpec('text', 'Plan item (drug / intervention)', type: FT.multi),
        FieldSpec('dose', 'Dose / route / frequency (as written in the chart)',
            hint: 'e.g. 500 mg PO q8h'),
        FieldSpec('state', 'Status',
            type: FT.choice, options: ['Suggested', 'Ordered', 'Given', 'Stopped']),
        FieldSpec('category', 'Category',
            type: FT.choice,
            options: ['Initial / ER', 'Medications & fluids', 'Procedure / surgery',
              'Consult / referral', 'Monitoring', 'Safety-netting']),
        FieldSpec('by', 'Who decided',
            type: FT.choice,
            options: ['Suggested by me', 'Team decision', 'Supervisor changed']),
      ],
      initial: m ??
          <String, dynamic>{'id': newId('m'), 'by': 'Team decision', 'state': 'Ordered'},
      canDelete: m != null,
    );
    if (res == null) return;
    final list = rec.lst('mgmt');
    if (res['__delete'] == true) {
      list.removeWhere((e) => e['id'] == m!['id']);
    } else {
      final i = list.indexWhere((e) => e['id'] == res['id']);
      if (i >= 0) {
        list[i] = res;
      } else {
        list.add(res);
      }
    }
    _changed();
  }

  Color _byColor(String by) {
    switch (by) {
      case 'Suggested by me':
        return Colors.green;
      case 'Supervisor changed':
        return Colors.amber;
      default:
        return Colors.blue;
    }
  }

  Widget _mgmt() {
    final list = rec.lst('mgmt');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _banner('Mark honestly who made each decision: what you suggested, what the '
            'team decided, and what the supervisor changed.',
            icon: Icons.fact_check_outlined),
        FilledButton.icon(
          onPressed: () => _editMgmt(),
          icon: const Icon(Icons.add),
          label: const Text('Add plan item'),
        ),
        const SizedBox(height: 8),
        for (final m in list)
          AppCard(
            child: ListTile(
              onTap: () => _editMgmt(m),
              leading: Icon(Icons.circle, color: _byColor((m['by'] ?? '').toString())),
              title: Text((m['text'] ?? '').toString()),
              subtitle: Text([
                '${tr((m['category'] ?? '').toString())} • ${tr((m['by'] ?? '').toString())}',
                if ((m['dose'] ?? '').toString().isNotEmpty) '${m['dose']}',
                if ((m['state'] ?? '').toString().isNotEmpty) tr('${m['state']}'),
              ].join('\n')),
              isThreeLine: (m['dose'] ?? '').toString().isNotEmpty,
            ),
          ),
        const SectionHeader('Disposition'),
        _choice('disposition', 'Disposition',
            const ['Admitted', 'Discharged', 'Transferred', 'Referred', 'Deceased']),
        _tf('followUp', 'Follow-up recommendations', lines: 2),
        _tf('outcome', 'Outcome', lines: 2),
        _next(5),
      ],
    );
  }

  Future<void> _editProgress([J? p]) async {
    final base = parseDate(rec.s('date')) ?? DateTime.now();
    final diff = DateTime.now().difference(base).inDays;
    final res = await showFormSheet(
      context,
      title: p == null ? 'New progress note' : 'Progress note',
      specs: const [
        FieldSpec('day', 'Day', hint: 'Day 1 / POD 2', options: ['Day 0', 'Day 1', 'Day 2', 'Day 3']),
        FieldSpec('date', 'Date', type: FT.date),
        FieldSpec('s', 'S - Subjective', type: FT.multi),
        FieldSpec('o', 'O - Objective (exam, vitals, results)', type: FT.multi),
        FieldSpec('a', 'A - Assessment', type: FT.multi),
        FieldSpec('p', 'P - Plan', type: FT.multi),
      ],
      initial: p ??
          <String, dynamic>{
            'id': newId('p'),
            'day': 'Day ${diff < 0 ? 0 : diff}',
            'date': todayStr(),
          },
      canDelete: p != null,
    );
    if (res == null) return;
    final list = rec.lst('progress');
    if (res['__delete'] == true) {
      list.removeWhere((e) => e['id'] == p!['id']);
    } else {
      final i = list.indexWhere((e) => e['id'] == res['id']);
      if (i >= 0) {
        list[i] = res;
      } else {
        list.add(res);
      }
      list.sort((a, b) => (a['date'] ?? '').toString().compareTo((b['date'] ?? '').toString()));
    }
    _changed();
  }

  Widget _progress() {
    final list = rec.lst('progress');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
          onPressed: () => _editProgress(),
          icon: const Icon(Icons.add),
          label: const Text('Add progress note (SOAP)'),
        ),
        const SizedBox(height: 8),
        if (list.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text('No progress notes yet.'),
          ),
        for (final p in list)
          AppCard(
            child: ListTile(
              onTap: () => _editProgress(p),
              title: Text('${tr('${p['day'] ?? ''}')} • ${prettyDate((p['date'] ?? '').toString())}'),
              subtitle: Text(
                [
                  for (final k in const ['s', 'o', 'a', 'p'])
                    if ((p[k] ?? '').toString().isNotEmpty)
                      '${k.toUpperCase()}: ${p[k]}',
                ].join('\n'),
              ),
            ),
          ),
        _next(6),
      ],
    );
  }

  Widget _learn() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _banner('This is the most valuable part: what did this case teach you?',
            icon: Icons.school_outlined),
        _tf('initialDx', 'My first diagnosis (before results)', lines: 2),
        _tf('whatChanged', 'What changed my diagnosis?', lines: 3),
        _tf('learned', 'What I learned', lines: 5),
        _tf('mistakes', 'Mistakes / near-misses (mine or others) — for learning', lines: 3),
        _tf('questions', 'Questions I could not answer (to review)', lines: 3),
        _tf('refs', 'References (book, guideline, page, link)', lines: 2),
        _tf('teaching', 'Supervisor teaching points', lines: 3),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Add to review list'),
          value: rec.review,
          onChanged: (v) {
            rec.set('review', v);
            _changed();
          },
        ),
        _next(7),
      ],
    );
  }

  // ------------------------------------------------------------ actions

  Future<void> _menu(String v) async {
    if (v == 'share') {
      await Share.share(caseAsText(rec));
    } else if (v == 'present') {
      await Share.share(casePresentation(rec));
    } else if (v == 'pack') {
      await _flush();
      if (!mounted) return;
      final opt = await askPackOptions(context, 1);
      if (opt == null) return;
      try {
        final f = await store.exportPack([rec], opt.password,
            images: opt.images, learning: opt.learning);
        await Share.shareXFiles([XFile(f.path)], text: 'MedLog case');
      } catch (e) {
        if (mounted) snack(context, '${tr('Could not share')}: $e');
      }
    } else if (v == 'delete') {
      final ok = await confirmDialog(context, 'Delete this case and its images?');
      if (!ok) return;
      _timer?.cancel();
      _dirty = false;
      await store.deleteCase(rec);
      if (mounted) Navigator.pop(context);
    }
  }

  /// Which of the 8 sections already have something in them.
  List<bool> _filled() {
    bool any(List<String> keys) => keys.any((k) => rec.s(k).trim().isNotEmpty);
    return [
      rec.s('specialty').isNotEmpty && rec.s('ageGroup').isNotEmpty,
      any(['cc', 'hpi', 'pmh']),
      any(['examGeneral', 'examSystemic', 'examFocused', 'v_bp', 'v_hr', 'v_temp']),
      rec.lst('inv').isNotEmpty || rec.lst('images').isNotEmpty,
      any(['ddx', 'workingDx', 'finalDx', 'problems']),
      rec.lst('mgmt').isNotEmpty || any(['disposition']),
      rec.lst('progress').isNotEmpty,
      any(['learned', 'initialDx', 'whatChanged']),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final filled = _filled();
    final done = filled.where((e) => e).length;
    final cs = Theme.of(context).colorScheme;

    Widget tab(IconData icon, String label, int i) {
      return Tab(
        height: 58,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(icon, size: 22),
                PositionedDirectional(
                  top: -2,
                  end: -5,
                  child: AnimatedScale(
                    scale: filled[i] ? 1 : 0,
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOutBack,
                    child: Container(
                      width: 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        border: Border.all(color: cs.surface, width: 1.5),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      );
    }

    return DefaultTabController(
      length: 8,
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(rec.s('code'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              Text(trp('{a} of {b} sections filled', {'a': done, 'b': 8}),
                  style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant, fontWeight: FontWeight.w500)),
            ],
          ),
          actions: [
            IconButton(
              icon: Icon(rec.starred ? Icons.star : Icons.star_border),
              onPressed: () {
                rec.set('starred', !rec.starred);
                _changed();
              },
            ),
            PopupMenuButton<String>(
              onSelected: _menu,
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'present', child: Text('Share case presentation')),
                PopupMenuItem(value: 'share', child: Text('Share as text (no initials)')),
                PopupMenuItem(value: 'pack', child: Text('Share to colleague (encrypted)')),
                PopupMenuItem(value: 'delete', child: Text('Delete case')),
              ],
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(62),
            child: Column(
              children: [
                TabBar(
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  tabs: [
                    tab(Icons.badge_outlined, tr('Info'), 0),
                    tab(Icons.history_edu_outlined, tr('History'), 1),
                    tab(Icons.monitor_heart_outlined, tr('Exam'), 2),
                    tab(Icons.biotech_outlined, tr('Investigations'), 3),
                    tab(Icons.psychology_outlined, tr('Assessment'), 4),
                    tab(Icons.medication_outlined, tr('Management'), 5),
                    tab(Icons.timeline, tr('Progress'), 6),
                    tab(Icons.school_outlined, tr('Learning'), 7),
                  ],
                ),
                AnimatedBar(done / 8, height: 3),
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            _info(),
            _history(),
            _exam(),
            _inv(),
            _assess(),
            _mgmt(),
            _progress(),
            _learn(),
          ],
        ),
      ),
    );
  }
}

// ================================================================ image viewer

class ImageViewer extends StatelessWidget {
  final J img;
  const ImageViewer({super.key, required this.img});

  @override
  Widget build(BuildContext context) {
    final title = [(img['type'] ?? '').toString(), (img['view'] ?? '').toString()]
        .where((e) => e.isNotEmpty)
        .join(' • ');
    final caption = (img['caption'] ?? '').toString();
    final interp = (img['interpretation'] ?? '').toString();
    return Scaffold(
      appBar: AppBar(
        title: Text(title.isEmpty ? tr('Image') : title),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => Navigator.pop(context, 'edit'),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => Navigator.pop(context, 'delete'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: InteractiveViewer(
              maxScale: 6,
              child: Center(
                child: Image.file(
                  File(store.imagePath(img['file'].toString())),
                  errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined),
                ),
              ),
            ),
          ),
          if (caption.isNotEmpty || interp.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (caption.isNotEmpty) Text(caption),
                  if (interp.isNotEmpty) Text('${tr('My interpretation')}: $interp'),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
