import 'lib_text.dart';
import 'library.dart';

/// "At a glance": the short version of an article, taken only from its own text.
/// For each key section (symptoms, causes, diagnosis, treatment, prognosis) it keeps the
/// first bullets, or the first two sentences.
class GlanceItem {
  final SecKind kind;
  final String heading;
  final List<String> points;
  const GlanceItem(this.kind, this.heading, this.points);
}

String _clip(String s, int n) => s.length <= n ? s : '${s.substring(0, n).trimRight()}…';

List<String> glancePoints(String text) {
  final lines = text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  final bullets = [for (final l in lines) if (l.startsWith('• ')) l.substring(2)];
  if (bullets.length >= 2) return [for (final b in bullets.take(4)) _clip(b, 150)];
  final sents = sentences(lines.where((l) => !l.startsWith('• ')).join(' '));
  return [for (final s in sents.take(2)) _clip(s, 240)];
}

const List<SecKind> _order = [SecKind.symptoms, SecKind.causes, SecKind.diagnosis, SecKind.treatment, SecKind.prevention];

List<GlanceItem> buildGlance(LibArticle a) {
  final out = <GlanceItem>[];
  for (final k in _order) {
    for (var i = 1; i < a.sections.length; i++) {
      final s = a.sections[i];
      if (secKind(s.heading) != k) continue;
      final pts = glancePoints(s.text);
      if (pts.isEmpty) continue;
      out.add(GlanceItem(k, s.heading, pts));
      break;
    }
  }
  return out;
}
