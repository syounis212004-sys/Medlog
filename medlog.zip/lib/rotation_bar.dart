import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'data.dart';
import 'i18n.dart';
import 'screens_portfolio.dart';
import 'ui_kit.dart';

/// One line that says which rotation you are in: "Orthopedics • day 31 of 31 • 12 cases".
/// Tap opens the rotation; the arrow switches between rotations; with none, it offers to add one.
class RotationBar extends StatelessWidget {
  const RotationBar({super.key});

  static String line(J r) {
    final start = parseDate('${r['start']}');
    final end = parseDate('${r['end'] ?? ''}');
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final parts = <String>[tr('${r['name']}')];
    if (start != null) {
      final day = today.difference(start).inDays + 1;
      if (end != null) {
        final total = end.difference(start).inDays + 1;
        if (day >= 1 && day <= total) parts.add(trp('day {a} of {b}', {'a': day, 'b': total}));
      } else if (day >= 1) {
        parts.add(trp('day {n}', {'n': day}));
      }
    }
    final id = '${r['id']}';
    parts.add(countLabel(store.casesOfRotation(id).length, 'case'));
    final duty = store.shifts.where((s) => s['rotationId'] == id).length;
    if (duty > 0) parts.add(countLabel(duty, 'duty day'));
    return parts.join(' • ');
  }

  Future<void> _switch(BuildContext context) async {
    final cur = store.currentRotation();
    final list = [...store.rotations]..sort((a, b) => '${b['start']}'.compareTo('${a['start']}'));
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          for (final r in list.take(12))
            ListTile(
              leading: Icon(specialtyIcon('${r['name']}')),
              title: m.Text(store.rotationLabel(r)),
              subtitle: m.Text('${r['start'] ?? ''} → ${r['end'] ?? ''}'),
              selected: cur != null && cur['id'] == r['id'],
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute<void>(builder: (_) => RotationScreen(rotationId: '${r['id']}')));
              },
            ),
          ListTile(
            leading: Icon(AppIcons.add),
            title: m.Text(tr('Add rotation')),
            onTap: () {
              Navigator.pop(ctx);
              editRotation(context);
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        final r = store.currentRotation();
        return Material(
          key: const ValueKey('rotation_bar'),
          color: cs.secondaryContainer.withValues(alpha: 0.6),
          borderRadius: BorderRadius.circular(Tk.rCard),
          child: InkWell(
            borderRadius: BorderRadius.circular(Tk.rCard),
            onTap: () => r == null ? editRotation(context) : Navigator.push(context, MaterialPageRoute<void>(builder: (_) => RotationScreen(rotationId: '${r['id']}'))),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(children: [
                Icon(r == null ? AppIcons.rotation : specialtyIcon('${r['name']}'), size: 22, color: cs.onSecondaryContainer),
                const SizedBox(width: 10),
                Expanded(
                  child: m.Text(r == null ? tr('Add rotation') : '${tr('Rotation')}: ${line(r)}',
                      maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: cs.onSecondaryContainer)),
                ),
                if (r != null)
                  IconButton(
                    key: const ValueKey('rotation_switch'),
                    visualDensity: VisualDensity.compact,
                    tooltip: tr('Switch rotation'),
                    icon: Icon(Icons.unfold_more, color: cs.onSecondaryContainer),
                    onPressed: () => _switch(context),
                  ),
              ]),
            ),
          ),
        );
      },
    );
  }
}
