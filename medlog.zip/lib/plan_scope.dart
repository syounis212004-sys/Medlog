import 'book_plan.dart';
import 'data.dart';
import 'library.dart';

/// What AI study works on: the books of the plans the person made and the chapters that are due. When the person has
/// plans, the AI tools take their text from these books; with no plan they use the whole library, as before.

class PlanScope {
  /// Books (pack ids) of the plans that are still running, in the order of the plans.
  final List<String> packIds;

  /// Per book, the chapters due now: today, overdue, or within the coming days.
  final Map<String, Set<int>> due;

  /// Titles of the books, for display.
  final Map<String, String> titles;
  const PlanScope(this.packIds, this.due, this.titles);

  bool get isEmpty => packIds.isEmpty;
  bool get hasDue => due.values.any((s) => s.isNotEmpty);
  int get dueCount => due.values.fold<int>(0, (n, s) => n + s.length);
}

const String kAiPlanScopeKey = 'aiPlanScope';

/// The switch on the AI study page: on by default.
bool aiPlanScopeOn() => store.settings[kAiPlanScopeKey] != false;

Future<void> setAiPlanScope(bool on) async {
  store.settings[kAiPlanScopeKey] = on;
  await store.saveSettings();
  store.refresh();
}

/// The running plans: they have not ended, or still have a chapter that is not done.
List<Map<String, dynamic>> runningPlans({DateTime? now}) {
  final today = now ?? DateTime.now();
  final t = DateTime(today.year, today.month, today.day);
  return [
    for (final p in BookPlanStore.all())
      if (library.pack('${p['packId']}') != null)
        if (!(parseDate('${p['end']}') ?? t.add(const Duration(days: 1))).isBefore(t)) p
  ];
}

/// The scope of the running plans. [horizonDays]: how far ahead the due chapters reach.
Future<PlanScope> currentPlanScope({DateTime? now, int horizonDays = 7}) async {
  final today = now ?? DateTime.now();
  final t = DateTime(today.year, today.month, today.day);
  final horizon = t.add(Duration(days: horizonDays));
  final packs = <String>[];
  final due = <String, Set<int>>{};
  final titles = <String, String>{};
  for (final p in runningPlans(now: now)) {
    final id = '${p['packId']}';
    if (!packs.contains(id)) packs.add(id);
    titles[id] = library.pack(id)?.title ?? '${p['title']}';
    final chs = await BookPlanStore.chaptersFor(p);
    final start = parseDate('${p['start']}') ?? t;
    final end = parseDate('${p['end']}') ?? start.add(const Duration(days: 30));
    final sched = BookPlanSchedule.assign(chs, start, end, (p['perWeek'] as int?) ?? 3, today);
    final set = due.putIfAbsent(id, () => <int>{});
    for (final c in chs) {
      final d = sched[c.number];
      if (!c.done && d != null && !d.isAfter(horizon)) set.add(c.number);
    }
  }
  return PlanScope(packs, due, titles);
}

/// The scope when the person has running plans and has not switched the plan off; null otherwise.
Future<PlanScope?> activePlanScope({DateTime? now}) async {
  if (!aiPlanScopeOn()) return null;
  final s = await currentPlanScope(now: now);
  return s.isEmpty ? null : s;
}

/// One article of a plan book.
class PlanArticle {
  final String packId;
  final int index;
  final String title;
  final bool due;
  const PlanArticle(this.packId, this.index, this.title, this.due);
  String get key => '$packId|$index';
}

/// The articles of the plan books, the ones in due chapters first. [dueOnly]: only those.
Future<List<PlanArticle>> planArticles(PlanScope s, {bool dueOnly = false}) async {
  final out = <PlanArticle>[];
  for (final id in s.packIds) {
    final titles = await library.titlesOf(id);
    final nums = await library.chapterNumbersOf(id);
    final dueSet = s.due[id] ?? const <int>{};
    for (var i = 0; i < titles.length; i++) {
      // with no chapter list the chapter number is the place of the entry in the book (1-based)
      final ch = nums.isEmpty ? i + 1 : (i < nums.length ? nums[i] : 0);
      final isDue = dueSet.contains(ch);
      if (dueOnly && !isDue) continue;
      out.add(PlanArticle(id, i, titles[i], isDue));
    }
  }
  return [...out.where((a) => a.due), ...out.where((a) => !a.due)];
}
