import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'data.dart';
import 'reminders.dart';
import 'study_tools.dart';

/// The focus session lives here, not in a screen: it keeps running while the person reads an article, takes a quiz or
/// leaves the app, and the small pill on top of every screen shows it. It is stored with the settings, so closing the
/// app does not lose it. Time is always read from the clock (never counted tick by tick), so a phone that sleeps
/// does not lose seconds.

enum FocusPhase { idle, work, rest, done }

class FocusService extends ChangeNotifier {
  FocusService._();
  static final FocusService instance = FocusService._();

  /// Tests replace the clock.
  static DateTime Function() clock = DateTime.now;
  static bool keepAwake = true;

  FocusPhase phase = FocusPhase.idle;
  String title = '', ref = '';
  int workMin = 25, breakMin = 5;
  int plannedSec = 0;
  int interruptions = 0;
  int savedMinutes = 0; // saved by the rounds of this run
  DateTime? _end;
  Duration? _frozen;
  Timer? _tick;

  bool get active => phase == FocusPhase.work || phase == FocusPhase.rest;
  bool get paused => _frozen != null;

  Duration get left {
    if (_frozen != null) return _frozen!;
    final e = _end;
    if (e == null) return Duration.zero;
    final d = e.difference(clock());
    return d.isNegative ? Duration.zero : d;
  }

  double get progress => plannedSec == 0 ? 0 : (1 - left.inSeconds / plannedSec).clamp(0.0, 1.0);

  // ------------------------------------------------------------ control

  Future<void> start({required String title, String ref = '', required int work, required int rest}) async {
    this.title = title.trim();
    this.ref = ref;
    workMin = work;
    breakMin = rest;
    interruptions = 0;
    savedMinutes = 0;
    await StudyLog.setWork(work);
    await StudyLog.setBreak(rest);
    // the end of the round is announced even when the app is in the background
    await Reminders.requestPermissionOnce();
    _begin(FocusPhase.work, work);
  }

  void _begin(FocusPhase p, int minutes) {
    plannedSec = minutes * 60;
    _end = clock().add(Duration(minutes: minutes));
    _frozen = null;
    phase = p;
    _arm();
    Reminders.focusEndsAt(_end!, onBreak: p == FocusPhase.rest);
    _persist();
    notifyListeners();
  }

  void _arm() {
    _tick?.cancel();
    _awake(phase == FocusPhase.work && !paused);
    _tick = Timer.periodic(const Duration(milliseconds: 500), (_) => _onTick());
  }

  /// One step of the timer now (the periodic timer calls this; tests call it after moving the clock).
  @visibleForTesting
  void tickNow() => _onTick();

  void _onTick() {
    if (!active) return;
    if (!paused && left == Duration.zero) {
      _roundOver();
    } else {
      notifyListeners();
    }
  }

  void pause() {
    if (!active || paused) return;
    _frozen = left;
    Reminders.focusCancel();
    _awake(false);
    _persist();
    notifyListeners();
  }

  void resume() {
    final f = _frozen;
    if (f == null) return;
    _end = clock().add(f);
    _frozen = null;
    Reminders.focusEndsAt(_end!, onBreak: phase == FocusPhase.rest);
    _awake(phase == FocusPhase.work);
    _persist();
    notifyListeners();
  }

  void distracted() {
    if (phase != FocusPhase.work) return;
    interruptions++;
    _persist();
    notifyListeners();
  }

  Future<void> _roundOver() async {
    _tick?.cancel();
    HapticFeedback.mediumImpact();
    if (phase == FocusPhase.work) {
      await _save(plannedSec);
      if (breakMin > 0) {
        _begin(FocusPhase.rest, breakMin);
        return;
      }
    }
    await _finish();
  }

  /// Ends the work round now and keeps the minutes really worked (at least one).
  Future<void> finishEarly() async {
    if (!active) return;
    _tick?.cancel();
    final worked = plannedSec - left.inSeconds;
    if (phase == FocusPhase.work && worked >= 60) await _save(worked);
    await _finish();
  }

  Future<void> skipBreak() => _finish();

  Future<void> _save(int seconds) async {
    final mins = (seconds / 60).round();
    if (mins <= 0) return;
    savedMinutes += mins;
    await StudyLog.add(minutes: mins, title: title, ref: ref, interruptions: interruptions, at: clock());
    interruptions = 0; // counted with the round that saved them
  }

  Future<void> _finish() async {
    _tick?.cancel();
    _end = null;
    _frozen = null;
    phase = FocusPhase.done;
    _awake(false);
    await Reminders.focusCancel();
    await _clearPersisted();
    notifyListeners();
  }

  /// Back to the set-up screen (after "Another round").
  void reset() {
    _tick?.cancel();
    _awake(false);
    phase = FocusPhase.idle;
    savedMinutes = 0;
    interruptions = 0;
    notifyListeners();
  }

  void _awake(bool on) {
    if (!keepAwake) return;
    try {
      on ? WakelockPlus.enable() : WakelockPlus.disable();
    } catch (_) {}
  }

  // ------------------------------------------------------------ the session survives the app

  static const _key = 'focusState';

  void _persist() {
    store.settings[_key] = {
      'phase': phase.name,
      'title': title,
      'ref': ref,
      'work': workMin,
      'break': breakMin,
      'planned': plannedSec,
      'int': interruptions,
      'saved': savedMinutes,
      'end': _end?.toIso8601String(),
      'frozen': _frozen?.inSeconds,
    };
    store.saveSettings();
  }

  Future<void> _clearPersisted() async {
    store.settings.remove(_key);
    await store.saveSettings();
  }

  /// Called when the app starts: a session that was running goes on from where it is. A work round that ended while
  /// the app was closed is saved in full and the break (or the end) follows.
  Future<void> restore() async {
    final m = store.settings[_key];
    if (m is! Map || phase != FocusPhase.idle) return;
    final p = FocusPhase.values.where((e) => e.name == '${m['phase']}').firstOrNull;
    if (p == null || (p != FocusPhase.work && p != FocusPhase.rest)) return;
    title = '${m['title'] ?? ''}';
    ref = '${m['ref'] ?? ''}';
    workMin = (m['work'] as num?)?.toInt() ?? 25;
    breakMin = (m['break'] as num?)?.toInt() ?? 5;
    plannedSec = (m['planned'] as num?)?.toInt() ?? 0;
    interruptions = (m['int'] as num?)?.toInt() ?? 0;
    savedMinutes = (m['saved'] as num?)?.toInt() ?? 0;
    phase = p;
    final frozen = (m['frozen'] as num?)?.toInt();
    final end = DateTime.tryParse('${m['end']}');
    if (frozen != null) {
      _frozen = Duration(seconds: frozen);
      _end = null;
      _arm();
      notifyListeners();
      return;
    }
    if (end == null) return _finish();
    _end = end;
    if (end.isAfter(clock())) {
      _arm();
      notifyListeners();
      return;
    }
    // it ended while the app was closed
    if (p == FocusPhase.work) {
      await _save(plannedSec);
      if (breakMin > 0 && clock().difference(end).inMinutes < breakMin) {
        _begin(FocusPhase.rest, breakMin - clock().difference(end).inMinutes);
        return;
      }
    }
    if (p == FocusPhase.work) {
      await _finish(); // a round was saved: show how much
    } else {
      _tick?.cancel();
      phase = FocusPhase.idle;
      await _clearPersisted();
      notifyListeners();
    }
  }
}
