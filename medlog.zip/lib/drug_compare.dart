import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'dosing.dart';
import 'formulary.dart';
import 'i18n.dart';
import 'ui.dart';

/// Two or three drugs of the imported files side by side: class, routes, indications, contraindications, cautions,
/// pregnancy, lactation, adverse effects, interactions. Only what the files say; nothing is added.

class DrugCompareRow {
  final String label;
  final List<String> values; // one per drug, '' when the file says nothing
  const DrugCompareRow(this.label, this.values);
  bool get any => values.any((v) => v.trim().isNotEmpty);
  bool get differs => values.map((v) => v.trim().toLowerCase()).toSet().length > 1;
}

String _top(List<FText> l, {int n = 3}) => [for (final t in l.take(n)) if (t.text.trim().isNotEmpty) '• ${t.text.trim()}'].join('\n');

/// The rows of the comparison, in a fixed order.
List<DrugCompareRow> compareRows(List<FDrug> drugs) {
  String routes(FDrug d) => {for (final f in d.forms) if (f.route.isNotEmpty) f.route}.join(', ');
  String groups(FDrug d) {
    final g = {for (final r in d.regimens) if (r.group.isNotEmpty) r.group};
    return g.join(', ');
  }

  return [
    DrugCompareRow('Class', [for (final d in drugs) d.drugClass]),
    DrugCompareRow('Routes', [for (final d in drugs) routes(d)]),
    DrugCompareRow('Regimens for', [for (final d in drugs) groups(d)]),
    DrugCompareRow('Indications', [for (final d in drugs) _top(d.indications, n: 4)]),
    DrugCompareRow('Contraindications', [for (final d in drugs) _top(d.contraindications)]),
    DrugCompareRow('Cautions', [for (final d in drugs) _top(d.cautions)]),
    DrugCompareRow('Pregnancy', [for (final d in drugs) _top(d.pregnancy, n: 2)]),
    DrugCompareRow('Breastfeeding', [for (final d in drugs) _top(d.lactation, n: 2)]),
    DrugCompareRow('Adverse effects', [for (final d in drugs) _top(d.adverse, n: 4)]),
    DrugCompareRow('Interactions listed', [for (final d in drugs) d.interactions.take(4).map((i) => '• ${i.with_}').join('\n')]),
  ].where((r) => r.any).toList();
}

class DrugCompareScreen extends StatefulWidget {
  const DrugCompareScreen({super.key});
  @override
  State<DrugCompareScreen> createState() => _DrugCompareScreenState();
}

class _DrugCompareScreenState extends State<DrugCompareScreen> {
  final _q = TextEditingController();
  final List<FDrug> _picked = [];

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final q = _q.text.trim().toLowerCase();
    final found = q.length < 2 || _picked.length >= 3
        ? <FDrug>[]
        : [for (final d in dosing.fdrugs) if ((d.name.toLowerCase().contains(q) || d.aka.any((a) => a.toLowerCase().contains(q))) && !_picked.any((p) => p.key == d.key)) d].take(8).toList();
    final rows = _picked.length >= 2 ? compareRows(_picked) : <DrugCompareRow>[];
    const tints = [Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFFAD1457)];
    return Scaffold(
      appBar: AppBar(title: Text('Compare drugs')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        Text('Pick two or three drugs. You see only what your imported files say about each one.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 8),
        if (_picked.length < 3)
          TextField(key: const ValueKey('cmp_search'), controller: _q, onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: tr('Add a drug'), prefixIcon: const Icon(AppIcons.search))),
        for (final d in found)
          ListTile(
            key: ValueKey('cmp_add_${d.key}'),
            dense: true,
            title: m.Text(d.name),
            trailing: const Icon(AppIcons.add),
            onTap: () => setState(() {
              _picked.add(d);
              _q.clear();
            }),
          ),
        if (_picked.isNotEmpty) ...[
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (var i = 0; i < _picked.length; i++)
              InputChip(
                avatar: CircleAvatar(backgroundColor: tints[i], radius: 6),
                label: m.Text(_picked[i].name, overflow: TextOverflow.ellipsis),
                onDeleted: () => setState(() => _picked.removeAt(i)),
              ),
          ]),
        ],
        const SizedBox(height: 10),
        if (_picked.length < 2)
          Text('Pick at least two drugs.')
        else if (rows.isEmpty)
          Text('Your files say nothing about these drugs to compare.')
        else
          for (final r in rows)
            AppCard(
              key: ValueKey('cmp_${r.label}'),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(r.label, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
                    if (r.differs) Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: cs.tertiaryContainer, borderRadius: BorderRadius.circular(9)), child: Text('Differs', style: TextStyle(fontSize: 11, color: cs.onTertiaryContainer, fontWeight: FontWeight.w700))),
                  ]),
                  for (var i = 0; i < _picked.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Directionality(
                        textDirection: TextDirection.ltr,
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Container(width: 4, height: 18, margin: const EdgeInsets.only(top: 2, right: 8), decoration: BoxDecoration(color: tints[i], borderRadius: BorderRadius.circular(2))),
                          Expanded(child: m.Text.rich(TextSpan(children: [
                            TextSpan(text: '${_picked[i].name}: ', style: const TextStyle(fontWeight: FontWeight.w800)),
                            TextSpan(text: r.values[i].trim().isEmpty ? tr('not stated') : r.values[i].trim(), style: TextStyle(color: r.values[i].trim().isEmpty ? cs.outline : null)),
                          ]), style: const TextStyle(height: 1.4))),
                        ]),
                      ),
                    ),
                ]),
              ),
            ),
      ]),
    );
  }
}
