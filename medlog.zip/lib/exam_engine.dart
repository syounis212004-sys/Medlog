import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import 'case_narrative.dart' show lcFirst;
import 'data.dart';

/// The examination by body system: the content (systems, steps in examiner's order, normal findings, abnormal findings
/// with where they are and how bad) and the record of what was found in one case. Everything here is plain Dart so it
/// can be tested without a screen.
class ExamQualifier {
  final String label;
  final List<String> options;
  const ExamQualifier(this.label, this.options);
}

class ExamNormal {
  final String id, text, sentence;
  const ExamNormal(this.id, this.text, this.sentence);
}

class ExamFinding {
  final String id, text, sentence, location; // location: none | side | a set name
  final List<String> replacesNormal;
  final List<ExamQualifier> qualifiers;
  const ExamFinding(this.id, this.text, this.sentence, this.location, this.replacesNormal, this.qualifiers);

  bool get needsPlace => location != 'none';
}

class ExamStep {
  final String id, label;
  final List<ExamNormal> normal;
  final List<ExamFinding> findings;
  const ExamStep(this.id, this.label, this.normal, this.findings);

  /// "Shoulder — Look" -> group "Shoulder", short label "Look"; steps without a dash form one group with no name.
  String get group => label.contains(' — ') ? label.split(' — ').first : '';
  String get shortLabel => label.contains(' — ') ? label.split(' — ').sublist(1).join(' — ') : label;
}

class ExamSystem {
  final String id, name;
  final Map<String, List<String>> locationSets;
  final List<ExamStep> steps;
  const ExamSystem(this.id, this.name, this.locationSets, this.steps);

  List<String> placesFor(ExamFinding f) => f.location == 'side' ? const ['Right', 'Left', 'Bilateral'] : (locationSets[f.location] ?? const []);
  ExamStep? step(String id) {
    for (final s in steps) {
      if (s.id == id) return s;
    }
    return null;
  }

  /// The groups (joints) in order; one unnamed group when no step has one.
  List<String> get groups {
    final out = <String>[];
    for (final s in steps) {
      if (!out.contains(s.group)) out.add(s.group);
    }
    return out;
  }
}

class ExamRepo {
  static List<ExamSystem> systems = [];

  static Future<void> load() async {
    if (systems.isNotEmpty) return;
    parse(jsonDecode(await rootBundle.loadString('assets/data/exam_systems.json')) as List);
  }

  static void parse(List raw) {
    final out = <ExamSystem>[];
    for (final s in raw) {
      if (s is! Map) continue;
      final sets = <String, List<String>>{
        for (final e in ((s['location_sets'] as Map?) ?? const {}).entries) '${e.key}': [for (final x in (e.value as List)) '$x'],
      };
      final steps = <ExamStep>[];
      for (final st in (s['steps'] as List)) {
        final m = st as Map;
        steps.add(ExamStep(
          '${m['id']}',
          '${m['label']}',
          [for (final n in (m['normal'] as List)) ExamNormal('${n['id']}', '${n['text']}', '${n['sentence']}')],
          [
            for (final f in (m['findings'] as List))
              ExamFinding(
                '${f['id']}',
                '${f['text']}',
                '${f['sentence']}',
                '${f['location'] ?? 'none'}',
                [for (final r in ((f['replaces_normal'] as List?) ?? const [])) '$r'],
                [for (final q in ((f['qualifiers'] as List?) ?? const [])) ExamQualifier('${q['label']}', [for (final o in (q['options'] as List)) '$o'])],
              ),
          ],
        ));
      }
      out.add(ExamSystem('${s['id']}', '${s['name']}', sets, steps));
    }
    systems = out;
  }

  static ExamSystem? byId(String id) {
    for (final s in systems) {
      if (s.id == id) return s;
    }
    return null;
  }
}

/// A finding that was chosen, with the places and descriptors picked for it.
class ExamPick {
  final String id;
  final List<String> places;
  final Map<String, String> qualifiers;
  const ExamPick(this.id, [this.places = const [], this.qualifiers = const {}]);

  Map<String, dynamic> toJson() => {'id': id, if (places.isNotEmpty) 'l': places, if (qualifiers.isNotEmpty) 'q': qualifiers};
  static ExamPick fromJson(Map j) => ExamPick(
        '${j['id']}',
        [for (final x in (j['l'] as List? ?? const [])) '$x'],
        {for (final e in ((j['q'] as Map?) ?? const {}).entries) '${e.key}': '${e.value}'},
      );
}

/// What was found for one system of one case: the steps examined as normal, the findings, and a free note.
/// Stored in `rec.d['exam2'][systemId]` as {'done': [stepIds], 'f': [{id, l, q}], 'note': ''}.
class ExamRecord {
  final CaseRec rec;
  ExamRecord(this.rec);

  Map<String, dynamic> _root() {
    final v = rec.d['exam2'];
    if (v is Map<String, dynamic>) return v;
    final m = v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
    rec.d['exam2'] = m;
    return m;
  }

  Map<String, dynamic> _sys(String id) {
    final r = _root();
    final v = r[id];
    if (v is Map<String, dynamic>) return v;
    final m = v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
    r[id] = m;
    return m;
  }

  void _prune(String id) {
    final r = _root();
    final s = r[id];
    if (s is Map && (s['done'] as List? ?? const []).isEmpty && (s['f'] as List? ?? const []).isEmpty && '${s['note'] ?? ''}'.trim().isEmpty) r.remove(id);
    if (r.isEmpty) rec.d.remove('exam2');
  }

  List<String> doneSteps(String sysId) => [for (final x in (_sys(sysId)['done'] as List? ?? const [])) '$x'];
  List<ExamPick> picks(String sysId) => [for (final x in (_sys(sysId)['f'] as List? ?? const [])) if (x is Map) ExamPick.fromJson(x)];
  String note(String sysId) => '${_sys(sysId)['note'] ?? ''}';

  bool stepDone(ExamSystem s, ExamStep st) => doneSteps(s.id).contains(st.id) || picks(s.id).any((p) => st.findings.any((f) => f.id == p.id));

  /// Marks a step as examined and normal (what is not contradicted by a finding reads as normal).
  void setStepNormal(ExamSystem s, ExamStep st, bool on) {
    final m = _sys(s.id);
    final d = doneSteps(s.id)..remove(st.id);
    if (on) d.add(st.id);
    m['done'] = d;
    _prune(s.id);
  }

  void allNormal(ExamSystem s) {
    final m = _sys(s.id);
    m['done'] = [for (final st in s.steps) st.id];
  }

  void clear(ExamSystem s) {
    _root().remove(s.id);
    _prune(s.id);
  }

  void setPick(ExamSystem s, ExamPick p) {
    final m = _sys(s.id);
    final l = picks(s.id)..removeWhere((x) => x.id == p.id);
    l.add(p);
    m['f'] = [for (final x in l) x.toJson()];
  }

  void removePick(ExamSystem s, String findingId) {
    final m = _sys(s.id);
    m['f'] = [for (final x in picks(s.id)) if (x.id != findingId) x.toJson()];
    _prune(s.id);
  }

  void setNote(ExamSystem s, String text) {
    final m = _sys(s.id);
    if (text.trim().isEmpty) {
      m.remove('note');
    } else {
      m['note'] = text;
    }
    _prune(s.id);
  }

  /// none | normal | abnormal | partial: nothing done, everything normal, some finding recorded, or only some steps.
  String state(ExamSystem s) {
    final f = picks(s.id);
    if (f.isNotEmpty || note(s.id).trim().isNotEmpty) return 'abnormal';
    final d = doneSteps(s.id);
    if (d.isEmpty) return 'none';
    return d.length >= s.steps.length ? 'normal' : 'partial';
  }

  int findingCount(ExamSystem s) => picks(s.id).length;
}

/// "Fine crackles were heard ({location})." + [right lower zone] -> "Fine crackles were heard (right lower zone)."
/// The descriptors picked (timing, grade) follow the sentence: "... , late inspiratory."
String findingSentence(ExamSystem s, ExamFinding f, ExamPick p) {
  var t = f.sentence.trim();
  final where = _places(p.places);
  if (t.contains('{location}')) {
    t = t.replaceAll('{location}', where.isEmpty ? 'site not stated' : where);
  } else if (where.isNotEmpty && f.needsPlace) {
    t = '${t.replaceFirst(RegExp(r'[.]$'), '')} ($where).';
  }
  final q = [for (final e in p.qualifiers.entries) if (e.value.isNotEmpty) '${e.key.toLowerCase()}: ${lcFirst(e.value)}'];
  if (q.isNotEmpty) t = '${t.replaceFirst(RegExp(r'[.]$'), '')} (${q.join('; ')}).';
  return t;
}

String _places(List<String> v) {
  final l = [for (final x in v) lcFirst(x)];
  if (l.isEmpty) return '';
  if (l.length == 1) return l.first;
  return '${l.sublist(0, l.length - 1).join(', ')} and ${l.last}';
}

/// The paragraph of one system as it will read in the case: per step, the normal findings that no finding contradicts
/// and then the abnormal ones; steps never examined are left out.
String examSystemText(CaseRec rec, ExamSystem s) {
  final r = ExamRecord(rec);
  final picks = r.picks(s.id);
  final done = r.doneSteps(s.id);
  final out = <String>[];
  for (final st in s.steps) {
    final mine = [for (final p in picks) if (st.findings.any((f) => f.id == p.id)) p];
    if (!done.contains(st.id) && mine.isEmpty) continue;
    final replaced = <String>{for (final p in mine) ...st.findings.firstWhere((f) => f.id == p.id).replacesNormal};
    if (done.contains(st.id)) {
      for (final n in st.normal) {
        if (!replaced.contains(n.id)) out.add(n.sentence.trim());
      }
    }
    for (final p in mine) {
      out.add(findingSentence(s, st.findings.firstWhere((f) => f.id == p.id), p));
    }
  }
  final note = r.note(s.id).trim();
  if (note.isNotEmpty) out.add(note);
  return out.join(' ');
}

/// Keeps the older `sys` summary of the case in step with the detailed record so the PDF and the case story, which read
/// it, show the sentences: state Normal / Abnormal / Not examined, the short findings as the note, the sentences as `full`.
void syncExamSummary(CaseRec rec) {
  final root = rec.d['exam2'];
  final sys = rec.d['sys'] is Map ? Map<String, dynamic>.from(rec.d['sys'] as Map) : <String, dynamic>{};
  sys.removeWhere((k, v) => v is Map && v['src'] == 'exam2');
  if (root is Map) {
    final r = ExamRecord(rec);
    for (final s in ExamRepo.systems) {
      final st = r.state(s);
      if (st == 'none') continue;
      final text = examSystemText(rec, s);
      final picks = r.picks(s.id);
      sys[s.name] = {
        's': st == 'normal' ? 'Normal' : 'Abnormal',
        'n': [for (final p in picks) ExamRepo.systems.expand((x) => x.steps).expand((x) => x.findings).firstWhere((f) => f.id == p.id, orElse: () => const ExamFinding('', '', '', 'none', [], [])).text].where((e) => e.isNotEmpty).join('; '),
        'full': text,
        'src': 'exam2',
      };
    }
  }
  if (sys.isEmpty) {
    rec.d.remove('sys');
  } else {
    rec.d['sys'] = sys;
  }
}

/// The older examination cards (CVS, Respiratory, ...) become the same systems here: a Normal card makes every step
/// normal, an Abnormal one keeps its note. Done once; the old entry is removed so nothing is written twice.
const Map<String, String> _kLegacy = {
  'CVS': 'cardiovascular',
  'Respiratory': 'respiratory',
  'Abdomen': 'abdomen',
  'CNS': 'neurology',
  'MSK': 'musculoskeletal',
  'ENT': 'ent',
  'Skin': 'skin',
};

bool migrateLegacyExam(CaseRec rec) {
  final sys = rec.d['sys'];
  if (sys is! Map || ExamRepo.systems.isEmpty) return false;
  final next = Map<String, dynamic>.from(sys);
  var changed = false;
  final r = ExamRecord(rec);
  for (final e in _kLegacy.entries) {
    final v = next[e.key];
    if (v is! Map || v['src'] == 'exam2') continue;
    final s = ExamRepo.byId(e.value);
    if (s == null) continue;
    final st = '${v['s'] ?? ''}', note = '${v['n'] ?? ''}'.trim();
    if (r.state(s) == 'none') {
      if (st == 'Normal') r.allNormal(s);
      if (note.isNotEmpty) r.setNote(s, note);
      if (st == 'Abnormal' && note.isEmpty) r.setNote(s, 'Abnormal (no description was recorded).');
    }
    if (st == 'Normal' || st == 'Abnormal' || note.isNotEmpty) {
      next.remove(e.key);
      changed = true;
    }
  }
  if (changed) {
    rec.d['sys'] = next;
    syncExamSummary(rec);
  }
  return changed;
}
