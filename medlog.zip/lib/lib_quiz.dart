import 'dart:math';

import 'data.dart';
import 'lib_text.dart';
import 'lib_user.dart';
import 'library.dart';

/// Self-test questions made only from the text of the library articles you downloaded.
/// Nothing is invented: every question is a sentence, a bullet or a title of an article,
/// the wrong options are taken from other articles, and the source sentence is shown after
/// answering. Which articles are asked is chosen with weights (core clinical articles,
/// your favorites, your rotation, your cases, your weak spots).

enum QKind { definition, cloze, treatment, symptom }

enum QuizSource { all, rotation, cases, favorites, weak, random }

enum QuizLevel { easy, medium, hard, auto }

class QuizQ {
  final QKind kind;
  final String stem;
  final List<String> options;
  final int answer;
  final String explanation;
  final String packId;
  final String title;
  final int index;

  /// Article title used in the question line of the treatment / symptom kinds.
  final String prompt;
  final QuizLevel level;
  const QuizQ({
    required this.kind,
    required this.stem,
    required this.options,
    required this.answer,
    required this.explanation,
    required this.packId,
    required this.title,
    required this.index,
    this.prompt = '',
    this.level = QuizLevel.medium,
  });

  String get correct => options[answer];
  String get hash => quizHash(stem, correct);
}

/// What the last [buildQuiz] did (shown on the screens).
class QuizReport {
  QuizSource source = QuizSource.all;
  QuizLevel level = QuizLevel.medium;
  QuizSource? fallbackFrom; // the chosen source had fewer than 3 articles
  int pool = 0;
  int reads = 0;
}

QuizReport lastQuizReport = QuizReport();

String _cleanTitle(String t) =>
    t.replaceAll(RegExp(r'\s+—\s+(WikEM|Wikipedia|CDC|NCI|Project Tulip)$'), '').replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();

final RegExp _medSuffix = RegExp(r'(itis|osis|pathy|ectomy|plasty|emia|oma|ase|ine|ide|mab|ism|algia|plegia|uria|penia|trophy|stomy|otomy|scopy|graphy)$', caseSensitive: false);
final RegExp _drugStrong = RegExp(
    r'(mab|pril|sartan|olol|statin|cillin|mycin|azole|vir|oxacin|cycline|triptan|dipine|prazole|tidine|epam|olam|thiazide|parin|xaban|gliptin|glitazone|formin|profen|fenac|coxib|setron|terol|navir|caine|sone|olone|penem|bactam|barbital|mol|tinib|ciclib)$',
    caseSensitive: false);
final RegExp _drugWeak = RegExp(r'(ine|ide)$', caseSensitive: false);
final RegExp _procSuffix = RegExp(r'(ectomy|plasty|otomy|ostomy|scopy|desis|pexy|rrhaphy)$', caseSensitive: false);
const Set<String> _drugWords = {
  'aspirin', 'acetaminophen', 'warfarin', 'heparin', 'insulin', 'digoxin', 'amiodarone', 'adenosine', 'atropine', 'lidocaine', 'morphine', 'codeine', 'tramadol', 'oxycodone', 'fentanyl',
  'gabapentin', 'pregabalin', 'methotrexate', 'colchicine', 'allopurinol', 'hydroxychloroquine', 'sulfasalazine', 'tamoxifen', 'levothyroxine', 'epinephrine', 'adrenaline', 'naloxone',
  'nitroglycerin', 'dopamine', 'dobutamine', 'noradrenaline', 'norepinephrine', 'vancomycin', 'ibuprofen', 'naproxen', 'diclofenac', 'prednisone', 'prednisolone', 'dexamethasone', 'furosemide',
};
const Set<String> _procWords = {
  'physiotherapy', 'radiotherapy', 'chemotherapy', 'immunotherapy', 'dialysis', 'transfusion', 'thrombolysis', 'intubation', 'cardioversion', 'defibrillation', 'immobilization', 'immobilisation',
  'traction', 'splinting', 'casting', 'angioplasty', 'arthrodesis', 'bracing', 'ventilation', 'resuscitation', 'drainage', 'debridement', 'cementation',
};
const Set<String> _notDrug = {
  'medicine', 'medicines', 'routine', 'determine', 'examine', 'guideline', 'guidelines', 'decline', 'combine', 'define', 'disease', 'diseases', 'increase', 'decrease', 'release', 'purchase', 'database',
  'baseline', 'outside', 'inside', 'provide', 'provided', 'divide', 'decide', 'alongside', 'bedside', 'intestine', 'intestines', 'uterine', 'bovine', 'canine', 'feline', 'equine', 'magazine', 'heroine',
  'sometimes', 'determined', 'examined', 'endocrine', 'exocrine', 'paracrine', 'medicinal', 'vaccine', 'vaccines', 'amine', 'porcine', 'carotene', 'adjacent', 'pipeline', 'discipline',
  'peritoneum', 'online', 'mainstream', 'undertaken', 'worldwide', 'nationwide', 'oxide', 'creatinine', 'glutamine', 'histamine', 'serotonine', 'molecule', 'molecules',
};
final RegExp _plainEnd = RegExp(r'(ly|ing|ed|ness|ers|ings|ally|ions|ment|ments|ward|wards)$');

/// A long word without a medical ending is only used when it is not an everyday word (rare among the articles read).
bool _otherOk(String w, _Pools p) => w.length >= 9 && !_plainEnd.hasMatch(w.toLowerCase()) && (p.freq[w.toLowerCase()] ?? 1) <= max(2, p.reads * 0.2);

final RegExp _drugContext = RegExp(r'treat|therap|drug|medic|prescrib|administ|inject|dose|oral|intraven|inhibitor|agent|antibiotic|analges|steroid|given|use of|used', caseSensitive: false);

/// Hides the title (and its long words) inside a sentence.
String? maskTitle(String sentence, String title) {
  final base = _cleanTitle(title);
  if (base.length < 4) return null;
  var s = sentence;
  s = s.replaceAll(RegExp(RegExp.escape(base), caseSensitive: false), '____');
  s = s.replaceAll(RegExp(r'\(\s*(also|or|abbreviated|commonly|known|sometimes|often)[^)]*\)', caseSensitive: false), '');
  s = s.replaceAll(RegExp(r'\(\s*[A-Z][A-Za-z]{1,6}s?\s*\)'), '');
  for (final w in base.split(RegExp(r'[\s\-/]+'))) {
    if (w.length >= 6) s = s.replaceAll(RegExp('\\b${RegExp.escape(w)}\\w*', caseSensitive: false), '____');
  }
  s = s.replaceAll(RegExp(r'(____\s*){2,}'), '____ ').replaceAll(RegExp(r'\s+'), ' ').trim();
  return s.contains('____') ? s : null;
}

List<String> _keyTerms(String sentence) {
  final out = <String>[];
  for (final m in RegExp(r"\b[A-Za-z][A-Za-z\-]{6,}\b").allMatches(sentence)) {
    final w = m.group(0)!;
    if (_stopWords.contains(w.toLowerCase())) continue;
    out.add(w);
  }
  return out;
}

const Set<String> _stopWords = {
  'however', 'because', 'although', 'between', 'including', 'usually', 'typically', 'commonly', 'several', 'another', 'patients', 'patient', 'without', 'through', 'during', 'compared', 'increased', 'decreased', 'associated', 'approximately', 'following', 'certain', 'different', 'sometimes', 'generally', 'particularly', 'especially', 'recommended', 'considered', 'whereas', 'therefore', 'experience', 'experienced', 'important', 'available', 'difficult', 'difficulty', 'information', 'development', 'understanding', 'environment', 'individual', 'individuals', 'population', 'populations', 'relationship', 'application', 'activities', 'significant', 'performance', 'professional', 'community', 'example', 'examples', 'knowledge', 'sufficient', 'production', 'secondary', 'condition', 'conditions', 'improvement', 'research', 'incidence', 'treatment', 'diagnosis', 'symptoms', 'disease', 'people', 'children', 'medical', 'clinical', 'studies', 'results',
};

bool _nearDup(String a, String b) {
  final x = a.toLowerCase().trim(), y = b.toLowerCase().trim();
  if (x == y) return true;
  if (x.length >= 3 && y.length >= 3 && (x.contains(y) || y.contains(x))) return true;
  return false;
}

/// First [need] items of [ordered] that are distinct from the answer and from each other (no near duplicates).
List<String>? _pickDistinct(Iterable<String> ordered, String answer, int need, {bool Function(String)? ok}) {
  final out = <String>[];
  for (final c in ordered) {
    if (c.trim().isEmpty || _nearDup(c, answer)) continue;
    if (out.any((e) => _nearDup(e, c))) continue;
    if (ok != null && !ok(c)) continue;
    out.add(c);
    if (out.length == need) return out;
  }
  return null;
}

// ---------------------------------------------------------------- terms

enum _TK { drug, proc, disease, other }

class _Term {
  final String text;
  final String key; // pack|index of the article
  final String low;
  _TK? _k;
  String? _s;
  _Term(this.text, this.key) : low = text.toLowerCase();
  _TK get kind => _k ??= _kindOf(text);
  String get suffix => _s ??= _suffixOf(text);
}

String _suffixOf(String w) {
  final l = w.toLowerCase();
  for (final r in [_drugStrong, _procSuffix, _medSuffix]) {
    final m = r.firstMatch(l);
    if (m != null) return m.group(0)!;
  }
  return '';
}

_TK _kindOf(String w) {
  final l = w.toLowerCase();
  if (_drugWords.contains(l) || _drugStrong.hasMatch(l)) return _TK.drug;
  if (_procWords.contains(l) || _procSuffix.hasMatch(l)) return _TK.proc;
  if (_medSuffix.hasMatch(l)) return _TK.disease;
  return _TK.other;
}

/// Drug or procedure word of a treatment sentence (null when it is not clear).
_TK? _treatmentKind(String w, String sentence) {
  final l = w.toLowerCase();
  if (_notDrug.contains(l)) return null;
  if (_drugWords.contains(l) || (_drugStrong.hasMatch(l) && l.length >= 6)) return _TK.drug;
  if (_procWords.contains(l) || (_procSuffix.hasMatch(l) && l.length >= 7)) return _TK.proc;
  if (l.length >= 8 && _drugWeak.hasMatch(l) && _drugContext.hasMatch(sentence)) return _TK.drug;
  return null;
}

class _Rd {
  final String pid;
  final int idx;
  final LibArticle art;
  final bool core;
  final String allLower;
  final QuizLevel level;
  _Rd(this.pid, this.idx, this.art, this.core, this.allLower, this.level);
  String get key => '$pid|$idx';
}

class _Finding {
  final String text;
  final String key;
  final int idx;
  const _Finding(this.text, this.key, this.idx);
}

class _Pools {
  final Map<SecKind, List<_Term>> cloze = {};
  final List<_Term> treat = [];
  final Map<String, List<_Finding>> findings = {}; // by pack
  final Map<String, int> freq = {}; // term -> number of articles that use it
  int reads = 0;
}

const List<SecKind> _clinical = [SecKind.symptoms, SecKind.diagnosis, SecKind.treatment, SecKind.causes];

bool _isCore(LibArticle a) {
  final kinds = <SecKind>{for (final s in a.sections) if (_clinical.contains(secKind(s.heading))) secKind(s.heading)};
  if (kinds.length < 2) return false;
  final lead = a.sections.isEmpty ? '' : a.sections.first.text;
  if (lead.length < 200) return false;
  final total = a.sections.fold<int>(0, (n, s) => n + s.text.length);
  return total >= 1200;
}

// ---------------------------------------------------------------- candidates

class QuizPick {
  final String packId;
  final int index;
  final String title;
  final double weight;
  const QuizPick(this.packId, this.index, this.title, this.weight);
}

class _C {
  final String pid;
  final int idx;
  final String title;
  final String lead;
  double w = 1;
  _C(this.pid, this.idx, this.title, this.lead);
  String get key => '$pid|$idx';
}

final RegExp _orgTitle = RegExp(r'\b(organi[sz]ation|association|society|institute|foundation|hospital|university|college|council|journal|list of|index of|timeline|history of|awards?|ministry|agency|company|corporation|clinic|school of|department|congress|federation)\b', caseSensitive: false);
final RegExp _orgLead = RegExp(r'\b(is|was|are) (an?|the) [^.]{0,50}(organi[sz]ation|company|society|institution|journal|hospital|university|agency|nonprofit|charity|born|physician|surgeon|researcher|professor|politician|footballer|actor)', caseSensitive: false);
final RegExp _medLead = RegExp(r'\b(disease|disorder|condition|syndrome|infection|symptom|treatment|pain|cancer|injury|fracture|inflammation|deficiency|failure|tumou?r|diagnos|drug|medication|surgery|therapy|chronic|acute)', caseSensitive: false);

double _baseWeight(String title, String lead) {
  var w = 1.0;
  if (lead.length < 60) {
    w *= 0.15;
  } else if (lead.length < 120) {
    w *= 0.5;
  }
  if (_orgTitle.hasMatch(title) || _orgLead.hasMatch(lead)) w *= 0.12;
  if (_medLead.hasMatch(lead)) w *= 1.6;
  if (title.length < 4) w *= 0.3;
  return w;
}

class _Sets {
  final Set<String> fav = {};
  final Set<String> recent = {};
  final Set<String> cases = {};
  final Set<String> weak = {};
  String? rotPack;
}

Future<_Sets> _loadSets() async {
  final s = _Sets();
  try {
    final rot = store.currentRotation();
    if (rot != null) {
      final id = packIdForRotation('${rot['name'] ?? ''}');
      if (id != null && library.pack(id) != null) s.rotPack = id;
    }
  } catch (_) {}
  Future<void> add(Set<String> into, String p, String t) async {
    if (library.pack(p) == null) return;
    final i = await library.indexOfTitle(p, t);
    if (i != null) into.add('$p|$i');
  }

  try {
    for (final f in favorites()) {
      await add(s.fav, '${f['pack']}', '${f['title']}');
    }
    for (final f in recentArticles()) {
      await add(s.recent, '${f['p']}', '${f['t']}');
    }
    for (final w in weakSpots()) {
      await add(s.weak, w.packId, w.title);
    }
  } catch (_) {}
  try {
    final seen = <String>{};
    var n = 0;
    for (final c in store.cases.values) {
      final dx = [c.s('finalDx'), c.s('workingDx')].firstWhere((e) => e.trim().isNotEmpty, orElse: () => '').trim().toLowerCase();
      if (dx.isEmpty || !seen.add(dx)) continue;
      if (++n > 25) break;
      for (final h in (await articlesForCase(c)).take(3)) {
        s.cases.add('${h.packId}|${h.index}');
      }
    }
  } catch (_) {}
  return s;
}

/// The weighted choice of articles (exposed for tests). Higher weight = more likely.
Future<List<QuizPick>> pickArticles({String? packId, String? query, int count = 10, int? seed, QuizSource source = QuizSource.all, int? limit}) async {
  final rnd = Random(seed ?? DateTime.now().millisecondsSinceEpoch);
  final cs = await _candidates(packId, query, source);
  return [for (final c in _draw(cs, rnd, limit ?? min(60, max(count * 3, 12)))) QuizPick(c.pid, c.idx, c.title, c.w)];
}

_Sets _lastSets = _Sets();

Future<List<_C>> _candidates(String? packId, String? query, QuizSource source) async {
  final report = lastQuizReport = QuizReport()..source = source;
  final packs = [for (final p in library.textPacks) if (packId == null || p.id == packId) p];
  if (packs.isEmpty) return const [];
  final sets = _lastSets = await _loadSets();

  final all = <_C>[];
  if (query != null && query.trim().isNotEmpty) {
    for (final h in await library.searchEx(query, packId: packId, limit: 80)) {
      all.add(_C(h.packId, h.index, h.title, h.lead));
    }
  } else {
    for (final p in packs) {
      final t = await library.titlesOf(p.id), l = await library.leadsOf(p.id);
      for (var i = 0; i < t.length; i++) {
        all.add(_C(p.id, i, t[i], l[i]));
      }
    }
  }
  var pool = all;
  if (source != QuizSource.all && source != QuizSource.random) {
    final Set<String> keys = switch (source) {
      QuizSource.rotation => {for (final c in all) if (c.pid == sets.rotPack) c.key},
      QuizSource.cases => sets.cases,
      QuizSource.favorites => {...sets.fav, ...sets.recent},
      QuizSource.weak => sets.weak,
      _ => <String>{},
    };
    final sub = [for (final c in all) if (keys.contains(c.key)) c];
    if (sub.length >= 3) {
      pool = sub;
    } else {
      report.fallbackFrom = source;
    }
  }
  if (source != QuizSource.random) {
    for (final c in pool) {
      var w = _baseWeight(c.title, c.lead);
      if (sets.weak.contains(c.key)) w *= 8;
      if (sets.fav.contains(c.key)) w *= 4;
      if (sets.recent.contains(c.key)) w *= 2.5;
      if (sets.cases.contains(c.key)) w *= 3;
      if (sets.rotPack != null && c.pid == sets.rotPack) w *= 2;
      c.w = w;
    }
  }
  report.pool = pool.length;
  return pool;
}

/// Weighted sampling without replacement (Efraimidis-Spirakis).
List<_C> _draw(List<_C> pool, Random rnd, int n) {
  if (pool.length <= n) return [...pool]..shuffle(rnd);
  final keyed = <MapEntry<double, _C>>[];
  for (final c in pool) {
    final u = max(rnd.nextDouble(), 1e-12);
    keyed.add(MapEntry(log(u) / c.w, c));
  }
  keyed.sort((a, b) => b.key.compareTo(a.key));
  return [for (final e in keyed.take(n)) e.value];
}

// ---------------------------------------------------------------- build

/// Builds up to [count] questions. [query] limits the topic ("knee", "sepsis"...), [packId] the course.
/// [source] decides where the articles come from, [level] how hard the wrong options are.
/// What happened (fallback, effective level) is in [lastQuizReport].
Future<List<QuizQ>> buildQuiz({
  String? packId,
  String? query,
  int count = 10,
  int? seed,
  QuizSource source = QuizSource.all,
  QuizLevel level = QuizLevel.medium,
  void Function(double progress)? onProgress,
}) async {
  final rnd = Random(seed ?? DateTime.now().millisecondsSinceEpoch);
  final cands = await _candidates(packId, query, source);
  lastQuizReport.level = level;
  if (cands.isEmpty) return const [];
  final sets = _lastSets;
  final results = quizResultsByArticle();
  QuizLevel levelFor(String key) {
    if (level != QuizLevel.auto) return level;
    if (sets.weak.contains(key)) return QuizLevel.easy;
    final r = results[key];
    if (r != null && r.isNotEmpty && r.first) return QuizLevel.hard;
    return QuizLevel.medium;
  }

  final maxReads = min(60, max(count * 3, 12));
  final picked = _draw(cands, rnd, maxReads);
  final broad = source == QuizSource.all || source == QuizSource.random || lastQuizReport.fallbackFrom != null;

  // 1) read the articles (the wrong options come from the other articles read here)
  final reads = <_Rd>[];
  final pools = _Pools();
  for (var k = 0; k < picked.length; k++) {
    final c = picked[k];
    final a = await library.read(c.pid, c.idx);
    onProgress?.call(0.8 * (k + 1) / picked.length);
    if (a == null || a.sections.isEmpty) continue;
    final text = a.sections.map((s) => s.text).join('\n').toLowerCase();
    final r = _Rd(c.pid, c.idx, a, _isCore(a), text, levelFor(c.key));
    reads.add(r);
    _learn(pools, r);
  }
  lastQuizReport.reads = reads.length;
  pools.reads = reads.length;

  // 2) core articles first; non-core ones only sometimes when the pool is broad
  final strict = <_Rd>[], loose = <_Rd>[];
  for (final r in reads) {
    final needCore = r.level == QuizLevel.easy ? broad : broad && rnd.nextDouble() > 0.35;
    if (!needCore || r.core) {
      strict.add(r);
    } else {
      loose.add(r);
    }
  }
  final ignored = quizIgnored();
  final out = <QuizQ>[];
  final counts = {for (final k in QKind.values) k: 0};
  final titlesCache = <String, List<String>>{};
  for (final r in [...strict, ...loose]) {
    if (out.length >= count) break;
    final rel = r.level == QuizLevel.easy ? const <LibHit>[] : await library.related(r.pid, r.idx, limit: 12);
    final order = [...QKind.values]..shuffle(rnd);
    order.sort((a, b) => counts[a]!.compareTo(counts[b]!));
    for (final kind in order) {
      QuizQ? q;
      switch (kind) {
        case QKind.definition:
          q = await _definition(r, rnd, titlesCache, rel);
        case QKind.cloze:
          q = _cloze(r, rnd, pools);
        case QKind.treatment:
          q = _treatment(r, rnd, pools);
        case QKind.symptom:
          q = _symptom(r, rnd, pools, rel);
      }
      if (q == null) continue;
      final stem = q.stem;
      if (ignored.contains(q.hash) || out.any((e) => e.stem == stem)) continue;
      out.add(q);
      counts[kind] = counts[kind]! + 1;
      break;
    }
    onProgress?.call(0.8 + 0.2 * min(1.0, out.length / count));
  }
  onProgress?.call(1);
  out.shuffle(rnd);
  return out;
}

/// Collects terms and findings of one article for the wrong options of the others.
void _learn(_Pools p, _Rd r) {
  final seenTerms = <String>{};
  for (final s in r.art.sections) {
    final kind = secKind(s.heading);
    for (final u in textUnits(s.text).take(14)) {
      for (final w in _keyTerms(u)) {
        final l = w.toLowerCase();
        if (seenTerms.add(l)) p.freq[l] = (p.freq[l] ?? 0) + 1;
        if (_medSuffix.hasMatch(w) || _drugStrong.hasMatch(w) || w.length >= 9) {
          (p.cloze[kind] ??= <_Term>[]).add(_Term(w, r.key));
        }
        if (kind == SecKind.treatment) {
          final tk = _treatmentKind(w, u);
          if (tk != null) p.treat.add(_Term(w, r.key).._k = tk);
        }
      }
    }
    if (kind == SecKind.symptoms) {
      for (final f in _findings(s.text)) {
        (p.findings[r.pid] ??= <_Finding>[]).add(_Finding(f.$1, r.key, r.idx));
      }
    }
  }
}

// ---------------------------------------------------------------- definition

Set<String> _words(String t) {
  const stop = {'with', 'from', 'disease', 'syndrome', 'disorder', 'type', 'acute', 'chronic', 'and', 'the', 'of', 'in'};
  return {for (final w in t.toLowerCase().split(RegExp(r'[^a-z0-9]+'))) if (w.length >= 4 && !stop.contains(w)) w};
}

final Map<String, List<Set<String>>> _wordCache = {};

Future<QuizQ?> _definition(_Rd r, Random rnd, Map<String, List<String>> cache, List<LibHit> rel) async {
  final a = r.art;
  final first = firstSentence(a.sections.first.text);
  if (first.length < 60 || first.length > 320) return null;
  final stem = maskTitle(first, a.title);
  if (stem == null) return null;
  final all = cache[r.pid] ??= await library.titlesOf(r.pid);
  final tw = _wordCache[r.pid] ??= [for (final t in all) _words(t)];
  final answer = _cleanTitle(a.title);
  final stemLow = stem.toLowerCase();
  final aw = _words(answer);
  final cand = <String>[];
  final used = <int>{r.idx};
  void add(int i) {
    if (used.add(i)) cand.add(_cleanTitle(all[i]));
  }

  final level = r.level;
  final byLen = List<int>.generate(all.length, (i) => i)..removeWhere((i) => i == r.idx);
  if (level == QuizLevel.easy) {
    byLen.shuffle(rnd);
    for (final i in byLen.take(500)) {
      if (tw[i].any(aw.contains)) continue; // other topics only
      add(i);
    }
  } else {
    final overlap = <int>[];
    for (var i = 0; i < all.length; i++) {
      if (i != r.idx && aw.isNotEmpty && tw[i].any(aw.contains)) overlap.add(i);
    }
    byLen.shuffle(rnd);
    if (level == QuizLevel.medium) {
      final relIdx = [for (final h in rel) h.index]..shuffle(rnd);
      relIdx.take(8).forEach(add);
      (overlap..shuffle(rnd)).forEach(add);
      final wc = answer.split(' ').length;
      byLen.sort((x, y) => (all[x].split(' ').length - wc).abs().compareTo((all[y].split(' ').length - wc).abs()));
    } else {
      for (final h in rel) {
        add(h.index);
      }
      overlap.sort((x, y) => tw[y].where(aw.contains).length.compareTo(tw[x].where(aw.contains).length));
      overlap.forEach(add);
      byLen.sort((x, y) => (all[x].length - answer.length).abs().compareTo((all[y].length - answer.length).abs()));
    }
    byLen.take(120).forEach(add);
  }
  final wrong = _pickDistinct(cand, answer, 3, ok: (t) => t.length >= 4 && !t.toLowerCase().startsWith('list of') && !stemLow.contains(t.toLowerCase()));
  if (wrong == null) return null;
  final opts = [answer, ...wrong]..shuffle(rnd);
  return QuizQ(kind: QKind.definition, stem: stem, options: opts, answer: opts.indexOf(answer), explanation: first, packId: r.pid, title: a.title, index: r.idx, level: r.level);
}

// ---------------------------------------------------------------- cloze

QuizQ? _cloze(_Rd r, Random rnd, _Pools pools) {
  final a = r.art;
  final secs = [...a.sections];
  secs.sort((x, y) => (_clinical.contains(secKind(x.heading)) ? 0 : 1).compareTo(_clinical.contains(secKind(y.heading)) ? 0 : 1));
  final level = r.level;
  int f(String w) => pools.freq[w.toLowerCase()] ?? 1;
  for (final s in secs.take(6)) {
    final kind = secKind(s.heading);
    final list = textUnits(s.text).where((t) => t.length >= 70 && t.length <= 230).toList()..shuffle(rnd);
    for (final snt in list.take(6)) {
      final terms = _keyTerms(snt).where((w) => (_medSuffix.hasMatch(w) || _drugStrong.hasMatch(w) || _otherOk(w, pools)) && snt.indexOf(w) >= 12).toSet().toList()..shuffle(rnd);
      // rarer terms for hard, common ones for easy
      if (level == QuizLevel.hard) {
        terms.sort((x, y) => f(x).compareTo(f(y)));
      } else if (level == QuizLevel.easy) {
        terms.sort((x, y) => f(y).compareTo(f(x)));
      }
      final sentLow = snt.toLowerCase();
      for (final term in terms) {
        final tk = _kindOf(term);
        final suf = _suffixOf(term);
        final low = term.toLowerCase();
        final seen = <String>{};
        final uniq = [
          for (final t in pools.cloze[kind] ?? const <_Term>[])
            if (t.key != r.key && t.low != low && !sentLow.contains(t.low) && !r.allLower.contains(t.low) && (t.kind != _TK.other || _otherOk(t.text, pools)) && seen.add(t.low)) t
        ]..shuffle(rnd);
        List<_Term> ordered = uniq;
        if (level != QuizLevel.easy) {
          int score(_Term t) {
            var sc = 0;
            if (suf.isNotEmpty && t.suffix == suf) sc -= 10;
            if (level == QuizLevel.hard) sc += (t.text.length - term.length).abs();
            return sc;
          }

          ordered = [for (final t in uniq) if (t.kind == tk) t]..sort((x, y) => score(x).compareTo(score(y)));
        }
        final wrong = _pickDistinct(ordered.map((t) => t.text), term, 3);
        if (wrong == null) continue;
        final stem = snt.replaceAll(RegExp('\\b${RegExp.escape(term)}\\b'), '____');
        final opts = [term, ...wrong]..shuffle(rnd);
        return QuizQ(kind: QKind.cloze, stem: stem, options: opts, answer: opts.indexOf(term), explanation: snt, packId: r.pid, title: a.title, index: r.idx, level: r.level);
      }
    }
  }
  return null;
}

// ---------------------------------------------------------------- treatment

QuizQ? _treatment(_Rd r, Random rnd, _Pools pools) {
  final a = r.art;
  final level = r.level;
  for (final s in a.sections) {
    if (secKind(s.heading) != SecKind.treatment) continue;
    final list = textUnits(s.text).where((t) => t.length >= 40 && t.length <= 300).toList()..shuffle(rnd);
    for (final snt in list.take(8)) {
      final cands = <(String, _TK)>[];
      for (final w in _keyTerms(snt)) {
        final tk = _treatmentKind(w, snt);
        if (tk != null && snt.indexOf(w) >= 8) cands.add((w, tk));
      }
      cands.shuffle(rnd);
      for (final (term, tk) in cands) {
        final low = term.toLowerCase();
        final suf = _suffixOf(term);
        final seen = <String>{};
        var pool = [
          for (final t in pools.treat)
            if (t.key != r.key && t.low != low && !r.allLower.contains(t.low) && seen.add(t.low)) t
        ]..shuffle(rnd);
        if (level != QuizLevel.easy) {
          pool = [for (final t in pool) if (t.kind == tk) t];
          int score(_Term t) {
            var sc = 0;
            if (suf.isNotEmpty && t.suffix == suf) sc -= 10;
            if (level == QuizLevel.hard) sc += (t.text.length - term.length).abs();
            return sc;
          }

          pool.sort((x, y) => score(x).compareTo(score(y)));
        }
        final wrong = _pickDistinct(pool.map((t) => t.text), term, 3);
        if (wrong == null) continue;
        final stem = snt.replaceAll(RegExp('\\b${RegExp.escape(term)}\\b'), '____');
        final opts = [term, ...wrong]..shuffle(rnd);
        return QuizQ(
          kind: QKind.treatment,
          stem: stem,
          options: opts,
          answer: opts.indexOf(term),
          explanation: snt,
          packId: r.pid,
          title: a.title,
          index: r.idx,
          prompt: _cleanTitle(a.title),
          level: r.level,
        );
      }
    }
  }
  return null;
}

// ---------------------------------------------------------------- symptom

final RegExp _notFinding = RegExp(r'\b(is|are|was|were|may|can|will|which|that|have|has|been|not|also|often|usually|typically|should|their|these|those|such|more|most|than)\b', caseSensitive: false);

/// Short findings (phrase, source sentence) from a "Signs and symptoms" section.
List<(String, String)> _findings(String text) {
  final out = <(String, String)>[];
  void add(String raw, String src) {
    var t = raw.trim().replaceAll(RegExp(r'^(and|or|a|an|the)\s+', caseSensitive: false), '').replaceAll(RegExp(r'[\s.;:,]+$'), '').trim();
    if (t.length < 5 || t.length > 46) return;
    final n = t.split(RegExp(r'\s+')).length;
    if (n == 1 && t.length < 7) return;
    if (n > 5 || RegExp(r'\d').hasMatch(t) || _notFinding.hasMatch(t) || t.contains('(') || t.contains(')')) return;
    out.add((t[0].toUpperCase() + t.substring(1), src));
  }

  for (final b in bulletLines(text)) {
    var head = b;
    final cut = RegExp(r'\s[–—-]\s|:\s').firstMatch(head);
    if (cut != null) head = head.substring(0, cut.start);
    if (head.length > 60) continue;
    add(head, b);
  }
  final prose = text.split('\n').where((l) => !l.trim().startsWith('•')).join(' ');
  for (final snt in sentences(prose)) {
    final m = RegExp(r'\b(?:include[sd]?|including|such as|(?:symptoms|signs|features|findings) (?:are|is))\s+(.+?)[.;]?$', caseSensitive: false).firstMatch(snt);
    if (m == null) continue;
    for (final part in m.group(1)!.split(RegExp(r',\s*(?:and\s+|or\s+)?|\s+and\s+|\s+or\s+'))) {
      add(part, snt);
    }
  }
  return out;
}

QuizQ? _symptom(_Rd r, Random rnd, _Pools pools, List<LibHit> rel) {
  final a = r.art;
  final level = r.level;
  final own = <(String, String)>[];
  for (final s in a.sections) {
    if (secKind(s.heading) == SecKind.symptoms) own.addAll(_findings(s.text));
  }
  if (own.isEmpty) return null;
  own.shuffle(rnd);
  final title = _cleanTitle(a.title);
  final relIdx = {for (final h in rel) h.index};
  for (final (text, src) in own.take(6)) {
    final pool = level == QuizLevel.easy ? [for (final l in pools.findings.values) ...l] : [...?pools.findings[r.pid]];
    final seen = <String>{};
    final others = [
      for (final f in pool)
        if (f.key != r.key && !r.allLower.contains(f.text.toLowerCase()) && seen.add(f.text.toLowerCase())) f
    ]..shuffle(rnd);
    if (level != QuizLevel.easy) {
      final tw = text.split(' ').length;
      int score(_Finding f) {
        var sc = 0;
        if (relIdx.contains(f.idx)) sc -= 20;
        if (level == QuizLevel.hard) sc += (f.text.split(' ').length - tw).abs() * 2;
        return sc;
      }

      others.sort((x, y) => score(x).compareTo(score(y)));
    }
    final wrong = _pickDistinct(others.map((f) => f.text), text, 3);
    if (wrong == null) continue;
    final opts = [text, ...wrong]..shuffle(rnd);
    return QuizQ(
      kind: QKind.symptom,
      stem: '${title.isEmpty ? a.title : title}: ____',
      options: opts,
      answer: opts.indexOf(text),
      explanation: src,
      packId: r.pid,
      title: a.title,
      index: r.idx,
      prompt: title,
      level: r.level,
    );
  }
  return null;
}
