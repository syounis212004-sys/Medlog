import 'dart:math';

import 'lib_text.dart';
import 'library.dart';

/// Self-test questions made only from the text of the library articles you downloaded.
/// Nothing is invented: a question is a sentence of an article with the key word hidden,
/// or "which topic is described here?" with titles of the same course as wrong answers.
/// The source article is always shown after answering.

enum QKind { definition, cloze }

class QuizQ {
  final QKind kind;
  final String stem;
  final List<String> options;
  final int answer;
  final String explanation;
  final String packId;
  final String title;
  final int index;
  const QuizQ({
    required this.kind,
    required this.stem,
    required this.options,
    required this.answer,
    required this.explanation,
    required this.packId,
    required this.title,
    required this.index,
  });

  String get correct => options[answer];
}

String _cleanTitle(String t) => t.replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();

final RegExp _medSuffix = RegExp(r'(itis|osis|pathy|ectomy|plasty|emia|oma|ase|ine|ide|mab|ism|algia|plegia|uria|penia|trophy|stomy|otomy|scopy|graphy)$', caseSensitive: false);

/// Hides the title (and its long words) inside a sentence.
String? maskTitle(String sentence, String title) {
  final base = _cleanTitle(title);
  if (base.length < 4) return null;
  var s = sentence;
  s = s.replaceAll(RegExp(RegExp.escape(base), caseSensitive: false), '____');
  s = s.replaceAll(RegExp(r'\(\s*(also|or|abbreviated|commonly|known|sometimes|often)[^)]*\)', caseSensitive: false), '');
  s = s.replaceAll(RegExp(r'\(\s*[A-Z][A-Za-z]{1,6}s?\s*\)'), '');
  for (final w in base.split(RegExp(r'[\s\-/]+'))) {
    if (w.length >= 6) s = s.replaceAll(RegExp('\\b${RegExp.escape(w)}\\w*', caseSensitive: false), '____');
  }
  s = s.replaceAll(RegExp(r'(____\s*){2,}'), '____ ').replaceAll(RegExp(r'\s+'), ' ').trim();
  return s.contains('____') ? s : null;
}

class _Src {
  final String packId;
  final int index;
  final LibArticle article;
  const _Src(this.packId, this.index, this.article);
}

List<String> _keyTerms(String sentence) {
  final out = <String>[];
  for (final m in RegExp(r"\b[A-Za-z][A-Za-z\-]{6,}\b").allMatches(sentence)) {
    final w = m.group(0)!;
    final low = w.toLowerCase();
    if (_stopWords.contains(low)) continue;
    out.add(w);
  }
  return out;
}

const Set<String> _stopWords = {
  'however', 'because', 'although', 'between', 'including', 'usually', 'typically', 'commonly', 'several', 'another', 'patients', 'patient', 'without', 'through', 'during',
  'compared', 'increased', 'decreased', 'associated', 'approximately', 'following', 'certain', 'different', 'sometimes', 'generally', 'particularly', 'especially', 'recommended',
  'considered', 'whereas', 'therefore', 'treatment', 'diagnosis', 'symptoms', 'disease', 'condition', 'people', 'children', 'medical', 'clinical', 'studies', 'results',
};

/// Builds up to [count] questions. [query] limits the topic ("knee", "sepsis"...), [packId] the course.
Future<List<QuizQ>> buildQuiz({String? packId, String? query, int count = 10, int? seed}) async {
  final rnd = Random(seed ?? DateTime.now().millisecondsSinceEpoch);
  final packs = [for (final p in library.textPacks) if (packId == null || p.id == packId) p];
  if (packs.isEmpty) return const [];
  // candidate articles
  final cand = <List<Object>>[]; // [packId, index]
  if (query != null && query.trim().isNotEmpty) {
    for (final h in await library.searchEx(query, packId: packId, limit: 80)) {
      cand.add([h.packId, h.index]);
    }
  } else {
    for (final p in packs) {
      final n = (await library.titlesOf(p.id)).length;
      final take = min(n, count * 6);
      final seen = <int>{};
      while (seen.length < take) {
        seen.add(rnd.nextInt(n));
      }
      for (final i in seen) {
        cand.add([p.id, i]);
      }
    }
  }
  cand.shuffle(rnd);
  final out = <QuizQ>[];
  final termPool = <String>[];
  final read = <_Src>[];
  final titlesCache = <String, List<String>>{};
  var tries = 0;
  for (final c in cand) {
    if (out.length >= count || tries > count * 8) break;
    tries++;
    final pid = c[0] as String;
    final idx = c[1] as int;
    final a = await library.read(pid, idx);
    if (a == null || a.sections.isEmpty) continue;
    read.add(_Src(pid, idx, a));
    for (final s in a.sections.take(6)) {
      for (final snt in sentences(s.text).take(6)) {
        termPool.addAll(_keyTerms(snt).where((w) => _medSuffix.hasMatch(w)));
      }
    }
    final wantDef = out.length.isEven;
    QuizQ? q;
    if (wantDef) {
      q = await _definition(a, pid, idx, rnd, titlesCache);
      q ??= _cloze(a, pid, idx, rnd, termPool);
    } else {
      q = _cloze(a, pid, idx, rnd, termPool);
      q ??= await _definition(a, pid, idx, rnd, titlesCache);
    }
    if (q != null && !out.any((e) => e.stem == q!.stem)) out.add(q);
  }
  return out;
}

Future<QuizQ?> _definition(LibArticle a, String pid, int idx, Random rnd, Map<String, List<String>> cache) async {
  final lead = a.sections.first.text;
  final first = firstSentence(lead);
  if (first.length < 60 || first.length > 320) return null;
  final stem = maskTitle(first, a.title);
  if (stem == null) return null;
  final all = cache[pid] ??= await library.titlesOf(pid);
  final answer = _cleanTitle(a.title);
  final wordCount = answer.split(' ').length;
  final pool = <String>[];
  for (var k = 0; k < 400 && pool.length < 3; k++) {
    final t = _cleanTitle(all[rnd.nextInt(all.length)]);
    if (t == answer || pool.contains(t) || t.length < 4) continue;
    if (t.toLowerCase().startsWith('list of')) continue;
    if ((t.split(' ').length - wordCount).abs() > 1) continue;
    if (stem.toLowerCase().contains(t.toLowerCase())) continue;
    pool.add(t);
  }
  if (pool.length < 3) return null;
  final opts = [answer, ...pool]..shuffle(rnd);
  return QuizQ(
    kind: QKind.definition,
    stem: stem,
    options: opts,
    answer: opts.indexOf(answer),
    explanation: first,
    packId: pid,
    title: a.title,
    index: idx,
  );
}

QuizQ? _cloze(LibArticle a, String pid, int idx, Random rnd, List<String> pool) {
  // prefer clinically useful sections
  final secs = [...a.sections];
  secs.sort((x, y) {
    int w(LibSection s) {
      final k = secKind(s.heading);
      return (k == SecKind.symptoms || k == SecKind.treatment || k == SecKind.diagnosis || k == SecKind.causes) ? 0 : 1;
    }

    return w(x).compareTo(w(y));
  });
  for (final s in secs.take(5)) {
    final list = sentences(s.text).where((t) => t.length >= 70 && t.length <= 230 && !t.contains('•')).toList()..shuffle(rnd);
    for (final snt in list.take(6)) {
      final terms = _keyTerms(snt).where((w) => _medSuffix.hasMatch(w) || w.length >= 9).toList()..shuffle(rnd);
      for (final term in terms) {
        if (snt.indexOf(term) < 12) continue; // not the first words of the sentence
        final same = pool.where((p) => p.toLowerCase() != term.toLowerCase() && (_medSuffix.firstMatch(p)?.group(0)?.toLowerCase() == _medSuffix.firstMatch(term)?.group(0)?.toLowerCase())).toSet().toList()..shuffle(rnd);
        final other = pool.where((p) => p.toLowerCase() != term.toLowerCase() && !same.contains(p)).toSet().toList()..shuffle(rnd);
        final wrong = [...same, ...other].take(3).toList();
        if (wrong.length < 3) continue;
        final stem = snt.replaceFirst(term, '____');
        final opts = [term, ...wrong]..shuffle(rnd);
        return QuizQ(
          kind: QKind.cloze,
          stem: stem,
          options: opts,
          answer: opts.indexOf(term),
          explanation: snt,
          packId: pid,
          title: a.title,
          index: idx,
        );
      }
    }
  }
  return null;
}
