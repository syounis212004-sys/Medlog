import 'package:flutter/material.dart';

import 'data.dart' show store;
import 'motion.dart';

/// A selectable look for the whole app. Everything else (cards, chips, nav bar,
/// gradients) is derived from the seed color.
class AppPalette {
  final String id;
  final String nameEn;
  final String nameAr;
  final Color seed;
  final Color accent; // second gradient color
  const AppPalette(this.id, this.nameEn, this.nameAr, this.seed, this.accent);
}

const List<AppPalette> kPalettes = [
  AppPalette('clinic', 'Clinic Teal', 'أخضر العيادة', Color(0xFF00796B), Color(0xFF26C6DA)),
  AppPalette('ocean', 'Ocean Blue', 'أزرق المحيط', Color(0xFF1565C0), Color(0xFF29B6F6)),
  AppPalette('royal', 'Royal Purple', 'بنفسجي ملكي', Color(0xFF5E35B1), Color(0xFFBA68C8)),
  AppPalette('sunset', 'Sunset', 'غروب', Color(0xFFE65100), Color(0xFFFFB300)),
  AppPalette('rose', 'Rose', 'وردي', Color(0xFFC2185B), Color(0xFFFF8A80)),
  AppPalette('forest', 'Forest', 'غابة', Color(0xFF2E7D32), Color(0xFF9CCC65)),
  AppPalette('graphite', 'Graphite', 'رمادي فحمي', Color(0xFF37474F), Color(0xFF90A4AE)),
];

AppPalette paletteById(String id) {
  for (final p in kPalettes) {
    if (p.id == id) return p;
  }
  return kPalettes.first;
}

final Map<String, ThemeData> _themeCache = {};

/// Themes are cached: the store notifies on every save and rebuilding a full
/// ThemeData each time would be wasted work.
ThemeData buildTheme(AppPalette p, Brightness b, {bool amoled = false, bool arabic = false}) {
  return _themeCache.putIfAbsent(
    '${p.id}|${b.name}|$amoled|$arabic',
    () => _buildTheme(p, b, amoled, arabic),
  );
}

ThemeData _buildTheme(AppPalette p, Brightness b, bool amoled, bool arabic) {
  var cs = ColorScheme.fromSeed(seedColor: p.seed, brightness: b);
  if (b == Brightness.dark && amoled) {
    cs = cs.copyWith(
      surface: Colors.black,
      surfaceContainerLowest: Colors.black,
      surfaceContainerLow: const Color(0xFF0B0B0B),
      surfaceContainer: const Color(0xFF111111),
      surfaceContainerHigh: const Color(0xFF181818),
      surfaceContainerHighest: const Color(0xFF202020),
    );
  }
  final radius = BorderRadius.circular(16);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: arabic ? 'Tajawal' : null,
    scaffoldBackgroundColor: cs.surface,
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: SharedAxisBuilder(),
        TargetPlatform.iOS: SharedAxisBuilder(),
        TargetPlatform.linux: SharedAxisBuilder(),
        TargetPlatform.macOS: SharedAxisBuilder(),
        TargetPlatform.windows: SharedAxisBuilder(),
      },
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: cs.surface,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: arabic ? 'Tajawal' : null,
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: cs.onSurface,
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: cs.surfaceContainerLow,
      shape: RoundedRectangleBorder(
        borderRadius: radius,
        side: BorderSide(color: cs.outlineVariant),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: cs.surfaceContainerHighest.withAlpha(b == Brightness.dark ? 90 : 120),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      enabledBorder:
          OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: cs.primary, width: 1.6),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      side: BorderSide(color: cs.outlineVariant),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    dialogTheme: DialogThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      showDragHandle: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    tabBarTheme: TabBarThemeData(
      dividerColor: Colors.transparent,
      indicatorSize: TabBarIndicatorSize.label,
      labelStyle: const TextStyle(fontWeight: FontWeight.w700),
    ),
    listTileTheme: const ListTileThemeData(
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 2),
    ),
  );
}

/// Gradient used by the header, logo and add button. It is built from the
/// palette's own saturated colors (not the light dark-mode scheme colors) so
/// white text on top always has good contrast.
LinearGradient paletteGradient(BuildContext context, {bool soft = false}) {
  final cs = Theme.of(context).colorScheme;
  final dark = Theme.of(context).brightness == Brightness.dark;
  if (soft) {
    final b = Color.lerp(cs.primary, cs.tertiary, 0.75)!;
    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [cs.primary.withAlpha(dark ? 70 : 38), b.withAlpha(dark ? 40 : 18)],
    );
  }
  final p = paletteById(store.paletteId);
  final a = Color.lerp(p.seed, Colors.black, dark ? 0.30 : 0.0)!;
  final b = Color.lerp(Color.lerp(p.seed, p.accent, 0.55)!, Colors.black, dark ? 0.30 : 0.0)!;
  return LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [a, b]);
}
