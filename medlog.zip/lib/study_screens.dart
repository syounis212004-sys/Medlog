import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'ai/voice_input.dart' show VoiceInputButton;
import 'app_icons.dart';
import 'data.dart';
import 'day_planner.dart' show DayStore;
import 'focus_session.dart';
import 'i18n.dart';
import 'lib_quiz.dart' show QuizPick;
import 'lib_user.dart';
import 'library.dart';
import 'screens_article.dart' show ArticleScreen;
import 'screens_quiz.dart' show QuizScreen;
import 'screens_search.dart' show SearchScreen;
import 'study_tools.dart';
import 'ui.dart';
import 'widgets.dart';

// ============================================================ knowledge gaps

/// One line: what the person did not know. Opened from a case ("What I did not know?") or from Learn.
Future<void> showGapDialog(BuildContext context, {String caseCode = ''}) async {
  final c = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text('What I did not know'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('One line is enough. It goes to your list to study later.'),
          const SizedBox(height: 10),
          TextField(
            key: const ValueKey('gap_text'),
            controller: c,
            autofocus: true,
            minLines: 2,
            maxLines: 4,
            onChanged: (_) => setS(() {}),
            decoration: InputDecoration(hintText: tr('e.g. when to start anticoagulation in AF'), suffixIcon: VoiceInputButton(controller: c, onChanged: () => setS(() {}))),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
          FilledButton(key: const ValueKey('gap_save'), onPressed: c.text.trim().isEmpty ? null : () => Navigator.pop(ctx, true), child: Text('Save')),
        ],
      ),
    ),
  );
  if (ok == true) {
    await KnowledgeGaps.add(c.text, caseCode: caseCode);
    if (context.mounted) snack(context, tr('Added to your knowledge gaps.'));
  }
  c.dispose();
}

class KnowledgeGapsScreen extends StatefulWidget {
  const KnowledgeGapsScreen({super.key});
  @override
  State<KnowledgeGapsScreen> createState() => _KnowledgeGapsScreenState();
}

class _KnowledgeGapsScreenState extends State<KnowledgeGapsScreen> {
  bool _showDone = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final open = KnowledgeGaps.all(done: false);
    final done = KnowledgeGaps.all(done: true);
    final list = _showDone ? done : open;
    return Scaffold(
      appBar: AppBar(title: Text('Knowledge gaps')),
      floatingActionButton: FloatingActionButton.extended(key: const ValueKey('gap_add'), onPressed: () async {
        await showGapDialog(context);
        if (mounted) setState(() {});
      }, icon: const Icon(AppIcons.add), label: Text('Add')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 96), children: [
        Text('The things you met on duty and did not know. Study them when you have time, then tick them.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 8),
        SegmentedButton<bool>(
          showSelectedIcon: false,
          segments: [ButtonSegment(value: false, label: m.Text('${tr('To study')} (${open.length})')), ButtonSegment(value: true, label: m.Text('${tr('Studied')} (${done.length})'))],
          selected: {_showDone},
          onSelectionChanged: (v) => setState(() => _showDone = v.first),
        ),
        const SizedBox(height: 8),
        if (list.isEmpty)
          Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(_showDone ? 'Nothing studied yet.' : 'No gaps. Add one after a case: "What I did not know".', textAlign: TextAlign.center))),
        for (final g in list)
          AppCard(
            key: ValueKey('gap_${g['id']}'),
            child: ListTile(
              leading: Checkbox(value: g['done'] == true, onChanged: (v) async {
                await KnowledgeGaps.setDone('${g['id']}', v == true);
                if (mounted) setState(() {});
              }),
              title: m.Text('${g['text']}', style: TextStyle(decoration: g['done'] == true ? TextDecoration.lineThrough : null, fontWeight: FontWeight.w600)),
              subtitle: m.Text([prettyDate('${g['date']}'), if ('${g['case'] ?? ''}'.isNotEmpty) '${g['case']}', if ('${g['src'] ?? ''}'.isNotEmpty) '${g['src']}'].join(' • ')),
              trailing: MenuSheetButton<String>(
                onSelected: (v) async {
                  if (v == 'find') {
                    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SearchScreen(initial: '${g['text']}')));
                  } else if (v == 'focus') {
                    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => FocusSessionScreen(title: '${g['text']}')));
                  } else if (v == 'delete') {
                    await KnowledgeGaps.remove('${g['id']}');
                    if (mounted) setState(() {});
                  }
                },
                actions: [
                  MenuAction('find', tr('Find it in the library'), AppIcons.search),
                  MenuAction('focus', tr('Start a focus session'), AppIcons.bolt),
                  MenuAction('delete', tr('Delete'), AppIcons.delete, danger: true),
                ],
              ),
            ),
          ),
      ]),
    );
  }
}

// ============================================================ the mistake notebook

class MistakeNotebookScreen extends StatefulWidget {
  const MistakeNotebookScreen({super.key});
  @override
  State<MistakeNotebookScreen> createState() => _MistakeNotebookScreenState();
}

class _MistakeNotebookScreenState extends State<MistakeNotebookScreen> {
  String _filter = 'all'; // all | knowledge | rushed | misread | guess | none

  List<J> _list() {
    final all = MistakeBook.all();
    if (_filter == 'all') return all;
    if (_filter == 'none') return [for (final x in all) if ('${x['reason'] ?? ''}'.isEmpty) x];
    return [for (final x in all) if ('${x['reason'] ?? ''}' == _filter) x];
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final by = MistakeBook.byReason();
    final total = MistakeBook.all().length;
    final tagged = by.entries.where((e) => e.key.isNotEmpty).toList()..sort((a, b) => b.value.compareTo(a.value));
    final list = _list();
    Widget chip(String key, String label, int n) => ChoiceChip(key: ValueKey('mk_$key'), label: m.Text('$label ($n)'), selected: _filter == key, onSelected: (_) => setState(() => _filter = key));
    return Scaffold(
      appBar: AppBar(title: Text('Mistake notebook')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        if (total == 0)
          Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('No mistakes yet. Wrong answers in "Test myself" and in a mock exam are kept here, with the reason.', textAlign: TextAlign.center)))
        else ...[
          if (tagged.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: m.Text('${tr('Most common reason')}: ${tr(mistakeReasonLabel(MistakeReason.values.firstWhere((r) => r.name == tagged.first.key)))} (${tagged.first.value})', key: const ValueKey('mk_top'), style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800, color: cs.primary)),
            ),
          Wrap(spacing: 8, runSpacing: 4, children: [
            chip('all', tr('All'), total),
            for (final r in MistakeReason.values) chip(r.name, tr(mistakeReasonLabel(r)), by[r.name] ?? 0),
            chip('none', tr('Not tagged'), by[''] ?? 0),
          ]),
          const SizedBox(height: 8),
          if (list.isNotEmpty)
            FilledButton.tonalIcon(
              key: const ValueKey('mk_practise'),
              onPressed: () {
                final seen = <String>{};
                final picks = <QuizPick>[];
                for (final x in list) {
                  final k = '${x['p']}|${x['i']}';
                  if (seen.add(k)) picks.add(QuizPick('${x['p']}', (x['i'] as num).toInt(), '${x['t']}', 1));
                }
                Navigator.push(context, MaterialPageRoute<void>(builder: (_) => QuizScreen(picks: picks.take(10).toList(), autoStart: true)));
              },
              icon: const Icon(AppIcons.quiz),
              label: Text('Practise the topics of these mistakes'),
            ),
          for (final x in list)
            AppCard(
              key: ValueKey('mkc_${x['id']}'),
              child: ExpansionTile(
                title: m.Text('${x['stem']}', maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, height: 1.35)),
                subtitle: m.Text([prettyDate('${x['date']}'), '${x['t']}', if (((x['n'] as num?)?.toInt() ?? 1) > 1) '×${x['n']}'].join(' • '), maxLines: 1, overflow: TextOverflow.ellipsis),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                expandedCrossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  m.Text('${tr('Answer')}: ${x['correct']}', style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary)),
                  if ('${x['expl']}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: m.Text('${x['expl']}', style: const TextStyle(height: 1.4))),
                  const SizedBox(height: 8),
                  Text('Why did I miss it?', style: theme.textTheme.labelLarge),
                  Wrap(spacing: 8, runSpacing: 4, children: [
                    for (final r in MistakeReason.values)
                      ChoiceChip(
                        key: ValueKey('mkr_${x['id']}_${r.name}'),
                        label: Text(mistakeReasonLabel(r)),
                        selected: '${x['reason']}' == r.name,
                        onSelected: (v) async {
                          await MistakeBook.setReason('${x['id']}', v ? r : null);
                          if (mounted) setState(() {});
                        },
                      ),
                  ]),
                  Wrap(spacing: 4, children: [
                    TextButton.icon(
                      onPressed: () async {
                        final i = await library.indexOfTitle('${x['p']}', '${x['t']}');
                        final idx = i ?? (x['i'] as num).toInt();
                        if (context.mounted) Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ArticleScreen(packId: '${x['p']}', index: idx)));
                      },
                      icon: const Icon(AppIcons.library, size: 18),
                      label: Text('Open the article'),
                    ),
                    TextButton.icon(
                      onPressed: () async {
                        await MistakeBook.remove('${x['id']}');
                        if (mounted) setState(() {});
                      },
                      icon: Icon(AppIcons.delete, size: 18, color: cs.error),
                      label: Text('Remove'),
                    ),
                  ]),
                ],
              ),
            ),
        ],
      ]),
    );
  }
}

// ============================================================ weekly progress

class StudyDashboardScreen extends StatelessWidget {
  const StudyDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final now = DateTime.now();
    final days = StudyLog.minutesByDay(now);
    final (total, top) = StudyLog.summary(now);
    final peak = days.fold<int>(0, (a, d) => d.$2 > a ? d.$2 : a);
    final sessions = StudyLog.sessionsIn(now);
    final dist = StudyLog.interruptionsIn(now);
    final streak = DayStore.streak(DayStore.log(), now);
    final ready = examReadiness(now: now);
    final weak = weakSpots().take(5).toList();
    final gaps = KnowledgeGaps.openCount;
    final mistakes = MistakeBook.all().length;
    String hm(int m) => m >= 60 ? '${m ~/ 60}h ${m % 60}m' : '${m}m';
    const wd = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return Scaffold(
      appBar: AppBar(title: Text('Weekly progress')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        AppCard(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Focus time, last 7 days', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Directionality(textDirection: TextDirection.ltr, child: m.Text(hm(total), key: const ValueKey('dash_total'), style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900, color: cs.primary))),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final d in days)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 3),
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                          Container(key: ValueKey('bar_${d.$1}'), height: peak == 0 ? 3 : (3 + 56 * d.$2 / peak), decoration: BoxDecoration(color: d.$2 == 0 ? cs.surfaceContainerHighest : cs.primary, borderRadius: BorderRadius.circular(4))),
                          const SizedBox(height: 4),
                          FittedBox(fit: BoxFit.scaleDown, child: m.Text(tr(wd[(DateTime.parse(d.$1).weekday - 1) % 7]), maxLines: 1, style: theme.textTheme.labelSmall)),
                        ]),
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 8),
              m.Text([trp('{n} sessions', {'n': sessions}), if (dist > 0) '${tr('Distractions')}: $dist', if (streak > 0) trp('{n} days in a row', {'n': streak})].join(' • '), style: theme.textTheme.bodySmall),
            ]),
          ),
        ),
        if (top.isNotEmpty) ...[
          SectionHeader(tr('Where the time went')),
          for (final t in top) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: m.Text(t.$1, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: m.Text(hm(t.$2), style: const TextStyle(fontWeight: FontWeight.w700))),
        ],
        SectionHeader(tr('Exam plan')),
        AppCard(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: ready.state == ReadinessState.none
                ? Text('No exam plan yet. Make one in My plan to see how the time is going.')
                : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    LinearProgressIndicator(value: ready.coverage, minHeight: 8, borderRadius: BorderRadius.circular(6)),
                    const SizedBox(height: 8),
                    m.Text(trp('{a} of {b} topics done • {d} days left', {'a': ready.done, 'b': ready.total, 'd': ready.daysLeft}), key: const ValueKey('dash_ready'), style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    m.Text(
                      switch (ready.state) {
                        ReadinessState.ahead => trp('Your pace ({r}/day) is above what the plan needs ({n}/day).', {'r': ready.perDayRecent.toStringAsFixed(1), 'n': ready.perDayNeeded}),
                        ReadinessState.onTrack => trp('Your pace ({r}/day) is close to what the plan needs ({n}/day).', {'r': ready.perDayRecent.toStringAsFixed(1), 'n': ready.perDayNeeded}),
                        _ => trp('The plan needs {n} topics a day; your last week was {r}/day.', {'r': ready.perDayRecent.toStringAsFixed(1), 'n': ready.perDayNeeded}),
                      },
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: 4),
                    Text('This reads your plan. It does not predict your result.', style: theme.textTheme.labelSmall),
                  ]),
          ),
        ),
        SectionHeader(tr('Weak topics')),
        if (weak.isEmpty) Text('Nothing weak yet: answer some questions in "Test myself".', style: theme.textTheme.bodySmall),
        for (final w in weak)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: m.Text(stripSource(w.title), maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: const Icon(AppIcons.chevronRight),
            onTap: () async {
              final i = await library.indexOfTitle(w.packId, w.title);
              if (i != null && context.mounted) Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ArticleScreen(packId: w.packId, index: i)));
            },
          ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(key: const ValueKey('dash_gaps'), onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const KnowledgeGapsScreen())), icon: const Icon(AppIcons.flag), label: m.Text('${tr('Gaps')} ($gaps)'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(key: const ValueKey('dash_mistakes'), onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const MistakeNotebookScreen())), icon: const Icon(AppIcons.error), label: m.Text('${tr('Mistakes')} ($mistakes)'))),
        ]),
      ]),
    );
  }
}
