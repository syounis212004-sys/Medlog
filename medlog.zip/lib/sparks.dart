import 'dart:convert';
import 'dart:math';

import 'package:flutter/services.dart' show rootBundle;

import 'data.dart';

/// A line of verse shown on the opening screen and on Home. The text comes from assets/data/sparks.json.
/// A poet's name is shown only when the file marks the attribution as "known"; every other verse is shown without a name.
class Spark {
  final String id, text, author;
  const Spark(this.id, this.text, this.author);
  List<String> get lines => text.split('\n');
}

class Sparks {
  static List<Spark> _all = const [];

  /// Reads the file once. A missing or broken file just means no verses.
  static Future<void> load() async {
    if (_all.isNotEmpty) return;
    try {
      final j = jsonDecode(await rootBundle.loadString('assets/data/sparks.json')) as Map;
      _all = [
        for (final e in (j['items'] as List? ?? const []))
          if (e is Map && e['enabled'] != false && '${e['text_ar'] ?? ''}'.trim().isNotEmpty)
            Spark('${e['id']}', '${e['text_ar']}'.trim(), e['attribution_status'] == 'known' ? '${e['author_ar'] ?? ''}'.trim() : ''),
      ];
    } catch (_) {
      _all = const [];
    }
  }

  static bool get on => store.settings['sparksOff'] != true;

  /// The verse of a given day: the same all day, a different one tomorrow.
  static Spark? ofDay(DateTime d) {
    if (!on || _all.isEmpty) return null;
    final day = DateTime(d.year, d.month, d.day).difference(DateTime(2024)).inDays;
    return _all[day % _all.length];
  }

  /// A random verse for the opening screen.
  static Spark? random([Random? r]) {
    if (!on || _all.isEmpty) return null;
    return _all[(r ?? Random()).nextInt(_all.length)];
  }

  static int get count => _all.length;
}
