import 'dart:convert';
import 'dart:math';

import 'package:flutter/services.dart' show rootBundle;

import 'data.dart';
import 'i18n.dart';

/// A line of verse shown on the opening screen and on Home. The text comes from assets/data/sparks.json.
/// A poet's name is shown only when the file marks the attribution as "known"; every other verse is shown without a name.
class Spark {
  final String id, text, textEn, author;
  /// When in the day the verse fits: morning | day | evening | night (empty = any time).
  final List<String> parts;
  const Spark(this.id, this.text, this.author, [this.parts = const [], this.textEn = '']);
  /// The line in the language of the app (Arabic when no English one is given).
  List<String> get lines => (isAr || textEn.isEmpty ? text : textEn).split('\n');
}

class Sparks {
  static List<Spark> _all = const [];

  /// Reads the file once. A missing or broken file just means no verses.
  static Future<void> load() async {
    if (_all.isNotEmpty) return;
    try {
      final j = jsonDecode(await rootBundle.loadString('assets/data/sparks.json')) as Map;
      _all = [
        for (final e in (j['items'] as List? ?? const []))
          if (e is Map && e['enabled'] != false && '${e['text_ar'] ?? ''}'.trim().isNotEmpty)
            Spark('${e['id']}', '${e['text_ar']}'.trim(), e['attribution_status'] == 'known' ? '${e['author_ar'] ?? ''}'.trim() : '', [for (final x in (e['part'] as List? ?? const [])) '$x'], '${e['text_en'] ?? ''}'.trim()),
      ];
    } catch (_) {
      _all = const [];
    }
  }

  static bool get on => store.settings['sparksOff'] != true;

  static String _partOf(int h) => h >= 5 && h < 11 ? 'morning' : (h >= 11 && h < 16 ? 'day' : (h >= 16 && h < 19 ? 'evening' : 'night'));

  /// The verse for now: one that fits this part of the day (a fresh start in the morning, effort by day, a calm
  /// thought in the evening, hope at night). The same one for the whole part of the day, another tomorrow.
  static Spark? ofDay(DateTime d) {
    if (!on || _all.isEmpty) return null;
    final part = _partOf(d.hour);
    final fit = [for (final s in _all) if (s.parts.contains(part)) s];
    final pool = fit.isEmpty ? _all : fit;
    final day = DateTime(d.year, d.month, d.day).difference(DateTime(2024)).inDays;
    return pool[day % pool.length];
  }

  /// A random verse for the opening screen.
  static Spark? random([Random? r]) {
    if (!on || _all.isEmpty) return null;
    return _all[(r ?? Random()).nextInt(_all.length)];
  }

  static int get count => _all.length;
}
