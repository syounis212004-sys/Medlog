import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'data.dart' show two;
import 'focus_service.dart';
import 'i18n.dart';
import 'study_tools.dart';
import 'ph.dart';

/// The screen of the focus session. It is only a view of [FocusService]: leaving it never ends the session. The timer
/// goes on (the pill on top of every screen shows it) while the person reads, takes a quiz or uses any other screen.
class FocusSessionScreen extends StatefulWidget {
  final String title;
  final String ref;

  /// How many of these screens are open (the pill hides itself while the full screen shows the same timer).
  static final ValueNotifier<int> open = ValueNotifier<int>(0);
  const FocusSessionScreen({super.key, this.title = '', this.ref = ''});
  @override
  State<FocusSessionScreen> createState() => _FocusSessionScreenState();
}

class _FocusSessionScreenState extends State<FocusSessionScreen> {
  final _topic = TextEditingController();
  int _work = StudyLog.workMinutes, _break = StudyLog.breakMinutes;
  FocusService get _s => FocusService.instance;

  @override
  void initState() {
    super.initState();
    _topic.text = widget.title;
    if (_s.phase == FocusPhase.done) _s.reset(); // a finished session from before: start clean
    WidgetsBinding.instance.addPostFrameCallback((_) => FocusSessionScreen.open.value++);
  }

  @override
  void dispose() {
    _topic.dispose();
    WidgetsBinding.instance.addPostFrameCallback((_) => FocusSessionScreen.open.value--);
    super.dispose();
  }

  String _mmss(Duration d) => '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text('Focus session')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: _s,
          builder: (context, _) => Padding(
            padding: const EdgeInsets.all(20),
            child: switch (_s.phase) {
              FocusPhase.idle => _setup(theme),
              FocusPhase.work || FocusPhase.rest => _running(theme, cs),
              FocusPhase.done => _finished(theme, cs),
            },
          ),
        ),
      ),
    );
  }

  Widget _setup(ThemeData theme) {
    Widget chips(String label, List<int> opts, int value, void Function(int) on) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            for (final o in opts) ChoiceChip(key: ValueKey('${label}_$o'), label: m.Text('$o ${tr('min')}'), selected: value == o, onSelected: (_) => setState(() => on(o))),
          ]),
        ]);
    return ListView(children: [
      Text('One thing at a time. Pick what you will work on and for how long.', style: theme.textTheme.bodyMedium),
      const SizedBox(height: 14),
      TextField(key: const ValueKey('focus_topic'), controller: _topic, textInputAction: TextInputAction.done, decoration: InputDecoration(labelText: tr('What will you work on?'), hintText: tr('Free study'))),
      const SizedBox(height: 16),
      chips('Work', const [15, 25, 45, 60], _work, (v) => _work = v),
      const SizedBox(height: 14),
      chips('Break', const [0, 5, 10, 15], _break, (v) => _break = v),
      const SizedBox(height: 20),
      FilledButton.icon(
        key: const ValueKey('focus_start'),
        onPressed: () => _s.start(title: _topic.text, ref: widget.ref, work: _work, rest: _break),
        icon: const Icon(AppIcons.bolt),
        label: Text('Start'),
      ),
      const SizedBox(height: 10),
      Text('After you start, leave this screen and study in the app: the timer stays on top of every screen, and a notification tells you when the time is up.', style: theme.textTheme.bodySmall),
    ]);
  }

  Widget _running(ThemeData theme, ColorScheme cs) {
    final rest = _s.phase == FocusPhase.rest;
    final left = _s.left;
    final title = _s.title.trim().isEmpty ? tr('Free study') : _s.title.trim();
    return Column(children: [
      const Spacer(),
      m.Text(rest ? tr('Break') : title, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      SizedBox(
        width: 230,
        height: 230,
        child: Stack(alignment: Alignment.center, children: [
          SizedBox.expand(child: CircularProgressIndicator(value: _s.progress, strokeWidth: 10, color: rest ? cs.tertiary : cs.primary, backgroundColor: cs.surfaceContainerHighest)),
          Directionality(textDirection: TextDirection.ltr, child: m.Text(_mmss(left), key: const ValueKey('focus_time'), style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()]))),
        ]),
      ),
      const SizedBox(height: 14),
      if (!rest && _s.interruptions > 0) m.Text('${tr('Distractions')}: ${_s.interruptions}', key: const ValueKey('focus_int'), style: theme.textTheme.bodySmall),
      const Spacer(),
      Text('You can leave this screen. The timer keeps running.', textAlign: TextAlign.center, style: theme.textTheme.bodySmall),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
        if (!rest)
          FilledButton.tonalIcon(key: const ValueKey('focus_pause'), onPressed: _s.paused ? _s.resume : _s.pause, icon: Icon(_s.paused ? AppIcons.bolt : Ph.pause), label: Text(_s.paused ? 'Resume' : 'Pause')),
        if (!rest) OutlinedButton.icon(key: const ValueKey('focus_distracted'), onPressed: _s.distracted, icon: const Icon(AppIcons.warn), label: Text('Something distracted me')),
        FilledButton.tonal(key: const ValueKey('study_here'), onPressed: () => Navigator.maybePop(context), child: Text('Back to the app')),
        TextButton(key: const ValueKey('focus_finish'), onPressed: rest ? _s.skipBreak : _s.finishEarly, child: Text(rest ? 'Skip the break' : 'Finish now')),
      ]),
    ]);
  }

  Widget _finished(ThemeData theme, ColorScheme cs) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(AppIcons.check, size: 56, color: cs.primary),
      const SizedBox(height: 12),
      m.Text(_s.savedMinutes > 0 ? trp('{n} minutes of focus saved', {'n': _s.savedMinutes}) : tr('Nothing to save: the session was shorter than a minute.'), key: const ValueKey('focus_done'), textAlign: TextAlign.center, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 22),
      FilledButton(key: const ValueKey('focus_again'), onPressed: _s.reset, child: Text('Another round')),
      TextButton(onPressed: () => Navigator.pop(context), child: Text('Done')),
    ]);
  }
}
