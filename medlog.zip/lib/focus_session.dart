import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';

import 'app_icons.dart';
import 'data.dart';
import 'i18n.dart';
import 'reminders.dart';
import 'study_tools.dart';

/// A focus session: work for a set time on one topic with a calm screen, then a break. The time really worked is kept
/// for the weekly progress. Pause, "something distracted me" (counted, not judged) and finish early are always there.

enum _Phase { setup, work, rest, done }

class FocusSessionScreen extends StatefulWidget {
  final String title;
  final String ref;

  /// Tests replace the clock; the screen reads time only through it.
  static DateTime Function() clock = DateTime.now;
  const FocusSessionScreen({super.key, this.title = '', this.ref = ''});
  @override
  State<FocusSessionScreen> createState() => _FocusSessionScreenState();
}

class _FocusSessionScreenState extends State<FocusSessionScreen> {
  final _topic = TextEditingController();
  _Phase _phase = _Phase.setup;
  int _work = StudyLog.workMinutes, _break = StudyLog.breakMinutes;
  DateTime? _end;
  Duration? _frozen; // time left while paused
  int _planned = 0; // seconds of the running phase
  int _interruptions = 0;
  int _savedMinutes = 0;
  Timer? _tick;

  DateTime get _now => FocusSessionScreen.clock();
  bool get _paused => _frozen != null;

  @override
  void initState() {
    super.initState();
    _topic.text = widget.title;
  }

  @override
  void dispose() {
    _tick?.cancel();
    _topic.dispose();
    Reminders.focusCancel();
    super.dispose();
  }

  Duration get _left {
    if (_frozen != null) return _frozen!;
    final e = _end;
    if (e == null) return Duration.zero;
    final d = e.difference(_now);
    return d.isNegative ? Duration.zero : d;
  }

  void _startPhase(_Phase p, int minutes) {
    _tick?.cancel();
    _planned = minutes * 60;
    _end = _now.add(Duration(minutes: minutes));
    _frozen = null;
    setState(() => _phase = p);
    Reminders.focusEndsAt(_end!, onBreak: p == _Phase.rest);
    _tick = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!mounted) return;
      if (_left == Duration.zero && !_paused) {
        _phaseOver();
      } else {
        setState(() {});
      }
    });
  }

  Future<void> _start() async {
    await StudyLog.setWork(_work);
    await StudyLog.setBreak(_break);
    _interruptions = 0;
    _startPhase(_Phase.work, _work);
  }

  void _pause() {
    setState(() => _frozen = _left);
    Reminders.focusCancel();
  }

  void _resume() {
    final f = _frozen;
    if (f == null) return;
    _end = _now.add(f);
    setState(() => _frozen = null);
    Reminders.focusEndsAt(_end!, onBreak: _phase == _Phase.rest);
  }

  Future<void> _phaseOver() async {
    _tick?.cancel();
    HapticFeedback.mediumImpact();
    if (_phase == _Phase.work) {
      await _save(_planned);
      if (_break > 0) {
        _startPhase(_Phase.rest, _break);
      } else {
        setState(() => _phase = _Phase.done);
      }
    } else {
      setState(() => _phase = _Phase.done);
    }
  }

  /// Keeps the minutes really worked in this round (at least one).
  Future<void> _save(int seconds) async {
    final mins = (seconds / 60).round();
    _savedMinutes += mins;
    await StudyLog.add(minutes: mins, title: _topic.text, ref: widget.ref, interruptions: _interruptions, at: _now);
    await Reminders.focusCancel();
  }

  Future<void> _finishEarly() async {
    _tick?.cancel();
    final worked = _planned - _left.inSeconds;
    if (_phase == _Phase.work && worked >= 60) {
      await _save(worked);
    } else {
      await Reminders.focusCancel();
    }
    if (mounted) setState(() => _phase = _Phase.done);
  }

  String _mmss(Duration d) => '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return PopScope(
      canPop: _phase != _Phase.work || _paused,
      onPopInvokedWithResult: (did, _) async {
        if (did) return;
        final leave = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('Leave the session?'),
            content: Text('The time you worked so far is kept.'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Stay')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text('Leave'))],
          ),
        );
        if (leave == true) {
          await _finishEarly();
          if (context.mounted) Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text('Focus session')),
        body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: switch (_phase) {
          _Phase.setup => _setup(theme),
          _Phase.work || _Phase.rest => _running(theme, cs),
          _Phase.done => _finished(theme, cs),
        })),
      ),
    );
  }

  Widget _setup(ThemeData theme) {
    Widget chips(String label, List<int> opts, int value, void Function(int) on, {String suffix = 'min'}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            for (final o in opts) ChoiceChip(key: ValueKey('${label}_$o'), label: m.Text('$o ${tr(suffix)}'), selected: value == o, onSelected: (_) => setState(() => on(o))),
          ]),
        ]);
    return ListView(children: [
      Text('One thing at a time. Pick what you will work on and for how long.', style: theme.textTheme.bodyMedium),
      const SizedBox(height: 14),
      TextField(key: const ValueKey('focus_topic'), controller: _topic, textInputAction: TextInputAction.done, decoration: InputDecoration(labelText: tr('What will you work on?'), hintText: tr('Free study'))),
      const SizedBox(height: 16),
      chips('Work', const [15, 25, 45, 60], _work, (v) => _work = v),
      const SizedBox(height: 14),
      chips('Break', const [0, 5, 10, 15], _break, (v) => _break = v),
      const SizedBox(height: 20),
      FilledButton.icon(key: const ValueKey('focus_start'), onPressed: _start, icon: const Icon(AppIcons.bolt), label: Text('Start')),
      const SizedBox(height: 10),
      Text('Keep the app open or switch to another app: a notification tells you when the time is up.', style: theme.textTheme.bodySmall),
    ]);
  }

  Widget _running(ThemeData theme, ColorScheme cs) {
    final rest = _phase == _Phase.rest;
    final left = _left;
    final f = _planned == 0 ? 0.0 : (1 - left.inSeconds / _planned).clamp(0.0, 1.0);
    return Column(children: [
      const Spacer(),
      m.Text(rest ? tr('Break') : (_topic.text.trim().isEmpty ? tr('Free study') : _topic.text.trim()), maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      SizedBox(
        width: 230,
        height: 230,
        child: Stack(alignment: Alignment.center, children: [
          SizedBox.expand(child: CircularProgressIndicator(value: f, strokeWidth: 10, color: rest ? cs.tertiary : cs.primary, backgroundColor: cs.surfaceContainerHighest)),
          Directionality(textDirection: TextDirection.ltr, child: m.Text(_mmss(left), key: const ValueKey('focus_time'), style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()]))),
        ]),
      ),
      const SizedBox(height: 14),
      if (!rest && _interruptions > 0) m.Text('${tr('Distractions')}: $_interruptions', key: const ValueKey('focus_int'), style: theme.textTheme.bodySmall),
      const Spacer(),
      Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
        if (!rest)
          FilledButton.tonalIcon(key: const ValueKey('focus_pause'), onPressed: _paused ? _resume : _pause, icon: Icon(_paused ? AppIcons.bolt : Icons.pause), label: Text(_paused ? 'Resume' : 'Pause')),
        if (!rest) OutlinedButton.icon(key: const ValueKey('focus_distracted'), onPressed: () => setState(() => _interruptions++), icon: const Icon(AppIcons.warn), label: Text('Something distracted me')),
        TextButton(key: const ValueKey('focus_finish'), onPressed: rest ? () => setState(() => _phase = _Phase.done) : _finishEarly, child: Text(rest ? 'Skip the break' : 'Finish now')),
      ]),
    ]);
  }

  Widget _finished(ThemeData theme, ColorScheme cs) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(AppIcons.check, size: 56, color: cs.primary),
      const SizedBox(height: 12),
      m.Text(_savedMinutes > 0 ? trp('{n} minutes of focus saved', {'n': _savedMinutes}) : tr('Nothing to save: the session was shorter than a minute.'), key: const ValueKey('focus_done'), textAlign: TextAlign.center, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      if (_interruptions > 0) Padding(padding: const EdgeInsets.only(top: 6), child: m.Text('${tr('Distractions')}: $_interruptions', style: theme.textTheme.bodySmall)),
      const SizedBox(height: 22),
      FilledButton(key: const ValueKey('focus_again'), onPressed: () => setState(() {
            _savedMinutes = 0;
            _interruptions = 0;
            _phase = _Phase.setup;
          }), child: Text('Another round')),
      TextButton(onPressed: () => Navigator.pop(context), child: Text('Done')),
    ]);
  }
}
