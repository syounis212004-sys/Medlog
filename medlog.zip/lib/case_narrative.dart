/// Turns the answers of the quick questions into sentences, offline and without AI.
///
/// "Onset: Sudden" + "Site: Foot" + "Local symptoms: Redness, Warmth, Swelling" becomes
/// "The onset was sudden. The site is foot. Local symptoms include redness, warmth and swelling."
/// Labels the rules know get a natural sentence; every other label falls back to "Label: values." so nothing is lost.

/// First letter small unless the word is an acronym or a name ("ECG", "GCS 15", "HIV", "CT", "Kernig sign").
String lcFirst(String v) {
  final t = v.trim();
  if (t.length < 2) return t;
  final first = t.split(RegExp(r'[\s/(]')).first;
  final acronym = first.length > 1 && first == first.toUpperCase() && RegExp(r'[A-Z]').hasMatch(first);
  if (acronym) return t;
  if (t[0] != t[0].toLowerCase() && t[1] == t[1].toLowerCase()) return '${t[0].toLowerCase()}${t.substring(1)}';
  return t;
}

String ucFirst(String v) => v.isEmpty ? v : '${v[0].toUpperCase()}${v.substring(1)}';

/// "a", "a and b", "a, b and c".
String joinList(List<String> v) {
  if (v.isEmpty) return '';
  if (v.length == 1) return v.first;
  return '${v.sublist(0, v.length - 1).join(', ')} and ${v.last}';
}

const Set<String> _notDone = {'Not assessed', 'Unable to assess'};

String _norm(String label) => label.toLowerCase().replaceAll(RegExp(r'\s*\([^)]*\)'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

String _end(String s) {
  final t = s.trim();
  if (t.isEmpty) return t;
  return RegExp(r'[.!?]$').hasMatch(t) ? t : '$t.';
}

/// One sentence for one answered question. [values] are the chosen options, [details] the free text beside them.
String sentenceFor(String label, List<String> values, String details) {
  final n = _norm(label);
  var vals = [for (final v in values) if (v.trim().isNotEmpty) v.trim()];
  final det = details.trim();
  // "Other" alone says nothing: the details (if any) carry it
  if (vals.length > 1 || det.isNotEmpty) vals = [for (final v in vals) if (v != 'Other') v];
  final shownLabel = label.replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();

  String tail(String s) => det.isEmpty ? _end(s) : '${s.replaceFirst(RegExp(r'[.!?]$'), '')} ($det).';

  if (vals.isNotEmpty && vals.every(_notDone.contains)) {
    return '${ucFirst(shownLabel)} ${vals.first == 'Unable to assess' ? 'could not be assessed' : 'was not assessed'}.';
  }
  if (vals.length == 1 && vals.first == 'None reported') {
    return tail('No ${_noun(n)} reported');
  }
  final l = [for (final v in vals) lcFirst(v)];
  final list = joinList(l);
  if (vals.isEmpty) return det.isEmpty ? '' : '${ucFirst(shownLabel)}: $det.';

  // single-valued attributes: "The onset was sudden."
  if (RegExp(r'^onset\b').hasMatch(n)) return tail('The onset was $list');
  if (RegExp(r'^(duration and course|course|clinical course|trajectory)\b').hasMatch(n)) return tail('The course has been $list');
  if (RegExp(r'^(site|pain site|side|laterality|distribution|pain character|character|reported severity|severity|pattern|anatomical region)\b').hasMatch(n)) {
    return tail('The ${n.replaceAll(RegExp(r'\s*/\s*presentation$'), '')} is $list');
  }
  if (n == 'primary system / presentation' || n == 'primary clinical problem' || n == 'problem') return tail('The main problem is $list');
  if (RegExp(r'^mechanism').hasMatch(n)) return tail('The mechanism or context was $list');
  // lists
  if (RegExp(r'^(associated symptoms|symptoms|symptoms / signs|local symptoms|associated acute symptoms)$').hasMatch(n)) return tail('Associated symptoms include $list');
  if (n == 'systemic features') return tail('Systemic features include $list');
  if (RegExp(r'^red flags').hasMatch(n)) return tail('Red flags: $list');
  if (RegExp(r'^(risk factors|host factors and risk|relevant medical risk factors|relevant history)$').hasMatch(n)) return tail('Relevant ${n == 'relevant history' ? 'history' : 'risk factors'}: $list');
  if (n == 'aggravating factors') return tail('Aggravated by $list');
  if (n == 'relieving factors') return tail('Relieved by $list');
  if (n == 'activity impact') return tail('Symptoms occur $list');
  if (RegExp(r'^(trigger|precipitating|possible entry point)').hasMatch(n)) return tail('Possible trigger or context: $list');
  if (n == 'allergy and medicines') return tail(ucFirst(list));
  if (RegExp(r'^observations').hasMatch(n)) return tail('Observations: $list');
  // everything else keeps its own name
  return tail('$shownLabel: $list');
}

String _noun(String n) {
  if (n == 'symptoms' || n == 'symptoms / signs') return 'symptoms';
  if (n.startsWith('red flags')) return 'red flags';
  return n;
}

/// The sentences of several answers as one paragraph.
String paragraphOf(List<({String label, List<String> values, String details})> answers, {String sep = ' '}) =>
    [for (final a in answers) sentenceFor(a.label, a.values, a.details)].where((s) => s.isNotEmpty).join(sep);

// ------------------------------------------------------------------------------------------------------ story

enum _K { main, mechanism, onset, course, site, attr, assoc, systemic, aggr, relieve, activity, trigger, risk, redflag, allergy, other }

_K _kindOf(String label) {
  final n = _norm(label);
  if (RegExp(r'^onset\b').hasMatch(n)) return _K.onset;
  if (RegExp(r'^(duration and course|course|clinical course|trajectory)\b').hasMatch(n)) return _K.course;
  if (RegExp(r'^(site|pain site|side|laterality|distribution|anatomical region)\b').hasMatch(n)) return _K.site;
  if (RegExp(r'^(pain character|character|reported severity|severity|pattern)\b').hasMatch(n)) return _K.attr;
  if (n == 'primary system / presentation' || n == 'primary clinical problem' || n == 'problem') return _K.main;
  if (RegExp(r'^mechanism').hasMatch(n)) return _K.mechanism;
  if (RegExp(r'^(associated symptoms|symptoms|symptoms / signs|local symptoms|associated acute symptoms)$').hasMatch(n)) return _K.assoc;
  if (n == 'systemic features') return _K.systemic;
  if (n == 'aggravating factors') return _K.aggr;
  if (n == 'relieving factors') return _K.relieve;
  if (n == 'activity impact') return _K.activity;
  if (RegExp(r'^(trigger|precipitating|possible entry point)').hasMatch(n)) return _K.trigger;
  if (RegExp(r'^(risk factors|host factors and risk|relevant medical risk factors|relevant history)$').hasMatch(n)) return _K.risk;
  if (RegExp(r'^red flags').hasMatch(n)) return _K.redflag;
  if (n == 'allergy and medicines') return _K.allergy;
  return _K.other;
}

/// The answers of one complaint (or of the specialty's own questions) as running text: the sentences are put in the
/// order a history is told (onset and course, where and how, what goes with it, what changes it, risks and red flags)
/// and related answers share a sentence.
String storyOf(List<({String label, List<String> values, String details})> answers) {
  final byKind = <_K, List<({String label, List<String> values, String details})>>{};
  for (final a in answers) {
    final vals = [for (final v in a.values) if (v.trim().isNotEmpty) v.trim()];
    if (vals.isEmpty && a.details.trim().isEmpty) continue;
    byKind.putIfAbsent(_kindOf(a.label), () => []).add(a);
  }
  List<String> vals(_K k) => [
        for (final a in byKind[k] ?? const <({String label, List<String> values, String details})>[])
          ...[for (final v in a.values) if (v.trim().isNotEmpty && v != 'Other') lcFirst(v)]
      ];
  String det(_K k) => [for (final a in byKind[k] ?? const <({String label, List<String> values, String details})>[]) if (a.details.trim().isNotEmpty) a.details.trim()].join('; ');
  bool plain(_K k) {
    final v = vals(k);
    return v.isNotEmpty && !v.every((x) => x == 'not assessed' || x == 'unable to assess' || x == 'none reported');
  }

  final out = <String>[];
  String withDet(String s, _K k) {
    final d = det(k);
    return d.isEmpty ? s : '$s ($d)';
  }

  if (plain(_K.main)) out.add(_end(withDet('The main problem is ${joinList(vals(_K.main))}', _K.main)));
  if (plain(_K.mechanism)) out.add(_end(withDet('The mechanism or context was ${joinList(vals(_K.mechanism))}', _K.mechanism)));
  final onset = plain(_K.onset), course = plain(_K.course);
  if (onset && course) {
    out.add(_end(withDet('The onset was ${joinList(vals(_K.onset))} and the course has been ${joinList(vals(_K.course))}', _K.onset)));
  } else if (onset) {
    out.add(_end(withDet('The onset was ${joinList(vals(_K.onset))}', _K.onset)));
  } else if (course) {
    out.add(_end(withDet('The course has been ${joinList(vals(_K.course))}', _K.course)));
  }
  // where and how: each answer keeps its own name, in one sentence
  final where = <String>[];
  for (final k in [_K.site, _K.attr]) {
    for (final a in byKind[k] ?? const <({String label, List<String> values, String details})>[]) {
      final v = [for (final x in a.values) if (x != 'Other' && !_notDone.contains(x)) lcFirst(x)];
      if (v.isNotEmpty) where.add('the ${_norm(a.label).replaceAll(RegExp(r'\s*/\s*presentation$'), '')} is ${joinList(v)}${a.details.trim().isEmpty ? '' : ' (${a.details.trim()})'}');
    }
  }
  if (where.isNotEmpty) out.add(_end(ucFirst(joinList(where))));
  final assoc = <String>[];
  if (plain(_K.assoc)) assoc.add('associated symptoms include ${joinList(vals(_K.assoc))}${det(_K.assoc).isEmpty ? '' : ' (${det(_K.assoc)})'}');
  if (plain(_K.systemic)) assoc.add('systemic features include ${joinList(vals(_K.systemic))}${det(_K.systemic).isEmpty ? '' : ' (${det(_K.systemic)})'}');
  if (assoc.isNotEmpty) out.add(_end(ucFirst(assoc.join('; '))));
  for (final k in [_K.assoc, _K.redflag]) {
    final v = vals(k);
    if (v.length == 1 && v.first == 'none reported') out.add(k == _K.assoc ? 'No associated symptoms were reported.' : 'No red flags were reported.');
  }
  final mod = <String>[];
  if (plain(_K.aggr)) mod.add('aggravated by ${joinList(vals(_K.aggr))}');
  if (plain(_K.relieve)) mod.add('relieved by ${joinList(vals(_K.relieve))}');
  if (mod.isNotEmpty) out.add(_end('Symptoms were ${mod.join(' and ')}'));
  if (plain(_K.activity)) out.add(_end('Symptoms occur ${joinList(vals(_K.activity))}'));
  if (plain(_K.trigger)) out.add(_end(withDet('Possible trigger or context: ${joinList(vals(_K.trigger))}', _K.trigger)));
  if (plain(_K.risk)) out.add(_end(withDet('Relevant risk factors: ${joinList(vals(_K.risk))}', _K.risk)));
  if (plain(_K.redflag)) out.add(_end(withDet('Red flags: ${joinList(vals(_K.redflag))}', _K.redflag)));
  if (plain(_K.allergy)) out.add(_end(ucFirst(joinList(vals(_K.allergy)))));
  // everything the rules do not know keeps its own name, in the order it was asked
  for (final a in answers) {
    if (_kindOf(a.label) == _K.other) {
      final s = sentenceFor(a.label, a.values, a.details);
      if (s.isNotEmpty) out.add(s);
    }
  }
  // answers of a known kind that only said "not assessed" / "unable to assess"
  for (final k in byKind.keys) {
    if (k == _K.other || plain(k)) continue;
    for (final a in byKind[k]!) {
      final v = vals(k);
      if (v.length == 1 && v.first == 'none reported') continue;
      final s = sentenceFor(a.label, a.values, a.details);
      if (s.isNotEmpty) out.add(s);
    }
  }
  return out.join(' ');
}

/// "a" or "an" in front of [noun] ("an ECG", "a CBC", "an ultrasound", "a chest X-ray").
String article(String noun) {
  final t = noun.trim();
  if (t.isEmpty) return 'a';
  final first = t.split(RegExp(r'[\s\-/]')).first;
  // numbers by how they are said: "an 8-day", "an 11-hour", "an 18-month", "a 12-hour"
  if (RegExp(r'^\d').hasMatch(first)) {
    final n = first.replaceAll(RegExp(r'\D.*'), '');
    return n.startsWith('8') || n == '11' || n == '18' ? 'an' : 'a';
  }
  final acronym = first.length > 1 && first == first.toUpperCase() && RegExp(r'^[A-Z0-9]+$').hasMatch(first);
  if (acronym) return 'AEFHILMNORSX'.contains(first[0]) ? 'an' : 'a';
  return 'aeiouAEIOU'.contains(t[0]) ? 'an' : 'a';
}

/// A free-text history field as a sentence: short list items ("CVA", "hypertension") join into
/// "Past medical history includes CVA and hypertension."; anything written as sentences stays as written.
String listSentence(String lead, String text, {String sep = ' and '}) {
  final items = [
    for (final raw in text.split(RegExp(r'[\n;]')))
      if (raw.trim().replaceFirst(RegExp(r'^[\-•*]\s*'), '').isNotEmpty) raw.trim().replaceFirst(RegExp(r'^[\-•*]\s*'), '')
  ];
  if (items.isEmpty) return '';
  final short = items.every((e) => e.split(RegExp(r'\s+')).length <= 7 && !RegExp(r'[.!?]\s*$').hasMatch(e));
  if (!short) return items.map(_end).join(' ');
  if (sep == '; ') return '$lead ${items.join('; ')}.';
  return '$lead ${joinList(items)}.';
}
