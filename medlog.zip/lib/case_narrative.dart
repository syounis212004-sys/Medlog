/// Turns the answers of the quick questions into sentences, offline and without AI.
///
/// "Onset: Sudden" + "Site: Foot" + "Local symptoms: Redness, Warmth, Swelling" becomes
/// "The onset was sudden. The site is foot. Local symptoms include redness, warmth and swelling."
/// Labels the rules know get a natural sentence; every other label falls back to "Label: values." so nothing is lost.

/// First letter small unless the word is an acronym or a name ("ECG", "GCS 15", "HIV", "CT", "Kernig sign").
String lcFirst(String v) {
  final t = v.trim();
  if (t.length < 2) return t;
  final first = t.split(RegExp(r'[\s/(]')).first;
  final acronym = first.length > 1 && first == first.toUpperCase() && RegExp(r'[A-Z]').hasMatch(first);
  if (acronym) return t;
  if (t[0] != t[0].toLowerCase() && t[1] == t[1].toLowerCase()) return '${t[0].toLowerCase()}${t.substring(1)}';
  return t;
}

String ucFirst(String v) => v.isEmpty ? v : '${v[0].toUpperCase()}${v.substring(1)}';

/// "a", "a and b", "a, b and c".
String joinList(List<String> v) {
  if (v.isEmpty) return '';
  if (v.length == 1) return v.first;
  return '${v.sublist(0, v.length - 1).join(', ')} and ${v.last}';
}

const Set<String> _notDone = {'Not assessed', 'Unable to assess'};

String _norm(String label) => label.toLowerCase().replaceAll(RegExp(r'\s*\([^)]*\)'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

String _end(String s) {
  final t = s.trim();
  if (t.isEmpty) return t;
  return RegExp(r'[.!?]$').hasMatch(t) ? t : '$t.';
}

/// One sentence for one answered question. [values] are the chosen options, [details] the free text beside them.
String sentenceFor(String label, List<String> values, String details) {
  final n = _norm(label);
  var vals = [for (final v in values) if (v.trim().isNotEmpty) v.trim()];
  final det = details.trim();
  // "Other" alone says nothing: the details (if any) carry it
  if (vals.length > 1 || det.isNotEmpty) vals = [for (final v in vals) if (v != 'Other') v];
  final shownLabel = label.replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();

  String tail(String s) => det.isEmpty ? _end(s) : '${s.replaceFirst(RegExp(r'[.!?]$'), '')} ($det).';

  if (vals.isNotEmpty && vals.every(_notDone.contains)) {
    return '${ucFirst(shownLabel)} ${vals.first == 'Unable to assess' ? 'could not be assessed' : 'was not assessed'}.';
  }
  if (vals.length == 1 && vals.first == 'None reported') {
    return tail('No ${_noun(n)} reported');
  }
  final l = [for (final v in vals) lcFirst(v)];
  final list = joinList(l);
  if (vals.isEmpty) return det.isEmpty ? '' : '${ucFirst(shownLabel)}: $det.';

  // single-valued attributes: "The onset was sudden."
  if (RegExp(r'^onset\b').hasMatch(n)) return tail('The onset was $list');
  if (RegExp(r'^(duration and course|course|clinical course|trajectory)\b').hasMatch(n)) return tail('The course has been $list');
  if (RegExp(r'^(site|pain site|side|laterality|distribution|pain character|character|reported severity|severity|pattern|anatomical region)\b').hasMatch(n)) {
    return tail('The ${n.replaceAll(RegExp(r'\s*/\s*presentation$'), '')} is $list');
  }
  if (n == 'primary system / presentation' || n == 'primary clinical problem' || n == 'problem') return tail('The main problem is $list');
  if (RegExp(r'^mechanism').hasMatch(n)) return tail('The mechanism or context was $list');
  // lists
  if (RegExp(r'^(associated symptoms|symptoms|symptoms / signs|local symptoms|associated acute symptoms)$').hasMatch(n)) return tail('Associated symptoms include $list');
  if (n == 'systemic features') return tail('Systemic features include $list');
  if (RegExp(r'^red flags').hasMatch(n)) return tail('Red flags: $list');
  if (RegExp(r'^(risk factors|host factors and risk|relevant medical risk factors|relevant history)$').hasMatch(n)) return tail('Relevant ${n == 'relevant history' ? 'history' : 'risk factors'}: $list');
  if (n == 'aggravating factors') return tail('Aggravated by $list');
  if (n == 'relieving factors') return tail('Relieved by $list');
  if (n == 'activity impact') return tail('Symptoms occur $list');
  if (RegExp(r'^(trigger|precipitating|possible entry point)').hasMatch(n)) return tail('Possible trigger or context: $list');
  if (n == 'allergy and medicines') return tail(ucFirst(list));
  if (RegExp(r'^observations').hasMatch(n)) return tail('Observations: $list');
  // everything else keeps its own name
  return tail('$shownLabel: $list');
}

String _noun(String n) {
  if (n == 'symptoms' || n == 'symptoms / signs') return 'symptoms';
  if (n.startsWith('red flags')) return 'red flags';
  return n;
}

/// The sentences of several answers as one paragraph.
String paragraphOf(List<({String label, List<String> values, String details})> answers, {String sep = ' '}) =>
    [for (final a in answers) sentenceFor(a.label, a.values, a.details)].where((s) => s.isNotEmpty).join(sep);
