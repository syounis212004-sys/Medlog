import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:archive/archive.dart';

import 'data.dart';
import 'error_log.dart';

/// The question bank: sets of multiple-choice questions the user imports (a zip or json made from a PDF by an AI with
/// the prompt below), kept on the phone, practised in "learn" or "exam" mode, with progress per question.
///
/// File format (version 1), one json object per file; a bank may come in several parts (same "id"):
/// {"format":"sharqmed-questions","version":1,"id":"slug","title":"...","source":"...","language":"en","part":1,
///  "questions":[{"id":"q001","topic":"...","text":"...","options":[{"key":"A","text":"..."}],"answer":["B"],
///  "explanation":"...","has_image":false,"image":"images/q001.png","needs_review":false}]}

const String kQbFormat = 'sharqmed-questions';

class QbOption {
  final String key, text;
  const QbOption(this.key, this.text);
  Map<String, dynamic> toJson() => {'key': key, 'text': text};
}

class QbQuestion {
  final String id, topic, text, explanation;
  final List<QbOption> options;
  final List<String> answer;
  final bool hasImage, needsReview;

  /// File name of the picture kept with the bank ('' when there is none).
  final String image;
  const QbQuestion(this.id, this.topic, this.text, this.options, this.answer, this.explanation, {this.hasImage = false, this.needsReview = false, this.image = ''});

  bool get multi => answer.length > 1;

  /// A question can be scored only when its answer key is known.
  bool get scorable => answer.isNotEmpty;

  /// Right when exactly the keys of the answer were chosen.
  bool isCorrect(Set<String> chosen) => scorable && chosen.length == answer.length && answer.every(chosen.contains);

  Map<String, dynamic> toJson() => {
        'id': id,
        'topic': topic,
        'text': text,
        'options': [for (final o in options) o.toJson()],
        'answer': answer,
        'explanation': explanation,
        'has_image': hasImage,
        'image': image,
        'needs_review': needsReview,
      };
}

class QbBank {
  final String id, title, source, language, imported;
  final List<QbQuestion> questions;
  const QbBank(this.id, this.title, this.source, this.language, this.imported, this.questions);

  List<String> get topics {
    final out = <String>[];
    for (final q in questions) {
      final t = q.topic.trim();
      if (t.isNotEmpty && !out.contains(t)) out.add(t);
    }
    return out;
  }

  int get usable => questions.where((q) => q.scorable).length;
  int get needReview => questions.where((q) => q.needsReview || !q.scorable).length;

  Map<String, dynamic> toJson() => {
        'format': kQbFormat,
        'version': 1,
        'id': id,
        'title': title,
        'source': source,
        'language': language,
        'imported': imported,
        'questions': [for (final q in questions) q.toJson()],
      };
}

class QbImportReport {
  final List<String> banks = []; // ids written
  int questions = 0;
  int skipped = 0;
  int images = 0;
  final List<String> problems = [];
}

class QbFormatException implements Exception {
  final String message;
  QbFormatException(this.message);
  @override
  String toString() => message;
}

/// One parsed file: a bank id with its (valid) questions, and what was left out.
class _Part {
  String id = '', title = '', source = '', language = 'en';
  final List<QbQuestion> questions = [];
  int skipped = 0;
  final List<String> problems = [];
}

String _s(Object? v) => '${v ?? ''}'.trim();

String _slug(String s) {
  final t = s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9؀-ۿ]+'), '-').replaceAll(RegExp(r'^-+|-+$'), '');
  return t.isEmpty ? 'bank' : (t.length > 48 ? t.substring(0, 48) : t);
}

/// Reads one json document. Throws [QbFormatException] when it is not a question file at all; a question that is not
/// usable is skipped and named in the problems.
Map<String, Object> _readPart(String text, String fileName) {
  Object? j;
  try {
    j = jsonDecode(text);
  } catch (_) {
    throw QbFormatException('$fileName: this is not valid JSON.');
  }
  if (j is! Map || j['format'] != kQbFormat) throw QbFormatException('$fileName: this is not a SharqMed question file.');
  final v = j['version'];
  if (v is! num || v.toInt() != 1) throw QbFormatException('$fileName: unsupported version.');
  final qs = j['questions'];
  if (qs is! List) throw QbFormatException('$fileName: no questions.');
  final p = _Part()
    ..id = _slug(_s(j['id']).isEmpty ? _s(j['title']) : _s(j['id']))
    ..title = _s(j['title']).isEmpty ? _s(j['id']) : _s(j['title'])
    ..source = _s(j['source'])
    ..language = _s(j['language']).isEmpty ? 'en' : _s(j['language']);
  final seen = <String>{};
  for (var i = 0; i < qs.length; i++) {
    final raw = qs[i];
    final label = raw is Map && _s(raw['id']).isNotEmpty ? _s(raw['id']) : '#${i + 1}';
    if (raw is! Map) {
      p.skipped++;
      p.problems.add('$fileName $label: not a question.');
      continue;
    }
    final stem = _s(raw['text']);
    final opts = <QbOption>[];
    final keys = <String>{};
    var dup = false;
    final ro = raw['options'];
    if (ro is List) {
      for (final o in ro) {
        if (o is! Map) continue;
        final k = _s(o['key']).toUpperCase();
        final t = _s(o['text']);
        if (k.isEmpty || t.isEmpty) continue;
        if (!keys.add(k)) dup = true;
        opts.add(QbOption(k, t));
      }
    }
    final ans = <String>[
      if (raw['answer'] is List) for (final a in raw['answer'] as List) _s(a).toUpperCase() else if (_s(raw['answer']).isNotEmpty) _s(raw['answer']).toUpperCase()
    ].where((e) => e.isNotEmpty).toSet().toList();
    final review = raw['needs_review'] == true;
    String? why;
    if (stem.isEmpty) {
      why = 'no question text';
    } else if (opts.length < 2) {
      why = 'fewer than two options';
    } else if (dup) {
      why = 'two options with the same letter';
    } else if (ans.any((a) => !keys.contains(a))) {
      why = 'the answer is not one of the options';
    }
    final id = _s(raw['id']).isEmpty ? 'q${(i + 1).toString().padLeft(3, '0')}' : _s(raw['id']);
    if (why == null && !seen.add(id)) why = 'the id $id appears twice in this file';
    if (why != null) {
      p.skipped++;
      p.problems.add('$fileName $label: $why.');
      continue;
    }
    p.questions.add(QbQuestion(id, _s(raw['topic']), stem, opts, ans, _s(raw['explanation']),
        hasImage: raw['has_image'] == true || _s(raw['image']).isNotEmpty, needsReview: review || ans.isEmpty, image: _s(raw['image'])));
  }
  return {'part': p};
}

class QuestionBank {
  QuestionBank._();

  static List<QbBank> banks = [];

  static Directory get dir => Directory('${store.root.path}/qbank');

  static String imagePath(String bankId, String image) => '${dir.path}/${bankId}_img/${image.split('/').last}';

  /// True once [load] has read the folder; the screen then opens at once instead of reading it again.
  static bool loaded = false;

  static Future<void> load() async {
    final out = <QbBank>[];
    try {
      if (await dir.exists()) {
        await for (final e in dir.list()) {
          if (e is! File || !e.path.endsWith('.json')) continue;
          try {
            final m = jsonDecode(await e.readAsString()) as Map<String, dynamic>;
            final p = _readPart(jsonEncode(m), e.path.split('/').last)['part'] as _Part;
            out.add(QbBank('${m['id']}', '${m['title']}', '${m['source'] ?? ''}', '${m['language'] ?? 'en'}', '${m['imported'] ?? ''}', p.questions));
          } catch (err, st) {
            ErrorLog.record('$err', st, where: 'qbank');
          }
        }
      }
    } catch (err, st) {
      ErrorLog.record('$err', st, where: 'qbank');
    }
    out.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    banks = out;
    loaded = true;
  }

  static QbBank? bank(String id) {
    for (final b in banks) {
      if (b.id == id) return b;
    }
    return null;
  }

  /// Imports zip and json files. Every file is read before anything is written: a bad file stops the import and leaves
  /// the bank as it was. Parts with the same bank id are merged; two parts that disagree about a question are refused.
  static Future<QbImportReport> importFiles(List<String> paths) async {
    final rep = QbImportReport();
    final parts = <_Part>[];
    final images = <String, List<int>>{}; // base name -> bytes
    for (final path in paths) {
      final name = path.split(Platform.pathSeparator).last;
      final lower = name.toLowerCase();
      if (lower.endsWith('.zip')) {
        final zip = ZipDecoder().decodeBytes(await File(path).readAsBytes());
        for (final entry in zip.files) {
          if (!entry.isFile || entry.name.contains('..') || entry.name.startsWith('/')) continue;
          final base = entry.name.split('/').last;
          if (base.startsWith('.') || entry.name.contains('__MACOSX')) continue;
          final lb = base.toLowerCase();
          if (lb.endsWith('.json')) {
            parts.add((_readPart(utf8.decode(entry.content as List<int>), '$name/$base'))['part'] as _Part);
          } else if (lb.endsWith('.png') || lb.endsWith('.jpg') || lb.endsWith('.jpeg') || lb.endsWith('.webp')) {
            images[base] = List<int>.from(entry.content as List<int>);
          }
        }
      } else if (lower.endsWith('.json')) {
        parts.add((_readPart(await File(path).readAsString(), name))['part'] as _Part);
      }
    }
    if (parts.isEmpty) throw QbFormatException('No question file found. Choose a .zip or .json file made with the question format.');

    // merge the parts of each bank
    final merged = <String, _Part>{};
    for (final p in parts) {
      final m = merged.putIfAbsent(p.id, () => _Part()
        ..id = p.id
        ..title = p.title
        ..source = p.source
        ..language = p.language);
      m.skipped += p.skipped;
      m.problems.addAll(p.problems);
      for (final q in p.questions) {
        final i = m.questions.indexWhere((e) => e.id == q.id);
        if (i < 0) {
          m.questions.add(q);
        } else if (m.questions[i].text != q.text) {
          throw QbFormatException('Two parts of "${p.title}" disagree about question ${q.id}. Fix the files and import again.');
        }
      }
    }
    await dir.create(recursive: true);
    for (final m in merged.values) {
      if (m.questions.isEmpty) {
        rep.problems.addAll(m.problems);
        rep.skipped += m.skipped;
        continue;
      }
      final withImages = <QbQuestion>[];
      for (final q in m.questions) {
        var img = '';
        if (q.image.isNotEmpty) {
          final base = q.image.split('/').last;
          final bytes = images[base];
          if (bytes != null) {
            final d = Directory('${dir.path}/${m.id}_img');
            await d.create(recursive: true);
            await File('${d.path}/$base').writeAsBytes(bytes, flush: true);
            img = base;
            rep.images++;
          }
        }
        withImages.add(QbQuestion(q.id, q.topic, q.text, q.options, q.answer, q.explanation, hasImage: q.hasImage, needsReview: q.needsReview, image: img));
      }
      final bank = QbBank(m.id, m.title, m.source, m.language, nowIso(), withImages);
      final f = File('${dir.path}/${m.id}.json');
      final tmp = File('${f.path}.tmp');
      await tmp.writeAsString(jsonEncode(bank.toJson()), flush: true);
      await tmp.rename(f.path);
      rep.banks.add(m.id);
      rep.questions += withImages.length;
      rep.skipped += m.skipped;
      rep.problems.addAll(m.problems);
    }
    await load();
    return rep;
  }

  static Future<void> delete(String id) async {
    final f = File('${dir.path}/$id.json');
    if (await f.exists()) await f.delete();
    final d = Directory('${dir.path}/${id}_img');
    if (await d.exists()) await d.delete(recursive: true);
    for (final p in store.listOf('qbprog').where((e) => '${e['id']}'.startsWith('$id|')).toList()) {
      store.listOf('qbprog').remove(p);
    }
    await store.saveExtra('qbprog');
    await load();
  }
}

// ------------------------------------------------------------------------------------------------------ progress

/// What is kept for each question: how often it was answered, right and wrong, the flag and a note.
class QbProgress {
  QbProgress._();

  static String key(String bankId, String qid) => '$bankId|$qid';

  static Map<String, J>? _map;
  static int _rev = -1;

  static Map<String, J> get _all {
    if (_map == null || _rev != store.rev) {
      _map = {for (final e in store.listOf('qbprog')) '${e['id']}': e};
      _rev = store.rev;
    }
    return _map!;
  }

  static J? of(String bankId, String qid) => _all[key(bankId, qid)];

  static bool flagged(String bankId, String qid) => of(bankId, qid)?['flag'] == true;
  static String note(String bankId, String qid) => '${of(bankId, qid)?['note'] ?? ''}';
  static int seen(String bankId, String qid) => (of(bankId, qid)?['seen'] as num?)?.toInt() ?? 0;
  static bool lastWrong(String bankId, String qid) => of(bankId, qid)?['last'] == 'wrong';

  static Future<void> _save(J e) async {
    _map = null;
    await store.upsertExtra('qbprog', e);
  }

  static J _entry(String bankId, String qid) => of(bankId, qid) ?? <String, dynamic>{'id': key(bankId, qid), 'seen': 0, 'right': 0, 'wrong': 0};

  static Future<void> record(String bankId, String qid, bool right) async {
    final e = _entry(bankId, qid);
    e['seen'] = ((e['seen'] as num?)?.toInt() ?? 0) + 1;
    e[right ? 'right' : 'wrong'] = ((e[right ? 'right' : 'wrong'] as num?)?.toInt() ?? 0) + 1;
    e['last'] = right ? 'right' : 'wrong';
    e['date'] = todayStr();
    await _save(e);
  }

  static Future<void> setFlag(String bankId, String qid, bool v) async {
    final e = _entry(bankId, qid);
    e['flag'] = v;
    await _save(e);
  }

  static Future<void> setNote(String bankId, String qid, String text) async {
    final e = _entry(bankId, qid);
    e['note'] = text.trim();
    await _save(e);
  }

  /// Share of the usable questions of [b] answered at least once, and share of those whose last answer was right.
  static ({int answered, int right, int total}) summary(QbBank b) {
    var a = 0, r = 0, t = 0;
    for (final q in b.questions) {
      if (!q.scorable) continue;
      t++;
      final e = of(b.id, q.id);
      if (e != null && ((e['seen'] as num?) ?? 0) > 0) {
        a++;
        if (e['last'] == 'right') r++;
      }
    }
    return (answered: a, right: r, total: t);
  }
}

// ------------------------------------------------------------------------------------------------------ sessions

enum QbMode { learn, exam }

class QbSetup {
  final QbMode mode;
  final Set<String> topics; // empty = all
  final String which; // all | new | wrong | flagged
  final int count; // 0 = all that match
  final int secondsPerQuestion; // exam only; 0 = no timer
  const QbSetup({this.mode = QbMode.learn, this.topics = const {}, this.which = 'all', this.count = 20, this.secondsPerQuestion = 0});
}

/// The questions of a session: scorable ones that match the filters, in a shuffled order.
List<QbQuestion> pickQuestions(QbBank b, QbSetup s, {Random? rnd}) {
  bool ok(QbQuestion q) {
    if (!q.scorable) return false;
    if (s.topics.isNotEmpty && !s.topics.contains(q.topic.trim())) return false;
    switch (s.which) {
      case 'new':
        return QbProgress.seen(b.id, q.id) == 0;
      case 'wrong':
        return QbProgress.lastWrong(b.id, q.id);
      case 'flagged':
        return QbProgress.flagged(b.id, q.id);
      default:
        return true;
    }
  }

  final l = [for (final q in b.questions) if (ok(q)) q]..shuffle(rnd ?? Random());
  return s.count > 0 && l.length > s.count ? l.sublist(0, s.count) : l;
}

/// How many questions each filter would give, for the setup sheet.
int countMatching(QbBank b, QbSetup s) => pickQuestions(b, QbSetup(topics: s.topics, which: s.which, count: 0)).length;

class QbAnswerRow {
  final String qid, topic;
  final Set<String> chosen;
  final bool correct, flagged;
  const QbAnswerRow(this.qid, this.topic, this.chosen, this.correct, this.flagged);
}

class QbResult {
  final QbBank bank;
  final QbMode mode;
  final List<QbQuestion> questions;
  final List<QbAnswerRow> rows;
  final int seconds;
  final int limitSeconds;
  const QbResult(this.bank, this.mode, this.questions, this.rows, this.seconds, this.limitSeconds);

  int get total => rows.length;
  int get right => rows.where((r) => r.correct).length;
  int get omitted => rows.where((r) => r.chosen.isEmpty).length;
  int get wrong => total - right - omitted;
  double get percent => total == 0 ? 0 : right * 100 / total;
  bool get timedOut => limitSeconds > 0 && seconds >= limitSeconds;

  /// topic -> [answered, right]
  Map<String, List<int>> get byTopic {
    final m = <String, List<int>>{};
    for (final r in rows) {
      final t = r.topic.isEmpty ? '-' : r.topic;
      final e = m.putIfAbsent(t, () => [0, 0]);
      e[0]++;
      if (r.correct) e[1]++;
    }
    return m;
  }
}

/// Writes the outcome of a finished session: the progress of every question that was answered and one line of history.
Future<void> saveQbSession(QbResult r, {bool progress = true}) async {
  for (final row in r.rows) {
    if (!progress || row.chosen.isEmpty) continue;
    await QbProgress.record(r.bank.id, row.qid, row.correct);
  }
  await store.upsertExtra('qbsessions', {
    'id': newId('qs'),
    'bank': r.bank.id,
    'date': nowIso(),
    'mode': r.mode.name,
    'total': r.total,
    'right': r.right,
    'omitted': r.omitted,
    'secs': r.seconds,
    'limit': r.limitSeconds,
  });
}

/// The prompt to give an AI together with the PDF of the questions.
const String kQbankAiPrompt = r'''You are converting a PDF of multiple-choice questions into JSON for an offline medical study app. Output ONLY valid JSON, no explanations before or after, no markdown outside one code block.

SCHEMA (version 1):
{
  "format": "sharqmed-questions",
  "version": 1,
  "id": "short-lowercase-slug-of-the-file",
  "title": "Human title of the question set",
  "source": "Book / exam / year as printed in the PDF (empty string if unknown)",
  "language": "en",
  "part": 1,
  "questions": [
    {
      "id": "q001",
      "topic": "Section or chapter heading this question sits under (empty string if none)",
      "text": "The full question stem, exactly as printed",
      "options": [{"key": "A", "text": "..."}, {"key": "B", "text": "..."}],
      "answer": ["B"],
      "explanation": "The printed explanation or rationale (empty string if none)",
      "has_image": false,
      "needs_review": false
    }
  ]
}

RULES
1. Copy the wording exactly. Do not rewrite, shorten, translate, or improve questions, options or explanations. Fix only obvious PDF damage: broken hyphenation at line ends, page headers/footers, page numbers, stray line breaks inside a sentence.
2. Never invent anything. If the PDF gives no answer key for a question, set "answer": [] and "needs_review": true. If it gives no explanation, use "". Do not guess answers from your own medical knowledge.
3. "answer" is always an array of option keys, e.g. ["C"]. Use several keys only when the PDF says several answers are correct. Keys are the letters printed in the PDF (A, B, C...). If options are numbered, convert 1,2,3 to A,B,C.
4. Keep every option in its printed order, including "All of the above", "None of the above", "Both A and B".
5. If a question refers to a picture, table, ECG or graph, keep the text, put "[image: short description of what the PDF shows]" at the end of the stem, and set "has_image": true.
6. Questions that share one case vignette ("Questions 4-6 refer to..."): repeat the vignette at the start of each question's "text".
7. If the answer key or the explanations are in a separate section at the end of the PDF, match them to the questions by number. If a number does not match, set "needs_review": true for that question.
8. "id": q001, q002... in the order of the PDF (continue the numbering across parts). "topic": the nearest heading above the question.
9. Keep Arabic or mixed-language text exactly as written.
10. Escape double quotes inside strings as \" and write real JSON: no comments, no trailing commas, no line breaks inside a string value (use \n if needed).

LENGTH
Put at most 40 questions in one reply. End the reply with the code block and then the single line: LAST: qNNN (the id of the last question you wrote). I will answer "continue" and you will write the next part with "part": 2, 3, ... using the same "id", "title", "source" and continuing the numbering. Do not repeat questions from earlier parts.

BEFORE YOU ANSWER, CHECK
- The JSON parses.
- Every question has text, at least 2 options, and an "answer" (or needs_review is true).
- The number of questions you wrote matches the numbers printed in that part of the PDF. If the PDF is scanned and some text is unreadable, mark those questions "needs_review": true instead of guessing.

Start with part 1 of the attached PDF.''';
