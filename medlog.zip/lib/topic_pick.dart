import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'i18n.dart';
import 'library.dart' show stripSource;
import 'plan_scope.dart';
import 'ref_data.dart';
import 'rotation_plan.dart';

/// Where a study topic comes from, in this order: this week of the rotation plan, then the core topics of the
/// rotation's specialty, then whatever the person types. Nothing is picked from "weak spots" or at random.
class TopicSource {
  static Future<List<String>> rotationTopics() async {
    final rot = store.currentRotation();
    if (rot == null) return const [];
    try {
      final cur = await RefData.curriculum();
      final specs = cur['specialties'];
      final data = specs is Map ? specs['${rot['name']}'] : null;
      if (data is! Map) return const [];
      return [for (final t in (data['coreTopics'] as List? ?? const [])) '${(t as Map)['topic']}'];
    } catch (_) {
      return const [];
    }
  }

  static Future<List<String>> thisWeek() async {
    final rot = store.currentRotation();
    if (rot == null) return const [];
    try {
      final cur = await RefData.curriculum();
      final specs = cur['specialties'];
      final data = specs is Map ? specs['${rot['name']}'] : null;
      if (data is! Map) return const [];
      final topics = [for (final t in (data['coreTopics'] as List? ?? const [])) Map<String, dynamic>.from(t as Map)];
      final start = DateTime.tryParse('${rot['start']}') ?? DateTime.now();
      final end = DateTime.tryParse('${rot['end'] ?? ''}');
      final weeks = RotationPlan.weeksOf(start, end);
      final week = RotationPlan.currentWeek(start, weeks, DateTime.now());
      final plan = RotationPlan.build(topics, weeks, moved: RotationPlanStore.moved('${rot['id']}'));
      return [for (final t in plan) if (t.week == week) t.topic];
    } catch (_) {
      return const [];
    }
  }

  /// The chapters of the books in the person's plans that are due now (titles), when the plan is on.
  static Future<List<String>> planTopics() async {
    try {
      final sc = await activePlanScope();
      if (sc == null) return const [];
      final arts = await planArticles(sc, dueOnly: true);
      final seen = <String>{};
      return [for (final a in arts) if (seen.add(stripSource(a.title))) stripSource(a.title)].take(12).toList();
    } catch (_) {
      return const [];
    }
  }

  /// One topic for today without asking: the plan's week first, then the rotation's list; null when there is none.
  static Future<String?> defaultTopic({String? not}) async {
    final pt = [for (final t in await planTopics()) if (t != not) t];
    if (pt.isNotEmpty) return pt[DateTime.now().day % pt.length];
    final w = [for (final t in await thisWeek()) if (t != not) t];
    if (w.isNotEmpty) return w[DateTime.now().day % w.length];
    final r = [for (final t in await rotationTopics()) if (t != not) t];
    if (r.isNotEmpty) return r[DateTime.now().day % r.length];
    return null;
  }
}

String _plain(String t) => t.split(':').first.split('(').first.trim();

/// Asks for a topic: this week's, the rotation's, or typed. Returns null when cancelled.
Future<String?> askTopic(BuildContext context) async {
  final fromPlan = await TopicSource.planTopics();
  final week = await TopicSource.thisWeek();
  final all = await TopicSource.rotationTopics();
  if (!context.mounted) return null;
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) {
      final c = TextEditingController();
      return SafeArea(
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.7,
            child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
              TextField(
                key: const ValueKey('topic_free'),
                controller: c,
                decoration: InputDecoration(labelText: tr('Any topic'), suffixIcon: IconButton(tooltip: tr('Next'), icon: const Icon(AppIcons.arrowForward), onPressed: () => c.text.trim().isEmpty ? null : Navigator.pop(ctx, c.text.trim()))),
                onSubmitted: (v) => v.trim().isEmpty ? null : Navigator.pop(ctx, v.trim()),
              ),
              if (fromPlan.isNotEmpty) ...[
                Padding(padding: const EdgeInsets.only(top: 14, bottom: 4), child: m.Text(tr('From my books plan'), style: Theme.of(ctx).textTheme.titleSmall)),
                for (final t in fromPlan) ListTile(key: ValueKey('plan_topic_$t'), dense: true, contentPadding: EdgeInsets.zero, title: m.Text(t, textDirection: TextDirection.ltr), onTap: () => Navigator.pop(ctx, t)),
              ],
              if (week.isNotEmpty) ...[
                Padding(padding: const EdgeInsets.only(top: 14, bottom: 4), child: m.Text(tr('This week in my plan'), style: Theme.of(ctx).textTheme.titleSmall)),
                for (final t in week) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: m.Text(t, textDirection: TextDirection.ltr), onTap: () => Navigator.pop(ctx, _plain(t))),
              ],
              if (all.isNotEmpty) ...[
                Padding(padding: const EdgeInsets.only(top: 14, bottom: 4), child: m.Text(tr('This rotation'), style: Theme.of(ctx).textTheme.titleSmall)),
                for (final t in all) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: m.Text(t, textDirection: TextDirection.ltr), onTap: () => Navigator.pop(ctx, _plain(t))),
              ],
            ]),
          ),
        ),
      );
    },
  );
}
