import 'package:flutter/material.dart';

import 'data.dart';
import 'screens_cases.dart';
import 'screens_portfolio.dart';
import 'ui.dart';
import 'widgets.dart';

const List<FieldSpec> kShiftSpecs = [
  FieldSpec('type', 'Shift type',
      type: FT.choice, options: ['Morning', 'Evening', 'Night', 'On-call']),
  FieldSpec('note', 'Note about the day', type: FT.multi),
];

Future<void> editShift(BuildContext context, String date, {String rotationId = ''}) async {
  final cur = store.shiftFor(date);
  final res = await showFormSheet(
    context,
    title: 'Duty day • ${prettyDate(date)}',
    specs: kShiftSpecs,
    initial: cur ??
        <String, dynamic>{
          'date': date,
          'type': 'Morning',
          'rotationId': rotationId,
        },
    canDelete: cur != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.shifts, 'shifts.json', date, key: 'date');
  } else {
    await store.upsert(store.shifts, 'shifts.json', res, key: 'date');
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final rot = store.currentRotation();
        final today = todayStr();
        final all = store.casesSorted();
        final todays = all.where((c) => c.s('date') == today).toList();
        final drafts = all.where((c) => c.s('status') == 'Draft').take(5).toList();
        final recent = all.take(5).toList();
        final shift = store.shiftFor(today);

        return Scaffold(
          appBar: AppBar(title: const Text('MedLog')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => openNewCase(context),
            icon: const Icon(Icons.add),
            label: const Text('New case'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              // ---- backup reminder
              if (store.cases.isNotEmpty &&
                  (store.daysSinceBackup == null || store.daysSinceBackup! > 7))
                AppCard(
                  color: Theme.of(context).colorScheme.tertiaryContainer,
                  child: ListTile(
                    leading: const Icon(Icons.backup_outlined),
                    title: Text(store.daysSinceBackup == null
                        ? 'You have never made a backup'
                        : 'Last backup was ${store.daysSinceBackup} days ago'),
                    subtitle: const Text('Tap to back up now'),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    ),
                  ),
                ),

              // ---- current rotation
              AppCard(
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    if (rot == null) {
                      editRotation(context);
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RotationScreen(rotationId: rot['id'].toString()),
                        ),
                      );
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: rot == null
                        ? Row(
                            children: [
                              const Icon(Icons.add_circle_outline),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  'Add your first rotation (e.g. Internal Medicine, Oct 1 – Oct 31)',
                                  style: theme.textTheme.bodyLarge,
                                ),
                              ),
                            ],
                          )
                        : _RotationSummary(rot: rot),
                  ),
                ),
              ),
              const SizedBox(height: 8),

              // ---- today
              AppCard(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(prettyDate(today), style: theme.textTheme.titleMedium),
                      const SizedBox(height: 4),
                      Text('${todays.length} case${todays.length == 1 ? '' : 's'} today'),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          if (shift != null)
                            Chip(
                              avatar: const Icon(Icons.check, size: 18),
                              label: Text('Duty day • ${shift['type'] ?? ''}'),
                            ),
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: () => editShift(
                              context,
                              today,
                              rotationId: rot == null ? '' : rot['id'].toString(),
                            ),
                            child: Text(shift == null ? 'Mark today as duty day' : 'Edit'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              if (todays.isNotEmpty) ...[
                const SectionHeader('Today'),
                for (final c in todays) CaseTile(c),
              ],
              if (drafts.isNotEmpty) ...[
                const SectionHeader('Unfinished drafts'),
                for (final c in drafts) CaseTile(c),
              ],
              if (recent.isNotEmpty) ...[
                const SectionHeader('Recent cases'),
                for (final c in recent) CaseTile(c),
              ],
              if (all.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Text(
                      'No cases yet. Tap “New case” and write just the complaint and HPI — '
                      'you can finish the rest after the shift.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _RotationSummary extends StatelessWidget {
  final J rot;
  const _RotationSummary({required this.rot});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final id = rot['id'].toString();
    final cases = store.casesOfRotation(id).length;
    final days = store.shifts.where((s) => s['rotationId'] == id).length;
    final procs = store.procedures.where((p) => p['rotationId'] == id).length;
    final start = (rot['start'] ?? '').toString();
    final end = (rot['end'] ?? '').toString();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Current rotation', style: theme.textTheme.labelMedium),
        Text(store.rotationLabel(rot), style: theme.textTheme.titleLarge),
        if (start.isNotEmpty)
          Text('${prettyDate(start)}${end.isEmpty ? '' : '  →  ${prettyDate(end)}'}'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 16,
          children: [
            Text('$cases cases'),
            Text('$days duty days'),
            Text('$procs procedures'),
          ],
        ),
      ],
    );
  }
}
