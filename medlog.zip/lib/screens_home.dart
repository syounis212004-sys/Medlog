import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'quick_add.dart';
import 'screens_cases.dart';
import 'ai/ai_context.dart';
import 'screens_learn.dart';
import 'screens_portfolio.dart';
import 'focus.dart';
import 'review.dart';
import 'screens_review.dart';
import 'screens_search.dart';
import 'app_icons.dart';
import 'home_hero.dart';
import 'rotation_bar.dart';
import 'day_planner.dart';
import 'book_plan.dart';
import 'screens_ai_study.dart' show AiHubScreen;
import 'screens_quiz.dart' show QuizScreen;
import 'ui.dart';
import 'widgets.dart';
import 'ph.dart';
import 'case_ui.dart';

const List<FieldSpec> kShiftSpecs = [
  FieldSpec('type', 'Shift type',
      type: FT.choice, options: ['Morning', 'Evening', 'Night', 'On-call']),
  FieldSpec('note', 'Note about the day', type: FT.multi),
];

Future<void> editShift(BuildContext context, String date,
    {String rotationId = ''}) async {
  final cur = store.shiftFor(date);
  final res = await showFormSheet(
    context,
    title: '${tr('Duty day')} • ${prettyDate(date)}',
    specs: kShiftSpecs,
    initial: cur ??
        <String, dynamic>{
          'date': date,
          'type': 'Morning',
          'rotationId': rotationId,
        },
    canDelete: cur != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.shifts, 'shifts.json', date, key: 'date');
  } else {
    await store.upsert(store.shifts, 'shifts.json', res, key: 'date');
  }
}


class HomeScreen extends StatelessWidget {
  /// Lets shortcuts jump to another tab of the shell.
  final ValueChanged<int>? onOpenTab;
  const HomeScreen({super.key, this.onOpenTab});

  void _push(BuildContext context, Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  Widget _big(BuildContext context, IconData icon, String title, String sub, VoidCallback onTap, {Key? key}) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return PressScale(child: Material(
      key: key,
      color: cs.surfaceContainerLow,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            CircleAvatar(radius: 22, backgroundColor: cs.primaryContainer, child: Icon(icon, color: cs.onPrimaryContainer)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                m.Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                if (sub.isNotEmpty) m.Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
              ]),
            ),
          ]),
        ),
      ),
    ));
  }

  Widget _studyPanel(BuildContext context, int due) {
    return Column(children: [
      FutureBuilder<(int, int)>(
        future: dayProgress(),
        builder: (context, snap) {
          final p = snap.data;
          final sub = p == null ? '' : (p.$2 == 0 ? tr('Nothing planned today') : trp('{a} of {b} done', {'a': p.$1, 'b': p.$2}));
          return _big(context, AppIcons.plan, tr('Today'), sub, () => _push(context, const DayPlannerScreen()), key: const Key('home_today'));
        },
      ),
      const SizedBox(height: 10),
      IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(child: _big(context, AppIcons.flashcards, tr('Review'), due > 0 ? trp('{n} cards to review', {'n': due}) : tr('Nothing due today'), () => _push(context, const ReviewSessionScreen()), key: const Key('home_review'))),
        const SizedBox(width: 10),
        Expanded(child: _big(context, AppIcons.quiz, tr('Practise'), tr('Test myself'), () => _push(context, const QuizScreen()), key: const Key('home_practise'))),
      ])),
      const SizedBox(height: 10),
      IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(child: _big(context, AppIcons.plan, tr('My plan'), tr('From my books, by date'), () => _push(context, const BookPlanScreen()), key: const Key('home_plan'))),
        const SizedBox(width: 10),
        Expanded(child: _big(context, AppIcons.ai, tr('Ask AI'), tr('Teach me, viva, question bank'), () => _push(context, const AiHubScreen()), key: const Key('home_askai'))),
      ])),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final cs = theme.colorScheme;
        final all = store.casesSorted();
        final drafts = all.where((c) => c.s('status') == 'Draft').take(3).toList();
        final recent = all.take(3).toList();
        var n = 0;

        Widget stagger(Widget w) => FadeSlideIn(index: n++, child: w);
        openProceduresTabHook = () => openProceduresScreen(context);
        final focus = buildFocus();
        final due = ReviewEngine.dueCount();
        final studying = store.mode == 'study';

        // "continue where you left off": the case I edited most recently (last 3 days)
        Widget? resume;
        final lastId = (store.settings['lastCase'] ?? '').toString();
        final lastAt = DateTime.tryParse((store.settings['lastCaseAt'] ?? '').toString());
        final lastRec = store.cases[lastId];
        if (lastRec != null && lastRec.s('status') != 'Completed' && lastAt != null && DateTime.now().difference(lastAt.toLocal()).inDays < 3) {
          final tab = (store.settings['lastTab'] is int) ? store.settings['lastTab'] as int : 0;
          resume = InkWell(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CaseEditorScreen(rec: lastRec, initialTab: tab))),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 48),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Row(children: [
                  Icon(Ph.playCircle, size: 20, color: cs.primary),
                  const SizedBox(width: 12),
                  Expanded(child: m.Text('${lastRec.s('code')} • ${lastRec.title}', maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600))),
                  const SizedBox(width: 8),
                  Text('Continue', style: theme.textTheme.bodySmall),
                  const Icon(AppIcons.chevronRight, size: 20),
                ]),
              ),
            ),
          );
        }

        return AiContextScope(
          ctx: const AiScreenContext(kind: 'home', title: 'Home'),
          child: CustomScrollView(
            slivers: [
              SliverAppBar(
                pinned: true,
                automaticallyImplyLeading: false,
                toolbarHeight: 60,
                titleSpacing: 16,
                title: Row(children: [
                  const MedLogMark(size: 32),
                  const SizedBox(width: 10),
                  Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: m.Text('SharqMed', maxLines: 1, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)))),
                ]),
                actions: [
                  IconButton(tooltip: tr('Search'), onPressed: () => _push(context, const SearchScreen()), icon: const Icon(AppIcons.search)),
                  IconButton(tooltip: tr('Settings'), onPressed: () => _push(context, const SettingsScreen()), icon: const Icon(AppIcons.settings)),
                  const SizedBox(width: 4),
                ],
              ),
              SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 720),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        stagger(HomeHero(now: DateTime.now())),
                        const SizedBox(height: 10),
                        stagger(const RotationBar()),
                        const SizedBox(height: 10),
                        stagger(SizedBox(
                          width: double.infinity,
                          child: SegmentedButton<String>(
                            key: const ValueKey('home_mode'),
                            showSelectedIcon: false,
                            segments: [
                              ButtonSegment(value: 'shift', icon: Icon(AppIcons.cases, size: 18), label: m.Text(tr('Shift'))),
                              ButtonSegment(value: 'study', icon: Icon(AppIcons.learn, size: 18), label: m.Text(tr('Study'))),
                            ],
                            selected: {studying ? 'study' : 'shift'},
                            onSelectionChanged: (v) {
                              store.settings['mode'] = v.first;
                              store.saveSettings();
                              store.refresh();
                            },
                          ),
                        )),
                        const SizedBox(height: 10),
                        if (studying) ...[
                          stagger(_studyPanel(context, due)),
                          const SizedBox(height: 8),
                        ],
                        // ---- what needs me now: at most three things, nothing when there is nothing
                        if (!studying && (focus.isNotEmpty || resume != null))
                          stagger(AppCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(12, 6, 4, 0),
                                child: Row(children: [
                                  Icon(AppIcons.flag, size: 18, color: cs.primary),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text('Today’s focus', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
                                  if (focus.length > 3)
                                    TextButton(
                                      style: TextButton.styleFrom(minimumSize: const Size(0, 44)),
                                      onPressed: () => _push(context, const FocusScreen()),
                                      child: Text(trp('All {n}', {'n': focus.length})),
                                    )
                                  else
                                    const SizedBox(height: 40),
                                ]),
                              ),
                              if (resume != null) resume,
                              for (final f in focus.take(3)) FocusRow(f),
                            ]),
                          )),
                        const SizedBox(height: 4),
                        // ---- four big doors
                        stagger(Column(children: [
                          IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Expanded(child: _big(context, AppIcons.cases, tr('Cases'), trp('{n} cases', {'n': all.length}), () => onOpenTab?.call(1), key: const Key('home_cases'))),
                            const SizedBox(width: 10),
                            Expanded(child: _big(context, AppIcons.library, tr('Library'), tr('Your books and courses'), () => onOpenTab?.call(2), key: const Key('home_library'))),
                          ])),
                          const SizedBox(height: 10),
                          IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Expanded(child: _big(context, AppIcons.learn, tr('Learn'), due > 0 ? trp('{n} cards to review', {'n': due}) : tr('Review and practise'), () => _push(context, const LearnScreen()), key: const Key('home_learn'))),
                            const SizedBox(width: 10),
                            Expanded(child: _big(context, AppIcons.tools, tr('Tools'), tr('Calculators, doses, search'), () => onOpenTab?.call(3), key: const Key('home_tools'))),
                          ])),
                        ])),
                        const SizedBox(height: 6),
                        // ---- backup reminder
                        if (store.cases.isNotEmpty && (store.daysSinceBackup == null || store.daysSinceBackup! > 7))
                          stagger(AppCard(
                            color: cs.tertiaryContainer,
                            child: ListTile(
                              dense: true,
                              leading: const Icon(Ph.cloudArrowUp),
                              title: Text(store.daysSinceBackup == null ? tr('You have never made a backup') : trp('Last backup was {n} days ago', {'n': store.daysSinceBackup!})),
                              subtitle: Text('Tap to back up now'),
                              onTap: () => _push(context, const SettingsScreen()),
                            ),
                          )),
                        if (!studying && drafts.isNotEmpty) ...[
                          SectionHeader('Unfinished drafts',
                              trailing: TextButton(
                                style: TextButton.styleFrom(minimumSize: const Size(0, 44)),
                                onPressed: () => onOpenTab?.call(1),
                                child: Text('All cases'),
                              )),
                          for (final c in drafts) stagger(CaseTile(c, key: ValueKey('draft_${c.id}'), margin: const EdgeInsets.symmetric(vertical: 4))),
                        ],
                        if (!studying && recent.isNotEmpty) ...[
                          const SectionHeader('Recent cases'),
                          for (final c in recent) stagger(CaseTile(c, key: ValueKey('recent_${c.id}'), margin: const EdgeInsets.symmetric(vertical: 4))),
                        ],
                        if (!studying && all.isEmpty)
                          EmptyState(
                            kind: EmptyKind.cases,
                            title: 'No cases yet',
                            message: 'Tap + and write just the complaint — you can finish the rest after the shift.',
                            action: FilledButton.icon(onPressed: () => showQuickAdd(context), icon: const Icon(AppIcons.add), label: Text('New case')),
                          ),
                        const SizedBox(height: 28),
                        const DesignerCredit(),
                        const SizedBox(height: 24),
                      ]),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class DesignerCredit extends StatelessWidget {
  const DesignerCredit({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Column(
      children: [
        Divider(color: cs.outlineVariant),
        const SizedBox(height: 8),
        Text(designedBy,
            style: theme.textTheme.labelMedium
                ?.copyWith(color: cs.onSurfaceVariant)),
        const SizedBox(height: 2),
        Text(designerName,
            style: theme.textTheme.titleSmall
                ?.copyWith(color: cs.primary, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text('SharqMed v$kAppVersion',
            style: theme.textTheme.labelSmall?.copyWith(color: cs.outline)),
      ],
    );
  }
}

