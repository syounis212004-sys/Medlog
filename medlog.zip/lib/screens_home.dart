import 'package:flutter/material.dart' hide Text;

import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'quick_add.dart';
import 'screens_calendar.dart';
import 'screens_cases.dart';
import 'screens_learn.dart';
import 'screens_portfolio.dart';
import 'focus.dart';
import 'screens_extras.dart';
import 'screens_review.dart';
import 'screens_search.dart';
import 'screens_study.dart';
import 'theme.dart';
import 'ui.dart';
import 'widgets.dart';

const List<FieldSpec> kShiftSpecs = [
  FieldSpec('type', 'Shift type',
      type: FT.choice, options: ['Morning', 'Evening', 'Night', 'On-call']),
  FieldSpec('note', 'Note about the day', type: FT.multi),
];

Future<void> editShift(BuildContext context, String date,
    {String rotationId = ''}) async {
  final cur = store.shiftFor(date);
  final res = await showFormSheet(
    context,
    title: '${tr('Duty day')} • ${prettyDate(date)}',
    specs: kShiftSpecs,
    initial: cur ??
        <String, dynamic>{
          'date': date,
          'type': 'Morning',
          'rotationId': rotationId,
        },
    canDelete: cur != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.shifts, 'shifts.json', date, key: 'date');
  } else {
    await store.upsert(store.shifts, 'shifts.json', res, key: 'date');
  }
}

String _greeting() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

class HomeScreen extends StatelessWidget {
  /// Lets shortcuts jump to another tab of the shell.
  final ValueChanged<int>? onOpenTab;
  const HomeScreen({super.key, this.onOpenTab});

  void _push(BuildContext context, Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final cs = theme.colorScheme;
        final rot = store.currentRotation();
        final today = todayStr();
        final all = store.casesSorted();
        final todays = all.where((c) => c.s('date') == today).toList();
        final drafts =
            all.where((c) => c.s('status') == 'Draft').take(5).toList();
        final recent = all.take(5).toList();
        final shift = store.shiftFor(today);
        final weekAgo =
            fmtDate(DateTime.now().subtract(const Duration(days: 7)));
        final thisWeek =
            all.where((c) => c.s('date').compareTo(weekAgo) > 0).length;
        var n = 0;

        Widget stagger(Widget w) => FadeSlideIn(index: n++, child: w);
        openProceduresTabHook = () => onOpenTab?.call(3);
        final focus = store.mode == 'study' ? const <FocusItem>[] : buildFocus();

        // "continue where you left off": the case I edited most recently (last 3 days)
        Widget? resume;
        final lastId = (store.settings['lastCase'] ?? '').toString();
        final lastAt =
            DateTime.tryParse((store.settings['lastCaseAt'] ?? '').toString());
        final lastRec = store.cases[lastId];
        if (lastRec != null &&
            lastAt != null &&
            DateTime.now().difference(lastAt.toLocal()).inDays < 3) {
          final tab = (store.settings['lastTab'] is int)
              ? store.settings['lastTab'] as int
              : 0;
          resume = AppCard(
            color: cs.primaryContainer.withAlpha(140),
            child: ListTile(
              leading: const Icon(Icons.play_circle_outline),
              title: Text('Continue where you left off'),
              subtitle: Text('${lastRec.s('code')} • ${lastRec.title}',
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        CaseEditorScreen(rec: lastRec, initialTab: tab)),
              ),
            ),
          );
        }

        return ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            // ---- header with moving heartbeat
            stagger(_Header(
              greeting: _greeting(),
              mode: store.mode,
              onMode: (m) => store.setLook('mode', m),
              onCalendar: () => _push(context, const CalendarScreen()),
              onSettings: () => _push(context, const SettingsScreen()),
              onPortfolio: () => _push(context, const PortfolioScreen()),
              onSearch: () => _push(context, const SearchScreen()),
            )),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  if (store.mode == 'study')
                    ...studyHomeSections(context, onOpenTab: onOpenTab),
                  if (store.mode != 'study') ...[
                    // ---- continue where I left off
                    if (resume != null) stagger(resume),
                  // ---- today's focus (top 3 gaps in my own records)
                  if (focus.isNotEmpty)
                    stagger(SectionCard(
                      title: 'Today’s focus',
                      icon: Icons.flag_outlined,
                      trailing: focus.length > 3
                          ? TextButton(
                              onPressed: () => _push(context, const FocusScreen()),
                              child: Text(trp('All {n}', {'n': focus.length})),
                            )
                          : null,
                      children: [for (final f in focus.take(3)) FocusTile(f)],
                    )),
                    // ---- stats
                    stagger(Row(
                      children: [
                        Expanded(
                            child: _StatTile(Icons.folder_copy_outlined,
                                all.length, 'Cases')),
                        const SizedBox(width: 8),
                        Expanded(
                            child: _StatTile(Icons.date_range_outlined,
                                thisWeek, 'This week')),
                        const SizedBox(width: 8),
                        Expanded(
                            child: _StatTile(Icons.healing_outlined,
                                store.procedures.length, 'Procedures')),
                      ],
                    )),
                    // ---- backup reminder
                    if (store.cases.isNotEmpty &&
                        (store.daysSinceBackup == null ||
                            store.daysSinceBackup! > 7))
                      stagger(AppCard(
                        color: cs.tertiaryContainer,
                        child: ListTile(
                          leading: const Icon(Icons.backup_outlined),
                          title: Text(store.daysSinceBackup == null
                              ? tr('You have never made a backup')
                              : trp('Last backup was {n} days ago',
                                  {'n': store.daysSinceBackup!})),
                          subtitle: Text('Tap to back up now'),
                          onTap: () => _push(context, const SettingsScreen()),
                        ),
                      )),
                    const SizedBox(height: 4),
                    // ---- current rotation
                    stagger(AppCard(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () {
                          if (rot == null) {
                            editRotation(context);
                          } else {
                            _push(
                                context,
                                RotationScreen(
                                    rotationId: rot['id'].toString()));
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: rot == null
                              ? Row(
                                  children: [
                                    const Icon(Icons.add_circle_outline),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        'Add your first rotation (e.g. Internal Medicine, Oct 1 – Oct 31)',
                                        style: theme.textTheme.bodyLarge,
                                      ),
                                    ),
                                  ],
                                )
                              : _RotationSummary(rot: rot),
                        ),
                      ),
                    )),
                    // ---- today
                    stagger(AppCard(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(prettyDate(today),
                                      style: theme.textTheme.titleMedium),
                                ),
                                Text(countLabel(todays.length, 'case'),
                                    style: theme.textTheme.labelLarge
                                        ?.copyWith(color: cs.primary)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 4,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                if (shift != null)
                                  Chip(
                                    avatar: Icon(Icons.circle,
                                        size: 12,
                                        color: shiftColor(
                                            (shift['type'] ?? '').toString())),
                                    label: Text(
                                        '${tr('Duty day')} • ${tr((shift['type'] ?? '').toString())}'),
                                  ),
                                TextButton(
                                  onPressed: () => editShift(
                                    context,
                                    today,
                                    rotationId:
                                        rot == null ? '' : rot['id'].toString(),
                                  ),
                                  child: Text(shift == null
                                      ? 'Mark today as duty day'
                                      : 'Edit'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    )),
                    // ---- shortcuts
                    stagger(Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        children: [
                          Expanded(
                            child: _Shortcut(
                                Icons.calendar_month_outlined,
                                'Calendar',
                                () => _push(context, const CalendarScreen())),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Shortcut(Icons.healing_outlined,
                                'Log procedure', () => editProcedure(context)),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Shortcut(Icons.help_outline, 'Add question',
                                () => editQuestion(context)),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Shortcut(Icons.edit_note, 'New note',
                                () => editNote(context)),
                          ),
                        ],
                      ),
                    )),
                    if (todays.isNotEmpty) ...[
                      const SectionHeader('Today'),
                      for (final c in todays) stagger(CaseTile(c)),
                    ],
                    if (drafts.isNotEmpty) ...[
                      SectionHeader('Unfinished drafts',
                          trailing: TextButton(
                            onPressed:
                                onOpenTab == null ? null : () => onOpenTab!(1),
                            child: Text('All cases'),
                          )),
                      for (final c in drafts) stagger(CaseTile(c)),
                    ],
                    if (recent.isNotEmpty) ...[
                      const SectionHeader('Recent cases'),
                      for (final c in recent) stagger(CaseTile(c)),
                    ],
                    if (all.isEmpty)
                      EmptyState(
                        kind: EmptyKind.cases,
                        title: 'No cases yet',
                        message: 'Tap + and write just the complaint — '
                            'you can finish the rest after the shift.',
                        action: FilledButton.icon(
                          onPressed: () => showQuickAdd(context),
                          icon: const Icon(Icons.add),
                          label: Text('New case'),
                        ),
                      ),
                  ],
                  const SizedBox(height: 28),
                  const DesignerCredit(),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

/// Gradient greeting card with the animated heartbeat line.
class _Header extends StatelessWidget {
  final String greeting;
  final String mode;
  final ValueChanged<String> onMode;
  final VoidCallback onCalendar;
  final VoidCallback onSettings;
  final VoidCallback onPortfolio;
  final VoidCallback onSearch;
  const _Header({
    required this.onSearch,
    required this.greeting,
    required this.mode,
    required this.onMode,
    required this.onCalendar,
    required this.onSettings,
    required this.onPortfolio,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final who = store.author;
    return Container(
      decoration: BoxDecoration(
        gradient: paletteGradient(context),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(20, 8, 8, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const MedLogMark(size: 34),
                  const SizedBox(width: 10),
                  Text('MedLog',
                      style: theme.textTheme.titleLarge?.copyWith(
                          color: Colors.white, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  IconButton(
                    tooltip: tr('Search'),
                    onPressed: onSearch,
                    icon: const Icon(Icons.search, color: Colors.white),
                  ),
                  IconButton(
                    tooltip: tr('Portfolio'),
                    onPressed: onPortfolio,
                    icon: const Icon(Icons.insights_outlined, color: Colors.white),
                  ),
                  IconButton(
                    tooltip: tr('Calendar'),
                    onPressed: onCalendar,
                    icon: const Icon(Icons.calendar_month_outlined,
                        color: Colors.white),
                  ),
                  IconButton(
                    tooltip: tr('Settings'),
                    onPressed: onSettings,
                    icon: const Icon(Icons.settings_outlined,
                        color: Colors.white),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 12),
                child: Text(
                  who.isEmpty ? tr(greeting) : '${tr(greeting)}, $who',
                  style: theme.textTheme.headlineSmall?.copyWith(
                      color: Colors.white, fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(height: 2),
              Text(prettyDate(todayStr()),
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(color: Colors.white.withAlpha(210))),
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 12, top: 8),
                child: _ModeToggle(mode: mode, onChanged: onMode),
              ),
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 12),
                child: EcgBanner(color: Colors.white, height: 54),
              ),
              const SizedBox(height: 4),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final IconData icon;
  final int value;
  final String label;
  const _StatTile(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return AppCard(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: cs.primary),
            const SizedBox(height: 6),
            CountUp(value,
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800)),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.labelMedium
                    ?.copyWith(color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

class _Shortcut extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Shortcut(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        decoration: BoxDecoration(
          color: cs.secondaryContainer.withAlpha(120),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Icon(icon, color: cs.onSecondaryContainer),
            const SizedBox(height: 4),
            Text(label,
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: cs.onSecondaryContainer)),
          ],
        ),
      ),
    );
  }
}

/// "Designed by ..." line shown at the bottom of Home and in About.
class DesignerCredit extends StatelessWidget {
  const DesignerCredit({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Column(
      children: [
        Divider(color: cs.outlineVariant),
        const SizedBox(height: 8),
        Text(designedBy,
            style: theme.textTheme.labelMedium
                ?.copyWith(color: cs.onSurfaceVariant)),
        const SizedBox(height: 2),
        Text(designerName,
            style: theme.textTheme.titleSmall
                ?.copyWith(color: cs.primary, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text('MedLog v$kAppVersion',
            style: theme.textTheme.labelSmall?.copyWith(color: cs.outline)),
      ],
    );
  }
}

class _RotationSummary extends StatelessWidget {
  final J rot;
  const _RotationSummary({required this.rot});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final id = rot['id'].toString();
    final cases = store.casesOfRotation(id).length;
    final days = store.shifts.where((s) => s['rotationId'] == id).length;
    final procs = store.procedures.where((p) => p['rotationId'] == id).length;
    final start = (rot['start'] ?? '').toString();
    final end = (rot['end'] ?? '').toString();

    // how far through the rotation we are
    double? progress;
    final sd = parseDate(start);
    final ed = parseDate(end);
    if (sd != null && ed != null && ed.isAfter(sd)) {
      final total = ed.difference(sd).inHours;
      final done = DateTime.now().difference(sd).inHours;
      progress = (done / total).clamp(0.0, 1.0);
    }

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Current rotation', style: theme.textTheme.labelMedium),
              Text(store.rotationLabel(rot), style: theme.textTheme.titleLarge),
              if (start.isNotEmpty)
                Text(
                    '${prettyDate(start)}${end.isEmpty ? '' : '  $arrow  ${prettyDate(end)}'}'),
              const SizedBox(height: 8),
              Wrap(
                spacing: 16,
                children: [
                  Text(countLabel(cases, 'case')),
                  Text(countLabel(days, 'duty day')),
                  Text(countLabel(procs, 'procedure')),
                ],
              ),
            ],
          ),
        ),
        if (progress != null) ...[
          const SizedBox(width: 12),
          AnimatedRing(
            progress,
            size: 64,
            center: Text('${(progress * 100).round()}%',
                style: theme.textTheme.labelLarge
                    ?.copyWith(fontWeight: FontWeight.w800)),
          ),
        ],
      ],
    );
  }
}

/// Shift (fast documentation) / Study (practice and review) switch in the header.
class _ModeToggle extends StatelessWidget {
  final String mode;
  final ValueChanged<String> onChanged;
  const _ModeToggle({required this.mode, required this.onChanged});

  Widget _seg(BuildContext context, String id, IconData icon, String label) {
    final sel = mode == id;
    return Expanded(
      child: GestureDetector(
        onTap: () => onChanged(id),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: sel ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: sel ? Colors.black87 : Colors.white),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: sel ? Colors.black87 : Colors.white)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(46),
        borderRadius: BorderRadius.circular(17),
      ),
      child: Row(
        children: [
          _seg(context, 'shift', Icons.bolt, 'Shift'),
          _seg(context, 'study', Icons.school_outlined, 'Study'),
        ],
      ),
    );
  }
}
