import 'dart:math';

import 'data.dart';
import 'lib_quiz.dart';
import 'lib_user.dart';
import 'library.dart';

/// Board / exam planner. Nothing is generated: the plan only lists article titles of the courses the
/// learner picked (their weak spots from past quizzes first, then topics not read or tested yet),
/// spread over the days left. Ticks are stored in the settings file on the phone.

/// Questions suggested per article in the daily summary.
const int kPlanQuestionsPerArticle = 4;

/// Articles per day the plan is sized for.
const int kPlanArticlesPerDay = 5;

class PlanItem {
  final String packId;
  final String title;
  final bool weak;
  const PlanItem(this.packId, this.title, this.weak);
  String get key => '$packId|$title';
  Map<String, dynamic> toJson() => {'p': packId, 't': title, if (weak) 'w': true};
}

class ExamPlan {
  final String name;
  final String date; // yyyy-mm-dd
  final List<String> packs;
  final List<PlanItem> items;
  final Set<String> done;
  const ExamPlan({required this.name, required this.date, required this.packs, required this.items, required this.done});

  Map<String, dynamic> toJson() => {
        'name': name,
        'date': date,
        'packs': packs,
        'items': [for (final i in items) i.toJson()],
        'done': done.toList(),
      };

  ExamPlan copyWith({List<PlanItem>? items, Set<String>? done}) => ExamPlan(name: name, date: date, packs: packs, items: items ?? this.items, done: done ?? this.done);

  static ExamPlan? fromJson(Object? j) {
    if (j is! Map) return null;
    final date = '${j['date'] ?? ''}';
    if (parseDate(date) == null) return null;
    return ExamPlan(
      name: '${j['name'] ?? ''}',
      date: date,
      packs: [for (final p in (j['packs'] as List? ?? const [])) '$p'],
      items: [
        for (final i in (j['items'] as List? ?? const []))
          if (i is Map) PlanItem('${i['p'] ?? ''}', '${i['t'] ?? ''}', i['w'] == true),
      ],
      done: {for (final d in (j['done'] as List? ?? const [])) '$d'},
    );
  }
}

class PlanDay {
  final DateTime date;
  final List<PlanItem> items;
  const PlanDay(this.date, this.items);
  int get articles => items.length;
  int get questions => items.length * kPlanQuestionsPerArticle;
}

ExamPlan? examPlan() => ExamPlan.fromJson(store.settings['examPlan']);

Future<void> saveExamPlan(ExamPlan? p) async {
  if (p == null) {
    store.settings.remove('examPlan');
  } else {
    store.settings['examPlan'] = p.toJson();
  }
  await store.saveSettings();
}

/// Whole days from today to the exam (0 = today, negative = passed).
int examDaysLeft(String date, {DateTime? now}) {
  final d = parseDate(date);
  if (d == null) return 0;
  final n = now ?? DateTime.now();
  return DateTime(d.year, d.month, d.day).difference(DateTime(n.year, n.month, n.day)).inDays;
}

/// Weak spots first, then topics from [packs] not tested and not recently read, a few courses at a time
/// so every chosen course is covered. Only titles that exist in the installed packs.
Future<List<PlanItem>> buildPlanItems({required List<String> packs, required String examDate, DateTime? now}) async {
  final days = max(1, examDaysLeft(examDate, now: now));
  final target = (days * kPlanArticlesPerDay).clamp(kPlanArticlesPerDay, 400);
  final out = <PlanItem>[];
  final seen = <String>{};
  final chosen = packs.where((p) => library.pack(p) != null).toList();
  for (final w in weakSpots()) {
    if (out.length >= target) break;
    if (library.pack(w.packId) == null) continue;
    if (chosen.isNotEmpty && !chosen.contains(w.packId)) continue;
    if (await library.indexOfTitle(w.packId, w.title) == null) continue;
    if (seen.add('${w.packId}|${w.title}')) out.add(PlanItem(w.packId, w.title, true));
  }
  final tested = quizResultsByArticle(rows: 100000).keys.toSet();
  final read = {for (final r in recentArticles()) '${r['p']}|${r['t']}'};
  final rnd = Random(examDate.codeUnits.fold<int>(7, (a, c) => (a * 31 + c) & 0x7fffffff));
  final lists = <List<PlanItem>>[];
  for (final p in chosen) {
    final t = await library.titlesOf(p), l = await library.leadsOf(p);
    final idx = <int>[
      for (var i = 0; i < t.length; i++)
        if (planWorthy(t[i], l[i]) && !tested.contains('$p|${t[i]}') && !read.contains('$p|${t[i]}') && !seen.contains('$p|${t[i]}')) i
    ]..shuffle(rnd);
    lists.add([for (final i in idx.take(target)) PlanItem(p, t[i], false)]);
  }
  for (var k = 0; out.length < target; k++) {
    var any = false;
    for (final l in lists) {
      if (k < l.length && out.length < target) {
        out.add(l[k]);
        any = true;
      }
    }
    if (!any) break;
  }
  return out;
}

/// What is left, spread over the days from today to the day before the exam (a single day when the exam is today).
List<PlanDay> planSchedule(ExamPlan plan, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = DateTime(n.year, n.month, n.day);
  final pending = [for (final i in plan.items) if (!plan.done.contains(i.key)) i];
  if (pending.isEmpty) return const [];
  final days = max(1, examDaysLeft(plan.date, now: n));
  final per = (pending.length / days).ceil();
  final out = <PlanDay>[];
  for (var d = 0; d < days && d * per < pending.length; d++) {
    out.add(PlanDay(today.add(Duration(days: d)), pending.sublist(d * per, min(pending.length, (d + 1) * per))));
  }
  return out;
}

Future<void> togglePlanDone(String key) async {
  final p = examPlan();
  if (p == null) return;
  final done = {...p.done};
  if (!done.remove(key)) done.add(key);
  await saveExamPlan(p.copyWith(done: done));
}
