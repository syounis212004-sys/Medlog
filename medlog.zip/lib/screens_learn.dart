import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as mm show Text;

import 'data.dart';
import 'i18n.dart';
import 'lib_plan.dart';
import 'library.dart';
import 'motion.dart';
import 'screens_cases.dart';
import 'screens_library.dart' show openArticle;
import 'screens_quiz.dart' show QuizScreen;
import 'screens_skills.dart';
import 'ui.dart';
import 'widgets.dart';

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Learn'),
          bottom: TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              Tab(icon: const Icon(Icons.healing_outlined), text: tr('Procedures'), height: 58),
              Tab(icon: const Icon(Icons.image_search_outlined), text: tr('Imaging'), height: 58),
              Tab(icon: const Icon(Icons.edit_note), text: tr('Notebook'), height: 58),
              Tab(icon: const Icon(Icons.help_outline), text: tr('Questions'), height: 58),
              Tab(icon: const Icon(Icons.record_voice_over_outlined), text: tr('Feedback'), height: 58),
              Tab(icon: const Icon(Icons.bookmark_border), text: tr('Review'), height: 58),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            SkillsTab(),
            ImagingTab(),
            _NotebookTab(),
            _QuestionsTab(),
            FeedbackTab(),
            _ReviewTab(),
          ],
        ),
      ),
    );
  }
}

// ================================================================ procedures

const List<String> kProcedureNames = [
  'IV cannulation', 'Blood sampling', 'ABG', 'Suturing', 'Wound dressing',
  'Urinary catheterization', 'NG tube', 'Casting / splinting', 'Reduction',
  'Lumbar puncture', 'Chest tube', 'CPR', 'ECG', 'Incision & drainage',
  'Intubation', 'Paracentesis', 'Normal delivery (assisted)', 'Other',
];

const List<String> kProcedureRoles = [
  'Observed', 'Assisted', 'Performed under supervision', 'Performed independently',
];

Future<void> editProcedure(BuildContext context, [J? p, String? presetName]) async {
  final cur = store.currentRotation();
  final res = await showFormSheet(
    context,
    title: p == null ? 'Log procedure' : 'Procedure',
    specs: const [
      FieldSpec('name', 'Procedure', options: kProcedureNames),
      FieldSpec('role', 'My role', type: FT.choice, options: kProcedureRoles),
      FieldSpec('confidence', 'My confidence now (1 = low, 5 = high)',
          type: FT.choice, options: ['1', '2', '3', '4', '5']),
      FieldSpec('assessedBy', 'Assessment',
          type: FT.choice, options: ['Self-assessed', 'Supervisor assessed']),
      FieldSpec('date', 'Date', type: FT.date),
      FieldSpec('caseCode', 'Related case code (optional)', hint: 'MED-0012'),
      FieldSpec('outcome', 'Outcome / complications / what I learned', type: FT.multi),
      FieldSpec('feedback', 'Supervisor feedback', type: FT.multi),
    ],
    initial: p ??
        <String, dynamic>{
          'id': newId('p'),
          'date': todayStr(),
          'rotationId': cur == null ? '' : cur['id'].toString(),
          'role': 'Assisted',
          'assessedBy': 'Self-assessed',
          if (presetName != null) 'name': presetName,
        },
    canDelete: p != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.procedures, 'procedures.json', p!['id'].toString());
  } else {
    await store.upsert(store.procedures, 'procedures.json', res);
  }
}


class ProceduresLogTab extends StatelessWidget {
  const ProceduresLogTab({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = List<J>.from(store.procedures);
        list.sort((a, b) =>
            (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        final counts = <String, int>{};
        for (final p in list) {
          final n = (p['name'] ?? '').toString();
          if (n.isEmpty) continue;
          counts[n] = (counts[n] ?? 0) + 1;
        }
        var confSum = 0;
        var confN = 0;
        var sup = 0;
        for (final p in list) {
          final c = int.tryParse((p['confidence'] ?? '').toString());
          if (c != null) {
            confSum += c;
            confN++;
          }
          if (p['assessedBy'] == 'Supervisor assessed') sup++;
        }
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editProcedure(context),
            icon: const Icon(Icons.add),
            label: const Text('Log procedure'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              if (list.isNotEmpty) ...[
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Chip(label: Text(trp('{n} logged', {'n': list.length}))),
                    if (confN > 0)
                      Chip(label: Text(trp('Avg confidence {n}/5', {'n': (confSum / confN).toStringAsFixed(1)}))),
                    Chip(label: Text(trp('{n} supervisor assessed', {'n': sup}))),
                  ],
                ),
                const SizedBox(height: 4),
              ],
              if (counts.isNotEmpty) ...[
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final e in counts.entries) Chip(label: Text('${tr(e.key)}: ${e.value}')),
                  ],
                ),
                const SizedBox(height: 8),
              ],
              if (list.isEmpty)
                const EmptyState(
                  kind: EmptyKind.learn,
                  title: 'No procedures logged yet.',
                  message: 'Log every cannulation, suture or ABG with your role and confidence.',
                ),
              for (var i = 0; i < list.length; i++)
                FadeSlideIn(
                  key: ValueKey(list[i]['id']),
                  index: i,
                  child: AppCard(
                    child: ListTile(
                      onTap: () => editProcedure(context, list[i]),
                      title: Text(tr((list[i]['name'] ?? '').toString())),
                      subtitle: Text(
                        [
                          prettyDate((list[i]['date'] ?? '').toString()),
                          tr((list[i]['role'] ?? '').toString()),
                          if ((list[i]['confidence'] ?? '').toString().isNotEmpty)
                            trp('confidence {n}/5', {'n': list[i]['confidence']}),
                          if ((list[i]['assessedBy'] ?? '') == 'Supervisor assessed')
                            tr('supervisor'),
                          if ((list[i]['caseCode'] ?? '').toString().isNotEmpty)
                            '${list[i]['caseCode']}',
                        ].where((e) => e.isNotEmpty).join(' • '),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ notebook

Future<void> editNote(BuildContext context, [J? n]) async {
  final res = await showFormSheet(
  context,
    title: n == null ? 'New note' : 'Note',
    specs: const [
      FieldSpec('title', 'Title'),
      FieldSpec('body', 'What I learned', type: FT.multi),
      FieldSpec('tags', 'Tags (comma separated)', hint: 'cardiology, antibiotics'),
      FieldSpec('caseCode', 'Related case code (optional)'),
    ],
    initial: n ?? <String, dynamic>{'id': newId('n'), 'date': todayStr()},
    canDelete: n != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.notes, 'notes.json', n!['id'].toString());
  } else {
    await store.upsert(store.notes, 'notes.json', res);
  }
  }


class _NotebookTab extends StatefulWidget {
  const _NotebookTab();

  @override
  State<_NotebookTab> createState() => _NotebookTabState();
}

class _NotebookTabState extends State<_NotebookTab> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final q = _q.trim().toLowerCase();
        final list = store.notes.where((n) {
          if (q.isEmpty) return true;
          return '${n['title']} ${n['body']} ${n['tags']}'.toLowerCase().contains(q);
        }).toList();
        list.sort((a, b) =>
            (b['updated'] ?? '').toString().compareTo((a['updated'] ?? '').toString()));
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editNote(context),
            icon: const Icon(Icons.edit_note),
            label: const Text('New note'),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: tr('Search notes'),
                    isDense: true,
                  ),
                  onChanged: (v) => setState(() => _q = v),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const EmptyState(
                        kind: EmptyKind.learn,
                        title: 'Your personal notebook',
                        message: 'Pearls, guidelines, doses, things the supervisor taught you.',
                      )
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 96),
                        children: [
                          for (var i = 0; i < list.length; i++)
                            FadeSlideIn(
                              key: ValueKey(list[i]['id']),
                              index: i,
                              child: AppCard(
                                child: ListTile(
                                  onTap: () => editNote(context, list[i]),
                                  title: Text((list[i]['title'] ?? '').toString().isEmpty
                                      ? '(untitled)'
                                      : list[i]['title'].toString()),
                                  subtitle: Text(
                                    (list[i]['body'] ?? '').toString(),
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ review

class _ReviewTab extends StatelessWidget {
  const _ReviewTab();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final all = store.casesSorted();
        final flagged = all.where((c) => c.review).toList();
        final withQuestions =
            all.where((c) => c.s('questions').trim().isNotEmpty).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
          children: [
            const ExamPlannerSection(),
            const SectionHeader('Cases flagged for review'),
            if (flagged.isEmpty)
              const EmptyState(
                kind: EmptyKind.generic,
                title: 'Nothing flagged',
                message: 'Use “To review later” inside a case.',
              ),
            for (var i = 0; i < flagged.length; i++) FadeSlideIn(index: i, child: CaseTile(flagged[i])),
            const SectionHeader('Open questions from my cases'),
            if (withQuestions.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text('No open questions.'),
              ),
            for (final c in withQuestions)
              AppCard(
                child: ListTile(
                  onTap: () => openCase(context, c),
                  title: Text('${c.s('code')} • ${c.title}',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(c.s('questions')),
                ),
              ),
          ],
        );
      },
    );
  }
}


// ================================================================ questions inbox

Future<void> editQuestion(BuildContext context, [J? q]) async {
  final res = await showFormSheet(
  context,
    title: q == null ? 'New question' : 'Question',
    specs: const [
      FieldSpec('question', 'Question', type: FT.multi),
      FieldSpec('status', 'Status', type: FT.choice, options: ['Open', 'Answered']),
      FieldSpec('answer', 'Answer', type: FT.multi),
      FieldSpec('reference', 'Reference (book, guideline, link)'),
      FieldSpec('caseCode', 'Related case code (optional)'),
    ],
    initial: q ?? <String, dynamic>{'id': newId('q'), 'date': todayStr(), 'status': 'Open'},
    canDelete: q != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.inbox, 'questions.json', q!['id'].toString());
  } else {
    await store.upsert(store.inbox, 'questions.json', res);
  }
  }



class _QuestionsTab extends StatefulWidget {
  const _QuestionsTab();

  @override
  State<_QuestionsTab> createState() => _QuestionsTabState();
}

class _QuestionsTabState extends State<_QuestionsTab> {
  bool _openOnly = true;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = store.inbox
            .where((q) => !_openOnly || (q['status'] ?? 'Open') != 'Answered')
            .toList()
          ..sort((a, b) =>
              (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editQuestion(context),
            icon: const Icon(Icons.help_outline),
            label: const Text('Add question'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              Row(
                children: [
                  FilterChip(
                    label: const Text('Open only'),
                    selected: _openOnly,
                    onSelected: (v) => setState(() => _openOnly = v),
                  ),
                ],
              ),
              if (list.isEmpty)
                const EmptyState(
                  kind: EmptyKind.learn,
                  title: 'Question inbox',
                  message: 'Write down every question you could not answer on the ward, '
                      'then answer it later and keep the reference.',
                ),
              for (var i = 0; i < list.length; i++)
                FadeSlideIn(
                  key: ValueKey(list[i]['id']),
                  index: i,
                  child: AppCard(
                    child: ListTile(
                      onTap: () => editQuestion(context, list[i]),
                      leading: Icon(
                        list[i]['status'] == 'Answered'
                            ? Icons.check_circle_outline
                            : Icons.help_outline,
                      ),
                      title: Text((list[i]['question'] ?? '').toString(),
                          maxLines: 3, overflow: TextOverflow.ellipsis),
                      subtitle: Text([
                        prettyDate((list[i]['date'] ?? '').toString()),
                        if ((list[i]['caseCode'] ?? '').toString().isNotEmpty)
                          '${list[i]['caseCode']}',
                        if ((list[i]['answer'] ?? '').toString().isNotEmpty) '${list[i]['answer']}',
                      ].where((e) => e.isNotEmpty).join('\n')),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}



// ================================================================ exam / board planner

/// Collapsible planner: exam date + courses -> a day-by-day list of the user's weak spots and
/// topics not studied yet (titles from the downloaded packs only), with ticks and days left.
class ExamPlannerSection extends StatelessWidget {
  const ExamPlannerSection({super.key});
  @override
  Widget build(BuildContext context) {
    return Fold(
      id: 'exam_planner',
      title: tr('Exam planner'),
      subtitle: tr('Plan your revision day by day'),
      icon: Icons.event_note_outlined,
      children: const [_PlannerBody()],
    );
  }
}

class _PlannerBody extends StatefulWidget {
  const _PlannerBody();
  @override
  State<_PlannerBody> createState() => _PlannerBodyState();
}

class _PlannerBodyState extends State<_PlannerBody> {
  ExamPlan? _plan = examPlan();
  bool _editing = false;
  bool _busy = false;
  late final TextEditingController _name = TextEditingController(text: _plan?.name ?? '');
  String _date = examPlan()?.date ?? '';
  late final Set<String> _packs = {...?_plan?.packs};

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _build({bool keepDone = false}) async {
    setState(() => _busy = true);
    final items = await buildPlanItems(packs: _packs.toList(), examDate: _date);
    final old = _plan;
    final plan = ExamPlan(
      name: _name.text.trim(),
      date: _date,
      packs: _packs.toList(),
      items: items,
      done: keepDone && old != null ? {...old.done} : <String>{},
    );
    await saveExamPlan(plan);
    if (!mounted) return;
    setState(() {
      _plan = plan;
      _editing = false;
      _busy = false;
    });
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final cur = parseDate(_date) ?? now.add(const Duration(days: 30));
    final d = await showDatePicker(context: context, initialDate: cur.isBefore(now) ? now : cur, firstDate: now, lastDate: now.add(const Duration(days: 730)));
    if (d != null && mounted) setState(() => _date = fmtDate(d));
  }

  Future<void> _openItem(PlanItem it) async {
    final i = await library.indexOfTitle(it.packId, it.title);
    if (i != null && mounted) openArticle(context, it.packId, i);
  }

  void _quizItem(PlanItem it) {
    final q = stripSource(it.title).replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();
    Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(packId: it.packId, query: q, autoStart: true, count: 5)));
  }

  Future<void> _tick(PlanItem it) async {
    await togglePlanDone(it.key);
    if (mounted) setState(() => _plan = examPlan());
  }

  String _summary(int a, int q) => trp(a == 1 ? '{a} article + {q} questions' : '{a} articles + {q} questions', {'a': a, 'q': q});

  Widget _row(PlanItem it, bool done) {
    final pack = library.pack(it.packId)?.title ?? '';
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Checkbox(value: done, onChanged: (_) => _tick(it)),
      title: mm.Text(stripSource(it.title), maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: done ? const TextStyle(decoration: TextDecoration.lineThrough) : null),
      subtitle: Text(it.weak ? '${tr('Weak spot')} • $pack' : pack, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: IconButton(tooltip: tr('Test myself'), icon: const Icon(Icons.quiz_outlined, size: 20), onPressed: () => _quizItem(it)),
      onTap: () => _openItem(it),
    );
  }

  Widget _form(ThemeData theme) {
    final packs = [for (final p in library.textPacks) if (p.kind != 'medline' && p.kind != 'user') p];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(controller: _name, decoration: InputDecoration(labelText: tr('Exam name (optional)'), hintText: tr('Board exam, final exam…'))),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: _pickDate,
        icon: const Icon(Icons.event),
        label: Text(parseDate(_date) == null ? tr('Choose the exam date') : prettyDate(_date)),
      ),
      const SizedBox(height: 10),
      Text('Courses to revise', style: theme.textTheme.labelLarge),
      const SizedBox(height: 4),
      Wrap(spacing: 6, runSpacing: 0, children: [
        for (final p in packs)
          FilterChip(
            label: mm.Text(p.title),
            selected: _packs.contains(p.id),
            visualDensity: VisualDensity.compact,
            onSelected: (v) => setState(() => v ? _packs.add(p.id) : _packs.remove(p.id)),
          ),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        FilledButton.icon(
          onPressed: _busy || parseDate(_date) == null || _packs.isEmpty ? null : () => _build(keepDone: _plan != null && _plan!.date == _date),
          icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome_motion_outlined),
          label: Text('Build my plan'),
        ),
        if (_plan != null && _editing) TextButton(onPressed: () => setState(() => _editing = false), child: Text('Cancel')),
      ]),
    ]);
  }

  Widget _view(ThemeData theme, ExamPlan plan) {
    final cs = theme.colorScheme;
    final left = examDaysLeft(plan.date);
    final total = plan.items.length;
    final done = plan.items.where((i) => plan.done.contains(i.key)).length;
    final days = planSchedule(plan);
    final bigText = left > 0 ? '$left' : (left == 0 ? '0' : '—');
    final label = left > 1 ? tr('days left') : left == 1 ? tr('day left') : left == 0 ? tr('Exam is today') : tr('The exam date has passed');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          width: 84,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(16)),
          child: Column(children: [
            mm.Text(bigText, key: const ValueKey('planDaysLeft'), style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900, color: cs.onPrimaryContainer)),
            if (left > 0) Text(label, style: theme.textTheme.labelSmall?.copyWith(color: cs.onPrimaryContainer)),
          ]),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (plan.name.isNotEmpty) mm.Text(plan.name, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            mm.Text(prettyDate(plan.date), style: theme.textTheme.bodyMedium),
            if (left <= 0) Text(label, style: theme.textTheme.bodySmall?.copyWith(color: cs.error)),
          ]),
        ),
      ]),
      const SizedBox(height: 10),
      if (total > 0) ...[
        LinearProgressIndicator(value: done / total, minHeight: 6, borderRadius: BorderRadius.circular(6)),
        const SizedBox(height: 4),
        Text(trp('{done} of {total} done', {'done': done, 'total': total}), style: theme.textTheme.bodySmall),
      ],
      const SizedBox(height: 8),
      if (total == 0)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text('Nothing to plan yet: no weak spots and no new topics in the chosen courses. Take a few self-tests, or pick more courses.', style: theme.textTheme.bodyMedium),
        )
      else if (days.isEmpty)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text('Everything on the plan is done. Well done!', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.green, fontWeight: FontWeight.w700)),
        )
      else ...[
        Text('${tr('Today')}: ${_summary(days.first.articles, days.first.questions)}', key: const ValueKey('planToday'), style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
        for (final it in days.first.items) _row(it, false),
        for (final d in days.skip(1).take(6))
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            dense: true,
            title: Text('${prettyDate(fmtDate(d.date))}: ${_summary(d.articles, d.questions)}', style: theme.textTheme.bodyMedium),
            children: [for (final it in d.items) _row(it, false)],
          ),
        if (days.length > 7) Padding(padding: const EdgeInsets.only(top: 4), child: Text(trp('and {n} more days', {'n': days.length - 7}), style: theme.textTheme.bodySmall)),
      ],
      if (done > 0)
        ExpansionTile(
          tilePadding: EdgeInsets.zero,
          dense: true,
          title: Text(trp('Done ({n})', {'n': done}), style: theme.textTheme.bodyMedium),
          children: [for (final it in plan.items.where((i) => plan.done.contains(i.key))) _row(it, true)],
        ),
      const SizedBox(height: 4),
      Wrap(spacing: 8, children: [
        TextButton.icon(onPressed: _busy ? null : () => _build(keepDone: true), icon: const Icon(Icons.refresh, size: 18), label: Text('Rebuild with my latest results')),
        TextButton.icon(onPressed: () => setState(() => _editing = true), icon: const Icon(Icons.edit_outlined, size: 18), label: Text('Change')),
        TextButton.icon(
          onPressed: () async {
            if (await confirmDialog(context, 'Delete this plan?')) {
              await saveExamPlan(null);
              if (mounted) setState(() => _plan = null);
            }
          },
          icon: const Icon(Icons.delete_outline, size: 18),
          label: Text('Delete'),
        ),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedBuilder(
      animation: library,
      builder: (context, _) {
        if (!library.ready || library.textPacks.where((p) => p.kind != 'medline').isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text('Download a course first (Library → Courses). Then pick your exam date and the planner lists what to revise each day.', style: theme.textTheme.bodyMedium),
          );
        }
        final plan = _plan;
        if (plan == null || _editing) {
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (plan == null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text('No exam date yet. Choose it and the courses you are revising: the plan puts your weak spots first.', style: theme.textTheme.bodyMedium),
              ),
            _form(theme),
          ]);
        }
        return _view(theme, plan);
      },
    );
  }
}
