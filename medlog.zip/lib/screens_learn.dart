import 'package:flutter/material.dart' hide Text;

import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'screens_cases.dart';
import 'ui.dart';
import 'widgets.dart';

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Learn'),
          bottom: TabBar(
            tabs: [
              Tab(icon: const Icon(Icons.healing_outlined), text: tr('Procedures'), height: 58),
              Tab(icon: const Icon(Icons.edit_note), text: tr('Notebook'), height: 58),
              Tab(icon: const Icon(Icons.bookmark_border), text: tr('Review'), height: 58),
              Tab(icon: const Icon(Icons.help_outline), text: tr('Questions'), height: 58),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _ProceduresTab(),
            _NotebookTab(),
            _ReviewTab(),
            _QuestionsTab(),
          ],
        ),
      ),
    );
  }
}

// ================================================================ procedures

const List<String> kProcedureNames = [
  'IV cannulation', 'Blood sampling', 'ABG', 'Suturing', 'Wound dressing',
  'Urinary catheterization', 'NG tube', 'Casting / splinting', 'Reduction',
  'Lumbar puncture', 'Chest tube', 'CPR', 'ECG', 'Incision & drainage',
  'Intubation', 'Paracentesis', 'Normal delivery (assisted)', 'Other',
];

const List<String> kProcedureRoles = [
  'Observed', 'Assisted', 'Performed under supervision', 'Performed independently',
];

Future<void> editProcedure(BuildContext context, [J? p]) async {
  final cur = store.currentRotation();
  final res = await showFormSheet(
    context,
    title: p == null ? 'Log procedure' : 'Procedure',
    specs: const [
      FieldSpec('name', 'Procedure', options: kProcedureNames),
      FieldSpec('role', 'My role', type: FT.choice, options: kProcedureRoles),
      FieldSpec('confidence', 'My confidence now (1 = low, 5 = high)',
          type: FT.choice, options: ['1', '2', '3', '4', '5']),
      FieldSpec('assessedBy', 'Assessment',
          type: FT.choice, options: ['Self-assessed', 'Supervisor assessed']),
      FieldSpec('date', 'Date', type: FT.date),
      FieldSpec('caseCode', 'Related case code (optional)', hint: 'MED-0012'),
      FieldSpec('outcome', 'Outcome / complications / what I learned', type: FT.multi),
      FieldSpec('feedback', 'Supervisor feedback', type: FT.multi),
    ],
    initial: p ??
        <String, dynamic>{
          'id': newId('p'),
          'date': todayStr(),
          'rotationId': cur == null ? '' : cur['id'].toString(),
          'role': 'Assisted',
          'assessedBy': 'Self-assessed',
        },
    canDelete: p != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.procedures, 'procedures.json', p!['id'].toString());
  } else {
    await store.upsert(store.procedures, 'procedures.json', res);
  }
}


class _ProceduresTab extends StatelessWidget {
  const _ProceduresTab();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = List<J>.from(store.procedures);
        list.sort((a, b) =>
            (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        final counts = <String, int>{};
        for (final p in list) {
          final n = (p['name'] ?? '').toString();
          if (n.isEmpty) continue;
          counts[n] = (counts[n] ?? 0) + 1;
        }
        var confSum = 0;
        var confN = 0;
        var sup = 0;
        for (final p in list) {
          final c = int.tryParse((p['confidence'] ?? '').toString());
          if (c != null) {
            confSum += c;
            confN++;
          }
          if (p['assessedBy'] == 'Supervisor assessed') sup++;
        }
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editProcedure(context),
            icon: const Icon(Icons.add),
            label: const Text('Log procedure'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              if (list.isNotEmpty) ...[
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Chip(label: Text(trp('{n} logged', {'n': list.length}))),
                    if (confN > 0)
                      Chip(label: Text(trp('Avg confidence {n}/5', {'n': (confSum / confN).toStringAsFixed(1)}))),
                    Chip(label: Text(trp('{n} supervisor assessed', {'n': sup}))),
                  ],
                ),
                const SizedBox(height: 4),
              ],
              if (counts.isNotEmpty) ...[
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final e in counts.entries) Chip(label: Text('${tr(e.key)}: ${e.value}')),
                  ],
                ),
                const SizedBox(height: 8),
              ],
              if (list.isEmpty)
                const EmptyState(
                  kind: EmptyKind.learn,
                  title: 'No procedures logged yet.',
                  message: 'Log every cannulation, suture or ABG with your role and confidence.',
                ),
              for (var i = 0; i < list.length; i++)
                FadeSlideIn(
                  key: ValueKey(list[i]['id']),
                  index: i,
                  child: AppCard(
                    child: ListTile(
                      onTap: () => editProcedure(context, list[i]),
                      title: Text(tr((list[i]['name'] ?? '').toString())),
                      subtitle: Text(
                        [
                          prettyDate((list[i]['date'] ?? '').toString()),
                          tr((list[i]['role'] ?? '').toString()),
                          if ((list[i]['confidence'] ?? '').toString().isNotEmpty)
                            trp('confidence {n}/5', {'n': list[i]['confidence']}),
                          if ((list[i]['assessedBy'] ?? '') == 'Supervisor assessed')
                            tr('supervisor'),
                          if ((list[i]['caseCode'] ?? '').toString().isNotEmpty)
                            '${list[i]['caseCode']}',
                        ].where((e) => e.isNotEmpty).join(' • '),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ notebook

Future<void> editNote(BuildContext context, [J? n]) async {
  final res = await showFormSheet(
  context,
    title: n == null ? 'New note' : 'Note',
    specs: const [
      FieldSpec('title', 'Title'),
      FieldSpec('body', 'What I learned', type: FT.multi),
      FieldSpec('tags', 'Tags (comma separated)', hint: 'cardiology, antibiotics'),
      FieldSpec('caseCode', 'Related case code (optional)'),
    ],
    initial: n ?? <String, dynamic>{'id': newId('n'), 'date': todayStr()},
    canDelete: n != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.notes, 'notes.json', n!['id'].toString());
  } else {
    await store.upsert(store.notes, 'notes.json', res);
  }
  }


class _NotebookTab extends StatefulWidget {
  const _NotebookTab();

  @override
  State<_NotebookTab> createState() => _NotebookTabState();
}

class _NotebookTabState extends State<_NotebookTab> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final q = _q.trim().toLowerCase();
        final list = store.notes.where((n) {
          if (q.isEmpty) return true;
          return '${n['title']} ${n['body']} ${n['tags']}'.toLowerCase().contains(q);
        }).toList();
        list.sort((a, b) =>
            (b['updated'] ?? '').toString().compareTo((a['updated'] ?? '').toString()));
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editNote(context),
            icon: const Icon(Icons.edit_note),
            label: const Text('New note'),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: tr('Search notes'),
                    isDense: true,
                  ),
                  onChanged: (v) => setState(() => _q = v),
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const EmptyState(
                        kind: EmptyKind.learn,
                        title: 'Your personal notebook',
                        message: 'Pearls, guidelines, doses, things the supervisor taught you.',
                      )
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 96),
                        children: [
                          for (var i = 0; i < list.length; i++)
                            FadeSlideIn(
                              key: ValueKey(list[i]['id']),
                              index: i,
                              child: AppCard(
                                child: ListTile(
                                  onTap: () => editNote(context, list[i]),
                                  title: Text((list[i]['title'] ?? '').toString().isEmpty
                                      ? '(untitled)'
                                      : list[i]['title'].toString()),
                                  subtitle: Text(
                                    (list[i]['body'] ?? '').toString(),
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ review

class _ReviewTab extends StatelessWidget {
  const _ReviewTab();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final all = store.casesSorted();
        final flagged = all.where((c) => c.review).toList();
        final withQuestions =
            all.where((c) => c.s('questions').trim().isNotEmpty).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
          children: [
            const SectionHeader('Cases flagged for review'),
            if (flagged.isEmpty)
              const EmptyState(
                kind: EmptyKind.generic,
                title: 'Nothing flagged',
                message: 'Use “To review later” inside a case.',
              ),
            for (var i = 0; i < flagged.length; i++) FadeSlideIn(index: i, child: CaseTile(flagged[i])),
            const SectionHeader('Open questions from my cases'),
            if (withQuestions.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text('No open questions.'),
              ),
            for (final c in withQuestions)
              AppCard(
                child: ListTile(
                  onTap: () => openCase(context, c),
                  title: Text('${c.s('code')} • ${c.title}',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(c.s('questions')),
                ),
              ),
          ],
        );
      },
    );
  }
}


// ================================================================ questions inbox

Future<void> editQuestion(BuildContext context, [J? q]) async {
  final res = await showFormSheet(
  context,
    title: q == null ? 'New question' : 'Question',
    specs: const [
      FieldSpec('question', 'Question', type: FT.multi),
      FieldSpec('status', 'Status', type: FT.choice, options: ['Open', 'Answered']),
      FieldSpec('answer', 'Answer', type: FT.multi),
      FieldSpec('reference', 'Reference (book, guideline, link)'),
      FieldSpec('caseCode', 'Related case code (optional)'),
    ],
    initial: q ?? <String, dynamic>{'id': newId('q'), 'date': todayStr(), 'status': 'Open'},
    canDelete: q != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.inbox, 'questions.json', q!['id'].toString());
  } else {
    await store.upsert(store.inbox, 'questions.json', res);
  }
  }



class _QuestionsTab extends StatefulWidget {
  const _QuestionsTab();

  @override
  State<_QuestionsTab> createState() => _QuestionsTabState();
}

class _QuestionsTabState extends State<_QuestionsTab> {
  bool _openOnly = true;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = store.inbox
            .where((q) => !_openOnly || (q['status'] ?? 'Open') != 'Answered')
            .toList()
          ..sort((a, b) =>
              (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => editQuestion(context),
            icon: const Icon(Icons.help_outline),
            label: const Text('Add question'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            children: [
              Row(
                children: [
                  FilterChip(
                    label: const Text('Open only'),
                    selected: _openOnly,
                    onSelected: (v) => setState(() => _openOnly = v),
                  ),
                ],
              ),
              if (list.isEmpty)
                const EmptyState(
                  kind: EmptyKind.learn,
                  title: 'Question inbox',
                  message: 'Write down every question you could not answer on the ward, '
                      'then answer it later and keep the reference.',
                ),
              for (var i = 0; i < list.length; i++)
                FadeSlideIn(
                  key: ValueKey(list[i]['id']),
                  index: i,
                  child: AppCard(
                    child: ListTile(
                      onTap: () => editQuestion(context, list[i]),
                      leading: Icon(
                        list[i]['status'] == 'Answered'
                            ? Icons.check_circle_outline
                            : Icons.help_outline,
                      ),
                      title: Text((list[i]['question'] ?? '').toString(),
                          maxLines: 3, overflow: TextOverflow.ellipsis),
                      subtitle: Text([
                        prettyDate((list[i]['date'] ?? '').toString()),
                        if ((list[i]['caseCode'] ?? '').toString().isNotEmpty)
                          '${list[i]['caseCode']}',
                        if ((list[i]['answer'] ?? '').toString().isNotEmpty) '${list[i]['answer']}',
                      ].where((e) => e.isNotEmpty).join('\n')),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
