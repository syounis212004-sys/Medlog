import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import 'ai/ai_cases.dart' show handoverText;
import 'data.dart';
import 'i18n.dart';
import 'ui.dart';
import 'widgets.dart';

/// The handover of a whole shift: the cases of the last two days that are not closed, each in the I-PASS form that the
/// case screen already writes, joined into one text to copy or share. Nothing is sent anywhere by the app.

/// Cases worth handing over: dated today or yesterday (or open drafts), not completed, newest first.
List<CaseRec> handoverCandidates({DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = fmtDate(n), yesterday = fmtDate(n.subtract(const Duration(days: 1)));
  final l = [
    for (final c in store.cases.values)
      if ((c.s('date') == today || c.s('date') == yesterday || c.s('status') == 'Draft') && c.s('status') != 'Completed' && !c.s('code').startsWith('DEMO')) c
  ];
  l.sort((a, b) => '${b.s('date')}${b.s('code')}'.compareTo('${a.s('date')}${a.s('code')}'));
  return l;
}

/// The text of the chosen cases, one I-PASS block each, with the duty line on top.
String shiftHandoverText(List<CaseRec> cases, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final b = StringBuffer();
  final shift = store.shiftFor(fmtDate(n));
  b.writeln('SHIFT HANDOVER • ${prettyDate(fmtDate(n))}${shift == null ? '' : ' • ${shift['type'] ?? 'Duty'}'} • ${cases.length} ${cases.length == 1 ? 'patient' : 'patients'}');
  for (var i = 0; i < cases.length; i++) {
    b.writeln('\n==== ${i + 1}/${cases.length} ====');
    b.writeln(handoverText(cases[i]));
  }
  return b.toString().trimRight();
}

class ShiftHandoverScreen extends StatefulWidget {
  const ShiftHandoverScreen({super.key});
  @override
  State<ShiftHandoverScreen> createState() => _ShiftHandoverScreenState();
}

class _ShiftHandoverScreenState extends State<ShiftHandoverScreen> {
  late final List<CaseRec> _all = handoverCandidates();
  late final Set<String> _on = {for (final c in _all) c.s('id')};

  List<CaseRec> get _chosen => [for (final c in _all) if (_on.contains(c.s('id'))) c];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text('Shift handover')),
      body: _all.isEmpty
          ? Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('No open cases from today or yesterday.', textAlign: TextAlign.center)))
          : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
              Text('Pick the patients to hand over. Each one is written as I-PASS (illness severity, patient summary, action list, situation awareness, synthesis).', style: theme.textTheme.bodySmall),
              const SizedBox(height: 4),
              Text('It has clinical details: send it only through the channel your hospital allows.', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.error)),
              const SizedBox(height: 8),
              for (final c in _all)
                AppCard(
                  child: CheckboxListTile(
                    key: ValueKey('ho_${c.s('id')}'),
                    value: _on.contains(c.s('id')),
                    onChanged: (v) => setState(() => v == true ? _on.add(c.s('id')) : _on.remove(c.s('id'))),
                    title: m.Text('${c.s('code')}${c.s('initials').isEmpty ? '' : ' • ${c.s('initials')}'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: m.Text([c.s('cc'), c.s('status')].where((e) => e.isNotEmpty).join(' • '), maxLines: 2, overflow: TextOverflow.ellipsis),
                  ),
                ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    key: const ValueKey('ho_copy'),
                    onPressed: _chosen.isEmpty
                        ? null
                        : () async {
                            await Clipboard.setData(ClipboardData(text: shiftHandoverText(_chosen)));
                            if (context.mounted) snack(context, tr('Copied.'));
                          },
                    icon: const Icon(Icons.copy_rounded),
                    label: Text('Copy'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _chosen.isEmpty ? null : () => Share.share(shiftHandoverText(_chosen)),
                    icon: const Icon(AppIcons.share),
                    label: Text('Share'),
                  ),
                ),
              ]),
            ]),
    );
  }
}
