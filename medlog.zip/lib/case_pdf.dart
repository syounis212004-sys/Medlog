import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'case_extras.dart';
import 'case_scores.dart';
import 'case_templates.dart';
import 'choices_engine.dart';
import 'data.dart';
import 'goals_signoff.dart' show isSigned, signCell;
import 'i18n.dart';
import 'pdf_export.dart' show clinStatusColor, clinStatusOf, clinStatusOnColor;
import 'plan_item.dart';

/// The case as a clinical document: real text (selectable, searchable), always in English, the sections in the order
/// of the rotation (assets/data/case_templates.json), nothing printed twice and no empty sections.
///
/// Two steps: [caseBlocks] turns a case into plain blocks (testable, English whatever the app language is), then
/// [buildCasePdf] draws the blocks with the pdf package.

// ---------------------------------------------------------------- blocks

abstract class CBlock {
  const CBlock();
}

class CBand extends CBlock {
  final String title, subtitle;
  final List<({String text, int bg, int fg})> pills;
  const CBand(this.title, this.subtitle, this.pills);
}

class CHeading extends CBlock {
  final String title;
  final int level; // 1 section, 2 sub heading
  const CHeading(this.title, {this.level = 1});
}

class CPara extends CBlock {
  final String label, text;
  final bool bold;
  const CPara(this.label, this.text, {this.bold = false});
}

/// A coloured box with lines. kind: red, amber, green, info.
class CBox extends CBlock {
  final String title, kind;
  final List<String> lines;
  const CBox(this.title, this.lines, {this.kind = 'info'});
}

class CTable extends CBlock {
  final List<String> head;
  final List<List<String>> rows;
  final List<double> weights;
  final Set<int> redRows;
  const CTable(this.head, this.rows, {this.weights = const [], this.redRows = const {}});
}

/// Facts shown two to a row: label, value.
class CPairs extends CBlock {
  final List<(String, String)> items;
  const CPairs(this.items);
}

class CImages extends CBlock {
  final List<({String path, String caption})> files;
  const CImages(this.files);
}

class CNewPage extends CBlock {
  const CNewPage();
}

/// Runs [f] with the app language forced to English: stored values and labels are English already, only tr() would
/// translate them. The previous setting is put back.
R inEnglish<R>(R Function() f) {
  final prev = langSetting;
  setLangSetting(kLangEn);
  try {
    return f();
  } finally {
    setLangSetting(prev);
  }
}

String _s(Object? v) => '${v ?? ''}'.trim();

// ---------------------------------------------------------------- sections

const Map<String, String> _vitalUnits = {
  'v_bp': 'BP (mmHg)',
  'v_hr': 'HR (bpm)',
  'v_temp': 'Temp (°C)',
  'v_rr': 'RR (/min)',
  'v_spo2': 'SpO2 (%)',
  'v_rbs': 'RBS (mg/dL)',
  'v_wt': 'Weight (kg)',
};

List<String> _lines(String s) {
  final out = <String>[];
  for (final raw in s.split(RegExp(r'[\n;]'))) {
    final t = raw.trim().replaceFirst(RegExp(r'^[\-•*]\s*'), '');
    if (t.isNotEmpty) out.add(t);
  }
  return out;
}

String _join(Iterable<String> a, [String sep = ' • ']) => a.where((e) => e.trim().isNotEmpty).join(sep);

CTable? _choiceTable(CaseChoices cc, String section, String title) {
  final rows = <List<String>>[
    for (final r in cc.lines(section: section))
      if (r.length > 1 && r[1].trim().isNotEmpty) [r[0], r[1], r.length > 2 ? r[2] : '']
  ];
  if (rows.isEmpty) return null;
  return CTable([title, 'Selection', 'Details'], rows, weights: const [1.5, 2.6, 1.6]);
}

/// Items the user flagged: the red flags text and every system marked Abnormal.
List<String> _flags(CaseRec c) {
  final out = <String>[..._lines(c.s('redFlags'))];
  final sys = c.d['sys'];
  if (sys is Map) {
    for (final e in sys.entries) {
      final v = e.value;
      if (v is Map && v['s'] == 'Abnormal') {
        final n = _s(v['n']);
        out.add('Abnormal ${e.key}${n.isEmpty ? '' : ': $n'}');
      }
    }
  }
  return out;
}

List<CBlock> _sec(CaseRec c, String id, {required String specialty}) {
  String s(String k) => c.s(k).trim();
  final cc = CaseChoices(c);
  final b = <CBlock>[];
  void h(String t, [int level = 1]) => b.add(CHeading(t, level: level));
  void sub(String label, String text) {
    if (text.trim().isEmpty) return;
    h(label, 2);
    b.add(CPara('', text));
  }

  switch (id) {
    case 'patient':
      final st = clinStatusOf(c);
      final pairs = <(String, String)>[
        ('Date', s('date')),
        ('Rotation', specialty),
        ('Age group', s('ageGroup')),
        ('Sex', s('sex')),
        ('Setting', s('setting')),
        ('Encounter', s('encounter')),
        ('Role', s('role')),
        ('Status at presentation', st),
      ].where((e) => e.$2.isNotEmpty).toList();
      if (pairs.isNotEmpty) {
        h('Patient and encounter');
        b.add(CPairs(pairs));
      }
      break;
    case 'cc':
      if (s('cc').isNotEmpty) {
        h('Chief complaint');
        final l = _lines(s('cc'));
        if (l.length > 1) {
          b.add(CBox('', l, kind: 'plain'));
        } else {
          b.add(CPara('', s('cc'), bold: true));
        }
      }
      break;
    case 'hpi':
      final t = _choiceTable(cc, 'History', 'Key history point');
      if (s('hpi').isNotEmpty || t != null) {
        h('History of presenting illness');
        if (s('hpi').isNotEmpty) b.add(CPara('', s('hpi')));
        if (t != null) b.add(t);
      }
      break;
    case 'ros':
      sub('Review of systems', s('ros'));
      break;
    case 'pmh':
      sub('Past medical history', s('pmh'));
      break;
    case 'psh':
      sub('Past surgical history', s('psh'));
      break;
    case 'meds':
      if (s('drugs').isNotEmpty) sub('Drug history', s('drugs'));
      // allergies are a safety item: always stated
      b.add(CBox('Allergies', [s('allergies').isEmpty ? 'Not documented' : s('allergies')], kind: s('allergies').isEmpty ? 'info' : 'amber'));
      break;
    case 'family':
      sub('Family history', s('family'));
      break;
    case 'social':
      sub('Social and functional history', s('social'));
      break;
    case 'spec':
      final f = specialtySplit(c.s('specialty')).history.where((f) => s(f[0]).isNotEmpty).toList();
      if (f.isNotEmpty) {
        h('${specialty.isEmpty ? 'Rotation' : specialty}: specific history');
        for (final x in f) {
          b.add(CPara(x[1], s(x[0])));
        }
      }
      break;
    case 'exam':
      final vit = _vitalUnits.keys.where((k) => s(k).isNotEmpty).toList();
      final adult = s('ageGroup') == 'Adult';
      final sys = c.d['sys'];
      final sysRows = <List<String>>[];
      final red = <int>{};
      if (sys is Map) {
        for (final e in sys.entries) {
          final v = e.value;
          if (v is Map && (_s(v['s']).isNotEmpty || _s(v['n']).isNotEmpty)) {
            if (v['s'] == 'Abnormal') red.add(sysRows.length);
            sysRows.add(['${e.key}', _s(v['s']), _s(v['n'])]);
          }
        }
      }
      final t = _choiceTable(cc, 'Examination', 'Examination point');
      final hasText = ['examGeneral', 'examSystemic', 'examFocused'].any((k) => s(k).isNotEmpty);
      if (vit.isNotEmpty || sysRows.isNotEmpty || hasText || t != null) {
        h('Examination');
        if (vit.isNotEmpty) {
          b.add(CTable([for (final k in vit) _vitalUnits[k]!], [
            [for (final k in vit) s(k)]
          ]));
          final bad = [for (final k in vit) if (vitalAbnormal(k, s(k), adult)) _vitalUnits[k]!.split(' ').first];
          if (bad.isNotEmpty) b.add(CPara('Abnormal vital signs', bad.join(', ')));
        }
        b.add(CPara('General', s('examGeneral')));
        b.add(CPara('Systemic', s('examSystemic')));
        b.add(CPara('Focused', s('examFocused')));
        final src = _join([
          if (s('obsGeneral').isNotEmpty) 'general: ${s('obsGeneral')}',
          if (s('obsSystemic').isNotEmpty) 'systemic: ${s('obsSystemic')}',
          if (s('obsFocused').isNotEmpty) 'focused: ${s('obsFocused')}',
        ], '; ');
        if (src.isNotEmpty) b.add(CPara('Findings obtained', src));
        if (sysRows.isNotEmpty) b.add(CTable(['System', 'State', 'Notes'], sysRows, weights: const <double>[1.1, 1, 2.4], redRows: red));
        if (t != null) b.add(t);
      }
      break;
    case 'specx':
      final f = specialtySplit(c.s('specialty')).exam.where((f) => s(f[0]).isNotEmpty).toList();
      if (f.isNotEmpty) {
        h('${specialty.isEmpty ? 'Rotation' : specialty}: specific findings');
        for (final x in f) {
          b.add(CPara(x[1], s(x[0])));
        }
      }
      break;
    case 'inv':
      final inv = c.lst('inv');
      final t = _choiceTable(cc, 'Investigations', 'Investigation');
      final ls = labSeries(c);
      final images = c.lst('images');
      final linked = {for (final i in inv) '${i['id']}'};
      final loose = [
        for (final im in images)
          if (_s(im['file']).isNotEmpty && !linked.contains('${im['inv']}')) im
      ];
      if (inv.isNotEmpty || t != null || ls.isNotEmpty || loose.isNotEmpty) {
        h('Investigations');
        if (inv.isNotEmpty) {
          b.add(CTable(
            ['Test', 'Status', 'Result', 'Interpretation'],
            [
              for (final i in inv) [_s(i['name']), _s(i['status']), _s(i['result']), _s(i['interpretation'])]
            ],
            weights: const <double>[1.4, 0.9, 1.9, 2],
          ));
          // the photo of a result goes under the table, named by its test
          for (final i in inv) {
            final pics = [
              for (final im in images)
                if ('${im['inv']}' == '${i['id']}' && _s(im['file']).isNotEmpty) (path: store.imagePath(_s(im['file'])), caption: _s(i['name']))
            ];
            if (pics.isNotEmpty) b.add(CImages(pics));
          }
        }
        if (t != null) b.add(t);
        if (ls.isNotEmpty) {
          h('Laboratory trends', 2);
          b.add(CTable(
            ['Test', 'Results (oldest to newest)', 'Unit'],
            [
              for (final x in ls)
                [x.test, x.readings.map((r) => r.value == r.value.roundToDouble() ? r.value.toStringAsFixed(0) : r.value.toString()).join('  >  '), x.unit]
            ],
            weights: const <double>[1.2, 3, 1],
          ));
        }
        if (loose.isNotEmpty) {
          h('Images', 2);
          b.add(CImages([
            for (final im in loose)
              (
                path: store.imagePath(_s(im['file'])),
                caption: _join([for (final k in ['type', 'view', 'caption', 'date']) _s(im[k])])
              )
          ]));
        }
      }
      break;
    case 'assess':
      final flags = _flags(c);
      final pl = problemsSorted(c);
      final evo = c.lst('evo');
      final sc = scoresOf(c);
      final t = _choiceTable(cc, 'Assessment', 'Assessment point');
      final any = flags.isNotEmpty ||
          ['problems', 'ddx', 'workingDx', 'finalDx', 'reasoning'].any((k) => s(k).isNotEmpty) ||
          pl.isNotEmpty ||
          evo.isNotEmpty ||
          sc.isNotEmpty ||
          t != null;
      if (any) {
        h('Assessment');
        if (flags.isNotEmpty) b.add(CBox('Red flags', flags, kind: 'red'));
        b.add(CPara('Problem list', s('problems')));
        if (pl.isNotEmpty) {
          b.add(CTable(['Problem', 'Status', 'Since'], [for (final p in pl) [_s(p['text']), _s(p['status']) == 'resolved' ? 'Resolved' : 'Active', _s(p['since'])]], weights: const <double>[3, 1, 1]));
        }
        b.add(CPara('Differential diagnosis', s('ddx')));
        b.add(CPara('Working diagnosis', s('workingDx'), bold: true));
        b.add(CPara('Final diagnosis', s('finalDx'), bold: true));
        b.add(CPara('Reasoning', s('reasoning')));
        if (evo.isNotEmpty) {
          b.add(CTable(['Step', 'Date', 'Diagnosis', 'Because'], [for (final e in evo) [_s(e['step']), _s(e['date']), _s(e['text']), _s(e['evidence'])]], weights: const <double>[1.1, 1, 2, 2]));
        }
        if (t != null) b.add(t);
        if (sc.isNotEmpty) {
          b.add(CTable(['Score', 'Result', 'Chosen', 'Date'], [for (final x in sc) [x.name, _join([x.value, x.meaning], '\n'), x.items.join('; '), '${x.date} ${x.time}'.trim()]], weights: const <double>[1.6, 1.6, 2.6, 1.1]));
        }
      }
      break;
    case 'mgmt':
      final inH = planInHospital(c), home = planTakeHome(c);
      final t = _choiceTable(cc, 'Management', 'Management point');
      List<List<String>> rows(List<J> l) => [
            for (final m in l)
              if (_s(m['text']).isNotEmpty)
                [_s(m['text']), _s(m['dose']), _s(m['category']), _join([_s(m['by']), _s(m['state'])], ' • ')]
          ];
      final r1 = rows(inH), r2 = rows(home);
      if (r1.isNotEmpty || r2.isNotEmpty || t != null) {
        h('Management plan');
        const head = ['Plan item', 'Details (dose, route, frequency, duration)', 'Type', 'By / status'];
        const w = <double>[2, 2.4, 1.2, 1.2];
        if (r1.isNotEmpty) {
          if (r2.isNotEmpty) h('In hospital', 2);
          b.add(CTable(head, r1, weights: w));
        }
        if (r2.isNotEmpty) {
          h('Take-home (at discharge)', 2);
          b.add(CTable(head, r2, weights: w));
        }
        if (t != null) b.add(t);
      }
      break;
    case 'progress':
      final pr = c.lst('progress');
      if (pr.isNotEmpty) {
        h('Progress and reassessment');
        b.add(CTable(['Day', 'Subjective', 'Objective', 'Assessment', 'Plan'], [for (final p in pr) [_join([_s(p['day']), _s(p['date'])], '\n'), _s(p['s']), _s(p['o']), _s(p['a']), _s(p['p'])]], weights: const <double>[1.2, 2, 2, 2, 2]));
      }
      break;
    case 'outcome':
      if (['disposition', 'outcome', 'outcomeCat', 'followUp'].any((k) => s(k).isNotEmpty)) {
        h('Outcome, disposition and follow-up');
        b.add(CPara('Disposition', s('disposition')));
        b.add(CPara('Outcome status', s('outcomeCat'), bold: true));
        b.add(CPara('Outcome', s('outcome')));
        b.add(CPara('Follow-up', s('followUp')));
      }
      break;
    case 'learning':
      final any = ['initialDx', 'whatChanged', 'learned', 'mistakes', 'questions', 'teaching', 'refs'].any((k) => s(k).isNotEmpty);
      if (any) {
        h('Learning points');
        b.add(CPara('First diagnosis (before results)', s('initialDx')));
        b.add(CPara('What changed the diagnosis', s('whatChanged')));
        if (_lines(s('learned')).isNotEmpty) b.add(CBox('What I learned', _lines(s('learned')), kind: 'green'));
        if (_lines(s('mistakes')).isNotEmpty) b.add(CBox('Mistakes and near-misses', _lines(s('mistakes')), kind: 'amber'));
        if (_lines(s('questions')).isNotEmpty) b.add(CBox('Questions to review', _lines(s('questions'))));
        b.add(CPara('Supervisor teaching', s('teaching')));
        b.add(CPara('References', s('refs')));
      }
      break;
  }
  return b;
}

CBand _band(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final st = clinStatusOf(c);
  const tag = 0xFF3E5C86;
  final dx = s('finalDx').isNotEmpty ? s('finalDx') : s('workingDx');
  final pills = <({String text, int bg, int fg})>[
    if (st.isNotEmpty) (text: st, bg: clinStatusColor(st).toARGB32(), fg: clinStatusOnColor(st).toARGB32()),
    if (s('status').isNotEmpty) (text: s('status'), bg: tag, fg: 0xFFFFFFFF),
    if (s('disposition').isNotEmpty) (text: s('disposition'), bg: tag, fg: 0xFFFFFFFF),
  ];
  return CBand(
    'Case ${s('code')}${dx.isEmpty ? '' : '  -  $dx'}',
    _join([specialty, s('date'), _join([s('ageGroup'), s('sex')], ' '), s('setting'), s('encounter')]),
    pills,
  );
}

/// Which sections have something to print, in the order of the rotation.
List<String> caseSectionOrder(CaseRec c) {
  final ids = CaseTemplates.idsFor(c.s('specialty'));
  final present = [for (final id in kCanonicalSectionIds) if (_sec(c, id, specialty: '').isNotEmpty) id];
  final order = CaseTemplates.completeOrder(ids, present);
  return [for (final id in order) if (present.contains(id)) id];
}

/// "Full" is the whole case in the order of its rotation; "meeting" is a one-page presentation (summary, narrowed
/// differential, analysis, plan, question for self-study); "summary" keeps the key stages.
const List<String> kCaseFormats = ['full', 'meeting', 'summary'];

List<CBlock> caseBlocks(CaseRec c, {String format = 'full', bool signOff = false}) => inEnglish(() {
      String s(String k) => c.s(k).trim();
      final specialty = CaseTemplates.rotationName(s('specialty'));
      final out = <CBlock>[_band(c, specialty)];
      if (format == 'meeting') {
        out.addAll(_meeting(c, specialty));
      } else if (format == 'summary') {
        out.addAll(_summary(c, specialty));
      } else {
        for (final id in caseSectionOrder(c)) {
          out.addAll(_sec(c, id, specialty: specialty));
        }
      }
      out.addAll(_signOff(c, signOff));
      return out;
    });

List<CBlock> _signOff(CaseRec c, bool signOff) {
  if (!signOff) return const [];
  final b = <CBlock>[const CHeading('Supervisor sign-off')];
  if (isSigned(c.d)) {
    b.add(CPara('Supervisor', signCell(c.d).replaceAll('\n', '  -  ')));
    if (c.s('supLevel').trim().isNotEmpty) b.add(CPara('Level of supervision', c.s('supLevel').trim()));
  } else {
    b.add(const CTable(['Supervisor name', 'Role', 'Signature or initials', 'Date'], [
      ['\n\n', '', '', '']
    ]));
  }
  return b;
}

String _firstSentences(String t, int max) {
  final x = t.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (x.length <= max) return x;
  final cut = x.substring(0, max);
  final dot = cut.lastIndexOf(RegExp(r'[.!?]'));
  return dot > max ~/ 2 ? cut.substring(0, dot + 1) : '${cut.trimRight()}...';
}

String _vitalsLine(CaseRec c) => [
      for (final k in _vitalUnits.keys)
        if (c.s(k).trim().isNotEmpty) '${_vitalUnits[k]!.split(' ').first} ${c.s(k).trim()}'
    ].join(', ');

List<CBlock> _plan(CaseRec c) {
  final rows = [
    for (final m in c.lst('mgmt'))
      if (_s(m['text']).isNotEmpty) [_s(m['text']), _s(m['dose']), _s(m['setting']) == kTakeHome ? 'Take-home' : 'Hospital']
  ];
  return rows.isEmpty ? const [] : [CTable(const ['Plan item', 'Details', 'Where'], rows, weights: const [2.2, 2.6, 1.0])];
}

List<CBlock> _meeting(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final b = <CBlock>[];
  final who = _join([s('ageGroup'), s('sex')], ' ');
  final where = _join([s('setting'), s('encounter')], ', ');
  final abn = [
    for (final e in (c.d['sys'] is Map ? (c.d['sys'] as Map).entries : const <MapEntry>[]))
      if (e.value is Map && (e.value as Map)['s'] == 'Abnormal') '${e.key}${_s((e.value as Map)['n']).isEmpty ? '' : ' (${_s((e.value as Map)['n'])})'}'
  ];
  final inv = [
    for (final i in c.lst('inv'))
      if (_s(i['name']).isNotEmpty && _s(i['result']).isNotEmpty) '${i['name']}: ${i['result']}'
  ];
  b.add(const CHeading('Summary'));
  b.add(CPara('', _join([
    _join([who.isEmpty ? '' : who, where.isEmpty ? '' : 'seen in $where'], ' '),
    if (s('cc').isNotEmpty) 'Presenting with ${_lines(s('cc')).join('; ')}.',
  ], '. ')));
  if (s('hpi').isNotEmpty) b.add(CPara('History', _firstSentences(s('hpi'), 520)));
  final bg = _join([s('pmh'), s('drugs').isEmpty ? '' : 'Drugs: ${s('drugs')}'], '. ');
  if (bg.isNotEmpty) b.add(CPara('Background', _firstSentences(bg, 260)));
  if (s('allergies').isNotEmpty) b.add(CPara('Allergies', s('allergies')));
  final vit = _vitalsLine(c);
  if (vit.isNotEmpty) b.add(CPara('Vital signs', vit));
  if (abn.isNotEmpty) b.add(CPara('Abnormal findings', abn.join('; ')));
  if (s('examFocused').isNotEmpty) b.add(CPara('Focused examination', _firstSentences(s('examFocused'), 240)));
  if (inv.isNotEmpty) b.add(CPara('Key investigations', inv.take(6).join('; ')));
  final flags = _flags(c);
  if (flags.isNotEmpty) b.add(CBox('Red flags', flags, kind: 'red'));
  if (s('ddx').isNotEmpty || s('workingDx').isNotEmpty) {
    b.add(const CHeading('Narrowed differential'));
    b.add(CPara('Differential', s('ddx')));
    b.add(CPara('Working diagnosis', s('workingDx'), bold: true));
    b.add(CPara('Final diagnosis', s('finalDx'), bold: true));
  } else if (s('finalDx').isNotEmpty) {
    b.add(const CHeading('Diagnosis'));
    b.add(CPara('Final diagnosis', s('finalDx'), bold: true));
  }
  if (s('reasoning').isNotEmpty) {
    b.add(const CHeading('Analysis'));
    b.add(CPara('', _firstSentences(s('reasoning'), 700)));
  }
  final plan = _plan(c);
  if (plan.isNotEmpty) {
    b.add(const CHeading('Plan'));
    b.addAll(plan);
  }
  if (_lines(s('questions')).isNotEmpty) b.add(CBox('Question for self-study', _lines(s('questions'))));
  return b;
}

List<CBlock> _summary(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final b = <CBlock>[];
  final pat = _sec(c, 'patient', specialty: specialty);
  b.addAll(pat);
  if (s('cc').isNotEmpty) b.add(CPara('Chief complaint', s('cc'), bold: true));
  if (s('hpi').isNotEmpty) b.add(CPara('History', _firstSentences(s('hpi'), 600)));
  final vit = _vitalsLine(c);
  if (vit.isNotEmpty) b.add(CPara('Vital signs', vit));
  final ass = _sec(c, 'assess', specialty: specialty);
  b.addAll(ass);
  final plan = _plan(c);
  if (plan.isNotEmpty) {
    b.add(const CHeading('Management plan'));
    b.addAll(plan);
  }
  b.addAll(_sec(c, 'outcome', specialty: specialty));
  b.addAll(_sec(c, 'learning', specialty: specialty));
  return b;
}

// ---------------------------------------------------------------- drawing

const PdfColor _navy = PdfColor.fromInt(0xFF1F3A5F);
const PdfColor _teal = PdfColor.fromInt(0xFF0F766E);
const PdfColor _muted = PdfColor.fromInt(0xFF5B6573);
const PdfColor _line = PdfColor.fromInt(0xFFD5DAE1);
const PdfColor _zebra = PdfColor.fromInt(0xFFF4F6FA);
const PdfColor _red = PdfColor.fromInt(0xFFC62828);

class _Style {
  final PdfColor ink, bg;
  const _Style(this.ink, this.bg);
}

_Style _boxStyle(String kind) => switch (kind) {
      'red' => const _Style(_red, PdfColor.fromInt(0xFFFDECEC)),
      'amber' => const _Style(PdfColor.fromInt(0xFF8A5A00), PdfColor.fromInt(0xFFFFF4DC)),
      'green' => const _Style(PdfColor.fromInt(0xFF2E7D32), PdfColor.fromInt(0xFFE8F5E9)),
      'plain' => const _Style(_navy, PdfColor.fromInt(0xFFF4F6FA)),
      _ => const _Style(_navy, PdfColor.fromInt(0xFFEAF1FA)),
    };

/// A photo scaled down (long side 900 px) and re-encoded: a phone photo is several megabytes.
Future<pw.MemoryImage?> _loadImage(String path) async {
  try {
    final f = File(path);
    if (!await f.exists()) return null;
    final bytes = await f.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: 900);
    final frame = await codec.getNextFrame();
    final data = await frame.image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return null;
    return pw.MemoryImage(data.buffer.asUint8List());
  } catch (_) {
    return null;
  }
}

Future<pw.Font> _font(String asset) async => pw.Font.ttf(await rootBundle.load(asset));

pw.Widget _cell(String t, {bool head = false, bool red = false, bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 3.5),
      child: pw.Text(t, style: pw.TextStyle(fontSize: 8.8, fontWeight: head || red || bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: head ? PdfColors.white : (red ? _red : PdfColors.black))),
    );

pw.Widget _table(CTable t) {
  final n = t.head.length;
  final w = t.weights.length == n ? t.weights : List<double>.filled(n, 1);
  return pw.Padding(
    padding: const pw.EdgeInsets.only(top: 3, bottom: 6),
    child: pw.Table(
      border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: _line, width: 0.5), bottom: pw.BorderSide(color: _line, width: 0.5)),
      columnWidths: {for (var i = 0; i < n; i++) i: pw.FlexColumnWidth(w[i])},
      children: [
        pw.TableRow(repeat: true, decoration: const pw.BoxDecoration(color: _navy), children: [for (final h in t.head) _cell(h, head: true)]),
        for (var r = 0; r < t.rows.length; r++)
          pw.TableRow(
            decoration: r.isOdd ? const pw.BoxDecoration(color: _zebra) : null,
            children: [for (var i = 0; i < n; i++) _cell(i < t.rows[r].length ? t.rows[r][i] : '', red: t.redRows.contains(r))],
          ),
      ],
    ),
  );
}

pw.Widget _box(CBox b) {
  final st = _boxStyle(b.kind);
  return pw.Container(
    width: double.infinity,
    margin: const pw.EdgeInsets.only(top: 3, bottom: 6),
    padding: const pw.EdgeInsets.fromLTRB(9, 6, 9, 6),
    decoration: pw.BoxDecoration(color: st.bg, border: pw.Border(left: pw.BorderSide(color: st.ink, width: 3))),
    child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      if (b.title.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(bottom: 2), child: pw.Text(b.title, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: st.ink))),
      for (final l in b.lines) pw.Padding(padding: const pw.EdgeInsets.only(top: 1), child: pw.Text(b.lines.length > 1 || b.kind != 'plain' ? '-  $l' : l, style: const pw.TextStyle(fontSize: 10))),
    ]),
  );
}

pw.Widget _heading(CHeading h) {
  if (h.level == 2) {
    return pw.Padding(padding: const pw.EdgeInsets.only(top: 6, bottom: 1.5), child: pw.Text(h.title, style: pw.TextStyle(fontSize: 10.2, fontWeight: pw.FontWeight.bold, color: _teal)));
  }
  return pw.Padding(
    padding: const pw.EdgeInsets.only(top: 11, bottom: 4),
    child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text(h.title, style: pw.TextStyle(fontSize: 12.5, fontWeight: pw.FontWeight.bold, color: _navy)),
      pw.SizedBox(height: 2),
      pw.Container(height: 1.1, color: _teal),
    ]),
  );
}

pw.Widget _para(CPara p) => pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 3.5),
      child: pw.RichText(
        text: pw.TextSpan(style: const pw.TextStyle(fontSize: 10, lineSpacing: 1.6), children: [
          if (p.label.isNotEmpty) pw.TextSpan(text: '${p.label}: ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: _navy)),
          pw.TextSpan(text: p.text, style: p.bold ? pw.TextStyle(fontWeight: pw.FontWeight.bold) : null),
        ]),
      ),
    );

pw.Widget _pairs(CPairs p) {
  final rows = <pw.TableRow>[];
  for (var i = 0; i < p.items.length; i += 2) {
    pw.Widget cell(int k) => k < p.items.length
        ? pw.Padding(
            padding: const pw.EdgeInsets.symmetric(vertical: 2.5, horizontal: 4),
            child: pw.RichText(text: pw.TextSpan(style: const pw.TextStyle(fontSize: 9.5), children: [
              pw.TextSpan(text: '${p.items[k].$1}: ', style: pw.TextStyle(color: _muted, fontWeight: pw.FontWeight.bold)),
              pw.TextSpan(text: p.items[k].$2),
            ])))
        : pw.SizedBox();
    rows.add(pw.TableRow(children: [cell(i), cell(i + 1)]));
  }
  return pw.Padding(
    padding: const pw.EdgeInsets.only(bottom: 4),
    child: pw.Table(border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: _line, width: 0.4), bottom: pw.BorderSide(color: _line, width: 0.4), top: pw.BorderSide(color: _line, width: 0.4)), children: rows),
  );
}

pw.Widget _bandWidget(CBand b) => pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 4),
      padding: const pw.EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: const pw.BoxDecoration(color: _navy, borderRadius: pw.BorderRadius.all(pw.Radius.circular(6))),
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(b.title, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
        if (b.subtitle.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text(b.subtitle, style: const pw.TextStyle(fontSize: 9.5, color: PdfColor.fromInt(0xFFD7E2F2)))),
        if (b.pills.isNotEmpty)
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 7),
            child: pw.Wrap(spacing: 5, runSpacing: 4, children: [
              for (final p in b.pills)
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: pw.BoxDecoration(color: PdfColor.fromInt(p.bg), borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8))),
                  child: pw.Text(p.text, style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold, color: PdfColor.fromInt(p.fg))),
                ),
            ]),
          ),
      ]),
    );

/// The PDF of one or many cases. With several cases a summary table comes first and every case starts on a new page.
Future<Uint8List> buildCasePdf(List<CaseRec> cases, {String? title, String format = 'full', bool signOff = false}) async {
  await CaseTemplates.ensureLoaded();
  final perCase = [for (final c in cases) caseBlocks(c, format: format, signOff: signOff)];
  final blocks = <CBlock>[];
  if (cases.length > 1) {
    inEnglish(() {
      blocks.add(CBand(title ?? 'Cases', '${cases.length} cases', const []));
      blocks.add(const CHeading('Summary'));
      blocks.add(CTable(
        ['Date', 'Code', 'Rotation', 'Diagnosis', 'Status at presentation', if (signOff) 'Supervisor sign-off'],
        [
          for (final c in cases)
            [c.s('date'), c.s('code'), CaseTemplates.rotationName(c.s('specialty')), c.title, clinStatusOf(c), if (signOff) signCell(c.d)]
        ],
        weights: signOff ? const <double>[1.2, 1.2, 1.4, 2, 1.2, 1.8] : const <double>[1.3, 1.3, 1.6, 2.4, 1.5],
      ));
    });
    blocks.add(const CNewPage());
  }
  for (var i = 0; i < perCase.length; i++) {
    blocks.addAll(perCase[i]);
    if (i < perCase.length - 1) blocks.add(const CNewPage());
  }

  final tinos = await _font('assets/fonts/Tinos_400Regular.ttf');
  final tinosBold = await _font('assets/fonts/Tinos_700Bold.ttf');
  final cairo = await _font('assets/fonts/Cairo_400Regular.ttf');
  final cairoBold = await _font('assets/fonts/Cairo_700Bold.ttf');
  final images = <String, pw.MemoryImage?>{};
  for (final b in blocks) {
    if (b is CImages) {
      for (final f in b.files) {
        images[f.path] ??= await _loadImage(f.path);
      }
    }
  }

  pw.Widget imagesWidget(CImages b) => pw.Padding(
        padding: const pw.EdgeInsets.only(top: 3, bottom: 6),
        child: pw.Wrap(spacing: 8, runSpacing: 8, children: [
          for (final f in b.files)
            if (images[f.path] != null)
              pw.SizedBox(
                width: 150,
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Container(decoration: pw.BoxDecoration(border: pw.Border.all(color: _line, width: 0.5)), child: pw.Image(images[f.path]!, width: 150, fit: pw.BoxFit.contain)),
                  if (f.caption.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 2), child: pw.Text(f.caption, style: const pw.TextStyle(fontSize: 8, color: _muted))),
                ]),
              ),
        ]),
      );

  // a label without text is never printed
  blocks.removeWhere((b) => b is CPara && b.text.trim().isEmpty);
  final widgets = <pw.Widget>[];
  for (var i = 0; i < blocks.length; i++) {
    final b = blocks[i];
    if (b is CNewPage) {
      widgets.add(pw.NewPage());
    } else if (b is CBand) {
      widgets.add(_bandWidget(b));
    } else if (b is CHeading) {
      // a heading is kept with what follows it when that is short, so it never ends a page alone
      final next = i + 1 < blocks.length ? blocks[i + 1] : null;
      if (next is CPara || next is CBox || next is CPairs) {
        widgets.add(pw.Container(
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            _heading(b),
            if (next is CPara) _para(next) else if (next is CBox) _box(next) else _pairs(next as CPairs),
          ]),
        ));
        i++;
      } else {
        widgets.add(_heading(b));
      }
    } else if (b is CPara) {
      widgets.add(_para(b));
    } else if (b is CBox) {
      widgets.add(_box(b));
    } else if (b is CTable) {
      widgets.add(_table(b));
    } else if (b is CPairs) {
      widgets.add(_pairs(b));
    } else if (b is CImages) {
      widgets.add(imagesWidget(b));
    }
  }
  widgets.add(pw.Padding(
    padding: const pw.EdgeInsets.only(top: 14),
    child: pw.Text('SharqMed adds no patient names or ID numbers. Check the text before you share.', style: const pw.TextStyle(fontSize: 8, color: _muted)),
  ));

  final footerLeft = cases.length == 1 ? 'SharqMed  -  case ${cases.first.s('code')}' : 'SharqMed  -  case file';
  final doc = pw.Document(title: title ?? (cases.length == 1 ? 'Case ${cases.first.s('code')}' : 'SharqMed cases'), author: 'SharqMed', creator: 'SharqMed');
  doc.addPage(pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.fromLTRB(36, 34, 36, 40),
      theme: pw.ThemeData.withFont(base: tinos, bold: tinosBold, italic: tinos, boldItalic: tinosBold, fontFallback: [cairo, cairoBold]),
    ),
    build: (_) => widgets,
    footer: (ctx) => pw.Padding(
      padding: const pw.EdgeInsets.only(top: 6),
      child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text(footerLeft, style: const pw.TextStyle(fontSize: 8, color: _muted)),
        pw.Text('Page ${ctx.pageNumber} / ${ctx.pagesCount}', style: pw.TextStyle(fontSize: 8, color: _navy, fontWeight: pw.FontWeight.bold)),
      ]),
    ),
  ));
  return Uint8List.fromList(await doc.save());
}

Future<File> writeCasePdf(List<CaseRec> cases, {String? title, String fileName = 'SharqMed', String format = 'full', bool signOff = false}) async {
  final bytes = await buildCasePdf(cases, title: title, format: format, signOff: signOff);
  final dir = await getTemporaryDirectory();
  final f = File('${dir.path}/$fileName.pdf');
  await f.writeAsBytes(bytes, flush: true);
  return f;
}
