import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'case_extras.dart';
import 'case_scores.dart';
import 'case_narrative.dart';
import 'case_story.dart';
import 'case_templates.dart';
import 'choices_engine.dart';
import 'data.dart';
import 'goals_signoff.dart' show isSigned, signCell;
import 'i18n.dart';
import 'pdf_export.dart' show clinStatusColor, clinStatusOf, clinStatusOnColor;
import 'plan_item.dart';

/// The case as a clinical document: real text (selectable, searchable), always in English, the sections in the order
/// of the rotation (assets/data/case_templates.json), nothing printed twice and no empty sections.
///
/// Two steps: [caseBlocks] turns a case into plain blocks (testable, English whatever the app language is), then
/// [buildCasePdf] draws the blocks with the pdf package.

// ---------------------------------------------------------------- blocks

abstract class CBlock {
  const CBlock();
}

class CBand extends CBlock {
  final String title, subtitle;
  final List<({String text, int bg, int fg})> pills;
  const CBand(this.title, this.subtitle, this.pills);
}

class CHeading extends CBlock {
  final String title;
  final int level; // 1 section, 2 sub heading
  const CHeading(this.title, {this.level = 1});
}

class CPara extends CBlock {
  final String label, text;
  final bool bold;
  const CPara(this.label, this.text, {this.bold = false});
}

/// A coloured box with lines. kind: red, amber, green, info.
class CBox extends CBlock {
  final String title, kind;
  final List<String> lines;
  const CBox(this.title, this.lines, {this.kind = 'info'});
}

class CTable extends CBlock {
  final List<String> head;
  final List<List<String>> rows;
  final List<double> weights;
  final Set<int> redRows;
  final bool showHead;

  /// A form to fill in by hand keeps its empty columns.
  final bool keepEmpty;
  const CTable(this.head, this.rows, {this.weights = const [], this.redRows = const {}, this.showHead = true, this.keepEmpty = false});
}

/// Facts shown two to a row: label, value.
class CPairs extends CBlock {
  final List<(String, String)> items;
  const CPairs(this.items);
}

class CImages extends CBlock {
  final List<({String path, String caption})> files;
  const CImages(this.files);
}

class CNewPage extends CBlock {
  const CNewPage();
}

/// Runs [f] with the app language forced to English: stored values and labels are English already, only tr() would
/// translate them. The previous setting is put back.
R inEnglish<R>(R Function() f) {
  final prev = langSetting;
  setLangSetting(kLangEn);
  try {
    return f();
  } finally {
    setLangSetting(prev);
  }
}

String _s(Object? v) => '${v ?? ''}'.trim();

// ---------------------------------------------------------------- sections

const Map<String, String> _vitalUnits = {
  'v_bp': 'BP (mmHg)',
  'v_hr': 'HR (bpm)',
  'v_temp': 'Temp (°C)',
  'v_rr': 'RR (/min)',
  'v_spo2': 'SpO2 (%)',
  'v_rbs': 'RBS (mg/dL)',
  'v_wt': 'Weight (kg)',
};

List<String> _lines(String s) {
  final out = <String>[];
  for (final raw in s.split(RegExp(r'[\n;]'))) {
    final t = raw.trim().replaceFirst(RegExp(r'^[\-•*]\s*'), '');
    if (t.isNotEmpty) out.add(t);
  }
  return out;
}

String _join(Iterable<String> a, [String sep = ' • ']) => a.where((e) => e.trim().isNotEmpty).join(sep);

/// The answers of the quick questions of one section as sentences: one paragraph for the specialty's own questions and
/// one under a small heading for each complaint added to the case ("Cellulitis: The onset was sudden. The site is foot ...").
List<CBlock>? _choiceTable(CaseChoices cc, String section, String title) {
  final all = cc.entries(section: section);
  if (all.isEmpty) return null;
  final out = <CBlock>[];
  void add(String heading, List<({String label, String group, List<String> values, String details})> es) {
    // findings read better one to a line; the history reads as running text
    final answers = [for (final e in es) (label: e.label, values: e.values, details: e.details)];
    final text = section == 'History' ? storyOf(answers) : paragraphOf(answers, sep: section == 'Examination' ? '\n' : ' ');
    if (text.isEmpty) return;
    if (heading.isNotEmpty) out.add(CHeading(heading, level: 2));
    out.add(CPara('', text));
  }

  add('', [for (final e in all) if (e.group.isEmpty) e]);
  final groups = <String>[];
  for (final e in all) {
    if (e.group.isNotEmpty && !groups.contains(e.group)) groups.add(e.group);
  }
  for (final g in groups) {
    add(g, [for (final e in all) if (e.group == g) e]);
  }
  return out.isEmpty ? null : out;
}

/// Items the user flagged: the red flags text and every system marked Abnormal.
List<String> _flags(CaseRec c) {
  final out = <String>[..._lines(c.s('redFlags'))];
  final sys = c.d['sys'];
  if (sys is Map) {
    for (final e in sys.entries) {
      final v = e.value;
      if (v is Map && v['s'] == 'Abnormal') {
        final n = _s(v['n']);
        out.add('Abnormal ${e.key}${n.isEmpty ? '' : ': $n'}');
      }
    }
  }
  return out;
}

List<CBlock> _sec(CaseRec c, String id, {required String specialty}) {
  String s(String k) => c.s(k).trim();
  final cc = CaseChoices(c);
  final b = <CBlock>[];
  void h(String t, [int level = 1]) => b.add(CHeading(t, level: level));
  void sub(String label, String text) {
    if (text.trim().isEmpty) return;
    h(label, 2);
    b.add(CPara('', text));
  }

  switch (id) {
    case 'patient':
      final st = clinStatusOf(c);
      final pairs = <(String, String)>[
        ('Date', s('date')),
        ('Rotation', specialty),
        ('Age group', s('ageGroup')),
        ('Sex', s('sex')),
        ('Setting', s('setting')),
        ('Encounter', s('encounter')),
        ('Role', s('role')),
        ('Status at presentation', st),
      ].where((e) => e.$2.isNotEmpty).toList();
      if (pairs.isNotEmpty) {
        h('Patient and encounter');
        b.add(CPairs(pairs));
      }
      break;
    case 'cc':
      if (s('cc').isNotEmpty) {
        h('Chief complaint');
        final l = _lines(s('cc'));
        if (l.length > 1) {
          b.add(CBox('', l, kind: 'plain'));
        } else {
          b.add(CPara('', s('cc'), bold: true));
        }
      }
      break;
    case 'hpi':
      final t = _choiceTable(cc, 'History', 'Key history point');
      final opening = hpiOpening(c);
      if (s('hpi').isNotEmpty || t != null || opening.isNotEmpty) {
        h('History of presenting illness');
        if (opening.isNotEmpty) b.add(CPara('', opening));
        if (s('hpi').isNotEmpty) b.add(CPara('', s('hpi')));
        if (t != null) b.addAll(t);
      }
      break;
    case 'ros':
      sub('Review of systems', s('ros'));
      break;
    case 'pmh':
      sub('Past medical history', pastHistory(c, 'pmh'));
      break;
    case 'psh':
      sub('Past surgical history', pastHistory(c, 'psh'));
      break;
    case 'meds':
      if (s('drugs').isNotEmpty) sub('Drug history', pastHistory(c, 'drugs'));
      // allergies are a safety item: always stated
      b.add(CBox('Allergies', [s('allergies').isEmpty ? 'Not documented' : s('allergies')], kind: s('allergies').isEmpty ? 'info' : 'amber'));
      break;
    case 'family':
      sub('Family history', s('family'));
      break;
    case 'social':
      sub('Social and functional history', s('social'));
      break;
    case 'spec':
      final f = specialtySplit(c.s('specialty')).history.where((f) => s(f[0]).isNotEmpty).toList();
      if (f.isNotEmpty) {
        h('${specialty.isEmpty ? 'Rotation' : specialty}: specific history');
        for (final x in f) {
          b.add(CPara(x[1], s(x[0])));
        }
      }
      break;
    case 'exam':
      final vitals = vitalsSentence(c);
      final systems = systemsSentences(c);
      final t = _choiceTable(cc, 'Examination', 'Examination point');
      final hasText = ['examGeneral', 'examSystemic', 'examFocused'].any((k) => s(k).isNotEmpty);
      if (vitals.isNotEmpty || systems.isNotEmpty || hasText || t != null) {
        h('Examination');
        if (vitals.isNotEmpty) b.add(CPara('', vitals));
        b.add(CPara('General', s('examGeneral')));
        b.add(CPara('Systemic', s('examSystemic')));
        b.add(CPara('Focused', s('examFocused')));
        final src = _join([
          if (s('obsGeneral').isNotEmpty) 'general: ${s('obsGeneral')}',
          if (s('obsSystemic').isNotEmpty) 'systemic: ${s('obsSystemic')}',
          if (s('obsFocused').isNotEmpty) 'focused: ${s('obsFocused')}',
        ], '; ');
        if (src.isNotEmpty) b.add(CPara('Findings obtained', src));
        if (systems.isNotEmpty) b.add(CPara('', systems));
        if (t != null) b.addAll(t);
      }
      break;
    case 'specx':
      final f = specialtySplit(c.s('specialty')).exam.where((f) => s(f[0]).isNotEmpty).toList();
      if (f.isNotEmpty) {
        h('${specialty.isEmpty ? 'Rotation' : specialty}: specific findings');
        for (final x in f) {
          b.add(CPara(x[1], s(x[0])));
        }
      }
      break;
    case 'inv':
      final inv = c.lst('inv');
      final t = _choiceTable(cc, 'Investigations', 'Investigation');
      final ls = labSeries(c);
      final images = c.lst('images');
      final linked = {for (final i in inv) '${i['id']}'};
      bool photoOf(J i) => images.any((im) => '${im['inv']}' == '${i['id']}' && _s(im['file']).isNotEmpty);
      final loose = [
        for (final im in images)
          if (_s(im['file']).isNotEmpty && !linked.contains('${im['inv']}')) im
      ];
      if (inv.isNotEmpty || t != null || ls.isNotEmpty || loose.isNotEmpty) {
        h('Investigations');
        if (inv.isNotEmpty) {
          final text = investigationSentences(c, hasPhoto: photoOf);
          if (text.isNotEmpty) b.add(CPara('', text));
          // the photo of a result goes under the text, named by its test
          for (final i in inv) {
            final pics = [
              for (final im in images)
                if ('${im['inv']}' == '${i['id']}' && _s(im['file']).isNotEmpty) (path: store.imagePath(_s(im['file'])), caption: _s(i['name']))
            ];
            if (pics.isNotEmpty) b.add(CImages(pics));
          }
        }
        if (t != null) b.addAll(t);
        if (ls.isNotEmpty) {
          // serial results: this is what a table is for
          h('Laboratory trends', 2);
          b.add(CTable(
            ['Test', 'Results (oldest to newest)', 'Unit'],
            [
              for (final x in ls)
                [x.test, x.readings.map((r) => r.value == r.value.roundToDouble() ? r.value.toStringAsFixed(0) : r.value.toString()).join('  >  '), x.unit]
            ],
            weights: const <double>[1.2, 3, 1],
          ));
        }
        if (loose.isNotEmpty) {
          h('Images', 2);
          b.add(CImages([
            for (final im in loose)
              (
                path: store.imagePath(_s(im['file'])),
                caption: _join([for (final k in ['type', 'view', 'caption', 'date']) _s(im[k])])
              )
          ]));
        }
      }
      break;
    case 'assess':
      final flags = _flags(c);
      final pl = problemsSorted(c);
      final evo = c.lst('evo');
      final sc = scoresOf(c);
      final t = _choiceTable(cc, 'Assessment', 'Assessment point');
      final any = flags.isNotEmpty ||
          ['problems', 'ddx', 'workingDx', 'finalDx', 'reasoning'].any((k) => s(k).isNotEmpty) ||
          pl.isNotEmpty ||
          evo.isNotEmpty ||
          sc.isNotEmpty ||
          t != null;
      if (any) {
        h('Assessment');
        if (flags.isNotEmpty) b.add(CBox('Red flags', flags, kind: 'red'));
        b.add(CPara('', problemSentence(c)));
        b.add(CPara('', differentialSentence(c)));
        b.add(CPara('', diagnosisSentences(c)));
        b.add(CPara('', s('reasoning')));
        if (evo.isNotEmpty) {
          // how the diagnosis changed over time: a table of steps
          b.add(CTable(['Step', 'Date', 'Diagnosis', 'Because'], [for (final e in evo) [_s(e['step']), _s(e['date']), _s(e['text']), _s(e['evidence'])]], weights: const <double>[1.1, 1, 2, 2]));
        }
        if (t != null) b.addAll(t);
        b.add(CPara('', scoreSentences(c)));
      }
      break;
    case 'mgmt':
      final inH = planInHospital(c), home = planTakeHome(c);
      final t = _choiceTable(cc, 'Management', 'Management point');
      final n1 = [for (final m in inH) if (_s(m['text']).isNotEmpty) m], n2 = [for (final m in home) if (_s(m['text']).isNotEmpty) m];
      if (n1.isNotEmpty || n2.isNotEmpty || t != null) {
        h('Management plan');
        List<List<String>> rows(List<J> l) => [for (final m in l) [_s(m['text']), _s(m['dose']), _s(m['category']), _join([_s(m['by']), _s(m['state'])], ' • ')]];
        const head = ['Plan item', 'Details (dose, route, frequency, duration)', 'Type', 'By / status'];
        const w = <double>[2, 2.4, 1.2, 1.2];
        // a few items read as sentences; a long list of drugs and doses is a table
        void block(String label, List<J> items) {
          if (items.isEmpty) return;
          if (n1.isNotEmpty && n2.isNotEmpty) h(label, 2);
          if (items.length >= 5) {
            b.add(CTable(head, rows(items), weights: w));
          } else {
            b.add(CPara('', planSentences(items)));
          }
        }

        block('In hospital', n1);
        block('Take-home (at discharge)', n2);
        if (t != null) b.addAll(t);
      }
      break;
    case 'progress':
      final pr = c.lst('progress');
      if (pr.isNotEmpty) {
        h('Progress and reassessment');
        b.add(CTable(['Day', 'Subjective', 'Objective', 'Assessment', 'Plan'], [for (final p in pr) [_join([_s(p['day']), _s(p['date'])], '\n'), _s(p['s']), _s(p['o']), _s(p['a']), _s(p['p'])]], weights: const <double>[1.2, 2, 2, 2, 2]));
      }
      break;
    case 'outcome':
      if (['disposition', 'outcome', 'outcomeCat', 'followUp'].any((k) => s(k).isNotEmpty)) {
        h('Outcome, disposition and follow-up');
        b.add(CPara('', dispositionSentence(c)));
        b.add(CPara('Outcome status', s('outcomeCat'), bold: true));
        b.add(CPara('Outcome', s('outcome')));
        b.add(CPara('Follow-up', s('followUp')));
      }
      break;
    case 'learning':
      final any = ['initialDx', 'whatChanged', 'learned', 'mistakes', 'questions', 'teaching', 'refs'].any((k) => s(k).isNotEmpty);
      if (any) {
        h('Learning points');
        b.add(CPara('First diagnosis (before results)', s('initialDx')));
        b.add(CPara('What changed the diagnosis', s('whatChanged')));
        if (_lines(s('learned')).isNotEmpty) b.add(CBox('What I learned', _lines(s('learned')), kind: 'green'));
        if (_lines(s('mistakes')).isNotEmpty) b.add(CBox('Mistakes and near-misses', _lines(s('mistakes')), kind: 'amber'));
        if (_lines(s('questions')).isNotEmpty) b.add(CBox('Questions to review', _lines(s('questions'))));
        b.add(CPara('Supervisor teaching', s('teaching')));
        b.add(CPara('References', s('refs')));
      }
      break;
  }
  return b;
}

CBand _band(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final st = clinStatusOf(c);
  const tag = 0xFF3E5C86;
  final dx = s('finalDx').isNotEmpty ? s('finalDx') : s('workingDx');
  final pills = <({String text, int bg, int fg})>[
    if (st.isNotEmpty) (text: st, bg: clinStatusColor(st).toARGB32(), fg: clinStatusOnColor(st).toARGB32()),
    if (s('status').isNotEmpty) (text: s('status'), bg: tag, fg: 0xFFFFFFFF),
    if (s('disposition').isNotEmpty) (text: s('disposition'), bg: tag, fg: 0xFFFFFFFF),
  ];
  return CBand(
    'Case ${s('code')}${dx.isEmpty ? '' : '  -  $dx'}',
    _join([specialty, s('date'), _join([s('ageGroup'), s('sex')], ' '), s('setting'), s('encounter')]),
    pills,
  );
}

/// One or two sentences a reader can take in at a glance: who, where, why, what it turned out to be, where it went.
String _oneLiner(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final who = _join([
    s('ageGroup').isEmpty ? '' : s('ageGroup').toLowerCase(),
    switch (s('sex')) { 'M' => 'male', 'F' => 'female', _ => '' },
    'patient',
  ], ' ');
  final cc = _lines(s('cc')).join('; ');
  final dx = s('finalDx').isNotEmpty ? s('finalDx') : s('workingDx');
  final ccText = cc.length > 1 && cc[0] != cc[0].toLowerCase() && cc[1] == cc[1].toLowerCase() ? '${cc[0].toLowerCase()}${cc.substring(1)}' : cc;
  final first = '${who[0].toUpperCase()}${who.substring(1)}'
      '${s('setting').isEmpty ? '' : ' seen in ${s('setting')}'}'
      '${cc.isEmpty ? '' : ' with $ccText'}.';
  final adult = s('ageGroup') == 'Adult';
  final bad = [for (final k in _vitalUnits.keys) if (s(k).isNotEmpty && vitalAbnormal(k, s(k), adult)) _vitalUnits[k]!.split(' ').first];
  final parts = <String>[
    first,
    if (bad.isNotEmpty) 'Abnormal vital signs: ${bad.join(', ')}.',
    if (dx.isNotEmpty) '${s('finalDx').isNotEmpty ? 'Diagnosis' : 'Working diagnosis'}: $dx.',
    if (s('disposition').isNotEmpty) 'Disposition: ${s('disposition')}.',
  ];
  return cc.isEmpty && dx.isEmpty ? '' : parts.join(' ');
}

/// Which sections have something to print, in the order of the rotation.
List<String> caseSectionOrder(CaseRec c) {
  final ids = CaseTemplates.idsFor(c.s('specialty'));
  final present = [for (final id in kCanonicalSectionIds) if (_sec(c, id, specialty: '').isNotEmpty) id];
  final order = CaseTemplates.completeOrder(ids, present);
  return [for (final id in order) if (present.contains(id)) id];
}

/// "Full" is the whole case in the order of its rotation; "meeting" is a one-page presentation (summary, narrowed
/// differential, analysis, plan, question for self-study); "summary" keeps the key stages.
const List<String> kCaseFormats = ['full', 'meeting', 'summary'];

List<CBlock> caseBlocks(CaseRec c, {String format = 'full', bool signOff = false}) => inEnglish(() {
      String s(String k) => c.s(k).trim();
      final specialty = CaseTemplates.rotationName(s('specialty'));
      final out = <CBlock>[_band(c, specialty)];
      if (format == 'full') {
        final line = _oneLiner(c, specialty);
        if (line.isNotEmpty) out.add(CBox('Summary', [line], kind: 'plain'));
      }
      if (format == 'meeting') {
        out.addAll(_meeting(c, specialty));
      } else if (format == 'summary') {
        out.addAll(_summary(c, specialty));
      } else {
        for (final id in caseSectionOrder(c)) {
          out.addAll(_sec(c, id, specialty: specialty));
        }
      }
      out.addAll(_signOff(c, signOff));
      return out;
    });

List<CBlock> _signOff(CaseRec c, bool signOff) {
  if (!signOff) return const [];
  final b = <CBlock>[const CHeading('Supervisor sign-off')];
  if (isSigned(c.d)) {
    b.add(CPara('Supervisor', signCell(c.d).replaceAll('\n', '  -  ')));
    if (c.s('supLevel').trim().isNotEmpty) b.add(CPara('Level of supervision', c.s('supLevel').trim()));
  } else {
    b.add(const CTable(['Supervisor name', 'Role', 'Signature or initials', 'Date'], [
      ['\n\n', '', '', '']
    ], keepEmpty: true));
  }
  return b;
}

String _firstSentences(String t, int max) {
  final x = t.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (x.length <= max) return x;
  final cut = x.substring(0, max);
  final dot = cut.lastIndexOf(RegExp(r'[.!?]'));
  return dot > max ~/ 2 ? cut.substring(0, dot + 1) : '${cut.trimRight()}...';
}

String _vitalsLine(CaseRec c) => [
      for (final k in _vitalUnits.keys)
        if (c.s(k).trim().isNotEmpty) '${_vitalUnits[k]!.split(' ').first} ${c.s(k).trim()}'
    ].join(', ');

List<CBlock> _plan(CaseRec c) {
  final rows = [
    for (final m in c.lst('mgmt'))
      if (_s(m['text']).isNotEmpty) [_s(m['text']), _s(m['dose']), _s(m['setting']) == kTakeHome ? 'Take-home' : 'Hospital']
  ];
  return rows.isEmpty ? const [] : [CTable(const ['Plan item', 'Details', 'Where'], rows, weights: const [2.2, 2.6, 1.0])];
}

List<CBlock> _meeting(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final b = <CBlock>[];
  final who = _join([s('ageGroup'), s('sex')], ' ');
  final where = _join([s('setting'), s('encounter')], ', ');
  final abn = [
    for (final e in (c.d['sys'] is Map ? (c.d['sys'] as Map).entries : const <MapEntry>[]))
      if (e.value is Map && (e.value as Map)['s'] == 'Abnormal') '${e.key}${_s((e.value as Map)['n']).isEmpty ? '' : ' (${_s((e.value as Map)['n'])})'}'
  ];
  final inv = [
    for (final i in c.lst('inv'))
      if (_s(i['name']).isNotEmpty && _s(i['result']).isNotEmpty) '${i['name']}: ${i['result']}'
  ];
  b.add(const CHeading('Summary'));
  b.add(CPara('', _join([
    _join([who.isEmpty ? '' : who, where.isEmpty ? '' : 'seen in $where'], ' '),
    if (s('cc').isNotEmpty) 'Presenting with ${_lines(s('cc')).join('; ')}.',
  ], '. ')));
  if (s('hpi').isNotEmpty) b.add(CPara('History', _firstSentences(s('hpi'), 520)));
  final bg = _join([s('pmh'), s('drugs').isEmpty ? '' : 'Drugs: ${s('drugs')}'], '. ');
  if (bg.isNotEmpty) b.add(CPara('Background', _firstSentences(bg, 260)));
  if (s('allergies').isNotEmpty) b.add(CPara('Allergies', s('allergies')));
  final vit = _vitalsLine(c);
  if (vit.isNotEmpty) b.add(CPara('Vital signs', vit));
  if (abn.isNotEmpty) b.add(CPara('Abnormal findings', abn.join('; ')));
  if (s('examFocused').isNotEmpty) b.add(CPara('Focused examination', _firstSentences(s('examFocused'), 240)));
  if (inv.isNotEmpty) b.add(CPara('Key investigations', inv.take(6).join('; ')));
  final flags = _flags(c);
  if (flags.isNotEmpty) b.add(CBox('Red flags', flags, kind: 'red'));
  if (s('ddx').isNotEmpty || s('workingDx').isNotEmpty) {
    b.add(const CHeading('Narrowed differential'));
    b.add(CPara('Differential', s('ddx')));
    b.add(CPara('Working diagnosis', s('workingDx'), bold: true));
    b.add(CPara('Final diagnosis', s('finalDx'), bold: true));
  } else if (s('finalDx').isNotEmpty) {
    b.add(const CHeading('Diagnosis'));
    b.add(CPara('Final diagnosis', s('finalDx'), bold: true));
  }
  if (s('reasoning').isNotEmpty) {
    b.add(const CHeading('Analysis'));
    b.add(CPara('', _firstSentences(s('reasoning'), 700)));
  }
  final plan = _plan(c);
  if (plan.isNotEmpty) {
    b.add(const CHeading('Plan'));
    b.addAll(plan);
  }
  if (_lines(s('questions')).isNotEmpty) b.add(CBox('Question for self-study', _lines(s('questions'))));
  return b;
}

List<CBlock> _summary(CaseRec c, String specialty) {
  String s(String k) => c.s(k).trim();
  final b = <CBlock>[];
  final pat = _sec(c, 'patient', specialty: specialty);
  b.addAll(pat);
  if (s('cc').isNotEmpty) b.add(CPara('Chief complaint', s('cc'), bold: true));
  if (s('hpi').isNotEmpty) b.add(CPara('History', _firstSentences(s('hpi'), 600)));
  final vit = _vitalsLine(c);
  if (vit.isNotEmpty) b.add(CPara('Vital signs', vit));
  final ass = _sec(c, 'assess', specialty: specialty);
  b.addAll(ass);
  final plan = _plan(c);
  if (plan.isNotEmpty) {
    b.add(const CHeading('Management plan'));
    b.addAll(plan);
  }
  b.addAll(_sec(c, 'outcome', specialty: specialty));
  b.addAll(_sec(c, 'learning', specialty: specialty));
  return b;
}

// ---------------------------------------------------------------- drawing

const PdfColor _navy = PdfColor.fromInt(0xFF1F3A5F);
const PdfColor _teal = PdfColor.fromInt(0xFF0F766E);
const PdfColor _muted = PdfColor.fromInt(0xFF5B6573);
const PdfColor _line = PdfColor.fromInt(0xFFD5DAE1);
const PdfColor _zebra = PdfColor.fromInt(0xFFF4F6FA);
const PdfColor _red = PdfColor.fromInt(0xFFC62828);

class _Style {
  final PdfColor ink, bg;
  const _Style(this.ink, this.bg);
}

_Style _boxStyle(String kind) => switch (kind) {
      'red' => const _Style(_red, PdfColor.fromInt(0xFFFDECEC)),
      'amber' => const _Style(PdfColor.fromInt(0xFF8A5A00), PdfColor.fromInt(0xFFFFF4DC)),
      'green' => const _Style(PdfColor.fromInt(0xFF2E7D32), PdfColor.fromInt(0xFFE8F5E9)),
      'plain' => const _Style(_navy, PdfColor.fromInt(0xFFF4F6FA)),
      _ => const _Style(_navy, PdfColor.fromInt(0xFFEAF1FA)),
    };

/// A photo scaled down (long side 900 px) and re-encoded: a phone photo is several megabytes.
Future<pw.MemoryImage?> _loadImage(String path) async {
  try {
    final f = File(path);
    if (!await f.exists()) return null;
    final bytes = await f.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: 900);
    final frame = await codec.getNextFrame();
    final data = await frame.image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return null;
    return pw.MemoryImage(data.buffer.asUint8List());
  } catch (_) {
    return null;
  }
}

Future<pw.Font> _font(String asset) async => pw.Font.ttf(await rootBundle.load(asset));

pw.Widget _cell(String t, {bool head = false, bool red = false, bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 3.5),
      child: pw.Text(t, style: pw.TextStyle(fontSize: 8.8, fontWeight: head || red || bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: head ? PdfColors.white : (red ? _red : PdfColors.black))),
    );

// The document is one flat list of widgets. A block that can be longer than a page must be a TOP-LEVEL widget that can be
// split (Text, Table, Wrap), never wrapped in Padding / Inseparable / Container (they cannot be split: that was the export
// error "Widget won't fit into the page"), and never nested in a Column inside the list (nested splitting loops).
// So every block builder returns a list of widgets, and spacing is a SizedBox beside the block, not a Padding around it.

List<pw.Widget> _tableParts(CTable src) {
  // a column in which no row has anything to say is left out (the first one always stays)
  final keep = [for (var i = 0; i < src.head.length; i++) if (i == 0 || src.keepEmpty || src.rows.any((r) => i < r.length && r[i].trim().isNotEmpty)) i];
  final w0 = src.weights.length == src.head.length ? src.weights : List<double>.filled(src.head.length, 1);
  final t = CTable([for (final i in keep) src.head[i]], [for (final r in src.rows) [for (final i in keep) i < r.length ? r[i] : '']],
      weights: [for (final i in keep) w0[i]], redRows: src.redRows, showHead: src.showHead, keepEmpty: src.keepEmpty);
  final n = t.head.length;
  final w = t.weights;
  final table = pw.Table(
    border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: _line, width: 0.5), bottom: pw.BorderSide(color: _line, width: 0.5)),
    columnWidths: {for (var i = 0; i < n; i++) i: pw.FlexColumnWidth(w[i])},
    children: [
      if (t.showHead) pw.TableRow(repeat: true, decoration: const pw.BoxDecoration(color: _navy), children: [for (final h in t.head) _cell(h, head: true)]),
      for (var r = 0; r < t.rows.length; r++)
        pw.TableRow(
          decoration: r.isOdd ? const pw.BoxDecoration(color: _zebra) : null,
          children: [for (var i = 0; i < n; i++) _cell(i < t.rows[r].length ? t.rows[r][i] : '', red: t.redRows.contains(r), bold: !t.showHead && i == 0)],
        ),
    ],
  );
  // a short table is never cut between two pages (a header with one row on one page and the rest on the next)
  if (_tableSmall(t)) return [pw.Padding(padding: const pw.EdgeInsets.only(top: 3, bottom: 6), child: pw.Inseparable(child: table))];
  // A long table runs over several pages. A table ROW cannot be split, so a table with a cell taller than a page is
  // printed as stacked "Head: value" lines instead.
  final stacked = t.rows.any((r) => r.any((c) => c.length > _maxCellChars));
  return [pw.SizedBox(height: 3), if (stacked) ..._tableStacked(t) else table, pw.SizedBox(height: 6)];
}

/// A table cell longer than this cannot sit in one table row (a row is never split over two pages).
const int _maxCellChars = 900;

bool _tableSmall(CTable t) {
  final chars = t.rows.fold<int>(0, (a, r) => a + r.fold<int>(0, (b, c) => b + c.length));
  return t.rows.length <= 10 && chars < 1400 && !t.rows.any((r) => r.any((c) => c.length > _maxCellChars));
}

List<pw.Widget> _tableStacked(CTable t) => [for (var r = 0; r < t.rows.length; r++) ..._stackedRow(t, r)];

List<pw.Widget> _stackedRow(CTable t, int r) {
  final row = t.rows[r];
  final red = t.redRows.contains(r);
  return [
    for (var i = 0; i < t.head.length && i < row.length; i++)
      if (row[i].trim().isNotEmpty)
        pw.RichText(
          overflow: pw.TextOverflow.span,
          text: pw.TextSpan(style: const pw.TextStyle(fontSize: 9, lineSpacing: 1.4), children: [
            if (t.showHead && t.head[i].isNotEmpty) pw.TextSpan(text: '${t.head[i]}: ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: _navy)),
            pw.TextSpan(text: row[i], style: red ? pw.TextStyle(fontWeight: pw.FontWeight.bold, color: _red) : (!t.showHead && i == 0 ? pw.TextStyle(fontWeight: pw.FontWeight.bold) : null)),
          ]),
        ),
    pw.Container(height: 0.5, color: _line, margin: const pw.EdgeInsets.symmetric(vertical: 3)),
  ];
}

bool _boxShort(CBox b) => b.lines.length <= 25 && b.lines.fold<int>(0, (a, l) => a + l.length) <= 2000;

/// Is this block short enough to be kept on one page with the heading above it?
bool _shortBlock(CBlock b) => switch (b) {
      CPara p => p.text.length <= 3000, // about 28 lines: well under one page (a page holds about 48)
      CBox x => _boxShort(x),
      CPairs x => x.items.length <= 24,
      CTable x => _tableSmall(x),
      _ => true,
    };

List<pw.Widget> _boxParts(CBox b) => _boxShort(b) ? [pw.Inseparable(child: _boxInner(b))] : _boxSplit(b);

/// A long box as separate lines, each with the box colour and edge, so that it can run over several pages.
List<pw.Widget> _boxSplit(CBox b) {
  final st = _boxStyle(b.kind);
  pw.Widget row(pw.Widget child, {double top = 1, double bottom = 1}) => pw.Container(
        width: double.infinity,
        padding: pw.EdgeInsets.fromLTRB(9, top, 9, bottom),
        decoration: pw.BoxDecoration(color: st.bg, border: pw.Border(left: pw.BorderSide(color: st.ink, width: 3))),
        child: child,
      );
  return [
    pw.SizedBox(height: 3),
    if (b.title.isNotEmpty) row(pw.Text(b.title, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: st.ink)), top: 6),
    for (final text in [for (final l in b.lines) ..._boxLine(l, bullet: b.lines.length > 1 || b.kind != 'plain')]) row(pw.Text(text, style: const pw.TextStyle(fontSize: 10))),
    pw.SizedBox(height: 6),
  ];
}

/// The rows of one box line: the bullet on the first one, long lines cut into several rows.
List<String> _boxLine(String l, {required bool bullet}) {
  final c = _chunks(l, _maxLineChars);
  return [for (var k = 0; k < c.length; k++) k == 0 && bullet ? '-  ${c[k]}' : c[k]];
}

/// One line of a box is one non-splittable row, so a pasted paragraph of many thousand characters is cut into rows of this size.
const int _maxLineChars = 1200;

/// The text cut at spaces into pieces of at most [max] characters (nothing is dropped).
List<String> _chunks(String s, int max) {
  if (s.length <= max) return [s];
  final out = <String>[];
  var rest = s;
  while (rest.length > max) {
    var cut = rest.lastIndexOf(' ', max);
    if (cut < max ~/ 2) cut = max;
    out.add(rest.substring(0, cut).trimRight());
    rest = rest.substring(cut).trimLeft();
  }
  if (rest.isNotEmpty) out.add(rest);
  return out;
}

pw.Widget _boxInner(CBox b) {
  final st = _boxStyle(b.kind);
  return pw.Container(
    width: double.infinity,
    margin: const pw.EdgeInsets.only(top: 3, bottom: 6),
    padding: const pw.EdgeInsets.fromLTRB(9, 6, 9, 6),
    decoration: pw.BoxDecoration(color: st.bg, border: pw.Border(left: pw.BorderSide(color: st.ink, width: 3))),
    child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      if (b.title.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(bottom: 2), child: pw.Text(b.title, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: st.ink))),
      for (final l in b.lines) pw.Padding(padding: const pw.EdgeInsets.only(top: 1), child: pw.Text(b.lines.length > 1 || b.kind != 'plain' ? '-  $l' : l, style: const pw.TextStyle(fontSize: 10))),
    ]),
  );
}

pw.Widget _heading(CHeading h) {
  if (h.level == 2) {
    return pw.Padding(padding: const pw.EdgeInsets.only(top: 6, bottom: 1.5), child: pw.Text(h.title, style: pw.TextStyle(fontSize: 10.2, fontWeight: pw.FontWeight.bold, color: _teal)));
  }
  return pw.Padding(
    padding: const pw.EdgeInsets.only(top: 11, bottom: 4),
    child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text(h.title, style: pw.TextStyle(fontSize: 12.5, fontWeight: pw.FontWeight.bold, color: _navy)),
      pw.SizedBox(height: 2),
      pw.Container(height: 1.1, color: _teal),
    ]),
  );
}

/// A paragraph can be longer than a page: the text itself (overflow: span) is the top-level widget so it can be split, spacing sits beside it.
List<pw.Widget> _paraParts(CPara p) => [
      pw.RichText(
        overflow: pw.TextOverflow.span, // only a text with overflow "span" may continue on the next page
        text: pw.TextSpan(style: const pw.TextStyle(fontSize: 10, lineSpacing: 1.6), children: [
          if (p.label.isNotEmpty) pw.TextSpan(text: '${p.label}: ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: _navy)),
          pw.TextSpan(text: p.text, style: p.bold ? pw.TextStyle(fontWeight: pw.FontWeight.bold) : null),
        ]),
      ),
      pw.SizedBox(height: 3.5),
    ];

List<pw.Widget> _pairsParts(CPairs p) {
  final rows = <pw.TableRow>[];
  for (var i = 0; i < p.items.length; i += 2) {
    pw.Widget cell(int k) => k < p.items.length
        ? pw.Padding(
            padding: const pw.EdgeInsets.symmetric(vertical: 2.5, horizontal: 4),
            child: pw.RichText(text: pw.TextSpan(style: const pw.TextStyle(fontSize: 9.5), children: [
              pw.TextSpan(text: '${p.items[k].$1}: ', style: pw.TextStyle(color: _muted, fontWeight: pw.FontWeight.bold)),
              pw.TextSpan(text: p.items[k].$2),
            ])))
        : pw.SizedBox();
    rows.add(pw.TableRow(children: [cell(i), cell(i + 1)]));
  }
  return [
    pw.Table(border: const pw.TableBorder(horizontalInside: pw.BorderSide(color: _line, width: 0.4), bottom: pw.BorderSide(color: _line, width: 0.4), top: pw.BorderSide(color: _line, width: 0.4)), children: rows),
    pw.SizedBox(height: 4),
  ];
}

/// The widgets of one content block.
List<pw.Widget> _blockParts(CBlock b) => switch (b) {
      CPara x => _paraParts(x),
      CBox x => _boxParts(x),
      CTable x => _tableParts(x),
      CPairs x => _pairsParts(x),
      _ => const <pw.Widget>[],
    };

pw.Widget _bandWidget(CBand b) => pw.Container(
      width: double.infinity,
      margin: const pw.EdgeInsets.only(bottom: 4),
      padding: const pw.EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: const pw.BoxDecoration(color: _navy, borderRadius: pw.BorderRadius.all(pw.Radius.circular(6))),
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(b.title, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
        if (b.subtitle.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text(b.subtitle, style: const pw.TextStyle(fontSize: 9.5, color: PdfColor.fromInt(0xFFD7E2F2)))),
        if (b.pills.isNotEmpty)
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 7),
            child: pw.Wrap(spacing: 5, runSpacing: 4, children: [
              for (final p in b.pills)
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: pw.BoxDecoration(color: PdfColor.fromInt(p.bg), borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8))),
                  child: pw.Text(p.text, style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold, color: PdfColor.fromInt(p.fg))),
                ),
            ]),
          ),
      ]),
    );

/// The PDF of one or many cases. With several cases a summary table comes first and every case starts on a new page.
Future<Uint8List> buildCasePdf(List<CaseRec> cases, {String? title, String format = 'full', bool signOff = false}) async {
  await CaseTemplates.ensureLoaded();
  final perCase = [for (final c in cases) caseBlocks(c, format: format, signOff: signOff)];
  final blocks = <CBlock>[];
  if (cases.length > 1) {
    inEnglish(() {
      blocks.add(CBand(title ?? 'Cases', '${cases.length} cases', const []));
      blocks.add(const CHeading('Summary'));
      blocks.add(CTable(
        ['Date', 'Code', 'Rotation', 'Diagnosis', 'Status at presentation', if (signOff) 'Supervisor sign-off'],
        [
          for (final c in cases)
            [c.s('date'), c.s('code'), CaseTemplates.rotationName(c.s('specialty')), c.title, clinStatusOf(c), if (signOff) signCell(c.d)]
        ],
        weights: signOff ? const <double>[1.2, 1.2, 1.4, 2, 1.2, 1.8] : const <double>[1.3, 1.3, 1.6, 2.4, 1.5],
      ));
    });
    blocks.add(const CNewPage());
  }
  for (var i = 0; i < perCase.length; i++) {
    blocks.addAll(perCase[i]);
    if (i < perCase.length - 1) blocks.add(const CNewPage());
  }

  final tinos = await _font('assets/fonts/Tinos_400Regular.ttf');
  final tinosBold = await _font('assets/fonts/Tinos_700Bold.ttf');
  final cairo = await _font('assets/fonts/Cairo_400Regular.ttf');
  final cairoBold = await _font('assets/fonts/Cairo_700Bold.ttf');
  final images = <String, pw.MemoryImage?>{};
  for (final b in blocks) {
    if (b is CImages) {
      for (final f in b.files) {
        images[f.path] ??= await _loadImage(f.path);
      }
    }
  }

  // one photo is big enough to read what is written on it; several share the line
  double imgW(CImages b) => b.files.length == 1 ? 230 : 150;
  List<pw.Widget> imagesParts(CImages b) => [
        pw.SizedBox(height: 3),
        pw.Wrap(spacing: 8, runSpacing: 8, children: [
          for (final f in b.files)
            if (images[f.path] != null)
              pw.SizedBox(
                width: imgW(b),
                child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                  pw.Container(decoration: pw.BoxDecoration(border: pw.Border.all(color: _line, width: 0.5)), child: pw.Image(images[f.path]!, width: imgW(b), fit: pw.BoxFit.contain)),
                  if (f.caption.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 2), child: pw.Text(f.caption, style: const pw.TextStyle(fontSize: 8, color: _muted))),
                ]),
              ),
        ]),
        pw.SizedBox(height: 6),
      ];

  // a label without text is never printed
  blocks.removeWhere((b) => b is CPara && b.text.trim().isEmpty);
  final widgets = <pw.Widget>[];
  for (var i = 0; i < blocks.length; i++) {
    final b = blocks[i];
    if (b is CNewPage) {
      widgets.add(pw.NewPage());
    } else if (b is CBand) {
      widgets.add(_bandWidget(b));
    } else if (b is CHeading) {
      // a heading is kept with what follows it when that is short, so it never ends a page alone
      final next = i + 1 < blocks.length ? blocks[i + 1] : null;
      if (next is CPara || next is CBox || next is CPairs || next is CTable) {
        // A heading and a SHORT block never end up on two pages (Inseparable). A block longer than a page cannot be
        // inseparable (that was the "Widget won't fit into the page" export error): there the heading stays a separate
        // widget and the block is split over the pages.
        final parts = _blockParts(next!);
        if (_shortBlock(next)) {
          widgets.add(pw.Inseparable(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [_heading(b), ...parts])));
        } else {
          widgets.add(_heading(b));
          widgets.addAll(parts);
        }
        i++;
      } else {
        widgets.add(_heading(b));
      }
    } else if (b is CPara || b is CBox || b is CTable || b is CPairs) {
      widgets.addAll(_blockParts(b));
    } else if (b is CImages) {
      widgets.addAll(imagesParts(b));
    }
  }
  widgets.add(pw.Padding(
    padding: const pw.EdgeInsets.only(top: 14),
    child: pw.Text('SharqMed adds no patient names or ID numbers. Check the text before you share.', style: const pw.TextStyle(fontSize: 8, color: _muted)),
  ));

  final footerLeft = cases.length == 1 ? 'SharqMed  -  case ${cases.first.s('code')}' : 'SharqMed  -  case file';
  final doc = pw.Document(title: title ?? (cases.length == 1 ? 'Case ${cases.first.s('code')}' : 'SharqMed cases'), author: 'SharqMed', creator: 'SharqMed');
  doc.addPage(pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.fromLTRB(36, 34, 36, 40),
      theme: pw.ThemeData.withFont(base: tinos, bold: tinosBold, italic: tinos, boldItalic: tinosBold, fontFallback: [cairo, cairoBold]),
    ),
    build: (_) => widgets,
    footer: (ctx) => pw.Padding(
      padding: const pw.EdgeInsets.only(top: 6),
      child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text(footerLeft, style: const pw.TextStyle(fontSize: 8, color: _muted)),
        pw.Text('Page ${ctx.pageNumber} / ${ctx.pagesCount}', style: pw.TextStyle(fontSize: 8, color: _navy, fontWeight: pw.FontWeight.bold)),
      ]),
    ),
  ));
  return Uint8List.fromList(await doc.save());
}

Future<File> writeCasePdf(List<CaseRec> cases, {String? title, String fileName = 'SharqMed', String format = 'full', bool signOff = false}) async {
  final bytes = await buildCasePdf(cases, title: title, format: format, signOff: signOff);
  final dir = await getTemporaryDirectory();
  final f = File('${dir.path}/$fileName.pdf');
  await f.writeAsBytes(bytes, flush: true);
  return f;
}
