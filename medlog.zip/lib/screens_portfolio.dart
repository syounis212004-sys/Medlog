import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:share_plus/share_plus.dart';

import 'data.dart';
import 'i18n.dart';
import 'main.dart' show navKeyFor, currentNavId;
import 'motion.dart';
import 'screens_calendar.dart';
import 'screens_cases.dart';
import 'screens_home.dart';
import 'theme.dart';
import 'ui.dart';
import 'widgets.dart';

// ================================================================ rotations

Future<void> editRotation(BuildContext context, [J? r]) async {
  final res = await showFormSheet(
    context,
    title: r == null ? 'New rotation' : 'Edit rotation',
    specs: [
      FieldSpec('name', 'Rotation / specialty', options: kSpecialtyNames),
      const FieldSpec('start', 'Start date', type: FT.date),
      const FieldSpec('end', 'End date', type: FT.date),
      const FieldSpec('hospital', 'Hospital / department'),
      const FieldSpec('supervisor', 'Supervisor (optional)'),
      const FieldSpec('goals', 'Goals (e.g. 10 cannulations, 5 DKA cases)', type: FT.multi),
      const FieldSpec('note', 'Notes', type: FT.multi),
    ],
    initial: r ??
        <String, dynamic>{
          'id': newId('r'),
          'start': todayStr(),
        },
    canDelete: r != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.rotations, 'rotations.json', r!['id'].toString());
  } else {
    await store.upsert(store.rotations, 'rotations.json', res);
  }
}

class RotationScreen extends StatelessWidget {
  final String rotationId;
  const RotationScreen({super.key, required this.rotationId});

  Future<void> _generate(BuildContext context, J rot) async {
    final start = parseDate((rot['start'] ?? '').toString());
    final end = parseDate((rot['end'] ?? '').toString());
    if (start == null || end == null) {
      snack(context, 'Set start and end dates for this rotation first.');
      return;
    }
    final days = await showDialog<Set<int>>(
      context: context,
      builder: (ctx) => const _WeekdayDialog(),
    );
    if (days == null || days.isEmpty) return;
    var added = 0;
    var d = DateTime(start.year, start.month, start.day);
    final last = DateTime(end.year, end.month, end.day);
    while (!d.isAfter(last)) {
      if (days.contains(d.weekday) && store.shiftFor(fmtDate(d)) == null) {
        store.shifts.add(<String, dynamic>{
          'date': fmtDate(d),
          'type': 'Morning',
          'rotationId': rotationId,
          'updated': nowIso(),
        });
        added++;
      }
      d = d.add(const Duration(days: 1));
    }
    await store.saveList('shifts.json', store.shifts);
    store.refresh();
    if (context.mounted) snack(context, trp('Added {n} duty days.', {'n': added}));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final rot = store.rotationById(rotationId);
        if (rot == null) {
          return Scaffold(appBar: AppBar(), body: const Center(child: Text('Rotation not found')));
        }
        final theme = Theme.of(context);
        final cases = store.casesOfRotation(rotationId);
        final shifts = store.shifts.where((s) => s['rotationId'] == rotationId).toList();
        shifts.sort((a, b) =>
            (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        final procs = store.procedures.where((p) => p['rotationId'] == rotationId).length;
        final perDay = <String, int>{};
        for (final c in cases) {
          perDay[c.s('date')] = (perDay[c.s('date')] ?? 0) + 1;
        }
        final goals = (rot['goals'] ?? '').toString();
        final note = (rot['note'] ?? '').toString();
        final sup = (rot['supervisor'] ?? '').toString();

        return Scaffold(
          appBar: AppBar(
            title: Text(store.rotationLabel(rot)),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => editRotation(context, rot),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                '${prettyDate((rot['start'] ?? '').toString())}'
                '${(rot['end'] ?? '').toString().isEmpty ? '' : '  $arrow  ${prettyDate(rot['end'].toString())}'}',
                style: theme.textTheme.titleMedium,
              ),
              if (sup.isNotEmpty) Text('${tr('Supervisor')}: $sup'),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  Chip(label: Text(countLabel(cases.length, 'case'))),
                  Chip(label: Text(countLabel(shifts.length, 'duty day'))),
                  Chip(label: Text(countLabel(procs, 'procedure'))),
                ],
              ),
              if (goals.isNotEmpty) ...[
                const SectionHeader('Goals'),
                Text(goals),
              ],
              if (note.isNotEmpty) ...[
                const SectionHeader('Notes'),
                Text(note),
              ],
              SectionHeader(
                'Duty days',
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'gen') _generate(context, rot);
                    if (v == 'one') {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      ).then((d) {
                        if (d != null && context.mounted) {
                          editShift(context, fmtDate(d), rotationId: rotationId);
                        }
                      });
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'gen', child: Text('Generate by weekdays')),
                    PopupMenuItem(value: 'one', child: Text('Add one day')),
                  ],
                ),
              ),
              if (shifts.isEmpty)
                Text('No duty days yet. Use the menu to generate them by weekdays '
                    '(e.g. every Sat, Mon, Wed).'),
              for (final s in shifts)
                AppCard(
                  child: ListTile(
                    onTap: () => editShift(context, s['date'].toString(),
                        rotationId: rotationId),
                    title: Text(prettyDate(s['date'].toString())),
                    subtitle: Text([
                      tr((s['type'] ?? '').toString()),
                      countLabel(perDay[s['date']] ?? 0, 'case'),
                    ].where((e) => e.isNotEmpty).join(' • ')),
                  ),
                ),
              const SectionHeader('Cases'),
              if (cases.isEmpty) Text('No cases in this rotation yet.'),
              for (final c in (cases..sort((a, b) => b.s('date').compareTo(a.s('date')))))
                CaseTile(c),
            ],
          ),
        );
      },
    );
  }
}

class _WeekdayDialog extends StatefulWidget {
  const _WeekdayDialog();

  @override
  State<_WeekdayDialog> createState() => _WeekdayDialogState();
}

class _WeekdayDialogState extends State<_WeekdayDialog> {
  final Set<int> _sel = {};

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Which weekdays are your duty days?'),
      content: Wrap(
        spacing: 8,
        children: [
          for (var i = 0; i < 7; i++)
            FilterChip(
              label: Text(kWeekdays[i]),
              selected: _sel.contains(i + 1),
              onSelected: (v) => setState(() {
                if (v) {
                  _sel.add(i + 1);
                } else {
                  _sel.remove(i + 1);
                }
              }),
            ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(context, _sel),
          child: const Text('Generate'),
        ),
      ],
    );
  }
}

// ================================================================ portfolio / stats

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});

  Widget _bars(BuildContext context, Map<String, int> data, {int top = 10, bool translate = false}) {
    if (data.isEmpty) return const Text('—');
    final entries = data.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final shown = entries.take(top).toList();
    final maxV = shown.first.value;
    return Column(
      children: [
        for (var i = 0; i < shown.length; i++)
          FadeSlideIn(
            index: i,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  SizedBox(
                    width: 130,
                    child: Text(translate ? tr(shown[i].key) : shown[i].key,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
                  Expanded(child: AnimatedBar(shown[i].value / maxV)),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 28,
                    child: CountUp(shown[i].value, style: Theme.of(context).textTheme.labelLarge),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final theme = Theme.of(context);
        final cases = store.cases.values.toList();
        final bySpec = <String, int>{};
        final byRole = <String, int>{};
        final byDx = <String, int>{};
        final perDay = <String, int>{};
        for (final c in cases) {
          final sp = c.s('specialty');
          if (sp.isNotEmpty) bySpec[sp] = (bySpec[sp] ?? 0) + 1;
          final ro = c.s('role');
          if (ro.isNotEmpty) byRole[ro] = (byRole[ro] ?? 0) + 1;
          var dx = c.s('finalDx').trim();
          if (dx.isEmpty) dx = c.s('workingDx').trim();
          if (dx.isNotEmpty) {
            final k = dx.toLowerCase();
            byDx[k] = (byDx[k] ?? 0) + 1;
          }
          final d = c.s('date');
          if (d.isNotEmpty) perDay[d] = (perDay[d] ?? 0) + 1;
        }
        final byProc = <String, int>{};
        for (final p in store.procedures) {
          final n = (p['name'] ?? '').toString();
          if (n.isNotEmpty) byProc[n] = (byProc[n] ?? 0) + 1;
        }
        final rots = List<J>.from(store.rotations)
          ..sort((a, b) =>
              (b['start'] ?? '').toString().compareTo((a['start'] ?? '').toString()));

        return Scaffold(
          appBar: AppBar(
            title: const Text('Portfolio'),
            actions: [
              IconButton(
                tooltip: tr('Calendar'),
                icon: const Icon(Icons.calendar_month_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CalendarScreen()),
                ),
              ),
              IconButton(
                tooltip: tr('Settings'),
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            children: [
              FadeSlideIn(
                child: GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 1.25,
                  children: [
                    _Big(Icons.folder_copy_outlined, cases.length, 'Cases'),
                    _Big(Icons.local_hospital_outlined, store.shifts.length, 'Duty days'),
                    _Big(Icons.healing_outlined, store.procedures.length, 'Procedures'),
                    _Big(Icons.edit_note, store.notes.length, 'Notes'),
                    _Big(Icons.swap_horiz, store.rotations.length, 'Rotations'),
                    _Big(Icons.star_outline, cases.where((c) => c.starred).length, 'Starred'),
                  ],
                ),
              ),
              const SectionHeader('Activity (last 16 weeks)'),
              FadeSlideIn(index: 1, child: _Heatmap(perDay)),
              SectionHeader(
                'Rotations',
                trailing: TextButton.icon(
                  onPressed: () => editRotation(context),
                  icon: const Icon(Icons.add),
                  label: Text('Add'),
                ),
              ),
              if (rots.isEmpty) const Text('No rotations yet.'),
              for (var i = 0; i < rots.length; i++)
                FadeSlideIn(
                  index: i,
                  child: AppCard(
                    child: ListTile(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RotationScreen(rotationId: rots[i]['id'].toString()),
                        ),
                      ),
                      title: Text(store.rotationLabel(rots[i])),
                      subtitle: Text(
                        '${prettyDate((rots[i]['start'] ?? '').toString())}'
                        '${(rots[i]['end'] ?? '').toString().isEmpty ? '' : ' $arrow ${prettyDate(rots[i]['end'].toString())}'}'
                        '\n${countLabel(store.casesOfRotation(rots[i]['id'].toString()).length, 'case')}',
                      ),
                      isThreeLine: true,
                    ),
                  ),
                ),
              const SectionHeader('Cases by specialty'),
              _bars(context, bySpec, translate: true),
              const SectionHeader('My role in cases'),
              _bars(context, byRole, translate: true),
              const SectionHeader('Most frequent diagnoses'),
              _bars(context, byDx, top: 8),
              const SectionHeader('Procedures'),
              _bars(context, byProc, translate: true),
              const SizedBox(height: 8),
              Text(
                'Counts show what you saw and did. They do not prove competence by themselves.',
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Big extends StatelessWidget {
  final IconData icon;
  final int value;
  final String label;
  const _Big(this.icon, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return AppCard(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: cs.primary),
            const SizedBox(height: 4),
            CountUp(value,
                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.labelMedium?.copyWith(color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

/// GitHub-style activity grid: one square per day, darker = more cases.
class _Heatmap extends StatelessWidget {
  final Map<String, int> perDay;
  const _Heatmap(this.perDay);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const weeks = 16;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    // week columns end on today's week; Monday first (rows are Mon..Sun)
    final endMonday = today.subtract(Duration(days: today.weekday - 1));
    final start = endMonday.subtract(const Duration(days: 7 * (weeks - 1)));
    var maxV = 1;
    for (final v in perDay.values) {
      if (v > maxV) maxV = v;
    }
    final on = animOn(context);
    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Directionality(
          textDirection: Directionality.of(context),
          child: Row(
            children: [
              for (var w = 0; w < weeks; w++)
                Expanded(
                  child: Column(
                    children: [
                      for (var d = 0; d < 7; d++)
                        Builder(builder: (_) {
                          final day = start.add(Duration(days: w * 7 + d));
                          final future = day.isAfter(today);
                          final n = perDay[fmtDate(day)] ?? 0;
                          final base = future
                              ? Colors.transparent
                              : (n == 0
                                  ? cs.surfaceContainerHighest
                                  : cs.primary.withAlpha((70 + 185 * (n / maxV)).round()));
                          return TweenAnimationBuilder<double>(
                            tween: Tween<double>(begin: on ? 0 : 1, end: 1),
                            duration: Duration(milliseconds: on ? 300 + w * 35 : 0),
                            curve: Curves.easeOut,
                            builder: (_, v, __) => Container(
                              margin: const EdgeInsets.all(1.5),
                              height: 14,
                              decoration: BoxDecoration(
                                color: base.withAlpha((base.a * 255 * v).round()),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          );
                        }),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================ settings

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  Future<void> _setPin() async {
    final a = await askText(context, 'New PIN (4–6 digits)',
        obscure: true, number: true, maxLength: 6);
    if (a == null) return;
    if (a.length < 4) {
      if (mounted) snack(context, 'PIN must be at least 4 digits.');
      return;
    }
    if (!mounted) return;
    final b = await askText(context, 'Repeat PIN', obscure: true, number: true, maxLength: 6);
    if (b == null) return;
    if (a != b) {
      if (mounted) snack(context, 'PINs do not match.');
      return;
    }
    await store.setPin(a);
    if (mounted) snack(context, 'PIN is set.');
  }

  Future<bool> _verifyPin() async {
    final cur = await askText(context, 'Enter current PIN',
        obscure: true, number: true, maxLength: 6);
    if (cur == null) return false;
    if (!store.checkPin(cur)) {
      if (mounted) snack(context, 'Wrong PIN.');
      return false;
    }
    return true;
  }

  Future<void> _removePin() async {
    if (!await _verifyPin()) return;
    await store.clearPin();
    if (mounted) snack(context, 'PIN removed.');
  }

  Future<void> _changePin() async {
    if (!await _verifyPin()) return;
    await _setPin();
  }

  Future<void> _editAuthor() async {
    final v = await askText(context, 'Your name for shared cases', hint: 'e.g. Dr. Sara');
    if (v == null) return;
    await store.setAuthor(v);
  }

  Future<void> _export() async {
    final pw = await askPassword(
      context,
      'Backup password',
      confirm: true,
      note: 'The backup is encrypted. If you forget this password nobody can open '
          'it — not even me. Write it down somewhere safe.',
    );
    if (pw == null) return;
    setState(() => _busy = true);
    try {
      final f = await store.exportBackup(pw);
      await Share.shareXFiles([XFile(f.path)], text: 'MedLog backup');
    } catch (e) {
      if (mounted) snack(context, '${tr('Export failed')}: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _exportCsv() async {
    setState(() => _busy = true);
    try {
      final files = await store.exportCsv();
      await Share.shareXFiles([for (final f in files) XFile(f.path)], text: 'MedLog logbook');
    } catch (e) {
      if (mounted) snack(context, '${tr('Export failed')}: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return;
    final bytes = await File(r.files.single.path!).readAsBytes();
    if (!mounted) return;
    String? pw;
    if (store.looksEncrypted(bytes)) {
      pw = await askPassword(context, 'Password of this file');
      if (pw == null) return;
    }
    setState(() => _busy = true);
    ImportPlan plan;
    try {
      plan = await store.previewImport(bytes, password: pw);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        snack(context, '$e');
      }
      return;
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (plan.empty) {
      snack(context, trp('Nothing new in this file ({n} already up to date).', {'n': plan.unchanged}));
      return;
    }
    final ok = await confirmDialog(
      context,
      '${plan.isPack ? (plan.author.isEmpty ? tr('Cases shared') : trp('Cases shared by {name}', {'name': plan.author})) : tr('Backup')}:\n'
      '• ${trp('{n} new cases', {'n': plan.newCases})}\n'
      '• ${trp('{n} updated', {'n': plan.updatedCases})}\n'
      '• ${trp('{n} unchanged', {'n': plan.unchanged})}\n'
      '• ${trp('{n} new images', {'n': plan.images.length})}\n\n'
      '${plan.isPack ? tr('Your own cases are never overwritten.') : tr('The newer version of each item wins.')}',
      action: 'Import',
    );
    if (!ok) return;
    setState(() => _busy = true);
    try {
      final msg = await store.applyImport(plan);
      if (mounted) snack(context, msg);
    } catch (e) {
      if (mounted) snack(context, '${tr('Import failed')}: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final images = store.imagesDir.listSync().length;
        final days = store.daysSinceBackup;
        return Scaffold(
          appBar: AppBar(title: const Text('Settings & backup')),
          body: ListView(
            children: [
              if (_busy) const LinearProgressIndicator(),
              const _AppearanceSection(),
              const Divider(),
              const SectionHeader('  Sharing'),
              ListTile(
                leading: const Icon(Icons.badge_outlined),
                title: const Text('My name on shared cases'),
                subtitle: Text(store.author.isEmpty ? 'Not set' : store.author),
                onTap: _editAuthor,
              ),
              SwitchListTile(
                secondary: const Icon(Icons.person_outline),
                title: const Text('Store patient initials on this phone'),
                subtitle: const Text('Off by default. Initials are never sent when sharing.'),
                value: store.useInitials,
                onChanged: (v) => store.setUseInitials(v),
              ),
              const Divider(),
              const SectionHeader('  Security'),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('App lock (PIN)'),
                subtitle: Text(store.hasPin ? 'On' : 'Off'),
                onTap: store.hasPin ? null : _setPin,
                trailing: store.hasPin
                    ? Wrap(
                        children: [
                          TextButton(onPressed: _changePin, child: const Text('Change')),
                          TextButton(onPressed: _removePin, child: const Text('Remove')),
                        ],
                      )
                    : null,
              ),
              SwitchListTile(
                secondary: const Icon(Icons.screen_lock_portrait_outlined),
                title: const Text('Block screenshots & hide in recent apps'),
                value: store.secureScreen,
                onChanged: (v) => store.setSecureScreen(v),
              ),
              const Divider(),
              const SectionHeader('  Backup & import'),
              ListTile(
                leading: const Icon(Icons.upload_file_outlined),
                title: const Text('Export encrypted backup'),
                subtitle: Text(days == null
                    ? tr('Never backed up')
                    : '${tr('Last backup')}: ${days == 0 ? tr('today') : trp('{n} days ago', {'n': days})}'),
                onTap: _busy ? null : _export,
              ),
              ListTile(
                leading: const Icon(Icons.download_outlined),
                title: const Text('Import backup or shared cases'),
                subtitle: const Text('.medlogbak, .medlogpack or an old ZIP — you see a preview first'),
                onTap: _busy ? null : _import,
              ),
              ListTile(
                leading: const Icon(Icons.table_chart_outlined),
                title: const Text('Export logbook (CSV)'),
                subtitle: const Text('Cases and procedures list for the hospital / Excel'),
                onTap: _busy ? null : _exportCsv,
              ),
              const Divider(),
              const SectionHeader('  Data & recovery'),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('On this phone'),
                subtitle: Text('${countLabel(store.cases.length, 'case')} • ${trp('{n} image files', {'n': images})}\n'
                    '${tr('Stored privately inside the app. Not in the gallery, not synced.')}\n'
                    '${tr('Data format')} v$kSchema • ${tr('app')} $kAppVersion'),
                isThreeLine: true,
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Privacy reminders\n'
                  '• No names, ID numbers or exact ages.\n'
                  '• Cover names / file numbers on any photo before capturing.\n'
                  '• Be careful with exact dates and rare details that could identify a patient.\n'
                  '• This is a personal learning log, not the official medical record.\n'
                  '• Ask your hospital about its documentation and photo policy.\n'
                  '• Keep backups somewhere private. A forgotten backup password cannot be recovered.\n'
                  '• Voice typing on the keyboard may send audio to the internet: do not dictate patient details.',
                ),
              ),
              const _AboutCard(),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ appearance & about

class _AppearanceSection extends StatelessWidget {
  const _AppearanceSection();

  Widget _seg(BuildContext context, String title, Widget control) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 6),
          SizedBox(width: double.infinity, child: control),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader('  Appearance'),
        _seg(
          context,
          tr('Language'),
          SegmentedButton<String>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: kLangSystem, label: Text('Auto')),
              ButtonSegment(value: kLangEn, label: Text('English')),
              ButtonSegment(value: kLangAr, label: Text('العربية')),
            ],
            selected: {store.lang},
            onSelectionChanged: (v) async {
              await store.setLook('lang', v.first);
              // the whole app restarts in the new language: come back to Settings
              WidgetsBinding.instance.addPostFrameCallback((_) {
                navKeyFor(currentNavId).currentState?.push(
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    );
              });
            },
          ),
        ),
        _seg(
          context,
          tr('Mode'),
          SegmentedButton<String>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 'system', icon: Icon(Icons.brightness_auto), label: Text('Auto')),
              ButtonSegment(value: 'light', icon: Icon(Icons.light_mode_outlined), label: Text('Light')),
              ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode_outlined), label: Text('Dark')),
            ],
            selected: {store.themeMode},
            onSelectionChanged: (v) => store.setLook('themeMode', v.first),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Text('Theme', style: Theme.of(context).textTheme.labelLarge),
        ),
        SizedBox(
          height: 112,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final p in kPalettes)
                _PaletteCard(p, selected: store.paletteId == p.id, dark: dark),
            ],
          ),
        ),
        const _FontPicker(),
        SwitchListTile(
          secondary: const Icon(Icons.contrast),
          title: const Text('Pure black dark mode'),
          subtitle: const Text('Saves battery on OLED screens'),
          value: store.amoled,
          onChanged: (v) => store.setLook('amoled', v),
        ),
        SwitchListTile(
          secondary: Icon(Icons.animation, color: cs.onSurfaceVariant),
          title: const Text('Animations'),
          subtitle: const Text('Heartbeat motion, transitions and counters'),
          value: store.motion,
          onChanged: (v) => store.setLook('motion', v),
        ),
      ],
    );
  }
}

class _FontPicker extends StatelessWidget {
  const _FontPicker();

  Widget _row(BuildContext context, String title, String sample, List<FontChoice> options,
      String selected, String key) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final f in options)
                ChoiceChip(
                  selected: selected == f.id,
                  onSelected: (_) => store.setLook(key, f.id),
                  // every option is drawn in its own font so you can compare
                  label: m.Text(
                    '${f.id == 'tinos' ? f.label : tr(f.label)}  $sample',
                    style: TextStyle(fontFamily: f.family, fontSize: 16),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _row(context, tr('Arabic font'), 'سجلّي الطبي', kArFonts, store.fontAr, 'fontAr'),
        _row(context, tr('English font'), 'Clinical Logbook', kEnFonts, store.fontEn, 'fontEn'),
      ],
    );
  }
}

class _PaletteCard extends StatelessWidget {
  final AppPalette p;
  final bool selected;
  final bool dark;
  const _PaletteCard(this.p, {required this.selected, required this.dark});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 10),
      child: GestureDetector(
        onTap: () => store.setLook('palette', p.id),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutBack,
          width: 92,
          padding: const EdgeInsets.all(6),
          transform: Matrix4.diagonal3Values(selected ? 1.0 : 0.94, selected ? 1.0 : 0.94, 1),
          transformAlignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? cs.primary : cs.outlineVariant,
              width: selected ? 2.4 : 1,
            ),
          ),
          child: Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [p.seed, p.accent],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    PositionedDirectional(
                      top: 6,
                      end: 6,
                      child: AnimatedOpacity(
                        opacity: selected ? 1 : 0,
                        duration: const Duration(milliseconds: 200),
                        child: const CircleAvatar(
                          radius: 10,
                          backgroundColor: Colors.white,
                          child: Icon(Icons.check, size: 14, color: Colors.black87),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                isAr ? p.nameAr : p.nameEn,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.labelSmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AboutCard extends StatelessWidget {
  const _AboutCard();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
      child: AppCard(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const MedLogMark(size: 72),
              const SizedBox(height: 12),
              Text('MedLog',
                  style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              Text('v$kAppVersion', style: theme.textTheme.labelMedium?.copyWith(color: cs.outline)),
              const SizedBox(height: 14),
              Text(designedBy,
                  style: theme.textTheme.labelMedium?.copyWith(color: cs.onSurfaceVariant)),
              const SizedBox(height: 2),
              Text(designerName,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.titleMedium
                      ?.copyWith(color: cs.primary, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              EcgBanner(color: cs.primary, height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
