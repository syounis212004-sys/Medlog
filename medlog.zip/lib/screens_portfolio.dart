import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import 'data.dart';
import 'screens_cases.dart';
import 'screens_home.dart';
import 'ui.dart';
import 'widgets.dart';

// ================================================================ rotations

Future<void> editRotation(BuildContext context, [J? r]) async {
  final res = await showFormSheet(
    context,
    title: r == null ? 'New rotation' : 'Edit rotation',
    specs: [
      FieldSpec('name', 'Rotation / specialty', options: kSpecialtyNames),
      const FieldSpec('start', 'Start date', type: FT.date),
      const FieldSpec('end', 'End date', type: FT.date),
      const FieldSpec('hospital', 'Hospital / department'),
      const FieldSpec('supervisor', 'Supervisor (optional)'),
      const FieldSpec('goals', 'Goals (e.g. 10 cannulations, 5 DKA cases)', type: FT.multi),
      const FieldSpec('note', 'Notes', type: FT.multi),
    ],
    initial: r ??
        <String, dynamic>{
          'id': newId('r'),
          'start': todayStr(),
        },
    canDelete: r != null,
  );
  if (res == null) return;
  if (res['__delete'] == true) {
    await store.removeFrom(store.rotations, 'rotations.json', r!['id'].toString());
  } else {
    await store.upsert(store.rotations, 'rotations.json', res);
  }
}

class RotationScreen extends StatelessWidget {
  final String rotationId;
  const RotationScreen({super.key, required this.rotationId});

  Future<void> _generate(BuildContext context, J rot) async {
    final start = parseDate((rot['start'] ?? '').toString());
    final end = parseDate((rot['end'] ?? '').toString());
    if (start == null || end == null) {
      snack(context, 'Set start and end dates for this rotation first.');
      return;
    }
    final days = await showDialog<Set<int>>(
      context: context,
      builder: (ctx) => const _WeekdayDialog(),
    );
    if (days == null || days.isEmpty) return;
    var added = 0;
    var d = DateTime(start.year, start.month, start.day);
    final last = DateTime(end.year, end.month, end.day);
    while (!d.isAfter(last)) {
      if (days.contains(d.weekday) && store.shiftFor(fmtDate(d)) == null) {
        store.shifts.add(<String, dynamic>{
          'date': fmtDate(d),
          'type': 'Morning',
          'rotationId': rotationId,
          'updated': nowIso(),
        });
        added++;
      }
      d = d.add(const Duration(days: 1));
    }
    await store.saveList('shifts.json', store.shifts);
    store.refresh();
    if (context.mounted) snack(context, 'Added $added duty days.');
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final rot = store.rotationById(rotationId);
        if (rot == null) {
          return Scaffold(appBar: AppBar(), body: const Center(child: Text('Rotation not found')));
        }
        final theme = Theme.of(context);
        final cases = store.casesOfRotation(rotationId);
        final shifts = store.shifts.where((s) => s['rotationId'] == rotationId).toList();
        shifts.sort((a, b) =>
            (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString()));
        final procs = store.procedures.where((p) => p['rotationId'] == rotationId).length;
        final perDay = <String, int>{};
        for (final c in cases) {
          perDay[c.s('date')] = (perDay[c.s('date')] ?? 0) + 1;
        }
        final goals = (rot['goals'] ?? '').toString();
        final note = (rot['note'] ?? '').toString();
        final sup = (rot['supervisor'] ?? '').toString();

        return Scaffold(
          appBar: AppBar(
            title: Text(store.rotationLabel(rot)),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => editRotation(context, rot),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                '${prettyDate((rot['start'] ?? '').toString())}'
                '${(rot['end'] ?? '').toString().isEmpty ? '' : '  →  ${prettyDate(rot['end'].toString())}'}',
                style: theme.textTheme.titleMedium,
              ),
              if (sup.isNotEmpty) Text('Supervisor: $sup'),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  Chip(label: Text('${cases.length} cases')),
                  Chip(label: Text('${shifts.length} duty days')),
                  Chip(label: Text('$procs procedures')),
                ],
              ),
              if (goals.isNotEmpty) ...[
                const SectionHeader('Goals'),
                Text(goals),
              ],
              if (note.isNotEmpty) ...[
                const SectionHeader('Notes'),
                Text(note),
              ],
              SectionHeader(
                'Duty days',
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'gen') _generate(context, rot);
                    if (v == 'one') {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      ).then((d) {
                        if (d != null && context.mounted) {
                          editShift(context, fmtDate(d), rotationId: rotationId);
                        }
                      });
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'gen', child: Text('Generate by weekdays')),
                    PopupMenuItem(value: 'one', child: Text('Add one day')),
                  ],
                ),
              ),
              if (shifts.isEmpty)
                const Text('No duty days yet. Use the menu to generate them by weekdays '
                    '(e.g. every Sat, Mon, Wed).'),
              for (final s in shifts)
                AppCard(
                  child: ListTile(
                    onTap: () => editShift(context, s['date'].toString(),
                        rotationId: rotationId),
                    title: Text(prettyDate(s['date'].toString())),
                    subtitle: Text([
                      (s['type'] ?? '').toString(),
                      '${perDay[s['date']] ?? 0} cases',
                    ].where((e) => e.isNotEmpty).join(' • ')),
                  ),
                ),
              const SectionHeader('Cases'),
              if (cases.isEmpty) const Text('No cases in this rotation yet.'),
              for (final c in (cases..sort((a, b) => b.s('date').compareTo(a.s('date')))))
                CaseTile(c),
            ],
          ),
        );
      },
    );
  }
}

class _WeekdayDialog extends StatefulWidget {
  const _WeekdayDialog();

  @override
  State<_WeekdayDialog> createState() => _WeekdayDialogState();
}

class _WeekdayDialogState extends State<_WeekdayDialog> {
  final Set<int> _sel = {};

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Which weekdays are your duty days?'),
      content: Wrap(
        spacing: 8,
        children: [
          for (var i = 0; i < 7; i++)
            FilterChip(
              label: Text(kWeekdays[i]),
              selected: _sel.contains(i + 1),
              onSelected: (v) => setState(() {
                if (v) {
                  _sel.add(i + 1);
                } else {
                  _sel.remove(i + 1);
                }
              }),
            ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(context, _sel),
          child: const Text('Generate'),
        ),
      ],
    );
  }
}

// ================================================================ portfolio / stats

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});

  Widget _bars(BuildContext context, Map<String, int> data, {int top = 10}) {
    if (data.isEmpty) return const Text('—');
    final entries = data.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final shown = entries.take(top).toList();
    final maxV = shown.first.value;
    return Column(
      children: [
        for (final e in shown)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(
                  width: 130,
                  child: Text(e.key, maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
                Expanded(
                  child: LinearProgressIndicator(value: e.value / maxV, minHeight: 10),
                ),
                const SizedBox(width: 8),
                Text('${e.value}'),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final cases = store.cases.values.toList();
        final bySpec = <String, int>{};
        final byRole = <String, int>{};
        final byDx = <String, int>{};
        for (final c in cases) {
          final sp = c.s('specialty');
          if (sp.isNotEmpty) bySpec[sp] = (bySpec[sp] ?? 0) + 1;
          final ro = c.s('role');
          if (ro.isNotEmpty) byRole[ro] = (byRole[ro] ?? 0) + 1;
          var dx = c.s('finalDx').trim();
          if (dx.isEmpty) dx = c.s('workingDx').trim();
          if (dx.isNotEmpty) {
            final k = dx.toLowerCase();
            byDx[k] = (byDx[k] ?? 0) + 1;
          }
        }
        final byProc = <String, int>{};
        for (final p in store.procedures) {
          final n = (p['name'] ?? '').toString();
          if (n.isNotEmpty) byProc[n] = (byProc[n] ?? 0) + 1;
        }
        final rots = List<J>.from(store.rotations)
          ..sort((a, b) =>
              (b['start'] ?? '').toString().compareTo((a['start'] ?? '').toString()));

        return Scaffold(
          appBar: AppBar(
            title: const Text('Portfolio'),
            actions: [
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  Chip(label: Text('${cases.length} cases')),
                  Chip(label: Text('${store.shifts.length} duty days')),
                  Chip(label: Text('${store.procedures.length} procedures')),
                  Chip(label: Text('${store.notes.length} notes')),
                  Chip(label: Text('${store.rotations.length} rotations')),
                ],
              ),
              SectionHeader(
                'Rotations',
                trailing: TextButton.icon(
                  onPressed: () => editRotation(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Add'),
                ),
              ),
              if (rots.isEmpty) const Text('No rotations yet.'),
              for (final r in rots)
                AppCard(
                  child: ListTile(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RotationScreen(rotationId: r['id'].toString()),
                      ),
                    ),
                    title: Text(store.rotationLabel(r)),
                    subtitle: Text(
                      '${prettyDate((r['start'] ?? '').toString())}'
                      '${(r['end'] ?? '').toString().isEmpty ? '' : ' → ${prettyDate(r['end'].toString())}'}'
                      '\n${store.casesOfRotation(r['id'].toString()).length} cases',
                    ),
                    isThreeLine: true,
                  ),
                ),
              const SectionHeader('Cases by specialty'),
              _bars(context, bySpec),
              const SectionHeader('My role in cases'),
              _bars(context, byRole),
              const SectionHeader('Most frequent diagnoses'),
              _bars(context, byDx, top: 8),
              const SectionHeader('Procedures'),
              _bars(context, byProc),
            ],
          ),
        );
      },
    );
  }
}

// ================================================================ settings

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  Future<void> _setPin() async {
    final a = await askText(context, 'New PIN (4–6 digits)',
        obscure: true, number: true, maxLength: 6);
    if (a == null) return;
    if (a.length < 4) {
      if (mounted) snack(context, 'PIN must be at least 4 digits.');
      return;
    }
    if (!mounted) return;
    final b = await askText(context, 'Repeat PIN', obscure: true, number: true, maxLength: 6);
    if (b == null) return;
    if (a != b) {
      if (mounted) snack(context, 'PINs do not match.');
      return;
    }
    await store.setPin(a);
    if (mounted) snack(context, 'PIN is set.');
  }

  Future<bool> _verifyPin() async {
    final cur = await askText(context, 'Enter current PIN',
        obscure: true, number: true, maxLength: 6);
    if (cur == null) return false;
    if (!store.checkPin(cur)) {
      if (mounted) snack(context, 'Wrong PIN.');
      return false;
    }
    return true;
  }

  Future<void> _removePin() async {
    if (!await _verifyPin()) return;
    await store.clearPin();
    if (mounted) snack(context, 'PIN removed.');
  }

  Future<void> _changePin() async {
    if (!await _verifyPin()) return;
    await _setPin();
  }

  Future<void> _editAuthor() async {
    final v = await askText(context, 'Your name for shared cases', hint: 'e.g. Dr. Sara');
    if (v == null) return;
    await store.setAuthor(v);
  }

  Future<void> _export() async {
    final pw = await askPassword(
      context,
      'Backup password',
      confirm: true,
      note: 'The backup is encrypted. If you forget this password nobody can open '
          'it — not even me. Write it down somewhere safe.',
    );
    if (pw == null) return;
    setState(() => _busy = true);
    try {
      final f = await store.exportBackup(pw);
      await Share.shareXFiles([XFile(f.path)], text: 'MedLog backup');
    } catch (e) {
      if (mounted) snack(context, 'Export failed: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _exportCsv() async {
    setState(() => _busy = true);
    try {
      final files = await store.exportCsv();
      await Share.shareXFiles([for (final f in files) XFile(f.path)], text: 'MedLog logbook');
    } catch (e) {
      if (mounted) snack(context, 'Export failed: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null || r.files.isEmpty || r.files.single.path == null) return;
    final bytes = await File(r.files.single.path!).readAsBytes();
    if (!mounted) return;
    String? pw;
    if (store.looksEncrypted(bytes)) {
      pw = await askPassword(context, 'Password of this file');
      if (pw == null) return;
    }
    setState(() => _busy = true);
    ImportPlan plan;
    try {
      plan = await store.previewImport(bytes, password: pw);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        snack(context, '$e');
      }
      return;
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (plan.empty) {
      snack(context, 'Nothing new in this file (${plan.unchanged} already up to date).');
      return;
    }
    final ok = await confirmDialog(
      context,
      '${plan.isPack ? 'Cases shared${plan.author.isEmpty ? '' : ' by ${plan.author}'}' : 'Backup'}:\n'
      '• ${plan.newCases} new cases\n'
      '• ${plan.updatedCases} updated\n'
      '• ${plan.unchanged} unchanged\n'
      '• ${plan.images.length} new images\n\n'
      '${plan.isPack ? 'Your own cases are never overwritten.' : 'The newer version of each item wins.'}',
      action: 'Import',
    );
    if (!ok) return;
    setState(() => _busy = true);
    try {
      final msg = await store.applyImport(plan);
      if (mounted) snack(context, msg);
    } catch (e) {
      if (mounted) snack(context, 'Import failed: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final images = store.imagesDir.listSync().length;
        final days = store.daysSinceBackup;
        return Scaffold(
          appBar: AppBar(title: const Text('Settings & backup')),
          body: ListView(
            children: [
              if (_busy) const LinearProgressIndicator(),
              const SectionHeader('  Sharing'),
              ListTile(
                leading: const Icon(Icons.badge_outlined),
                title: const Text('My name on shared cases'),
                subtitle: Text(store.author.isEmpty ? 'Not set' : store.author),
                onTap: _editAuthor,
              ),
              SwitchListTile(
                secondary: const Icon(Icons.person_outline),
                title: const Text('Store patient initials on this phone'),
                subtitle: const Text('Off by default. Initials are never sent when sharing.'),
                value: store.useInitials,
                onChanged: (v) => store.setUseInitials(v),
              ),
              const Divider(),
              const SectionHeader('  Security'),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('App lock (PIN)'),
                subtitle: Text(store.hasPin ? 'On' : 'Off'),
                onTap: store.hasPin ? null : _setPin,
                trailing: store.hasPin
                    ? Wrap(
                        children: [
                          TextButton(onPressed: _changePin, child: const Text('Change')),
                          TextButton(onPressed: _removePin, child: const Text('Remove')),
                        ],
                      )
                    : null,
              ),
              SwitchListTile(
                secondary: const Icon(Icons.screen_lock_portrait_outlined),
                title: const Text('Block screenshots & hide in recent apps'),
                value: store.secureScreen,
                onChanged: (v) => store.setSecureScreen(v),
              ),
              const Divider(),
              const SectionHeader('  Backup & import'),
              ListTile(
                leading: const Icon(Icons.upload_file_outlined),
                title: const Text('Export encrypted backup'),
                subtitle: Text(days == null
                    ? 'Never backed up'
                    : 'Last backup: ${days == 0 ? 'today' : '$days days ago'}'),
                onTap: _busy ? null : _export,
              ),
              ListTile(
                leading: const Icon(Icons.download_outlined),
                title: const Text('Import backup or shared cases'),
                subtitle: const Text('.medlogbak, .medlogpack or an old ZIP — you see a preview first'),
                onTap: _busy ? null : _import,
              ),
              ListTile(
                leading: const Icon(Icons.table_chart_outlined),
                title: const Text('Export logbook (CSV)'),
                subtitle: const Text('Cases and procedures list for the hospital / Excel'),
                onTap: _busy ? null : _exportCsv,
              ),
              const Divider(),
              const SectionHeader('  Data & recovery'),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('On this phone'),
                subtitle: Text('${store.cases.length} cases • $images image files\n'
                    'Stored privately inside the app. Not in the gallery, not synced.\n'
                    'Data format v$kSchema • app $kAppVersion'),
                isThreeLine: true,
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Privacy reminders\n'
                  '• No names, ID numbers or exact ages.\n'
                  '• Cover names / file numbers on any photo before capturing.\n'
                  '• Be careful with exact dates and rare details that could identify a patient.\n'
                  '• This is a personal learning log, not the official medical record.\n'
                  '• Ask your hospital about its documentation and photo policy.\n'
                  '• Keep backups somewhere private. A forgotten backup password cannot be recovered.\n'
                  '• Voice typing on the keyboard may send audio to the internet: do not dictate patient details.',
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
