import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'lib_text.dart' show normQuote;

/// Text taken from a book (usually a PDF) arrives with the line breaks of the page, hyphenated words, page numbers
/// and running headers. These helpers turn one section of it into readable blocks: paragraphs, headings, bullet
/// items and wide table-like lines. Nothing is rewritten: only line breaks, hyphens and page furniture change.

enum BookKind { para, heading, bullet, pre }

class BookBlock {
  final BookKind kind;
  final String text;
  const BookBlock(this.kind, this.text);
  @override
  String toString() => '${kind.name}: $text';
}

final RegExp _bulletRe = RegExp(r'^([•▪▸◦●■·\-\*–]|\d{1,2}[.)]|\([a-z0-9]{1,2}\)|[a-z][.)])\s+');
final RegExp _pageNo = RegExp(r'^(page\s+)?\d{1,4}$', caseSensitive: false);
final RegExp _sentenceEnd = RegExp(r'[.!?:;)\]"”’]$');

bool _isTableLine(String l) {
  if (l.contains('\t')) return true;
  return RegExp(r'\S {3,}\S').allMatches(l).length >= 2;
}

bool _isUpperHeading(String s) {
  final letters = s.replaceAll(RegExp(r'[^A-Za-z]'), '');
  return letters.length >= 4 && letters == letters.toUpperCase() && s.length <= 70;
}

bool _looksHeading(String s, String? next) {
  if (s.length > 70 || s.length < 3 || next == null) return false;
  if (_sentenceEnd.hasMatch(s) || s.endsWith(',')) return false;
  if (_isUpperHeading(s)) return true;
  if (RegExp(r'^\d+(\.\d+)*\s+\S').hasMatch(s) && s.split(' ').length <= 10) return true;
  final words = s.split(RegExp(r'\s+'));
  if (words.length > 9) return false;
  if (!RegExp(r'^[A-Z]').hasMatch(s)) return false;
  // Title Case: most longer words start with a capital letter
  final long = words.where((w) => w.length > 3).toList();
  return long.isNotEmpty && long.where((w) => RegExp(r'^[A-Z0-9]').hasMatch(w)).length * 3 >= long.length * 2;
}

List<BookBlock> parseBookText(String raw) {
  final text = raw.replaceAll('\r\n', '\n').replaceAll('­', '').replaceAll(' ', ' ');
  var lines = [for (final l in text.split('\n')) l.trimRight()];

  // page numbers and running headers/footers (a short line that comes back many times)
  final counts = <String, int>{};
  for (final l in lines) {
    final k = l.trim();
    if (k.isNotEmpty && k.length <= 60) counts[k] = (counts[k] ?? 0) + 1;
  }
  lines = [
    for (final l in lines)
      if (!(_pageNo.hasMatch(l.trim()) || (l.trim().length >= 4 && (counts[l.trim()] ?? 0) >= 4 && !_bulletRe.hasMatch(l.trim())))) l
  ];

  // are the lines wrapped at the page width? (many lines of about the same, moderate length)
  final lens = [for (final l in lines) if (l.trim().length > 25) l.trim().length]..sort();
  final maxLen = lens.isEmpty ? 0 : lens[(lens.length * 0.9).floor().clamp(0, lens.length - 1)];
  final wrapped = lens.length >= 4 && maxLen <= 130;

  final blocks = <BookBlock>[];
  var buf = '';
  var atBlockStart = true;
  void flush() {
    if (buf.isNotEmpty) {
      blocks.add(BookBlock(BookKind.para, buf));
      buf = '';
    }
    atBlockStart = true;
  }

  bool continues(String prev, String cur, int prevLen) {
    if (RegExp(r'^[a-z(]').hasMatch(cur)) return true;
    if (!_sentenceEnd.hasMatch(prev)) return wrapped || prev.length > 40;
    // a sentence ended: the paragraph goes on only when the line was a full line of wrapped text
    return wrapped && prevLen >= maxLen * 0.8;
  }

  String? nextNonEmpty(int i) {
    for (var j = i + 1; j < lines.length; j++) {
      if (lines[j].trim().isNotEmpty) return lines[j].trim();
    }
    return null;
  }

  var lastLen = 0;
  for (var i = 0; i < lines.length; i++) {
    final line = lines[i];
    final s = line.trim();
    if (s.isEmpty) {
      flush();
      continue;
    }
    if (_isTableLine(line)) {
      flush();
      final rows = [line];
      while (i + 1 < lines.length && lines[i + 1].trim().isNotEmpty && _isTableLine(lines[i + 1])) {
        rows.add(lines[++i]);
      }
      blocks.add(BookBlock(BookKind.pre, rows.join('\n')));
      continue;
    }
    if (_bulletRe.hasMatch(s)) {
      flush();
      final marker = _bulletRe.firstMatch(s)!.group(1)!;
      final numbered = RegExp(r'^\d|^\(|^[a-z][.)]').hasMatch(marker);
      var body = numbered ? s : s.substring(marker.length).trimLeft();
      // wrapped continuation lines of the item
      while (i + 1 < lines.length) {
        final n = lines[i + 1].trim();
        if (n.isEmpty || _bulletRe.hasMatch(n) || _isTableLine(lines[i + 1]) || _looksHeading(n, nextNonEmpty(i + 1))) break;
        if (!continues(body, n, body.length)) break;
        body = body.endsWith('-') && RegExp(r'^[a-z]').hasMatch(n) ? body.substring(0, body.length - 1) + n : '$body $n';
        i++;
      }
      blocks.add(BookBlock(BookKind.bullet, body.replaceAll(RegExp(r'\s+'), ' ')));
      continue;
    }
    if (atBlockStart && buf.isEmpty && _looksHeading(s, nextNonEmpty(i))) {
      blocks.add(BookBlock(BookKind.heading, s));
      atBlockStart = true;
      continue;
    }
    if (buf.isEmpty) {
      buf = s;
    } else if (buf.endsWith('-') && RegExp(r'^[a-z]').hasMatch(s) && !buf.endsWith(' -')) {
      buf = buf.substring(0, buf.length - 1) + s; // word split by the line end
    } else if (continues(buf, s, lastLen)) {
      buf = '$buf $s';
    } else {
      flush();
      buf = s;
    }
    atBlockStart = false;
    lastLen = s.length;
  }
  flush();
  return [for (final b in blocks) BookBlock(b.kind, b.kind == BookKind.pre ? b.text : b.text.replaceAll(RegExp(r'[ \t]+'), ' ').trim())];
}

bool _mostlyArabic(String s) {
  final ar = RegExp(r'[؀-ۿ]').allMatches(s).length;
  final letters = RegExp(r'[A-Za-z؀-ۿ]').allMatches(s).length;
  return letters > 0 && ar * 2 > letters;
}

/// One section of a book: the blocks of [parseBookText], with the sentence being looked for highlighted.
class BookBody extends StatelessWidget {
  final String text;
  final double scale;
  final String focus;
  const BookBody(this.text, {super.key, required this.scale, this.focus = ''});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final base = theme.textTheme.bodyMedium;
    final fs = (base?.fontSize ?? 14) * scale;
    final blocks = parseBookText(text);
    final rtl = _mostlyArabic(text);
    bool hit(String t) => focus.isNotEmpty && normQuote(t).contains(focus);
    Widget wrap(Widget child, bool flash, {double bottom = 10}) => Container(
          margin: EdgeInsets.only(bottom: bottom),
          padding: flash ? const EdgeInsets.symmetric(horizontal: 4, vertical: 2) : EdgeInsets.zero,
          decoration: flash ? BoxDecoration(color: cs.tertiary.withAlpha(60), borderRadius: BorderRadius.circular(8)) : null,
          child: child,
        );
    final align = rtl ? TextAlign.right : TextAlign.left;
    return Directionality(
      textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        for (final b in blocks)
          switch (b.kind) {
            BookKind.heading => Padding(
                padding: const EdgeInsets.only(top: 8, bottom: 6),
                child: m.Text(b.text, textAlign: align, style: theme.textTheme.titleSmall?.copyWith(fontSize: (theme.textTheme.titleSmall?.fontSize ?? 14) * scale, fontWeight: FontWeight.w800, color: cs.primary, height: 1.35)),
              ),
            BookKind.bullet => wrap(
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Padding(
                    padding: EdgeInsetsDirectional.only(top: fs * 0.55, end: 10, start: 4),
                    child: Container(width: 6, height: 6, decoration: BoxDecoration(color: cs.primary, shape: BoxShape.circle)),
                  ),
                  Expanded(child: m.Text(b.text, textAlign: align, style: base?.copyWith(fontSize: fs, height: 1.55))),
                ]),
                hit(b.text),
                bottom: 6),
            BookKind.pre => wrap(
                Container(
                  decoration: BoxDecoration(color: cs.surfaceContainerHighest.withAlpha(120), borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.all(8),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: m.Text(b.text, textDirection: TextDirection.ltr, style: TextStyle(fontFamily: 'monospace', fontSize: fs * 0.82, height: 1.4, color: cs.onSurface)),
                  ),
                ),
                hit(b.text)),
            BookKind.para => wrap(m.Text(b.text, textAlign: align, style: base?.copyWith(fontSize: fs, height: 1.65)), hit(b.text)),
          },
      ]),
    );
  }
}
