import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'i18n.dart';
import 'lib_text.dart' show normQuote, sentences;

/// Text taken from a book (usually a PDF) arrives with the line breaks of the page, hyphenated words, page numbers
/// and running headers. These helpers turn one section of it into readable blocks: paragraphs, headings, bullet
/// items and wide table-like lines. Nothing is rewritten: only line breaks, hyphens and page furniture change.

enum BookKind { para, heading, bullet, pre, keyFact, mnemonic, question }

class BookBlock {
  final BookKind kind;
  final String text;

  /// Bullets: 0 for a main point, 1 and 2 for what is written under it (taken from the indentation of the page).
  final int level;

  /// key fact: the line of items that follows its colon; mnemonic: the letters and what each one stands for.
  final List<String> lines;
  const BookBlock(this.kind, this.text, {this.level = 0, this.lines = const []});
  @override
  String toString() => '${kind.name}: $text';
}

final RegExp _keyFactRe = RegExp(r'^KEY\s*FACT\b[:\s]*');
final RegExp _mnemonicRe = RegExp(r'^MNEMONIC\b[:\s]*');
bool _isMarker(String t) => _keyFactRe.hasMatch(t) || _mnemonicRe.hasMatch(t);

final RegExp _bulletRe = RegExp(r'^([•▪▸◦●■·\-\*–]|\d{1,2}[.)]|\([a-z0-9]{1,2}\)|[a-z][.)])\s+');
final RegExp _pageNo = RegExp(r'^(page\s+)?\d{1,4}$', caseSensitive: false);
final RegExp _sentenceEnd = RegExp(r'[.!?:;)\]"”’]$');

bool _isTableLine(String l) {
  if (l.contains('\t')) return true;
  return RegExp(r'\S {3,}\S').allMatches(l).length >= 2;
}

bool _isUpperHeading(String s) {
  final letters = s.replaceAll(RegExp(r'[^A-Za-z]'), '');
  return letters.length >= 4 && letters == letters.toUpperCase() && s.length <= 70;
}

bool _looksHeading(String s, String? next) {
  if (s.length > 70 || s.length < 3 || next == null) return false;
  if (_sentenceEnd.hasMatch(s) || s.endsWith(',')) return false;
  if (_isUpperHeading(s)) return true;
  if (RegExp(r'^\d+(\.\d+)*\s+\S').hasMatch(s) && s.split(' ').length <= 10) return true;
  final words = s.split(RegExp(r'\s+'));
  if (words.length > 9) return false;
  if (!RegExp(r'^[A-Z]').hasMatch(s)) return false;
  // Title Case: most longer words start with a capital letter
  final long = words.where((w) => w.length > 3).toList();
  return long.isNotEmpty && long.where((w) => RegExp(r'^[A-Z0-9]').hasMatch(w)).length * 3 >= long.length * 2;
}

List<BookBlock> parseBookText(String raw) {
  final text = raw.replaceAll('\r\n', '\n').replaceAll('­', '').replaceAll(' ', ' ');
  var lines = [for (final l in text.split('\n')) l.trimRight()];

  // page numbers and running headers/footers (a short line that comes back many times)
  final counts = <String, int>{};
  for (final l in lines) {
    final k = l.trim();
    if (k.isNotEmpty && k.length <= 60) counts[k] = (counts[k] ?? 0) + 1;
  }
  lines = [
    for (final l in lines)
      if (!(_pageNo.hasMatch(l.trim()) || (l.trim().length >= 4 && (counts[l.trim()] ?? 0) >= 4 && !_bulletRe.hasMatch(l.trim())))) l
  ];

  // are the lines wrapped at the page width? (many lines of about the same, moderate length)
  final lens = [for (final l in lines) if (l.trim().length > 25) l.trim().length]..sort();
  final maxLen = lens.isEmpty ? 0 : lens[(lens.length * 0.9).floor().clamp(0, lens.length - 1)];
  final wrapped = lens.length >= 4 && maxLen <= 130;

  final blocks = <BookBlock>[];
  var buf = '';
  var atBlockStart = true;
  void flush() {
    if (buf.isNotEmpty) {
      blocks.add(BookBlock(BookKind.para, buf));
      buf = '';
    }
    atBlockStart = true;
  }

  bool continues(String prev, String cur, int prevLen) {
    if (RegExp(r'^[a-z(]').hasMatch(cur)) return true;
    if (!_sentenceEnd.hasMatch(prev)) return wrapped || prev.length > 40;
    // a sentence ended: the paragraph goes on only when the line was a full line of wrapped text
    return wrapped && prevLen >= maxLen * 0.8;
  }

  String? nextNonEmpty(int i) {
    for (var j = i + 1; j < lines.length; j++) {
      if (lines[j].trim().isNotEmpty) return lines[j].trim();
    }
    return null;
  }

  var lastLen = 0;
  for (var i = 0; i < lines.length; i++) {
    final line = lines[i];
    final s = line.trim();
    if (s.isEmpty) {
      flush();
      continue;
    }
    final kf = _keyFactRe.firstMatch(s);
    if (kf != null) {
      // "KEY FACT ..." is a margin note of the book: one block, with the line of items that follows a colon
      flush();
      var text = s.substring(kf.end).trim();
      var prev = text;
      final extra = <String>[];
      while (i + 1 < lines.length) {
        final n = lines[i + 1].trim();
        if (n.isEmpty || _isMarker(n) || _bulletRe.hasMatch(n) || _isTableLine(lines[i + 1])) break;
        if (prev.endsWith(':')) {
          extra.add(n);
          i++;
          break;
        }
        if (RegExp(r'[.!?]$').hasMatch(prev)) break;
        text = '$text $n';
        prev = n;
        i++;
      }
      blocks.add(BookBlock(BookKind.keyFact, text.replaceAll(RegExp(r'\s+'), ' '), lines: extra));
      continue;
    }
    final mn = _mnemonicRe.firstMatch(s);
    if (mn != null) {
      // "MNEMONIC title:" followed by the acronym and what its letters mean, until the next sentence of text
      flush();
      var title = s.substring(mn.end).trim();
      final body = <String>[];
      while (i + 1 < lines.length && body.length < 6) {
        final n = lines[i + 1].trim();
        if (n.isEmpty || _isMarker(n) || _bulletRe.hasMatch(n) || _isTableLine(lines[i + 1])) break;
        final wrappedLine = RegExp(r'^[a-z(]').hasMatch(n);
        if (!wrappedLine && RegExp(r'[.!?]$').hasMatch(n) && n.length > 3) break;
        if (wrappedLine && body.isEmpty && !title.endsWith(':')) {
          title = '$title $n';
        } else if (wrappedLine && body.isNotEmpty) {
          body[body.length - 1] = '${body.last} $n';
        } else {
          body.add(n);
        }
        i++;
      }
      blocks.add(BookBlock(BookKind.mnemonic, title.replaceAll(RegExp(r'\s+'), ' '), lines: body));
      continue;
    }
    if (_isTableLine(line)) {
      flush();
      final rows = [line];
      while (i + 1 < lines.length && lines[i + 1].trim().isNotEmpty && _isTableLine(lines[i + 1])) {
        rows.add(lines[++i]);
      }
      blocks.add(BookBlock(BookKind.pre, rows.join('\n')));
      continue;
    }
    if (_bulletRe.hasMatch(s)) {
      flush();
      final marker = _bulletRe.firstMatch(s)!.group(1)!;
      final numbered = RegExp(r'^\d|^\(|^[a-z][.)]').hasMatch(marker);
      var body = numbered ? s : s.substring(marker.length).trimLeft();
      // wrapped continuation lines of the item
      while (i + 1 < lines.length) {
        final n = lines[i + 1].trim();
        if (n.isEmpty || _isMarker(n) || _bulletRe.hasMatch(n) || _isTableLine(lines[i + 1]) || _looksHeading(n, nextNonEmpty(i + 1))) break;
        if (!continues(body, n, body.length)) break;
        body = body.endsWith('-') && RegExp(r'^[a-z]').hasMatch(n) ? body.substring(0, body.length - 1) + n : '$body $n';
        i++;
      }
      final indent = line.length - line.trimLeft().length;
      blocks.add(BookBlock(BookKind.bullet, body.replaceAll(RegExp(r'\s+'), ' '), level: indent >= 4 ? 2 : (indent >= 1 ? 1 : 0)));
      continue;
    }
    if (atBlockStart && buf.isEmpty && _looksHeading(s, nextNonEmpty(i))) {
      blocks.add(BookBlock(BookKind.heading, s));
      atBlockStart = true;
      continue;
    }
    if (buf.isEmpty) {
      buf = s;
    } else if (buf.endsWith('-') && RegExp(r'^[a-z]').hasMatch(s) && !buf.endsWith(' -')) {
      buf = buf.substring(0, buf.length - 1) + s; // word split by the line end
    } else if (continues(buf, s, lastLen)) {
      buf = '$buf $s';
    } else {
      flush();
      buf = s;
    }
    atBlockStart = false;
    lastLen = s.length;
  }
  flush();
  return [
    for (final b in blocks)
      if (b.kind == BookKind.pre)
        b
      else
        BookBlock(
          // a long paragraph that ends in a question is a case question of the book's margin
          b.kind == BookKind.para && b.text.trim().endsWith('?') && b.text.length >= 90 ? BookKind.question : b.kind,
          b.text.replaceAll(RegExp(r'[ \t]+'), ' ').trim(),
          level: b.level,
          lines: b.lines,
        )
  ];
}


/// A long paragraph cut at sentence ends into blocks of about [max] characters (two or three sentences).
List<String> splitLongParagraph(String text, {int max = 330, int minLong = 420}) {
  if (text.length < minLong) return [text];
  final out = <String>[];
  var cur = '';
  for (final snt in sentences(text)) {
    if (cur.isNotEmpty && cur.length + snt.length > max) {
      out.add(cur);
      cur = snt;
    } else {
      cur = cur.isEmpty ? snt : '$cur $snt';
    }
  }
  if (cur.isNotEmpty) out.add(cur);
  return out.isEmpty ? [text] : out;
}

final RegExp _emphasis = RegExp(
  r'(\(([A-Z][A-Za-z0-9\-]{1,9})\))|(\b\d+(?:[.,]\d+)?(?:\s?[–-]\s?\d+(?:[.,]\d+)?)?\s?(?:%|mg/dL|mg/kg|mg|mcg|mEq/L|mmol/L|mL/kg|mL|L|kg|g/dL|g|mmHg|°C|bpm|years?|months?|weeks?|days?|hours?)(?![A-Za-z0-9]))',
);

/// The text of a paragraph as spans: the first sentence in the full colour (the idea of the paragraph), the
/// abbreviation defined in brackets and numbers with their units heavier. The words themselves never change.
List<InlineSpan> emphasisSpans(String text, TextStyle base, Color accent, {bool leadFirst = true, Color? dim}) {
  var lead = '';
  var rest = text;
  if (leadFirst) {
    final ss = sentences(text);
    if (ss.length >= 2 && ss.first.length <= 260 && text.startsWith(ss.first)) {
      lead = ss.first;
      rest = text.substring(lead.length);
    }
  }
  List<InlineSpan> run(String t, TextStyle st) {
    final out = <InlineSpan>[];
    var at = 0;
    for (final m in _emphasis.allMatches(t)) {
      if (m.start > at) out.add(TextSpan(text: t.substring(at, m.start), style: st));
      out.add(TextSpan(text: m.group(0), style: st.copyWith(fontWeight: FontWeight.w700, color: m.group(1) != null ? accent : null)));
      at = m.end;
    }
    if (at < t.length) out.add(TextSpan(text: t.substring(at), style: st));
    return out;
  }

  return [
    // the first sentence in the full text colour, the rest a little softer: the idea of the paragraph stands out
    // without a heavy weight (the book fonts have only regular and bold)
    if (lead.isNotEmpty) ...run(lead, base),
    ...run(rest, lead.isNotEmpty && dim != null ? base.copyWith(color: dim) : base),
  ];
}

bool _mostlyArabic(String s) {
  final ar = RegExp(r'[\u0600-\u06FF]').allMatches(s).length;
  final letters = RegExp(r'[A-Za-z\u0600-\u06FF]').allMatches(s).length;
  return letters > 0 && ar * 2 > letters;
}

/// One section of a book: the blocks of [parseBookText], long paragraphs cut into short blocks, the sentence being
/// looked for highlighted. A long section shows its first part and a button for the rest.
class BookBody extends StatefulWidget {
  final String text;
  final double scale;
  final String focus;
  const BookBody(this.text, {super.key, required this.scale, this.focus = ''});

  @override
  State<BookBody> createState() => _BookBodyState();
}

class _BookBodyState extends State<BookBody> {
  static const int _firstPart = 10;
  bool _all = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final base = theme.textTheme.bodyMedium;
    final fs = (base?.fontSize ?? 14) * widget.scale;
    final rtl = _mostlyArabic(widget.text);
    final focus = widget.focus;
    // paragraphs become short blocks; headings, bullets and tables stay as they are
    final blocks = <BookBlock>[
      for (final b in parseBookText(widget.text))
        if (b.kind == BookKind.para) ...[for (final x in splitLongParagraph(b.text)) BookBlock(BookKind.para, x)] else b
    ];
    bool hit(String t) => focus.isNotEmpty && normQuote(t).contains(focus);
    final cut = !_all && focus.isEmpty && blocks.length > _firstPart + 2;
    final shown = cut ? blocks.take(_firstPart).toList() : blocks;
    Widget wrap(Widget child, bool flash, {double bottom = 12}) => Container(
          margin: EdgeInsets.only(bottom: bottom),
          padding: flash ? const EdgeInsets.symmetric(horizontal: 4, vertical: 2) : EdgeInsets.zero,
          decoration: flash ? BoxDecoration(color: cs.tertiary.withAlpha(60), borderRadius: BorderRadius.circular(8)) : null,
          child: child,
        );
    final align = rtl ? TextAlign.right : TextAlign.left;
    final bodyStyle = (base ?? const TextStyle()).copyWith(fontSize: fs, height: 1.5, color: cs.onSurface);
    return Directionality(
      textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        for (final (k, b) in shown.indexed)
          switch (b.kind) {
            BookKind.heading => Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 6),
                child: m.Text(b.text, textAlign: align, style: theme.textTheme.titleSmall?.copyWith(fontSize: (theme.textTheme.titleSmall?.fontSize ?? 14) * widget.scale, fontWeight: FontWeight.w800, color: cs.primary, height: 1.35)),
              ),
            BookKind.bullet => wrap(
                // a main point with points under it is the heading of that group
                Padding(
                  padding: EdgeInsetsDirectional.only(start: 18.0 * b.level),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(
                      padding: EdgeInsetsDirectional.only(top: fs * 0.5, end: 10, start: 4),
                      child: b.level == 0
                          ? Container(width: 6, height: 6, decoration: BoxDecoration(color: cs.primary, shape: BoxShape.circle))
                          : Container(width: 7, height: 2, color: cs.outline),
                    ),
                    Expanded(
                      child: m.Text.rich(
                        TextSpan(
                          children: (b.level == 0 && k + 1 < shown.length && shown[k + 1].kind == BookKind.bullet && shown[k + 1].level > 0)
                              ? [TextSpan(text: b.text, style: bodyStyle.copyWith(fontWeight: FontWeight.w800, color: cs.primary))]
                              : emphasisSpans(b.text, bodyStyle, cs.primary, leadFirst: false),
                        ),
                        textAlign: align,
                      ),
                    ),
                  ]),
                ),
                hit(b.text),
                bottom: (k + 1 < shown.length && shown[k + 1].kind == BookKind.bullet && shown[k + 1].level > b.level) ? 3 : 8),
            BookKind.keyFact => wrap(
                Container(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                  decoration: BoxDecoration(
                    color: cs.tertiaryContainer.withAlpha(70),
                    borderRadius: BorderRadius.circular(12),
                    border: BorderDirectional(start: BorderSide(color: cs.tertiary, width: 4)),
                  ),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(padding: EdgeInsetsDirectional.only(end: 10, top: fs * 0.15), child: Icon(Icons.star_rounded, size: fs * 1.15, color: cs.tertiary)),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        m.Text.rich(TextSpan(children: emphasisSpans(b.text, bodyStyle.copyWith(fontWeight: FontWeight.w600), cs.primary, leadFirst: false)), textAlign: align),
                        for (final l in b.lines) Padding(padding: const EdgeInsets.only(top: 4), child: m.Text(l, textAlign: align, style: bodyStyle)),
                      ]),
                    ),
                  ]),
                ),
                hit(b.text)),
            BookKind.mnemonic => wrap(
                Container(
                  key: const ValueKey('book_mnemonic'),
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                  decoration: BoxDecoration(
                    color: cs.secondaryContainer.withAlpha(80),
                    borderRadius: BorderRadius.circular(12),
                    border: BorderDirectional(start: BorderSide(color: cs.secondary, width: 4)),
                  ),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(padding: EdgeInsetsDirectional.only(end: 10, top: fs * 0.15), child: Icon(Icons.lightbulb_outline, size: fs * 1.15, color: cs.secondary)),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        m.Text(b.text, textAlign: align, style: bodyStyle.copyWith(fontWeight: FontWeight.w700)),
                        for (final l in b.lines)
                          Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: _isUpperHeading(l) && l.length <= 14
                                ? m.Text(l, textAlign: align, style: bodyStyle.copyWith(fontWeight: FontWeight.w900, letterSpacing: 3, fontSize: fs * 1.25, color: cs.secondary))
                                : m.Text(l, textAlign: align, style: bodyStyle),
                          ),
                      ]),
                    ),
                  ]),
                ),
                hit(b.text)),
            BookKind.question => wrap(
                Container(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: cs.outlineVariant)),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Padding(padding: EdgeInsetsDirectional.only(end: 10, top: fs * 0.15), child: Icon(Icons.help_outline, size: fs * 1.15, color: cs.outline)),
                    Expanded(child: m.Text(b.text, textAlign: align, style: bodyStyle.copyWith(fontStyle: FontStyle.italic))),
                  ]),
                ),
                hit(b.text)),
            BookKind.pre => wrap(
                Container(
                  decoration: BoxDecoration(color: cs.surfaceContainerHighest.withAlpha(120), borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.all(8),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: m.Text(b.text, textDirection: TextDirection.ltr, style: TextStyle(fontFamily: 'monospace', fontSize: fs * 0.82, height: 1.4, color: cs.onSurface)),
                  ),
                ),
                hit(b.text)),
            BookKind.para => wrap(m.Text.rich(TextSpan(children: emphasisSpans(b.text, bodyStyle, cs.primary, dim: cs.onSurface.withAlpha(225))), textAlign: align), hit(b.text)),
          },
        if (cut)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: TextButton.icon(
              key: const ValueKey('book_more'),
              onPressed: () => setState(() => _all = true),
              icon: const Icon(Icons.expand_more),
              label: m.Text(trp('Show the rest ({n} more blocks)', {'n': blocks.length - _firstPart})),
            ),
          ),
      ]),
    );
  }
}
