import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'case_ui.dart';
import 'choices_engine.dart';
import 'data.dart';
import 'exam_engine.dart';
import 'i18n.dart';
import 'ph.dart';
import 'sem.dart';

// ================================================================================================ what is related

const Map<String, IconData> _kIcons = {
  'cardiovascular': Ph.heartbeat,
  'respiratory': Ph.wind,
  'abdomen': Ph.stethoscope,
  'neurology': Ph.brain,
  'musculoskeletal': Ph.bone,
  'ent': Ph.ear,
  'eye': Ph.eye,
  'skin': Ph.hand,
  'genitourinary': Ph.drop,
  'lymph_nodes': Ph.circleDashed,
  'thyroid': Ph.person,
  'mental_state': Ph.chatsTeardrop,
  'obstetric': Ph.baby,
};

/// The vital signs that matter for each system, and the words of the case (complaint, history answers, tests) that
/// point to it. Plain rules: the point is to put in front of the examiner what the case already says about the system.
const Map<String, List<String>> _kVitals = {
  'cardiovascular': ['v_bp', 'v_hr', 'v_spo2'],
  'respiratory': ['v_rr', 'v_spo2', 'v_temp'],
  'abdomen': ['v_bp', 'v_hr', 'v_temp'],
  'neurology': ['v_bp', 'v_hr', 'v_rbs'],
  'obstetric': ['v_bp', 'v_hr'],
  'thyroid': ['v_hr', 'v_temp'],
  'skin': ['v_temp'],
  'ent': ['v_temp'],
};

const Map<String, List<String>> _kWords = {
  'cardiovascular': ['chest pain', 'palpitation', 'syncope', 'faint', 'oedema', 'edema', 'hypertension', 'ecg', 'troponin', 'echo', 'heart', 'cardiac'],
  'respiratory': ['cough', 'dyspn', 'breath', 'sob', 'wheez', 'sputum', 'haemoptysis', 'chest x', 'cxr', 'spo2', 'asthma', 'copd', 'pneumon', 'lung'],
  'abdomen': ['abdom', 'vomit', 'nausea', 'diarr', 'constipat', 'bowel', 'jaundice', 'epigastr', 'ultrasound', 'liver', 'hernia', 'appendic'],
  'neurology': ['headache', 'weakness', 'seizure', 'numb', 'dizz', 'stroke', 'gcs', 'ct head', 'mri', 'speech', 'conscious', 'tremor'],
  'musculoskeletal': ['fracture', 'joint', 'swelling', 'injury', 'trauma', 'limb', 'back pain', 'x-ray', 'xray', 'knee', 'shoulder', 'hip', 'ankle', 'wrist', 'elbow', 'fall'],
  'ent': ['ear', 'throat', 'nose', 'sinus', 'tonsil', 'hearing', 'hoarse', 'epistaxis'],
  'eye': ['eye', 'vision', 'visual', 'red eye', 'diplopia'],
  'skin': ['rash', 'skin', 'wound', 'ulcer', 'cellulitis', 'burn', 'itch', 'lesion'],
  'genitourinary': ['urin', 'dysuria', 'haematuria', 'hematuria', 'testic', 'scrot', 'renal', 'kidney', 'flank'],
  'lymph_nodes': ['lymph', 'node', 'neck swelling', 'fever', 'weight loss'],
  'thyroid': ['thyroid', 'goit', 'neck swelling', 'palpitation', 'weight loss', 'heat intolerance'],
  'mental_state': ['mood', 'anxiety', 'depress', 'psych', 'suicid', 'confus', 'hallucin', 'sleep'],
  'obstetric': ['pregnan', 'antenatal', 'labour', 'labor', 'fetal', 'foetal', 'vaginal', 'gestation', 'obstetric'],
};

const Map<String, List<String>> _kBySpecialty = {
  'Orthopedics': ['musculoskeletal', 'neurology'],
  'Ortho': ['musculoskeletal', 'neurology'],
  'Cardiology': ['cardiovascular', 'respiratory'],
  'Pulmonology': ['respiratory', 'cardiovascular'],
  'Gastroenterology': ['abdomen'],
  'General Surgery': ['abdomen', 'skin', 'lymph_nodes'],
  'ENT': ['ent', 'lymph_nodes', 'thyroid'],
  'Ophthalmology': ['eye', 'neurology'],
  'Dermatology': ['skin', 'lymph_nodes'],
  'Urology': ['genitourinary', 'abdomen'],
  'Neurology': ['neurology', 'mental_state'],
  'Psychiatry': ['mental_state', 'neurology'],
  'OB/GYN': ['obstetric', 'abdomen', 'genitourinary'],
  'Obstetrics and Gynecology': ['obstetric', 'abdomen', 'genitourinary'],
  'Endocrinology': ['thyroid', 'cardiovascular'],
  'Internal Medicine': ['cardiovascular', 'respiratory', 'abdomen', 'neurology'],
  'Emergency': ['cardiovascular', 'respiratory', 'abdomen', 'neurology'],
  'Emergency Medicine': ['cardiovascular', 'respiratory', 'abdomen', 'neurology'],
  'ICU': ['respiratory', 'cardiovascular', 'neurology'],
  'Intensive Care': ['respiratory', 'cardiovascular', 'neurology'],
  'Family Medicine': ['cardiovascular', 'respiratory', 'abdomen'],
  'Pediatrics': ['respiratory', 'abdomen', 'ent', 'cardiovascular'],
};

/// The systems in the order they are offered: the ones that suit the case's specialty first.
List<ExamSystem> examOrder(String specialty) {
  final first = _kBySpecialty[specialty] ?? const <String>[];
  final all = ExamRepo.systems;
  return [
    for (final id in first) if (ExamRepo.byId(id) != null) ExamRepo.byId(id)!,
    for (final s in all) if (!first.contains(s.id)) s,
  ];
}

/// What the case already says about a system: the vital signs that matter, the complaint, the history answers and the
/// investigations that mention it. Each line is plain text with a flag for an abnormal vital sign.
class ExamRelated {
  final List<({String text, bool bad})> lines;
  const ExamRelated(this.lines);
  bool get isEmpty => lines.isEmpty;
}

ExamRelated examRelated(CaseRec rec, ExamSystem s) {
  final out = <({String text, bool bad})>[];
  const names = {'v_bp': 'BP', 'v_hr': 'HR', 'v_temp': 'Temp', 'v_rr': 'RR', 'v_spo2': 'SpO2', 'v_rbs': 'RBS'};
  const units = {'v_bp': ' mmHg', 'v_hr': ' bpm', 'v_temp': ' °C', 'v_rr': '/min', 'v_spo2': '%', 'v_rbs': ' mg/dL'};
  final adult = rec.s('ageGroup') == 'Adult';
  for (final k in _kVitals[s.id] ?? const <String>[]) {
    final v = rec.s(k).trim();
    if (v.isEmpty) continue;
    out.add((text: '${names[k]} $v${units[k]}', bad: vitalAbnormal(k, v, adult)));
  }
  final words = _kWords[s.id] ?? const <String>[];
  bool hit(String t) {
    final x = t.toLowerCase();
    return words.any(x.contains);
  }

  final cc = rec.s('cc').trim();
  if (cc.isNotEmpty && hit(cc)) out.add((text: '${tr('Chief complaint')}: $cc', bad: false));
  try {
    for (final l in CaseChoices(rec).lines(section: 'History')) {
      final line = '${l[0]}: ${l[1]}';
      if (hit(line) && out.length < 12) out.add((text: line, bad: false));
    }
  } catch (_) {}
  for (final i in rec.lst('inv')) {
    final name = '${i['name'] ?? ''}'.trim();
    if (name.isEmpty || !hit(name)) continue;
    final res = '${i['result'] ?? ''}'.trim();
    out.add((text: res.isEmpty ? name : '$name: $res', bad: false));
  }
  return ExamRelated(out);
}

// ================================================================================================ the hub

/// The examination page of the case: every system as a card (what was found, how far it got), so any system can be
/// examined in any order. Tapping one opens its own page.
class ExamHub extends StatefulWidget {
  final CaseRec rec;
  final VoidCallback onChanged;
  const ExamHub({super.key, required this.rec, required this.onChanged});

  @override
  State<ExamHub> createState() => _ExamHubState();
}

class _ExamHubState extends State<ExamHub> {
  bool _ready = ExamRepo.systems.isNotEmpty;

  @override
  void initState() {
    super.initState();
    if (!_ready) {
      ExamRepo.load().then((_) {
        if (migrateLegacyExam(widget.rec)) widget.onChanged();
        if (mounted) setState(() => _ready = true);
      });
    } else if (migrateLegacyExam(widget.rec)) {
      WidgetsBinding.instance.addPostFrameCallback((_) => widget.onChanged());
    }
  }

  void _changed() {
    syncExamSummary(widget.rec);
    widget.onChanged();
    setState(() {});
  }

  Future<void> _open(ExamSystem s) async {
    await Navigator.push<void>(context, MaterialPageRoute<void>(builder: (_) => ExamSystemScreen(rec: widget.rec, system: s, onChanged: _changed)));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final rec = widget.rec;
    final r = ExamRecord(rec);
    final order = examOrder(rec.s('specialty'));
    final suggested = (_kBySpecialty[rec.s('specialty')] ?? const <String>[]).length;
    final examined = [for (final s in order) if (r.state(s) != 'none') s].length;
    final abnormal = [for (final s in order) if (r.state(s) == 'abnormal') s].length;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text('Examination by system', style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
        FilledButton.tonalIcon(
          key: const Key('sys_all_normal'),
          icon: const Icon(Ph.checkCircle, size: 18),
          label: Text('All normal'),
          onPressed: () {
            // the systems nothing was recorded for become normal; what was recorded is kept
            for (final s in order) {
              if (r.state(s) == 'none') r.allNormal(s);
            }
            _changed();
          },
        ),
      ]),
      const SizedBox(height: 4),
      m.Text(trp('{a} of {b} systems examined, {c} with findings', {'a': examined, 'b': order.length, 'c': abnormal}), style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant)),
      const SizedBox(height: 10),
      for (var i = 0; i < order.length; i++) ...[
        if (suggested > 0 && i == suggested)
          Padding(padding: const EdgeInsets.fromLTRB(2, 8, 0, 6), child: Text('Other systems', style: tt.labelLarge?.copyWith(color: cs.onSurfaceVariant))),
        _card(order[i], r, cs, tt),
      ],
    ]);
  }

  Widget _card(ExamSystem s, ExamRecord r, ColorScheme cs, TextTheme tt) {
    final st = r.state(s);
    final done = r.doneSteps(s.id).length;
    final n = r.findingCount(s);
    final (Color tone, String label) = switch (st) {
      'normal' => (Sem.success, tr('Normal')),
      'abnormal' => (Sem.warning, n > 0 ? trp('{n} findings', {'n': n}) : tr('Abnormal')),
      'partial' => (cs.primary, trp('{a} of {b} steps', {'a': done, 'b': s.steps.length})),
      _ => (cs.onSurfaceVariant, tr('Not examined')),
    };
    final rel = examRelated(widget.rec, s);
    return Card(
      key: ValueKey('exam_${s.id}'),
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _open(s),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: st == 'none' ? cs.surfaceContainerHighest : tone.withAlpha(40), shape: BoxShape.circle),
              child: Icon(_kIcons[s.id] ?? Ph.stethoscope, color: st == 'none' ? cs.onSurfaceVariant : tone),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                m.Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 2),
                Text(label, style: TextStyle(color: tone, fontWeight: FontWeight.w700, fontSize: 13.5)),
                if (rel.isEmpty == false && st == 'none')
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: m.Text(trp('{n} related notes in this case', {'n': rel.lines.length}), style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12.5)),
                  ),
              ]),
            ),
            const Icon(Ph.caretRight, size: 18),
          ]),
        ),
      ),
    );
  }
}

// ================================================================================================ one system

class ExamSystemScreen extends StatefulWidget {
  final CaseRec rec;
  final ExamSystem system;
  final VoidCallback onChanged;
  const ExamSystemScreen({super.key, required this.rec, required this.system, required this.onChanged});

  @override
  State<ExamSystemScreen> createState() => _ExamSystemScreenState();
}

class _ExamSystemScreenState extends State<ExamSystemScreen> {
  late final ExamRecord _r = ExamRecord(widget.rec);
  ExamSystem get _s => widget.system;

  void _changed() {
    widget.onChanged();
    setState(() {});
  }

  Future<void> _add(ExamStep st) async {
    final f = await showModalBottomSheet<ExamFinding>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => _FindingPicker(step: st, chosen: {for (final p in _r.picks(_s.id)) p.id}),
    );
    if (f == null || !mounted) return;
    if (!f.needsPlace && f.qualifiers.isEmpty) {
      _r.setPick(_s, ExamPick(f.id));
      _changed();
      return;
    }
    await _edit(f, null);
  }

  Future<void> _edit(ExamFinding f, ExamPick? current) async {
    final p = await showModalBottomSheet<ExamPick>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => _PickDetails(system: _s, finding: f, current: current),
    );
    if (p == null || !mounted) return;
    _r.setPick(_s, p);
    _changed();
  }

  Widget _related(ColorScheme cs, TextTheme tt) {
    final rel = examRelated(widget.rec, _s);
    if (rel.isEmpty) return const SizedBox.shrink();
    return Card(
      key: const Key('exam_related'),
      color: cs.secondaryContainer.withAlpha(90),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Ph.clipboard, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text('From this case', style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 6),
          for (final l in rel.lines)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(padding: const EdgeInsets.only(top: 6, right: 8), child: Icon(Ph.circle, size: 6, color: l.bad ? Sem.danger : cs.onSurfaceVariant)),
                Expanded(child: m.Text(l.text, style: TextStyle(height: 1.35, fontWeight: l.bad ? FontWeight.w800 : FontWeight.w400, color: l.bad ? Sem.danger : null))),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _preview(ColorScheme cs, TextTheme tt) {
    final t = examSystemText(widget.rec, _s);
    return Card(
      key: const Key('exam_preview'),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Ph.notePencil, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text('How it reads in the case', style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 6),
          t.isEmpty ? Text('Nothing recorded yet. Tap Normal or add a finding in a step.', style: TextStyle(color: cs.onSurfaceVariant)) : SelectableText(t, style: const TextStyle(height: 1.45)),
        ]),
      ),
    );
  }

  Widget _stepCard(ExamStep st, ColorScheme cs, TextTheme tt) {
    final picks = [for (final p in _r.picks(_s.id)) if (st.findings.any((f) => f.id == p.id)) p];
    final done = _r.doneSteps(_s.id).contains(st.id);
    final replaced = <String>{for (final p in picks) ...st.findings.firstWhere((f) => f.id == p.id).replacesNormal};
    final examined = done || picks.isNotEmpty;
    return Card(
      key: ValueKey('step_${st.id}'),
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: m.Text(st.shortLabel, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
            if (examined) Icon(picks.isNotEmpty ? Ph.warning : Ph.checkCircle, size: 20, color: picks.isNotEmpty ? Sem.warning : Sem.success),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                key: ValueKey('stepn_${st.id}'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(46),
                  backgroundColor: done ? Sem.success.withAlpha(30) : null,
                  side: BorderSide(color: done ? Sem.success : cs.outlineVariant, width: done ? 1.6 : 1),
                ),
                onPressed: () {
                  _r.setStepNormal(_s, st, !done);
                  _changed();
                },
                icon: Icon(done ? Ph.checkCircle : Ph.circle, size: 18, color: done ? Sem.success : null),
                label: FittedBox(fit: BoxFit.scaleDown, child: Text('Normal')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.tonalIcon(
                key: ValueKey('stepa_${st.id}'),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                onPressed: () => _add(st),
                icon: const Icon(Ph.plus, size: 18),
                label: FittedBox(fit: BoxFit.scaleDown, child: Text('Add finding')),
              ),
            ),
          ]),
          if (done) ...[
            const SizedBox(height: 8),
            for (final n in st.normal)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(replaced.contains(n.id) ? Ph.minusCircle : Ph.check, size: 16, color: replaced.contains(n.id) ? cs.onSurfaceVariant : Sem.success),
                  const SizedBox(width: 8),
                  Expanded(
                    child: m.Text(n.text, style: TextStyle(fontSize: 14, color: replaced.contains(n.id) ? cs.onSurfaceVariant : null, decoration: replaced.contains(n.id) ? TextDecoration.lineThrough : null)),
                  ),
                ]),
              ),
          ],
          for (final p in picks) ...[
            const SizedBox(height: 6),
            Builder(builder: (_) {
              final f = st.findings.firstWhere((x) => x.id == p.id);
              return Material(
                color: Sem.warning.withAlpha(28),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Sem.warning)),
                child: InkWell(
                  key: ValueKey('pick_${p.id}'),
                  borderRadius: BorderRadius.circular(12),
                  onTap: f.needsPlace || f.qualifiers.isNotEmpty ? () => _edit(f, p) : null,
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 4, 8),
                    child: Row(children: [
                      Expanded(child: m.Text(findingSentence(_s, f, p), style: const TextStyle(height: 1.35, fontWeight: FontWeight.w600))),
                      IconButton(
                        tooltip: tr('Delete'),
                        icon: const Icon(Ph.x, size: 18),
                        onPressed: () {
                          _r.removePick(_s, p.id);
                          _changed();
                        },
                      ),
                    ]),
                  ),
                ),
              );
            }),
          ],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final groups = _s.groups;
    return Scaffold(
      appBar: AppBar(
        title: m.Text(_s.name),
        actions: [
          TextButton.icon(
            key: const Key('sys_screen_all_normal'),
            onPressed: () {
              _r.allNormal(_s);
              _changed();
            },
            icon: const Icon(Ph.checkCircle, size: 18),
            label: Text('All normal'),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Ph.dotsThreeVertical),
            onSelected: (v) {
              if (v == 'clear') {
                _r.clear(_s);
                _changed();
              }
            },
            itemBuilder: (_) => [PopupMenuItem(value: 'clear', child: Text('Clear this system'))],
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        _related(cs, tt),
        _preview(cs, tt),
        if (groups.length > 1 || (groups.length == 1 && groups.first.isNotEmpty))
          for (final g in groups)
            Builder(builder: (_) {
              final steps = [for (final st in _s.steps) if (st.group == g) st];
              final touched = steps.where((st) => _r.stepDone(_s, st)).length;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: PhExpansionTile(
                  key: ValueKey('group_$g'),
                  initiallyExpanded: touched > 0,
                  title: m.Text(g.isEmpty ? _s.name : g, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: m.Text(touched == 0 ? tr('Not examined') : trp('{a} of {b} steps', {'a': touched, 'b': steps.length})),
                  childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                  children: [for (final st in steps) _stepCard(st, cs, tt)],
                ),
              );
            })
        else
          for (final st in _s.steps) _stepCard(st, cs, tt),
        const SizedBox(height: 4),
        TextFormField(
          key: const Key('exam_note'),
          initialValue: _r.note(_s.id),
          minLines: 2,
          maxLines: 5,
          decoration: InputDecoration(labelText: tr('Anything else you found')),
          onChanged: (t) {
            _r.setNote(_s, t);
            widget.onChanged();
          },
        ),
      ]),
    );
  }
}

// ================================================================================================ pickers

class _FindingPicker extends StatefulWidget {
  final ExamStep step;
  final Set<String> chosen;
  const _FindingPicker({required this.step, required this.chosen});

  @override
  State<_FindingPicker> createState() => _FindingPickerState();
}

class _FindingPickerState extends State<_FindingPicker> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final list = [for (final f in widget.step.findings) if (_q.isEmpty || f.text.toLowerCase().contains(_q)) f];
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.8,
          child: Column(children: [
            Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Align(alignment: AlignmentDirectional.centerStart, child: m.Text(widget.step.label, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)))),
            if (widget.step.findings.length > 8)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: TextField(decoration: InputDecoration(isDense: true, prefixIcon: const Icon(Ph.magnifyingGlass), labelText: tr('Search')), onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
              ),
            Expanded(
              child: ListView(children: [
                for (final f in list)
                  ListTile(
                    key: ValueKey('find_${f.id}'),
                    title: m.Text(f.text),
                    subtitle: f.needsPlace || f.qualifiers.isNotEmpty ? Text('Asks where or how bad') : null,
                    trailing: widget.chosen.contains(f.id) ? Icon(Ph.checkCircle, color: cs.primary) : null,
                    onTap: () => Navigator.pop(context, f),
                  ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

/// Where the finding is (one or several places) and the descriptors that go with it.
class _PickDetails extends StatefulWidget {
  final ExamSystem system;
  final ExamFinding finding;
  final ExamPick? current;
  const _PickDetails({required this.system, required this.finding, this.current});

  @override
  State<_PickDetails> createState() => _PickDetailsState();
}

class _PickDetailsState extends State<_PickDetails> {
  late final Set<String> _places = {...?widget.current?.places};
  late final Map<String, String> _q = {...?widget.current?.qualifiers};

  @override
  Widget build(BuildContext context) {
    final f = widget.finding;
    final tt = Theme.of(context).textTheme;
    final places = widget.system.placesFor(f);
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            m.Text(f.text, style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            if (places.isNotEmpty) ...[
              const SizedBox(height: 14),
              Text('Where?', style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              OptionGroup(
                keyPrefix: 'place',
                options: places,
                selected: _places,
                multi: f.location != 'side',
                onTap: (v) => setState(() {
                  if (f.location == 'side') {
                    _places
                      ..clear()
                      ..add(v);
                  } else {
                    _places.contains(v) ? _places.remove(v) : _places.add(v);
                  }
                }),
              ),
            ],
            for (final q in f.qualifiers) ...[
              const SizedBox(height: 14),
              m.Text(q.label, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              OptionGroup(
                keyPrefix: 'qual_${q.label}',
                options: q.options,
                selected: {if ((_q[q.label] ?? '').isNotEmpty) _q[q.label]!},
                multi: false,
                onTap: (v) => setState(() => _q[q.label] == v ? _q.remove(q.label) : _q[q.label] = v),
              ),
            ],
            const SizedBox(height: 18),
            FilledButton.icon(
              key: const Key('pick_save'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
              onPressed: places.isNotEmpty && _places.isEmpty ? null : () => Navigator.pop(context, ExamPick(f.id, [for (final p in places) if (_places.contains(p)) p], {..._q})),
              icon: const Icon(Ph.check),
              label: Text('Save finding'),
            ),
          ]),
        ),
      ),
    );
  }
}
