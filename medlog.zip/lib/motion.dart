import 'app_icons.dart';
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/scheduler.dart';
import 'package:lottie/lottie.dart';

import 'i18n.dart';
import 'theme.dart';
import 'ph.dart';

/// Global switch for decorative motion (Settings > Animations). Also honoured:
/// the phone's own "remove animations" accessibility option.
bool motionOn = true;

bool animOn(BuildContext context) =>
    motionOn && !MediaQuery.of(context).disableAnimations;

// ---------------------------------------------------------------- page transition

/// Direction-aware shared-axis slide + fade used for every screen push.
class SharedAxisBuilder extends PageTransitionsBuilder {
  const SharedAxisBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (!animOn(context)) return child;
    final dx = Directionality.of(context) == TextDirection.rtl ? -1.0 : 1.0;
    final enter = CurvedAnimation(
      parent: animation,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeInCubic,
    );
    final leave = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInOutCubic);
    return SlideTransition(
      position: Tween<Offset>(begin: Offset(0.10 * dx, 0), end: Offset.zero).animate(enter),
      child: FadeTransition(
        opacity: enter,
        child: SlideTransition(
          position: Tween<Offset>(begin: Offset.zero, end: Offset(-0.05 * dx, 0)).animate(leave),
          child: child,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- list entrance

/// Fades and lifts its child into place. [index] staggers a list.
class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int index;
  const FadeSlideIn({super.key, required this.child, this.index = 0});

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
  Timer? _t;
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!animOn(context)) {
      _c.value = 1;
      return;
    }
    final delay = math.min(widget.index, 8) * 55;
    if (delay == 0) {
      _c.forward();
    } else {
      _t = Timer(Duration(milliseconds: delay), () {
        if (mounted) _c.forward();
      });
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: a,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(a),
        child: widget.child,
      ),
    );
  }
}

// ---------------------------------------------------------------- numbers & bars

class CountUp extends StatelessWidget {
  final int value;
  final TextStyle? style;
  const CountUp(this.value, {super.key, this.style});

  @override
  Widget build(BuildContext context) {
    if (!animOn(context)) return Text('$value', style: style);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.toDouble()),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => Text('${v.round()}', style: style),
    );
  }
}

class AnimatedBar extends StatelessWidget {
  final double value; // 0..1
  final double height;
  final Color? color;
  const AnimatedBar(this.value, {super.key, this.height = 10, this.color});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = animOn(context);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: on ? 0 : value, end: value),
      duration: on ? const Duration(milliseconds: 900) : Duration.zero,
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => ClipRRect(
        borderRadius: BorderRadius.circular(height),
        child: LinearProgressIndicator(
          value: v,
          minHeight: height,
          color: color ?? cs.primary,
          backgroundColor: cs.surfaceContainerHighest,
        ),
      ),
    );
  }
}

/// Circular progress that sweeps in, with a centre label.
class AnimatedRing extends StatelessWidget {
  final double value; // 0..1
  final double size;
  final Widget? center;
  final Color? color;
  const AnimatedRing(this.value, {super.key, this.size = 64, this.center, this.color});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = animOn(context);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: on ? 0 : value, end: value),
      duration: on ? const Duration(milliseconds: 1000) : Duration.zero,
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: size,
              height: size,
              child: CircularProgressIndicator(
                value: v,
                strokeWidth: size / 9,
                strokeCap: StrokeCap.round,
                color: color ?? cs.primary,
                backgroundColor: cs.surfaceContainerHighest,
              ),
            ),
            if (center != null) center!,
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- ECG motion graphic

/// One heartbeat cycle sampled over [0, 1] (baseline 0, up is positive).
double _beat(double x) {
  double g(double c, double w, double a) => a * math.exp(-math.pow((x - c) / w, 2));
  return g(0.18, 0.045, 0.16) + // P
      g(0.38, 0.012, -0.12) + // Q
      g(0.42, 0.014, 1.0) + // R
      g(0.46, 0.012, -0.28) + // S
      g(0.68, 0.07, 0.28); // T
}

class _EcgPainter extends CustomPainter {
  final double t; // 0..1 head position (scanner)
  final Color color;
  final double beats;
  final double strokeWidth;
  final bool animated;
  _EcgPainter(this.t, this.color, this.beats, this.strokeWidth, this.animated);

  @override
  void paint(Canvas canvas, Size size) {
    final mid = size.height * 0.62;
    final amp = size.height * 0.52;
    final n = (size.width / 2).ceil();
    final pts = <Offset>[];
    for (var i = 0; i <= n; i++) {
      final u = i / n;
      final ph = (u * beats) % 1.0;
      pts.add(Offset(u * size.width, mid - _beat(ph) * amp));
    }
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = color.withAlpha(animated ? 55 : 220);
    final full = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final p in pts.skip(1)) {
      full.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(full, base);
    if (!animated) return;

    // bright trailing segment + glowing head
    final headIdx = (t * n).floor().clamp(0, n);
    final tail = (n * 0.28).round();
    final start = math.max(0, headIdx - tail);
    for (var i = start; i < headIdx; i++) {
      final f = (i - start) / math.max(1, headIdx - start);
      final seg = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth * (1.0 + f * 0.6)
        ..strokeCap = StrokeCap.round
        ..color = color.withAlpha((40 + 215 * f).round());
      canvas.drawLine(pts[i], pts[i + 1], seg);
    }
    final head = pts[headIdx];
    canvas.drawCircle(head, strokeWidth * 3.2, Paint()..color = color.withAlpha(60));
    canvas.drawCircle(head, strokeWidth * 1.6, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_EcgPainter old) =>
      old.t != t || old.color != color || old.beats != beats || old.animated != animated;
}

/// Looping heartbeat line. Cheap: one controller, one painter.
class EcgBanner extends StatefulWidget {
  final double height;
  final Color color;
  final double beats;
  final double strokeWidth;
  const EcgBanner({
    super.key,
    this.height = 56,
    required this.color,
    this.beats = 3,
    this.strokeWidth = 2.2,
  });

  @override
  State<EcgBanner> createState() => _EcgBannerState();
}

class _EcgBannerState extends State<EcgBanner> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));

  @override
  void initState() {
    super.initState();
    _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final on = animOn(context);
    // the heartbeat itself is a medical symbol: never mirror it in RTL
    return Directionality(
      textDirection: TextDirection.ltr,
      child: SizedBox(
        height: widget.height,
        width: double.infinity,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => CustomPaint(
            painter: _EcgPainter(
              on ? _c.value : 1,
              widget.color,
              widget.beats,
              widget.strokeWidth,
              on,
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- empty states

enum EmptyKind { cases, learn, calendar, search, generic }

IconData _emptyIcon(EmptyKind k) {
  switch (k) {
    case EmptyKind.cases:
      return AppIcons.clipboard;
    case EmptyKind.learn:
      return AppIcons.library;
    case EmptyKind.calendar:
      return Ph.calendarCheck;
    case EmptyKind.search:
      return Ph.magnifyingGlassMinus;
    case EmptyKind.generic:
      return Ph.tray;
  }
}

/// Animated illustration for empty lists: expanding pulse rings, a floating icon.
class EmptyState extends StatefulWidget {
  final EmptyKind kind;
  final String title;
  final String message;
  final Widget? action;
  const EmptyState({
    super.key,
    this.kind = EmptyKind.generic,
    this.title = '',
    this.message = '',
    this.action,
  });

  @override
  State<EmptyState> createState() => _EmptyStateState();
}

class _EmptyStateState extends State<EmptyState> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 3));

  @override
  void initState() {
    super.initState();
    _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final theme = Theme.of(context);
    final on = animOn(context);
    return FadeSlideIn(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 150,
                height: 150,
                child: AnimatedBuilder(
                  animation: _c,
                  builder: (_, __) {
                    final bob = on ? math.sin(_c.value * 2 * math.pi) * 5 : 0.0;
                    return Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomPaint(
                          size: const Size(150, 150),
                          painter: _RingsPainter(on ? _c.value : 0.4, cs.primary),
                        ),
                        Transform.translate(
                          offset: Offset(0, bob),
                          child: Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              gradient: paletteGradient(context, soft: true),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Icon(_emptyIcon(widget.kind), size: 36, color: cs.primary),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              if (widget.title.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(widget.title,
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    textAlign: TextAlign.center),
              ],
              if (widget.message.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(widget.message,
                    style: theme.textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
                    textAlign: TextAlign.center),
              ],
              if (widget.action != null) ...[
                const SizedBox(height: 16),
                widget.action!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _RingsPainter extends CustomPainter {
  final double t;
  final Color color;
  _RingsPainter(this.t, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    for (var i = 0; i < 3; i++) {
      final p = (t + i / 3) % 1.0;
      final r = 36 + p * 39;
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = color.withAlpha(((1 - p) * 90).round()),
      );
    }
  }

  @override
  bool shouldRepaint(_RingsPainter old) => old.t != t || old.color != color;
}

// ---------------------------------------------------------------- logo + splash

/// App mark: the app icon (an open book with a heartbeat line), the same picture everywhere.
class MedLogMark extends StatelessWidget {
  final double size;
  const MedLogMark({super.key, this.size = 96});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF013435),
        borderRadius: BorderRadius.circular(size * 0.24),
        boxShadow: [
          BoxShadow(color: const Color(0xFF013435).withAlpha(70), blurRadius: size * 0.25, offset: Offset(0, size * 0.08)),
        ],
      ),
      child: Image.asset(
        'assets/brand/logo.png',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Center(child: m('S', const Color(0xFFF6E7D0), size * 0.42, FontWeight.w800)),
      ),
    );
  }
}

/// First thing the user sees: the SharqMed dawn animation (the ribbon S, the sun and the name) plays on a deep teal ground,
/// then the designer credit fades up. A tap skips it. With animations off it is skipped at once.
class SplashScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SplashScreen({super.key, required this.onDone});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  static const String asset = 'assets/brand/sharqmed_dawn.json';
  // the dawn animation lasts 2.1 s; the credit and a short hold follow
  late final AnimationController _lottie = AnimationController(vsync: this, duration: const Duration(milliseconds: 2100));
  late final AnimationController _credit = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
  bool _fired = false;

  @override
  void initState() {
    super.initState();
    _lottie.addStatusListener((s) async {
      if (s != AnimationStatus.completed || !mounted) return;
      _credit.forward();
      await Future<void>.delayed(const Duration(milliseconds: 900));
      _finish();
    });
    SchedulerBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (!animOn(context)) {
        _finish();
      } else {
        _lottie.forward();
      }
    });
  }

  void _finish() {
    if (_fired) return;
    _fired = true;
    widget.onDone();
  }

  @override
  void dispose() {
    _lottie.dispose();
    _credit.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final side = math.min(w * 0.86, 380.0);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _finish,
      child: Scaffold(
        backgroundColor: const Color(0xFF012E33),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          // the same deep teal as the app icon tile, a little lighter at the top
          decoration: const BoxDecoration(
            gradient: RadialGradient(center: Alignment(-0.3, -0.5), radius: 1.2, colors: [Color(0xFF07494B), Color(0xFF012F32), Color(0xFF01282A)], stops: [0, 0.55, 1]),
          ),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Spacer(flex: 5),
                SizedBox(
                  key: const ValueKey('splash_lottie'),
                  width: side,
                  height: side,
                  child: Lottie.asset(
                    asset,
                    controller: _lottie,
                    fit: BoxFit.contain,
                    repeat: false,
                    errorBuilder: (_, __, ___) => const Center(child: MedLogMark(size: 116)),
                  ),
                ),
                const Spacer(flex: 4),
                FadeTransition(
                  opacity: CurvedAnimation(parent: _credit, curve: Curves.easeOut),
                  child: Column(
                    children: [
                      m(designedBy, const Color(0xB3FFFFFF), 13, FontWeight.w500),
                      const SizedBox(height: 4),
                      m(designerName, const Color(0xFFF6E7D0), 17, FontWeight.w700),
                    ],
                  ),
                ),
                const SizedBox(height: 36),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget m(String s, Color c, double size, FontWeight w, {TextAlign align = TextAlign.center}) =>
    Text(s, textAlign: align, style: TextStyle(color: c, fontSize: size, fontWeight: w));

// ---------------------------------------------------------------- icons that move

