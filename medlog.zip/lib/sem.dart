import 'package:flutter/material.dart';

/// Colours that carry a meaning, the same in every screen and every theme (checked for contrast on light and dark
/// surfaces by test/g35_contrast_test.dart). Use these instead of the Material named colours (green, red, amber...).
class Sem {
  const Sem._();

  /// done, correct, verified, saved
  static const Color success = Color(0xFF2E9E5B);

  /// wrong, failed, allergy, delete
  static const Color danger = Color(0xFFD64545);

  /// behind, pending, caution
  static const Color warning = Color(0xFFC8761A);

  /// information, neutral progress
  static const Color info = Color(0xFF3A86D6);

  /// a favourite (star)
  static const Color star = Color(0xFFF2A900);
}
