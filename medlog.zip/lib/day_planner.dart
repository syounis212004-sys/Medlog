import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'book_plan.dart';
import 'data.dart';
import 'i18n.dart';
import 'lib_plan.dart';
import 'library.dart';
import 'screens_library.dart';
import 'ui.dart';
import 'widgets.dart';

/// The day planner: what is due TODAY in the plans the person made (book plans, the exam plan) plus the tasks they
/// add themselves. Nothing is suggested by the app. Ticking an item writes back to its own plan, and the number
/// done each day is kept so the person can see how the plan is going.

class DayItem {
  final String id; // unique inside the day
  final String kind; // book | exam | task
  final String title;
  final String sub;
  final bool done;
  final bool overdue;
  final String ref1; // book: plan id | exam: pack id | task: task id
  final String ref2; // book: chapter number | exam: article title
  const DayItem({required this.id, required this.kind, required this.title, required this.sub, required this.done, this.overdue = false, this.ref1 = '', this.ref2 = ''});
}

class DayStore {
  static const _tasks = 'dayTasks';
  static const _log = 'dayLog';

  static List<Map<String, dynamic>> tasks() {
    final v = store.settings[_tasks];
    return v is List ? [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)] : <Map<String, dynamic>>[];
  }

  static Future<void> _saveTasks(List<Map<String, dynamic>> l) async {
    store.settings[_tasks] = l;
    await store.saveSettings();
    store.refresh();
  }

  static Future<void> addTask(String title, {String? date}) async {
    final t = title.trim();
    if (t.isEmpty) return;
    await _saveTasks([...tasks(), {'id': newId('dt'), 'title': t, 'date': date ?? todayStr(), 'done': false}]);
  }

  static Future<void> setTaskDone(String id, bool done) async {
    final l = tasks();
    for (final e in l) {
      if (e['id'] == id) {
        e['done'] = done;
        if (done) {
          e['doneOn'] = todayStr();
        } else {
          e.remove('doneOn');
        }
      }
    }
    await _saveTasks(l);
  }

  static Future<void> deleteTask(String id) => _saveTasks(tasks()..removeWhere((e) => e['id'] == id));

  /// {date: {'d': done, 't': total}}
  static Map<String, Map<String, int>> log() {
    final v = store.settings[_log];
    if (v is! Map) return {};
    return {
      for (final e in v.entries)
        if (e.value is Map) '${e.key}': {'d': ((e.value as Map)['d'] as num?)?.toInt() ?? 0, 't': ((e.value as Map)['t'] as num?)?.toInt() ?? 0}
    };
  }

  static Future<void> record(String date, int done, int total) async {
    final l = {...log()};
    l[date] = {'d': done, 't': total};
    // keep the last 120 days
    final keys = l.keys.toList()..sort();
    for (final k in keys.take(keys.length > 120 ? keys.length - 120 : 0)) {
      l.remove(k);
    }
    store.settings[_log] = l;
    await store.saveSettings();
  }

  /// Days in a row (up to and including today when it is complete, otherwise up to yesterday) on which everything planned was done.
  static int streak(Map<String, Map<String, int>> log, DateTime now) {
    bool full(DateTime d) {
      final e = log[fmtDate(d)];
      return e != null && e['t']! > 0 && e['d']! >= e['t']!;
    }

    var d = DateTime(now.year, now.month, now.day);
    if (!full(d)) d = d.subtract(const Duration(days: 1));
    var n = 0;
    while (full(d)) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }
}

/// Today's items, in this order: tasks that are late, book chapters, exam plan items, tasks of today.
Future<List<DayItem>> buildDayItems({DateTime? now}) async {
  final n = now ?? DateTime.now();
  final today = fmtDate(n);
  final out = <DayItem>[];

  final tasks = DayStore.tasks();
  for (final t in tasks) {
    final done = t['done'] == true;
    final date = '${t['date'] ?? today}';
    final shown = done ? '${t['doneOn'] ?? ''}' == today : date.compareTo(today) <= 0;
    if (!shown) continue;
    out.add(DayItem(id: 't_${t['id']}', kind: 'task', title: '${t['title']}', sub: date.compareTo(today) < 0 && !done ? prettyDate(date) : '', done: done, overdue: !done && date.compareTo(today) < 0, ref1: '${t['id']}'));
  }

  for (final plan in BookPlanStore.all()) {
    try {
      final chs = await BookPlanStore.chaptersFor(plan);
      final start = parseDate('${plan['start']}') ?? n;
      final end = parseDate('${plan['end']}') ?? start.add(const Duration(days: 30));
      final sched = BookPlanSchedule.assign(chs, start, end, (plan['perWeek'] as int?) ?? 3, n);
      final todayD = DateTime(n.year, n.month, n.day);
      final on = plan['doneOn'] is Map ? Map<String, dynamic>.from(plan['doneOn'] as Map) : <String, dynamic>{};
      for (final c in chs) {
        final due = sched[c.number];
        if (!c.done && due != null && !due.isAfter(todayD)) {
          out.add(DayItem(id: 'b_${plan['id']}_${c.number}', kind: 'book', title: c.title, sub: '${plan['title']}${c.focus.isEmpty ? '' : ' • ${c.focus}'}', done: false, ref1: '${plan['id']}', ref2: '${c.number}'));
        } else if (c.done && '${on['${c.number}']}' == today) {
          out.add(DayItem(id: 'b_${plan['id']}_${c.number}', kind: 'book', title: c.title, sub: '${plan['title']}', done: true, ref1: '${plan['id']}', ref2: '${c.number}'));
        }
      }
    } catch (_) {}
  }

  final ex = examPlan();
  if (ex != null) {
    final due = <PlanItem>[];
    for (final d in planSchedule(ex, now: n)) {
      if (fmtDate(d.date) == today) due.addAll(d.items);
    }
    final late = {for (final i in planOverdue(ex, now: n)) i.key};
    for (final i in planOverdue(ex, now: n)) {
      if (!due.any((x) => x.key == i.key)) due.add(i);
    }
    for (final i in due) {
      out.add(DayItem(id: 'e_${i.key}', kind: 'exam', title: stripSource(i.title), sub: ex.name, done: false, overdue: late.contains(i.key), ref1: i.packId, ref2: i.title));
    }
    for (final i in ex.items) {
      if (ex.done.contains(i.key) && ex.doneOn[i.key] == today) {
        out.add(DayItem(id: 'e_${i.key}', kind: 'exam', title: stripSource(i.title), sub: ex.name, done: true, ref1: i.packId, ref2: i.title));
      }
    }
  }
  return out;
}

Future<void> toggleDayItem(DayItem it) async {
  switch (it.kind) {
    case 'task':
      await DayStore.setTaskDone(it.ref1, !it.done);
    case 'book':
      await BookPlanStore.setChapterDone(it.ref1, int.tryParse(it.ref2) ?? -1, !it.done);
    case 'exam':
      await togglePlanDone('${it.ref1}|${it.ref2}');
  }
}

/// "3 of 5" for the home card, without building the chapter list twice.
Future<(int, int)> dayProgress({DateTime? now}) async {
  final items = await buildDayItems(now: now);
  return (items.where((i) => i.done).length, items.length);
}

class DayPlannerScreen extends StatefulWidget {
  const DayPlannerScreen({super.key});
  @override
  State<DayPlannerScreen> createState() => _DayPlannerScreenState();
}

class _DayPlannerScreenState extends State<DayPlannerScreen> {
  final _add = TextEditingController();
  List<DayItem>? _items;

  @override
  void initState() {
    super.initState();
    store.addListener(_changed);
    _load();
  }

  @override
  void dispose() {
    store.removeListener(_changed);
    _add.dispose();
    super.dispose();
  }

  void _changed() => _load();

  Future<void> _load() async {
    final items = await buildDayItems();
    if (mounted) setState(() => _items = items);
    // the count of the day is kept for the history; the screen does not wait for the disk
    DayStore.record(todayStr(), items.where((i) => i.done).length, items.length);
  }

  Future<void> _open(DayItem it) async {
    if (it.kind == 'book') {
      final plan = BookPlanStore.all().firstWhere((p) => p['id'] == it.ref1, orElse: () => <String, dynamic>{});
      if (plan.isNotEmpty) await openBookChapter(context, '${plan['packId']}', int.tryParse(it.ref2) ?? 0);
    } else if (it.kind == 'exam') {
      final i = await library.indexOfTitle(it.ref1, it.ref2);
      if (i != null && mounted) openArticle(context, it.ref1, i);
    }
  }

  IconData _icon(String k) => switch (k) {
        'book' => AppIcons.read,
        'exam' => AppIcons.quiz,
        _ => AppIcons.notes,
      };

  Widget _section(String title, List<DayItem> list) {
    if (list.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SectionHeader(title),
      for (final it in list)
        AppCard(
          child: ListTile(
            key: ValueKey('day_${it.id}'),
            leading: Checkbox(value: it.done, onChanged: (_) => toggleDayItem(it)),
            title: m.Text(it.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(decoration: it.done ? TextDecoration.lineThrough : null, fontWeight: FontWeight.w600)),
            subtitle: it.sub.isEmpty
                ? null
                : m.Text(it.sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: it.overdue ? theme.colorScheme.error : null)),
            trailing: it.kind == 'task'
                ? IconButton(tooltip: tr('Delete'), icon: Icon(AppIcons.delete, size: 20), onPressed: () => DayStore.deleteTask(it.ref1))
                : Icon(_icon(it.kind), size: 20, color: theme.colorScheme.outline),
            onTap: it.kind == 'task' ? () => toggleDayItem(it) : () => _open(it),
          ),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final items = _items;
    final done = items?.where((i) => i.done).length ?? 0;
    final total = items?.length ?? 0;
    final log = DayStore.log();
    final now = DateTime.now();
    final streak = DayStore.streak(log, now);
    return Scaffold(
      appBar: AppBar(title: Text('Today')),
      body: items == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
              AppCard(
                key: const ValueKey('day_summary'),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      SizedBox(
                        width: 64,
                        height: 64,
                        child: Stack(alignment: Alignment.center, children: [
                          CircularProgressIndicator(value: total == 0 ? 0 : done / total, strokeWidth: 7, backgroundColor: cs.surfaceContainerHighest),
                          m.Text('$done/$total', key: const ValueKey('day_count'), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ]),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(total == 0 ? 'Nothing planned today' : (done == total ? 'Everything done today' : 'Done today'), style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                          if (streak > 0) m.Text(trp('{n} days in a row', {'n': streak}), style: theme.textTheme.bodySmall?.copyWith(color: cs.primary, fontWeight: FontWeight.w700)),
                        ]),
                      ),
                    ]),
                    const SizedBox(height: 12),
                    // the last 7 days
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      for (var k = 6; k >= 0; k--) _DayBar(date: DateTime(now.year, now.month, now.day).subtract(Duration(days: k)), entry: log[fmtDate(DateTime(now.year, now.month, now.day).subtract(Duration(days: k)))]),
                    ]),
                  ]),
                ),
              ),
              _section(tr('Late'), [for (final i in items) if (i.overdue && !i.done) i]),
              _section(tr('Reading'), [for (final i in items) if (i.kind == 'book' && !i.overdue) i]),
              _section(tr('Exam plan'), [for (final i in items) if (i.kind == 'exam' && !i.overdue) i]),
              _section(tr('My tasks'), [for (final i in items) if (i.kind == 'task' && !i.overdue) i]),
              if (total == 0)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Text('Your plans have nothing due today. Add a task below, or create a plan in My plan.', textAlign: TextAlign.center, style: theme.textTheme.bodyMedium),
                ),
              const SizedBox(height: 12),
              TextField(
                key: const ValueKey('day_add'),
                controller: _add,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  labelText: tr('Add a task for today'),
                  suffixIcon: IconButton(
                    tooltip: tr('Add'),
                    icon: Icon(AppIcons.add),
                    onPressed: () async {
                      final t = _add.text;
                      _add.clear();
                      await DayStore.addTask(t);
                    },
                  ),
                ),
                onSubmitted: (t) async {
                  _add.clear();
                  await DayStore.addTask(t);
                },
              ),
              const SizedBox(height: 4),
              Text('Only your own plans and tasks appear here. Ticking a chapter or an exam item here also ticks it in its plan.', style: theme.textTheme.bodySmall),
            ]),
    );
  }
}

class _DayBar extends StatelessWidget {
  final DateTime date;
  final Map<String, int>? entry;
  const _DayBar({required this.date, required this.entry});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = entry?['t'] ?? 0, d = entry?['d'] ?? 0;
    final f = t == 0 ? 0.0 : (d / t).clamp(0.0, 1.0);
    final full = t > 0 && d >= t;
    return Column(children: [
      SizedBox(
        width: 22,
        height: 40,
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            width: 14,
            height: t == 0 ? 4 : 6 + 34 * f,
            decoration: BoxDecoration(color: t == 0 ? cs.surfaceContainerHighest : (full ? cs.primary : cs.primary.withValues(alpha: 0.45)), borderRadius: BorderRadius.circular(6)),
          ),
        ),
      ),
      const SizedBox(height: 4),
      m.Text(const ['M', 'T', 'W', 'T', 'F', 'S', 'S'][date.weekday - 1], style: TextStyle(fontSize: 11, color: cs.outline)),
    ]);
  }
}
