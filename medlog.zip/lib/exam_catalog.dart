/// Findings offered for each body system in the examination: the normal ones are written the way a clinician writes a
/// normal examination (as negatives), so a whole system can be recorded with one tap and still read like a note.
class SysFindings {
  final List<String> normal, abnormal;
  const SysFindings(this.normal, this.abnormal);
}

const Map<String, SysFindings> kExamFindings = {
  'General': SysFindings(
    ['Conscious, alert and oriented', 'Comfortable at rest', 'Not pale', 'Not jaundiced', 'No cyanosis', 'No clubbing', 'No peripheral oedema', 'No lymphadenopathy', 'Well hydrated'],
    ['In distress', 'Pale', 'Jaundiced', 'Cyanosed', 'Clubbing', 'Peripheral oedema', 'Lymphadenopathy', 'Dehydrated', 'Cachexic', 'Drowsy or confused'],
  ),
  'CVS': SysFindings(
    ['Regular pulse', 'Normal heart sounds S1 and S2', 'No murmurs', 'No raised JVP', 'No peripheral oedema', 'Peripheral pulses present and equal', 'Capillary refill under 2 seconds'],
    ['Irregular pulse', 'Tachycardia', 'Bradycardia', 'Murmur', 'Added heart sounds (S3 or S4)', 'Raised JVP', 'Peripheral oedema', 'Weak or absent peripheral pulses', 'Delayed capillary refill', 'Displaced apex beat'],
  ),
  'Respiratory': SysFindings(
    ['Normal respiratory rate and effort', 'No use of accessory muscles', 'Equal chest expansion', 'Resonant percussion', 'Vesicular breath sounds', 'No added sounds'],
    ['Tachypnoea', 'Use of accessory muscles', 'Reduced chest expansion', 'Dull percussion', 'Hyper-resonant percussion', 'Reduced air entry', 'Bronchial breathing', 'Wheeze', 'Crackles', 'Stridor', 'Pleural rub'],
  ),
  'Abdomen': SysFindings(
    ['Abdomen soft and non-tender', 'No distension', 'No guarding or rigidity', 'No palpable masses', 'No organomegaly', 'Bowel sounds present', 'Hernial orifices intact'],
    ['Distended', 'Tenderness', 'Guarding', 'Rigidity', 'Rebound tenderness', 'Palpable mass', 'Hepatomegaly', 'Splenomegaly', 'Ascites', 'Absent or hyperactive bowel sounds', 'Surgical scar', 'Hernia'],
  ),
  'CNS': SysFindings(
    ['GCS 15/15', 'Cranial nerves intact', 'Normal tone', 'Power 5/5 in all limbs', 'Reflexes normal and symmetrical', 'Sensation intact', 'Plantar responses flexor', 'Normal gait', 'No meningism'],
    ['Reduced GCS', 'Cranial nerve deficit', 'Increased tone or spasticity', 'Reduced tone', 'Focal weakness', 'Reduced or brisk reflexes', 'Sensory loss', 'Upgoing plantar response', 'Ataxic gait', 'Neck stiffness', 'Speech disturbance'],
  ),
  'MSK': SysFindings(
    ['No deformity', 'No swelling', 'No tenderness', 'Full range of movement', 'Normal power', 'Distal pulses and sensation intact', 'Joints stable'],
    ['Deformity', 'Swelling', 'Bony tenderness', 'Reduced range of movement', 'Joint effusion', 'Crepitus', 'Instability', 'Reduced power', 'Distal neurovascular deficit', 'Open wound'],
  ),
  'ENT': SysFindings(
    ['Ears normal, tympanic membranes intact', 'Nose patent, no discharge', 'Throat not inflamed', 'Tonsils normal', 'No cervical lymphadenopathy'],
    ['Ear discharge', 'Red or bulging tympanic membrane', 'Nasal obstruction or discharge', 'Pharyngeal erythema', 'Tonsillar enlargement or exudate', 'Cervical lymphadenopathy', 'Neck swelling'],
  ),
  'Skin': SysFindings(
    ['No rash', 'No lesions', 'Normal skin turgor', 'Warm and well perfused'],
    ['Rash', 'Erythema', 'Ulcer', 'Wound', 'Petechiae or purpura', 'Urticaria', 'Bruising', 'Cellulitis', 'Pressure sore', 'Cold clammy skin'],
  ),
};
