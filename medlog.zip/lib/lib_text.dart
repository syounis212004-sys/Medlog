import 'package:flutter/material.dart';

/// Small text helpers for the library: abbreviations, article sections, sentences and
/// a typo-tolerant distance. Everything here is offline and works on the article text only.

const Map<String, String> kLibAbbrev = {
  'oa': 'osteoarthritis',
  'ra': 'rheumatoid arthritis',
  'mi': 'myocardial infarction',
  'acs': 'acute coronary syndrome',
  'chf': 'heart failure',
  'hf': 'heart failure',
  'af': 'atrial fibrillation',
  'afib': 'atrial fibrillation',
  'htn': 'hypertension',
  'dm': 'diabetes mellitus',
  'dka': 'diabetic ketoacidosis',
  'copd': 'chronic obstructive pulmonary disease',
  'cap': 'pneumonia',
  'pe': 'pulmonary embolism',
  'dvt': 'deep vein thrombosis',
  'uti': 'urinary tract infection',
  'ckd': 'chronic kidney disease',
  'aki': 'acute kidney injury',
  'gerd': 'gastroesophageal reflux disease',
  'ibd': 'inflammatory bowel disease',
  'ibs': 'irritable bowel syndrome',
  'tb': 'tuberculosis',
  'sle': 'systemic lupus erythematosus',
  'ms': 'multiple sclerosis',
  'cva': 'stroke',
  'tia': 'transient ischemic attack',
  'ards': 'acute respiratory distress syndrome',
  'sob': 'shortness of breath',
  'acl': 'anterior cruciate ligament',
  'pcl': 'posterior cruciate ligament',
  'orif': 'open reduction and internal fixation',
  'cts': 'carpal tunnel syndrome',
  'gbs': 'guillain barre syndrome',
  'bph': 'benign prostatic hyperplasia',
  'pid': 'pelvic inflammatory disease',
  'pcos': 'polycystic ovary syndrome',
  'ptsd': 'post-traumatic stress disorder',
  'ocd': 'obsessive compulsive disorder',
  'adhd': 'attention deficit hyperactivity disorder',
  'ecg': 'electrocardiography',
  'ekg': 'electrocardiography',
  'cxr': 'chest radiograph',
  'ct': 'computed tomography',
  'mri': 'magnetic resonance imaging',
  'nsaid': 'nonsteroidal anti-inflammatory drug',
  'gi': 'gastrointestinal',
  'hiv': 'hiv/aids',
  'dic': 'disseminated intravascular coagulation',
  'itp': 'immune thrombocytopenia',
  'ttp': 'thrombotic thrombocytopenic purpura',
  'cll': 'chronic lymphocytic leukemia',
  'aml': 'acute myeloid leukemia',
  'all': 'acute lymphoblastic leukemia',
  'cml': 'chronic myeloid leukemia',
  'nhl': 'non-hodgkin lymphoma',
  'sah': 'subarachnoid hemorrhage',
  'ich': 'intracerebral hemorrhage',
  'rds': 'respiratory distress syndrome',
  'vsd': 'ventricular septic defect',
  'asd': 'atrial septal defect',
  'pda': 'patent ductus arteriosus',
};

/// The query itself plus, for each abbreviation in it, a variant with the long form.
List<String> expandAbbrev(String q) {
  final words = q.toLowerCase().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
  final out = <String>[q.trim()];
  if (words.any(kLibAbbrev.containsKey)) {
    out.add(words.map((w) => kLibAbbrev[w] ?? w).join(' '));
  }
  return out;
}

enum SecKind { lead, symptoms, causes, diagnosis, treatment, prevention, epidemiology, history, other }

SecKind secKind(String heading) {
  final h = heading.toLowerCase();
  if (RegExp(r'signs and symptoms|symptom|clinical (presentation|features)|presentation|what are the symptoms').hasMatch(h)) return SecKind.symptoms;
  if (RegExp(r'cause|etiolog|risk factor|pathophys|pathogen|mechanism|who is more likely').hasMatch(h)) return SecKind.causes;
  if (RegExp(r'diagnos|investigation|screening|classification|differential|imaging|tests').hasMatch(h)) return SecKind.diagnosis;
  if (RegExp(r'treatment|management|therap|medication|surgery|surgical|rehabilitation|what are the treatments').hasMatch(h)) return SecKind.treatment;
  if (RegExp(r'prevent|prognos|outcome|complication').hasMatch(h)) return SecKind.prevention;
  if (RegExp(r'epidemiolog|prevalence|incidence').hasMatch(h)) return SecKind.epidemiology;
  if (RegExp(r'history|society|culture|etymolog|research|other animals').hasMatch(h)) return SecKind.history;
  return SecKind.other;
}

IconData secIcon(SecKind k) {
  switch (k) {
    case SecKind.lead:
      return Icons.short_text;
    case SecKind.symptoms:
      return Icons.sick_outlined;
    case SecKind.causes:
      return Icons.account_tree_outlined;
    case SecKind.diagnosis:
      return Icons.biotech_outlined;
    case SecKind.treatment:
      return Icons.medication_outlined;
    case SecKind.prevention:
      return Icons.shield_outlined;
    case SecKind.epidemiology:
      return Icons.groups_outlined;
    case SecKind.history:
      return Icons.history_edu_outlined;
    case SecKind.other:
      return Icons.notes_outlined;
  }
}

/// Short English label for the jump chips.
String secLabel(SecKind k) {
  switch (k) {
    case SecKind.symptoms:
      return 'Symptoms';
    case SecKind.causes:
      return 'Causes';
    case SecKind.diagnosis:
      return 'Diagnosis';
    case SecKind.treatment:
      return 'Treatment';
    case SecKind.prevention:
      return 'Prognosis';
    case SecKind.epidemiology:
      return 'Epidemiology';
    case SecKind.history:
      return 'History';
    default:
      return 'More';
  }
}

/// Splits text into sentences (keeps common abbreviations and decimals together).
List<String> sentences(String text) {
  final t = text.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.isEmpty) return const [];
  final protected = t
      .replaceAllMapped(RegExp(r'\b(e\.g|i\.e|vs|Dr|Fig|approx|ca|cf|et al|No|St|Mr|Mrs)\.', caseSensitive: false), (m) => '${m[1]}\u0001')
      .replaceAllMapped(RegExp(r'(\d)\.(\d)'), (m) => '${m[1]}\u0002${m[2]}');
  final out = <String>[];
  for (final s in protected.split(RegExp(r'(?<=[.!?])\s+(?=[A-Z0-9"(])'))) {
    final x = s.replaceAll('\u0001', '.').replaceAll('\u0002', '.').trim();
    if (x.isNotEmpty) out.add(x);
  }
  return out;
}

String firstSentence(String text) {
  final s = sentences(text);
  return s.isEmpty ? '' : s.first;
}

/// Edit distance with adjacent swaps, stops early above [max].
int editDistance(String a, String b, {int max = 3}) {
  if ((a.length - b.length).abs() > max) return max + 1;
  var prev2 = List<int>.filled(b.length + 1, 0);
  var prev = List<int>.generate(b.length + 1, (i) => i);
  for (var i = 1; i <= a.length; i++) {
    final cur = List<int>.filled(b.length + 1, 0);
    cur[0] = i;
    var rowMin = cur[0];
    for (var j = 1; j <= b.length; j++) {
      final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
      var v = [prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost].reduce((x, y) => x < y ? x : y);
      if (i > 1 && j > 1 && a.codeUnitAt(i - 1) == b.codeUnitAt(j - 2) && a.codeUnitAt(i - 2) == b.codeUnitAt(j - 1)) {
        final t = prev2[j - 2] + 1;
        if (t < v) v = t;
      }
      cur[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > max) return max + 1;
    prev2 = prev;
    prev = cur;
  }
  return prev[b.length];
}
