import 'package:flutter/material.dart';

/// Small text helpers for the library: abbreviations, article sections, sentences and
/// a typo-tolerant distance. Everything here is offline and works on the article text only.

const Map<String, String> kLibAbbrev = {
  'oa': 'osteoarthritis',
  'ra': 'rheumatoid arthritis',
  'mi': 'myocardial infarction',
  'acs': 'acute coronary syndrome',
  'chf': 'heart failure',
  'hf': 'heart failure',
  'af': 'atrial fibrillation',
  'afib': 'atrial fibrillation',
  'htn': 'hypertension',
  'dm': 'diabetes mellitus',
  'dka': 'diabetic ketoacidosis',
  'copd': 'chronic obstructive pulmonary disease',
  'cap': 'pneumonia',
  'pe': 'pulmonary embolism',
  'dvt': 'deep vein thrombosis',
  'uti': 'urinary tract infection',
  'ckd': 'chronic kidney disease',
  'aki': 'acute kidney injury',
  'gerd': 'gastroesophageal reflux disease',
  'ibd': 'inflammatory bowel disease',
  'ibs': 'irritable bowel syndrome',
  'tb': 'tuberculosis',
  'sle': 'systemic lupus erythematosus',
  'ms': 'multiple sclerosis',
  'cva': 'stroke',
  'tia': 'transient ischemic attack',
  'ards': 'acute respiratory distress syndrome',
  'sob': 'shortness of breath',
  'acl': 'anterior cruciate ligament',
  'pcl': 'posterior cruciate ligament',
  'orif': 'open reduction and internal fixation',
  'cts': 'carpal tunnel syndrome',
  'gbs': 'guillain barre syndrome',
  'bph': 'benign prostatic hyperplasia',
  'pid': 'pelvic inflammatory disease',
  'pcos': 'polycystic ovary syndrome',
  'ptsd': 'post-traumatic stress disorder',
  'ocd': 'obsessive compulsive disorder',
  'adhd': 'attention deficit hyperactivity disorder',
  'ecg': 'electrocardiography',
  'ekg': 'electrocardiography',
  'cxr': 'chest radiograph',
  'ct': 'computed tomography',
  'mri': 'magnetic resonance imaging',
  'nsaid': 'nonsteroidal anti-inflammatory drug',
  'gi': 'gastrointestinal',
  'hiv': 'hiv/aids',
  'dic': 'disseminated intravascular coagulation',
  'itp': 'immune thrombocytopenia',
  'ttp': 'thrombotic thrombocytopenic purpura',
  'cll': 'chronic lymphocytic leukemia',
  'aml': 'acute myeloid leukemia',
  'all': 'acute lymphoblastic leukemia',
  'cml': 'chronic myeloid leukemia',
  'nhl': 'non-hodgkin lymphoma',
  'sah': 'subarachnoid hemorrhage',
  'ich': 'intracerebral hemorrhage',
  'rds': 'respiratory distress syndrome',
  'vsd': 'ventricular septic defect',
  'asd': 'atrial septal defect',
  'pda': 'patent ductus arteriosus',
};

/// The query itself plus, for each abbreviation in it, a variant with the long form.
List<String> expandAbbrev(String q) {
  final words = q.toLowerCase().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
  final out = <String>[q.trim()];
  if (words.any(kLibAbbrev.containsKey)) {
    out.add(words.map((w) => kLibAbbrev[w] ?? w).join(' '));
  }
  return out;
}

enum SecKind { lead, symptoms, causes, diagnosis, treatment, prevention, epidemiology, history, other }

SecKind secKind(String heading) {
  final h = heading.toLowerCase();
  if (RegExp(r'signs and symptoms|symptom|clinical (presentation|features)|presentation|what are the symptoms').hasMatch(h)) return SecKind.symptoms;
  if (RegExp(r'cause|etiolog|risk factor|pathophys|pathogen|mechanism|who is more likely').hasMatch(h)) return SecKind.causes;
  if (RegExp(r'diagnos|investigation|screening|classification|differential|imaging|tests').hasMatch(h)) return SecKind.diagnosis;
  if (RegExp(r'treatment|management|therap|medication|surgery|surgical|rehabilitation|what are the treatments').hasMatch(h)) return SecKind.treatment;
  if (RegExp(r'prevent|prognos|outcome|complication').hasMatch(h)) return SecKind.prevention;
  if (RegExp(r'epidemiolog|prevalence|incidence').hasMatch(h)) return SecKind.epidemiology;
  if (RegExp(r'history|society|culture|etymolog|research|other animals').hasMatch(h)) return SecKind.history;
  return SecKind.other;
}

IconData secIcon(SecKind k) {
  switch (k) {
    case SecKind.lead:
      return Icons.short_text;
    case SecKind.symptoms:
      return Icons.sick_outlined;
    case SecKind.causes:
      return Icons.account_tree_outlined;
    case SecKind.diagnosis:
      return Icons.biotech_outlined;
    case SecKind.treatment:
      return Icons.medication_outlined;
    case SecKind.prevention:
      return Icons.shield_outlined;
    case SecKind.epidemiology:
      return Icons.groups_outlined;
    case SecKind.history:
      return Icons.history_edu_outlined;
    case SecKind.other:
      return Icons.notes_outlined;
  }
}

/// Short English label for the jump chips.
String secLabel(SecKind k) {
  switch (k) {
    case SecKind.symptoms:
      return 'Symptoms';
    case SecKind.causes:
      return 'Causes';
    case SecKind.diagnosis:
      return 'Diagnosis';
    case SecKind.treatment:
      return 'Treatment';
    case SecKind.prevention:
      return 'Prognosis';
    case SecKind.epidemiology:
      return 'Epidemiology';
    case SecKind.history:
      return 'History';
    default:
      return 'More';
  }
}

/// Splits text into sentences (keeps common abbreviations and decimals together).
List<String> sentences(String text) {
  final t = text.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.isEmpty) return const [];
  final protected = t
      .replaceAllMapped(RegExp(r'\b(e\.g|i\.e|vs|Dr|Fig|approx|ca|cf|et al|No|St|Mr|Mrs)\.', caseSensitive: false), (m) => '${m[1]}\u0001')
      .replaceAllMapped(RegExp(r'(\d)\.(\d)'), (m) => '${m[1]}\u0002${m[2]}');
  final out = <String>[];
  for (final s in protected.split(RegExp(r'(?<=[.!?])\s+(?=[A-Z0-9"(])'))) {
    final x = s.replaceAll('\u0001', '.').replaceAll('\u0002', '.').trim();
    if (x.isNotEmpty) out.add(x);
  }
  return out;
}

String firstSentence(String text) {
  final s = sentences(text);
  return s.isEmpty ? '' : s.first;
}

/// Edit distance with adjacent swaps, stops early above [max].
int editDistance(String a, String b, {int max = 3}) {
  if ((a.length - b.length).abs() > max) return max + 1;
  var prev2 = List<int>.filled(b.length + 1, 0);
  var prev = List<int>.generate(b.length + 1, (i) => i);
  for (var i = 1; i <= a.length; i++) {
    final cur = List<int>.filled(b.length + 1, 0);
    cur[0] = i;
    var rowMin = cur[0];
    for (var j = 1; j <= b.length; j++) {
      final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
      var v = [prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost].reduce((x, y) => x < y ? x : y);
      if (i > 1 && j > 1 && a.codeUnitAt(i - 1) == b.codeUnitAt(j - 2) && a.codeUnitAt(i - 2) == b.codeUnitAt(j - 1)) {
        final t = prev2[j - 2] + 1;
        if (t < v) v = t;
      }
      cur[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > max) return max + 1;
    prev2 = prev;
    prev = cur;
  }
  return prev[b.length];
}

/// Lines of a section that are bullets ("• item"), without the bullet sign.
List<String> bulletLines(String text) {
  final out = <String>[];
  for (final l in text.split('\n')) {
    final t = l.trim();
    if (t.startsWith('•')) {
      final x = t.substring(1).trim();
      if (x.isNotEmpty) out.add(x);
    }
  }
  return out;
}

/// Sentences and bullet lines of a section, each as one unit (bullets keep their own line).
List<String> textUnits(String text) {
  final out = <String>[];
  final buf = StringBuffer();
  void flush() {
    if (buf.isNotEmpty) out.addAll(sentences(buf.toString()));
    buf.clear();
  }

  for (final l in text.split('\n')) {
    final t = l.trim();
    if (t.startsWith('•')) {
      flush();
      final x = t.substring(1).trim();
      if (x.isNotEmpty) out.add(x);
    } else if (t.isNotEmpty) {
      buf.write('$t ');
    }
  }
  flush();
  return out;
}

// ---------------------------------------------------------------------------------------------
// Canonical sections for the Study Sheet: every heading of every source maps to one of these,
// in this fixed reading order. [secKind] above is unchanged for the older callers.

enum Canon { background, causes, pathophys, epidemiology, symptoms, differential, diagnosis, treatment, disposition, complications, prognosis, prevention, other, history }

const List<Canon> kCanonOrder = [
  Canon.background,
  Canon.causes,
  Canon.pathophys,
  Canon.epidemiology,
  Canon.symptoms,
  Canon.differential,
  Canon.diagnosis,
  Canon.treatment,
  Canon.disposition,
  Canon.complications,
  Canon.prognosis,
  Canon.prevention,
  Canon.other,
  Canon.history,
];

final RegExp _cDiff = RegExp(r'differential');
final RegExp _cDisp = RegExp(r'dispositi|follow-?\s?up|admission|referral');
final RegExp _cSym = RegExp(r'signs and symptoms|symptom|clinical (presentation|features)|presentation|^findings|history and physical|what are the symptoms');
final RegExp _cTreat = RegExp(r'treatment|management|therap|medications?$|^medications?|surgery|surgical|rehabilitation|what are the treatments|^recovery');
final RegExp _cDiag = RegExp(r'diagnos|evaluation|work-?\s?up|investigation|screening|classification|imaging|tests?$|testing|recommended tests|laborator|^interpretation|^tests');
final RegExp _cComp = RegExp(r'complication');
final RegExp _cProg = RegExp(r'prognos|outcome');
final RegExp _cPrev = RegExp(r'prevent');
final RegExp _cEpi = RegExp(r'epidemiolog|prevalence|incidence|disease rates');
final RegExp _cCause = RegExp(r'cause|etiolog|risk factor|who is more likely|how it spreads');
final RegExp _cPath = RegExp(r'pathophys|pathogen|^mechanism$|^mechanism of disease|pathology');
final RegExp _cHist = RegExp(r'history|society|culture|etymolog|research|other animals');
final RegExp _cBack = RegExp(r'^(background|general|overview|definition|introduction|summary|key points|at a glance|about|what is|description)');

/// Maps a section heading ('' = the lead) to its canonical section.
Canon canonOf(String heading) {
  final h = heading.toLowerCase().trim();
  if (h.isEmpty) return Canon.background;
  if (_cDiff.hasMatch(h)) return Canon.differential;
  if (_cDisp.hasMatch(h)) return Canon.disposition;
  if (_cSym.hasMatch(h)) return Canon.symptoms;
  if (_cTreat.hasMatch(h)) return Canon.treatment;
  if (_cDiag.hasMatch(h)) return Canon.diagnosis;
  if (_cComp.hasMatch(h)) return Canon.complications;
  if (_cProg.hasMatch(h)) return Canon.prognosis;
  if (_cPrev.hasMatch(h)) return Canon.prevention;
  if (_cEpi.hasMatch(h)) return Canon.epidemiology;
  if (_cCause.hasMatch(h)) return Canon.causes;
  if (_cPath.hasMatch(h)) return Canon.pathophys;
  if (_cHist.hasMatch(h) && !h.startsWith('history and')) return Canon.history;
  if (_cBack.hasMatch(h)) return Canon.background;
  return Canon.other;
}

/// English label (wrap with tr() when shown).
String canonLabel(Canon c) {
  switch (c) {
    case Canon.background:
      return 'Background';
    case Canon.causes:
      return 'Causes';
    case Canon.pathophys:
      return 'Pathophysiology';
    case Canon.epidemiology:
      return 'Epidemiology';
    case Canon.symptoms:
      return 'Symptoms';
    case Canon.differential:
      return 'Differential';
    case Canon.diagnosis:
      return 'Diagnosis';
    case Canon.treatment:
      return 'Treatment';
    case Canon.disposition:
      return 'Disposition';
    case Canon.complications:
      return 'Complications';
    case Canon.prognosis:
      return 'Prognosis';
    case Canon.prevention:
      return 'Prevention';
    case Canon.history:
      return 'History';
    case Canon.other:
      return 'More';
  }
}

IconData canonIcon(Canon c) {
  switch (c) {
    case Canon.background:
      return Icons.short_text;
    case Canon.causes:
      return Icons.account_tree_outlined;
    case Canon.pathophys:
      return Icons.science_outlined;
    case Canon.epidemiology:
      return Icons.groups_outlined;
    case Canon.symptoms:
      return Icons.sick_outlined;
    case Canon.differential:
      return Icons.compare_arrows;
    case Canon.diagnosis:
      return Icons.biotech_outlined;
    case Canon.treatment:
      return Icons.medication_outlined;
    case Canon.disposition:
      return Icons.local_hospital_outlined;
    case Canon.complications:
      return Icons.warning_amber_outlined;
    case Canon.prognosis:
      return Icons.trending_up;
    case Canon.prevention:
      return Icons.shield_outlined;
    case Canon.history:
      return Icons.history_edu_outlined;
    case Canon.other:
      return Icons.notes_outlined;
  }
}

/// Accent colour of a canonical section (a lighter tone on dark backgrounds).
Color canonColor(Canon c, bool dark) {
  int light, dk;
  switch (c) {
    case Canon.background:
      light = 0xFF3B6EA8;
      dk = 0xFF8DB4E8;
    case Canon.causes:
      light = 0xFF7B5EA7;
      dk = 0xFFBBA3E3;
    case Canon.pathophys:
      light = 0xFF2A8C8C;
      dk = 0xFF7FD0D0;
    case Canon.epidemiology:
      light = 0xFF5F7487;
      dk = 0xFFA9BCCB;
    case Canon.symptoms:
      light = 0xFFC2630F;
      dk = 0xFFF2A765;
    case Canon.differential:
      light = 0xFF8A6D00;
      dk = 0xFFE3C95E;
    case Canon.diagnosis:
      light = 0xFF3F51B5;
      dk = 0xFFA3AEF2;
    case Canon.treatment:
      light = 0xFF2E7D4F;
      dk = 0xFF7FD3A0;
    case Canon.disposition:
      light = 0xFF00796B;
      dk = 0xFF6FD5C8;
    case Canon.complications:
      light = 0xFFB3402D;
      dk = 0xFFF29585;
    case Canon.prognosis:
      light = 0xFF7A5646;
      dk = 0xFFD1B0A2;
    case Canon.prevention:
      light = 0xFF1B8A6B;
      dk = 0xFF76D6B8;
    case Canon.history:
    case Canon.other:
      light = 0xFF607080;
      dk = 0xFFB0BDC9;
  }
  return Color(dark ? dk : light);
}
