import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as mm show Text;

import 'calculators.dart';
import 'data.dart';
import 'i18n.dart';
import 'widgets.dart';

/// Clinical calculators that work without internet. Each one shows its formula so it can be checked.
class CalculatorsScreen extends StatelessWidget {
  const CalculatorsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Calculators')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Text('Standard published formulas, for learning. Always confirm with your hospital protocol.', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          const Fold(id: 'cl_bmi', title: 'BMI', icon: Icons.monitor_weight_outlined, children: [_BmiCalc()]),
          const Fold(id: 'cl_map', title: 'Mean arterial pressure (MAP)', icon: Icons.favorite_outline, children: [_MapCalc()]),
          const Fold(id: 'cl_gcs', title: 'Glasgow Coma Scale (GCS)', icon: Icons.psychology_outlined, children: [_GcsCalc()]),
          const Fold(id: 'cl_curb', title: 'CURB-65 (pneumonia severity)', icon: Icons.air, children: [
            _Checklist(
              items: [
                ['Confusion (new)', 1],
                ['Urea > 7 mmol/L (BUN > 19 mg/dL)', 1],
                ['Respiratory rate ≥ 30/min', 1],
                ['Systolic BP < 90 or diastolic ≤ 60 mmHg', 1],
                ['Age ≥ 65', 1],
              ],
              kind: _CheckKind.curb,
              source: 'Lim WS et al., Thorax 2003',
            ),
          ]),
          const Fold(id: 'cl_wdvt', title: 'Wells score for DVT', icon: Icons.accessibility_new, children: [
            _Checklist(items: kWellsDvt, kind: _CheckKind.wellsDvt, source: 'Wells PS et al., Lancet 1997 / NEJM 2003'),
          ]),
          const Fold(id: 'cl_wpe', title: 'Wells score for pulmonary embolism', icon: Icons.bubble_chart_outlined, children: [
            _Checklist(items: kWellsPe, kind: _CheckKind.wellsPe, source: 'Wells PS et al., Thromb Haemost 2000'),
          ]),
          const Fold(id: 'cl_cha', title: 'CHA2DS2-VASc (stroke risk in AF)', icon: Icons.bolt_outlined, children: [
            _Checklist(items: kChadsVasc, kind: _CheckKind.chads, source: 'Lip GYH et al., Chest 2010'),
          ]),
          const Fold(id: 'cl_ag', title: 'Anion gap', icon: Icons.science_outlined, children: [_AnionCalc()]),
          const Fold(id: 'cl_ca', title: 'Corrected calcium', icon: Icons.science_outlined, children: [_CaCalc()]),
          const Fold(id: 'cl_qtc', title: 'QTc (Bazett)', icon: Icons.show_chart, children: [_QtcCalc()]),
          const Fold(id: 'cl_egfr', title: 'eGFR (CKD-EPI 2021)', icon: Icons.water_drop_outlined, children: [_EgfrCalc()]),
          const Fold(id: 'cl_cg', title: 'Creatinine clearance (Cockcroft-Gault)', icon: Icons.water_drop_outlined, children: [_CgCalc()]),
          const Fold(id: 'cl_fluid', title: 'Maintenance fluids in children (4-2-1)', icon: Icons.child_care, children: [_FluidCalc()]),
          const Fold(id: 'cl_edd', title: 'Due date and gestational age', icon: Icons.pregnant_woman, children: [_EddCalc()]),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- building blocks

double? _n(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));

Widget _field(TextEditingController c, String label, VoidCallback onChanged, {String? hint}) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: tr(label), hintText: hint),
        onChanged: (_) => onChanged(),
      ),
    );

class _Result extends StatelessWidget {
  final String value;
  final String meaning;
  final String formula;
  const _Result(this.value, this.meaning, this.formula);
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (value.isNotEmpty)
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: cs.primaryContainer.withAlpha(110), borderRadius: BorderRadius.circular(14)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Directionality(textDirection: TextDirection.ltr, child: mm.Text(value, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800))),
            if (meaning.isNotEmpty) Text(meaning, style: theme.textTheme.bodyMedium),
          ]),
        ),
      const SizedBox(height: 6),
      Directionality(textDirection: TextDirection.ltr, child: Align(alignment: AlignmentDirectional.centerStart, child: mm.Text(formula, style: theme.textTheme.bodySmall?.copyWith(color: cs.outline)))),
    ]);
  }
}

class _Chips extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onPick;
  const _Chips(this.labels, this.selected, this.onPick);
  @override
  Widget build(BuildContext context) => Wrap(spacing: 8, runSpacing: 4, children: [
        for (var i = 0; i < labels.length; i++) ChoiceChip(label: mm.Text(labels[i]), selected: selected == i, onSelected: (_) => onPick(i)),
      ]);
}

// ---------------------------------------------------------------- calculators

class _BmiCalc extends StatefulWidget {
  const _BmiCalc();
  @override
  State<_BmiCalc> createState() => _BmiCalcState();
}

class _BmiCalcState extends State<_BmiCalc> {
  final w = TextEditingController(), h = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final kg = _n(w), cm = _n(h);
    final ok = kg != null && cm != null && kg > 0 && cm > 0;
    final v = ok ? bmi(kg, cm) : 0.0;
    return Column(children: [
      _field(w, 'Weight (kg)', () => setState(() {})),
      _field(h, 'Height (cm)', () => setState(() {})),
      _Result(ok ? v.toStringAsFixed(1) : '', ok ? tr(bmiClass(v)) : '', 'BMI = weight (kg) / height (m)²   •   WHO: <18.5, 18.5–24.9, 25–29.9, ≥30'),
    ]);
  }
}

class _MapCalc extends StatefulWidget {
  const _MapCalc();
  @override
  State<_MapCalc> createState() => _MapCalcState();
}

class _MapCalcState extends State<_MapCalc> {
  final s = TextEditingController(), d = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final a = _n(s), b = _n(d);
    final ok = a != null && b != null;
    return Column(children: [
      _field(s, 'Systolic (mmHg)', () => setState(() {})),
      _field(d, 'Diastolic (mmHg)', () => setState(() {})),
      _Result(ok ? '${map(a, b).toStringAsFixed(0)} mmHg' : '', ok ? (map(a, b) < 65 ? tr('Below 65 mmHg: perfusion may be inadequate') : '') : '', 'MAP = (SBP + 2 × DBP) / 3'),
    ]);
  }
}

class _AnionCalc extends StatefulWidget {
  const _AnionCalc();
  @override
  State<_AnionCalc> createState() => _AnionCalcState();
}

class _AnionCalcState extends State<_AnionCalc> {
  final na = TextEditingController(), cl = TextEditingController(), hc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final a = _n(na), b = _n(cl), c = _n(hc);
    final ok = a != null && b != null && c != null;
    return Column(children: [
      _field(na, 'Sodium (mEq/L)', () => setState(() {})),
      _field(cl, 'Chloride (mEq/L)', () => setState(() {})),
      _field(hc, 'Bicarbonate (mEq/L)', () => setState(() {})),
      _Result(ok ? anionGap(a, b, c).toStringAsFixed(0) : '', ok ? tr('Normal is about 8–12 mEq/L (depends on the lab)') : '', 'Anion gap = Na − (Cl + HCO₃)'),
    ]);
  }
}

class _CaCalc extends StatefulWidget {
  const _CaCalc();
  @override
  State<_CaCalc> createState() => _CaCalcState();
}

class _CaCalcState extends State<_CaCalc> {
  final ca = TextEditingController(), al = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final a = _n(ca), b = _n(al);
    final ok = a != null && b != null;
    return Column(children: [
      _field(ca, 'Total calcium (mg/dL)', () => setState(() {})),
      _field(al, 'Albumin (g/dL)', () => setState(() {})),
      _Result(ok ? '${correctedCalcium(a, b).toStringAsFixed(1)} mg/dL' : '', '', 'Corrected Ca = Ca + 0.8 × (4.0 − albumin)'),
    ]);
  }
}

class _QtcCalc extends StatefulWidget {
  const _QtcCalc();
  @override
  State<_QtcCalc> createState() => _QtcCalcState();
}

class _QtcCalcState extends State<_QtcCalc> {
  final qt = TextEditingController(), hr = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final a = _n(qt), b = _n(hr);
    final ok = a != null && b != null && b > 0;
    return Column(children: [
      _field(qt, 'QT interval (ms)', () => setState(() {})),
      _field(hr, 'Heart rate (bpm)', () => setState(() {})),
      _Result(ok ? '${qtcBazett(a, b).toStringAsFixed(0)} ms' : '', ok ? tr('Often called prolonged above 450 ms (men) / 460 ms (women). Follow your guideline.') : '', 'QTc = QT / √RR   (RR in seconds = 60 / heart rate)'),
    ]);
  }
}

class _EgfrCalc extends StatefulWidget {
  const _EgfrCalc();
  @override
  State<_EgfrCalc> createState() => _EgfrCalcState();
}

class _EgfrCalcState extends State<_EgfrCalc> {
  final cr = TextEditingController(), age = TextEditingController();
  bool female = false;
  @override
  Widget build(BuildContext context) {
    final c = _n(cr), a = _n(age);
    final ok = c != null && a != null && c > 0 && a > 0;
    final v = ok ? egfrCkdEpi2021(c, a.round(), female) : 0.0;
    String stage() {
      if (v >= 90) return 'G1 (≥ 90)';
      if (v >= 60) return 'G2 (60–89)';
      if (v >= 45) return 'G3a (45–59)';
      if (v >= 30) return 'G3b (30–44)';
      if (v >= 15) return 'G4 (15–29)';
      return 'G5 (< 15)';
    }

    return Column(children: [
      _field(cr, 'Serum creatinine (mg/dL)', () => setState(() {})),
      _field(age, 'Age (years)', () => setState(() {})),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: Text('Female'), value: female, onChanged: (v) => setState(() => female = v)),
      _Result(ok ? '${v.toStringAsFixed(0)} mL/min/1.73 m²' : '', ok ? 'CKD ${stage()}' : '', 'CKD-EPI 2021: 142 × min(Scr/κ,1)^α × max(Scr/κ,1)^−1.200 × 0.9938^age × 1.012 (female).  κ = 0.7 F / 0.9 M;  α = −0.241 F / −0.302 M.  (Inker LA et al., NEJM 2021)'),
    ]);
  }
}

class _CgCalc extends StatefulWidget {
  const _CgCalc();
  @override
  State<_CgCalc> createState() => _CgCalcState();
}

class _CgCalcState extends State<_CgCalc> {
  final age = TextEditingController(), kg = TextEditingController(), cr = TextEditingController();
  bool female = false;
  @override
  Widget build(BuildContext context) {
    final a = _n(age), w = _n(kg), c = _n(cr);
    final ok = a != null && w != null && c != null && c > 0;
    return Column(children: [
      _field(age, 'Age (years)', () => setState(() {})),
      _field(kg, 'Weight (kg)', () => setState(() {})),
      _field(cr, 'Serum creatinine (mg/dL)', () => setState(() {})),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: Text('Female'), value: female, onChanged: (v) => setState(() => female = v)),
      _Result(ok ? '${cockcroftGault(a.round(), w, c, female).toStringAsFixed(0)} mL/min' : '', '', 'CrCl = (140 − age) × weight / (72 × Scr), × 0.85 if female'),
    ]);
  }
}

class _FluidCalc extends StatefulWidget {
  const _FluidCalc();
  @override
  State<_FluidCalc> createState() => _FluidCalcState();
}

class _FluidCalcState extends State<_FluidCalc> {
  final kg = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final w = _n(kg);
    final ok = w != null && w > 0;
    return Column(children: [
      _field(kg, 'Weight (kg)', () => setState(() {})),
      _Result(ok ? '${maintenanceFluid421(w).toStringAsFixed(0)} mL/hour' : '', ok ? '${(maintenanceFluid421(w) * 24).toStringAsFixed(0)} mL / 24h' : '', '4 mL/kg/h for the first 10 kg, + 2 mL/kg/h for the next 10 kg, + 1 mL/kg/h for each kg above 20'),
    ]);
  }
}

class _EddCalc extends StatefulWidget {
  const _EddCalc();
  @override
  State<_EddCalc> createState() => _EddCalcState();
}

class _EddCalcState extends State<_EddCalc> {
  DateTime? lmp;
  @override
  Widget build(BuildContext context) {
    final l = lmp;
    final ga = l == null ? null : gestationalAge(l, DateTime.now());
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      OutlinedButton.icon(
        icon: const Icon(Icons.event),
        label: Text(l == null ? tr('Pick the first day of the last period') : fmtDate(l)),
        onPressed: () async {
          final d = await showDatePicker(context: context, initialDate: l ?? DateTime.now(), firstDate: DateTime.now().subtract(const Duration(days: 320)), lastDate: DateTime.now());
          if (d != null) setState(() => lmp = d);
        },
      ),
      const SizedBox(height: 10),
      _Result(l == null ? '' : 'EDD ${fmtDate(eddFromLmp(l))}', ga == null ? '' : '${ga.$1}w + ${ga.$2}d', "Naegele's rule: EDD = LMP + 280 days (regular 28-day cycle)"),
    ]);
  }
}

class _GcsCalc extends StatefulWidget {
  const _GcsCalc();
  @override
  State<_GcsCalc> createState() => _GcsCalcState();
}

class _GcsCalcState extends State<_GcsCalc> {
  int e = 3, v = 4, mo = 5; // selected index in the lists below (score = 4 - index etc.)
  static const eye = ['4 Spontaneous', '3 To voice', '2 To pain', '1 None'];
  static const verbal = ['5 Oriented', '4 Confused', '3 Words', '2 Sounds', '1 None'];
  static const motor = ['6 Obeys', '5 Localizes', '4 Withdraws', '3 Flexion', '2 Extension', '1 None'];
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final total = gcs(4 - e, 5 - v, 6 - mo);
    Widget group(String title, List<String> l, int sel, ValueChanged<int> f) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.only(top: 6, bottom: 2), child: Text(title, style: theme.textTheme.labelLarge)),
          _Chips(l, sel, (i) => setState(() => f(i))),
        ]);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      group('Eye opening', eye, e, (i) => e = i),
      group('Verbal response', verbal, v, (i) => v = i),
      group('Motor response', motor, mo, (i) => mo = i),
      const SizedBox(height: 10),
      _Result('GCS $total', tr(gcsClass(total)), 'E${4 - e} V${5 - v} M${6 - mo}   •   Teasdale G, Jennett B, Lancet 1974'),
    ]);
  }
}

enum _CheckKind { curb, wellsDvt, wellsPe, chads }

class _Checklist extends StatefulWidget {
  final List<List<Object>> items;
  final _CheckKind kind;
  final String source;
  const _Checklist({required this.items, required this.kind, required this.source});
  @override
  State<_Checklist> createState() => _ChecklistState();
}

class _ChecklistState extends State<_Checklist> {
  final Set<int> on = {};
  @override
  Widget build(BuildContext context) {
    final score = sumChecked(widget.items, on);
    String shown = score == score.roundToDouble() ? score.toStringAsFixed(0) : score.toStringAsFixed(1);
    String meaning;
    switch (widget.kind) {
      case _CheckKind.curb:
        meaning = tr(curb65Risk(score.round()));
        break;
      case _CheckKind.wellsDvt:
        meaning = score >= 2 ? tr('DVT likely (≥ 2): imaging is advised') : tr('DVT unlikely (< 2): D-dimer can help rule it out');
        break;
      case _CheckKind.wellsPe:
        meaning = score > 4 ? tr('PE likely (> 4): imaging is advised') : tr('PE unlikely (≤ 4): D-dimer can help rule it out');
        break;
      case _CheckKind.chads:
        meaning = score >= 2 ? tr('Higher risk: anticoagulation is usually recommended. Follow your guideline.') : tr('Low to intermediate risk. Follow your guideline.');
        break;
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (var i = 0; i < widget.items.length; i++)
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          controlAffinity: ListTileControlAffinity.leading,
          title: Directionality(textDirection: TextDirection.ltr, child: mm.Text('${widget.items[i][0]}   (${(widget.items[i][1] as num) > 0 ? '+' : ''}${widget.items[i][1]})')),
          value: on.contains(i),
          onChanged: (v) => setState(() => v == true ? on.add(i) : on.remove(i)),
        ),
      const SizedBox(height: 6),
      _Result(shown, meaning, widget.source),
    ]);
  }
}
