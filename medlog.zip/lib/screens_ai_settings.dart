import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';

import 'ai/ai_api.dart';
import 'ai/ai_widgets.dart' show showAiCaseConsent;
import 'i18n.dart';
import 'widgets.dart';

/// Settings > AI assistant. Everything here is stored on this phone only (keys in the Android Keystore).
class AiSettingsScreen extends StatefulWidget {
  const AiSettingsScreen({super.key});

  @override
  State<AiSettingsScreen> createState() => _AiSettingsScreenState();
}

const Map<String, List<String>> _kGroupInfo = {
  'ask': ['Ask my references', 'Answers questions using the library you installed.'],
  'explain': ['Explain / translate', 'Explains or translates a passage in simple words.'],
  'quiz': ['Question bank', 'Drafts practice questions from a topic.'],
  'case': ['Case assistant', 'Suggests ideas for a case from a de-identified summary.'],
  'reports': ['Reports & summaries', 'Drafts summaries of your own logbook.'],
  'help': ['App help', 'Answers "how do I do this in MedLog".'],
};

class _AiSettingsScreenState extends State<AiSettingsScreen> {
  final TextEditingController _key = TextEditingController();
  final TextEditingController _base = TextEditingController();
  final TextEditingController _model = TextEditingController();
  bool _show = false;
  bool _busy = false;
  String _msg = '';
  bool _msgOk = false;

  @override
  void initState() {
    super.initState();
    AiStore.changes.addListener(_r);
    AiStore.ensureLoaded().then((_) {
      if (!mounted) return;
      _base.text = AiStore.openaiBase;
      _model.text = AiStore.modelOf(AiStore.provider);
      setState(() {});
    });
    _base.text = AiStore.openaiBase;
    _model.text = AiStore.modelOf(AiStore.provider);
    Ai.isOnline();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    AiStore.changes.removeListener(_r);
    _key.dispose();
    _base.dispose();
    _model.dispose();
    super.dispose();
  }

  AiProviderId get _p => AiStore.provider;

  Future<void> _setProvider(AiProviderId p) async {
    AiStore.provider = p;
    _key.clear();
    _msg = '';
    _model.text = AiStore.modelOf(p);
    await AiStore.save();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (d?.text != null) setState(() => _key.text = d!.text!.trim());
  }

  Future<void> _saveBase() async {
    if (_p != AiProviderId.openai) return;
    AiStore.openaiBase = _base.text.trim().isEmpty ? AiProviders.openaiDefaultBase : _base.text.trim();
    await AiStore.save();
  }

  Future<void> _saveKey() async {
    await _saveBase();
    final k = _key.text.trim();
    if (k.isEmpty) return;
    await AiStore.setKey(_p, k);
    _key.clear();
    setState(() {
      _msg = tr('Key saved on this phone.');
      _msgOk = true;
    });
  }

  Future<void> _test() async {
    await _saveBase();
    final typed = _key.text.trim();
    final key = typed.isNotEmpty ? typed : AiStore.keyOf(_p);
    if (key.isEmpty) {
      setState(() {
        _msg = tr('Paste a key first.');
        _msgOk = false;
      });
      return;
    }
    setState(() {
      _busy = true;
      _msg = '';
    });
    final r = await Ai.testKey(_p, key, _model.text.trim(), openaiBase: AiStore.openaiBase);
    if (!mounted) return;
    if (r.ok) {
      if (typed.isNotEmpty) {
        await AiStore.setKey(_p, typed);
        _key.clear();
      }
      if (AiStore.modelOf(_p).isEmpty && r.text.isNotEmpty) {
        AiStore.models[_p.name] = r.text;
        _model.text = r.text;
        await AiStore.save();
      }
    }
    setState(() {
      _busy = false;
      _msgOk = r.ok;
      _msg = r.ok
          ? tr('It works. Model in use: {m}').replaceAll('{m}', r.text)
          : r.offline
              ? tr('No internet right now. The app works fully without it; try again when you are online.')
              : (r.error ?? tr('The AI request failed.'));
    });
  }

  Future<void> _pickModel() async {
    await _saveBase();
    final key = _key.text.trim().isNotEmpty ? _key.text.trim() : AiStore.keyOf(_p);
    if (key.isEmpty) {
      setState(() {
        _msg = tr('Paste a key first.');
        _msgOk = false;
      });
      return;
    }
    setState(() {
      _busy = true;
      _msg = '';
    });
    final r = await Ai.fetchModels(_p, key, openaiBase: AiStore.openaiBase);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.error != null || r.models.isEmpty) {
      setState(() {
        _msgOk = false;
        _msg = r.error ?? tr('No models found.');
      });
      return;
    }
    final auto = AiProviders.pickDefault(_p, r.models);
    final chosen = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.7,
          builder: (ctx, sc) => ListView(controller: sc, children: [
            ListTile(title: Text('Choose a model', style: const TextStyle(fontWeight: FontWeight.w700))),
            ListTile(
              leading: const Icon(Icons.bolt),
              title: Text('Cheap and fast (automatic)'),
              subtitle: m.Text(auto),
              onTap: () => Navigator.pop(ctx, auto),
            ),
            for (final mo in r.models)
              ListTile(
                dense: true,
                title: m.Text(mo.id),
                subtitle: mo.label != mo.id ? m.Text(mo.label) : null,
                trailing: mo.id == AiStore.modelOf(_p) ? const Icon(Icons.check) : null,
                onTap: () => Navigator.pop(ctx, mo.id),
              ),
          ]),
        ),
      ),
    );
    if (chosen != null) {
      AiStore.models[_p.name] = chosen;
      _model.text = chosen;
      await AiStore.save();
    }
  }

  Future<void> _toggleCase(bool v) async {
    if (!v) {
      AiStore.allowCase = false;
      await AiStore.save();
      return;
    }
    if (!AiStore.caseConsented) {
      await showAiCaseConsent(context);
    } else {
      AiStore.allowCase = true;
      await AiStore.save();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final hasKey = AiStore.hasKey();
    final today = AiStore.requestsToday;
    return Scaffold(
      appBar: AppBar(title: Text('AI assistant')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Card(
            margin: EdgeInsets.zero,
            color: cs.surfaceContainerHighest.withValues(alpha: 0.5),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.shield_outlined, size: 18, color: cs.primary),
                  const SizedBox(width: 8),
                  Expanded(child: Text('How your data is handled', style: const TextStyle(fontWeight: FontWeight.w700))),
                ]),
                const SizedBox(height: 6),
                Text('The app works fully without AI and without internet. AI is optional and only makes suggestions: nothing is saved without your confirmation.'),
                const SizedBox(height: 6),
                Text('You use your own key. It is stored only on this phone (Android Keystore) and is never part of backups or exports. It is sent only to the provider you choose.'),
                const SizedBox(height: 6),
                Text('Never sent: names, ids, phone numbers, addresses, hospital or doctor names, images, exact dates or whole notes. Case summaries are shown to you first.'),
                const SizedBox(height: 6),
                Text('AI answers can be wrong. Always check them against a reliable source.'),
              ]),
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Use the AI assistant', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(AiStore.master ? (hasKey ? 'On' : 'On, but no key yet') : 'Off'),
            value: AiStore.master,
            onChanged: (v) async {
              AiStore.master = v;
              await AiStore.save();
            },
          ),
          const Divider(),
          Text('Provider', style: const TextStyle(fontWeight: FontWeight.w700)),
          for (final p in AiProviderId.values)
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              onTap: () => _setProvider(p),
              leading: Icon(_p == p ? Icons.radio_button_checked : Icons.radio_button_off, color: _p == p ? cs.primary : null),
              title: m.Text(AiProviders.label(p)),
              subtitle: p == AiProviderId.gemini ? Text('Free tier available: good to start with') : null,
              trailing: AiStore.hasKey(p) ? const Icon(Icons.key, size: 18) : null,
            ),
          const SizedBox(height: 8),
          if (_p == AiProviderId.openai) ...[
            TextField(
              controller: _base,
              keyboardType: TextInputType.url,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(labelText: tr('Server address'), hintText: 'https://api.openai.com/v1', border: const OutlineInputBorder()),
              onSubmitted: (_) => _saveBase(),
            ),
            const SizedBox(height: 4),
            Text('Works with OpenAI, OpenRouter, Groq or a local server (http only on your own network).', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            const SizedBox(height: 8),
          ],
          TextField(
            controller: _key,
            obscureText: !_show,
            enableSuggestions: false,
            autocorrect: false,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: tr('API key'),
              helperText: hasKey ? tr('A key is stored on this phone. Paste a new one to replace it.') : null,
              helperMaxLines: 2,
              border: const OutlineInputBorder(),
              suffixIcon: Wrap(children: [
                IconButton(tooltip: tr('Show / hide'), icon: Icon(_show ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _show = !_show)),
                IconButton(tooltip: tr('Paste'), icon: const Icon(Icons.content_paste), onPressed: _paste),
              ]),
            ),
          ),
          const SizedBox(height: 4),
          m.Text(tr('{k}: get a key. Free keys have daily limits.').replaceAll('{k}', AiProviders.keyHelp(_p)), style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton(onPressed: _busy ? null : _saveKey, child: Text('Save key')),
            OutlinedButton.icon(
              onPressed: _busy ? null : _test,
              icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.network_check),
              label: Text('Test connection'),
            ),
            if (hasKey)
              TextButton(
                onPressed: _busy
                    ? null
                    : () async {
                        if (await confirmDialog(context, tr('Remove the key from this phone?'), action: 'Remove')) {
                          await AiStore.setKey(_p, '');
                          setState(() => _msg = '');
                        }
                      },
                child: Text('Remove key'),
              ),
          ]),
          if (_msg.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(_msgOk ? Icons.check_circle_outline : Icons.error_outline, size: 18, color: _msgOk ? Colors.green : cs.error),
                const SizedBox(width: 6),
                Expanded(child: m.Text(_msg, style: TextStyle(color: _msgOk ? null : cs.error))),
              ]),
            ),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Model'),
            subtitle: m.Text(AiStore.modelOf(_p).isEmpty ? tr('Automatic (cheap and fast)') : AiStore.modelOf(_p)),
            trailing: const Icon(Icons.chevron_right),
            onTap: _busy ? null : _pickModel,
          ),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _model,
                textDirection: TextDirection.ltr,
                autocorrect: false,
                decoration: InputDecoration(labelText: tr('Model name (advanced)'), isDense: true, border: const OutlineInputBorder()),
                onSubmitted: (v) async {
                  AiStore.models[_p.name] = v.trim();
                  await AiStore.save();
                },
              ),
            ),
          ]),
          const Divider(height: 32),
          Text('What AI may be used for', style: const TextStyle(fontWeight: FontWeight.w700)),
          for (final g in kAiGroups)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              title: Text(_kGroupInfo[g]![0]),
              subtitle: Text(_kGroupInfo[g]![1]),
              value: AiStore.features[g] != false,
              onChanged: (v) async {
                AiStore.features[g] = v;
                await AiStore.save();
              },
            ),
          const Divider(height: 32),
          Text('What may leave this phone', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('Always: your question text (with identifiers removed).', style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Passages of my installed library'),
            subtitle: Text('Public licensed text that helps the answer.'),
            value: AiStore.allowLibrary,
            onChanged: (v) async {
              AiStore.allowLibrary = v;
              await AiStore.save();
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('De-identified case summaries'),
            subtitle: Text('Shown to you and approved before sending. Cases marked "never send" are excluded.'),
            value: AiStore.allowCase,
            onChanged: _toggleCase,
          ),
          Text('Preview before sending', style: const TextStyle(fontWeight: FontWeight.w600)),
          for (final o in const [['always', 'Before every send'], ['session', 'Once per session']])
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: Icon(AiStore.previewMode == o[0] ? Icons.radio_button_checked : Icons.radio_button_off, color: AiStore.previewMode == o[0] ? cs.primary : null),
              title: Text(o[1]),
              onTap: () async {
                AiStore.previewMode = o[0];
                await AiStore.save();
              },
            ),
          const Divider(height: 32),
          Text('Usage', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          m.Text(tr('Requests today: {n}').replaceAll('{n}', '$today')),
          if (AiStore.quotaHitToday)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('The free quota was reached today. It usually resets the next day, or use another key.', style: TextStyle(color: cs.error, fontSize: 13)),
            ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.history),
            title: Text('Activity log'),
            subtitle: Text('What was sent, when and to whom'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiActivityLogScreen())),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.delete_sweep_outlined),
            title: Text('Clear AI cache'),
            subtitle: m.Text(tr('{n} saved answers').replaceAll('{n}', '${AiCache.count}')),
            onTap: () async {
              await AiCache.clear();
              if (mounted) snack(context, tr('AI cache cleared.'));
            },
          ),
        ],
      ),
    );
  }
}

/// What was sent (never the text itself): feature, time, provider, size.
class AiActivityLogScreen extends StatefulWidget {
  const AiActivityLogScreen({super.key});

  @override
  State<AiActivityLogScreen> createState() => _AiActivityLogScreenState();
}

class _AiActivityLogScreenState extends State<AiActivityLogScreen> {
  @override
  void initState() {
    super.initState();
    AiStore.ensureLoaded().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = AiAudit.entries.reversed.toList();
    const lv = ['Question only', 'Question + library text', 'De-identified case summary'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Activity log'),
        actions: [
          IconButton(
            tooltip: tr('Clear'),
            icon: const Icon(Icons.delete_outline),
            onPressed: l.isEmpty
                ? null
                : () async {
                    if (await confirmDialog(context, tr('Clear the AI activity log?'), action: 'Clear')) {
                      await AiAudit.clear();
                      if (mounted) setState(() {});
                    }
                  },
          ),
        ],
      ),
      body: l.isEmpty
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Nothing has been sent yet.')))
          : ListView.separated(
              itemCount: l.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final e = l[i];
                final flag = e['k'] == 'flag';
                final ok = e['ok'] == true;
                final t = (e['t'] ?? '').toString().replaceFirst('T', ' ');
                final when = t.length >= 16 ? t.substring(0, 16) : t;
                final lvl = (e['lv'] is int && e['lv'] >= 0 && e['lv'] < 3) ? lv[e['lv'] as int] : lv[0];
                return ListTile(
                  dense: true,
                  leading: Icon(flag ? Icons.flag_outlined : (ok ? Icons.north_east : Icons.error_outline), color: ok || flag ? null : Theme.of(context).colorScheme.error),
                  title: m.Text(flag ? '${tr('Problem reported')}: ${e['f']}' : '${e['f']}'),
                  subtitle: m.Text(flag ? when : '$when • ${e['p'] ?? ''} ${e['m'] ?? ''}\n${tr(lvl)} • ${e['b'] ?? 0} ${tr('bytes')}${ok ? '' : ' • ${tr('failed')}'}'),
                  isThreeLine: !flag,
                );
              },
            ),
    );
  }
}
