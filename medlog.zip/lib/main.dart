import 'package:flutter/material.dart' hide Text;
import 'package:flutter_localizations/flutter_localizations.dart';

import 'data.dart';
import 'i18n.dart';
import 'motion.dart';
import 'quick_add.dart';
import 'screens_cases.dart';
import 'screens_home.dart';
import 'screens_learn.dart';
import 'screens_portfolio.dart';
import 'theme.dart';
import 'widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MedLogApp());
}

class MedLogApp extends StatefulWidget {
  const MedLogApp({super.key});

  @override
  State<MedLogApp> createState() => _MedLogAppState();
}

class _MedLogAppState extends State<MedLogApp> with WidgetsBindingObserver {
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.init().then((_) => store.applySecure());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final p = _pausedAt;
      if (p != null && DateTime.now().difference(p).inSeconds > 30) {
        store.lock();
      }
      _pausedAt = null;
    }
  }

  @override
  void didChangeLocales(List<Locale>? locales) {
    // "follow the phone" language: rebuild when the phone language changes
    if (store.lang == kLangSystem && mounted) setState(() {});
  }

  ThemeMode get _mode {
    switch (store.themeMode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final pal = paletteById(store.paletteId);
        final ar = isAr;
        return MaterialApp(
          title: 'MedLog',
          debugShowCheckedModeBanner: false,
          locale: appLocale,
          supportedLocales: const [Locale('en'), Locale('ar')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: buildTheme(pal, Brightness.light, arabic: ar),
          darkTheme: buildTheme(pal, Brightness.dark, amoled: store.amoled, arabic: ar),
          themeMode: _mode,
          themeAnimationDuration: const Duration(milliseconds: 450),
          themeAnimationCurve: Curves.easeInOut,
          // The lock screen is drawn above the Navigator, so pushed screens can
          // never cover it. The key rebuilds every screen when the language
          // changes so no string is left in the old language.
          builder: (context, child) {
            return KeyedSubtree(
              key: ValueKey(store.ready ? langCode : 'boot'),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  child ?? const SizedBox.shrink(),
                  if (store.ready && store.locked) const Positioned.fill(child: PinScreen()),
                ],
              ),
            );
          },
          home: const Root(),
        );
      },
    );
  }
}

bool _splashShown = false;

class Root extends StatefulWidget {
  const Root({super.key});

  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  bool _done = _splashShown;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        Widget body;
        if (!store.ready) {
          body = const Scaffold(key: ValueKey('boot'), body: SizedBox.expand());
        } else if (!_done) {
          body = SplashScreen(
            key: const ValueKey('splash'),
            onDone: () {
              _splashShown = true;
              if (mounted) setState(() => _done = true);
            },
          );
        } else {
          body = const Shell(key: ValueKey('shell'));
        }
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 500),
          switchInCurve: Curves.easeOut,
          child: body,
        );
      },
    );
  }
}

// ================================================================ shell + navigation

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  void _go(int v) => setState(() => _i = v);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TabStack(
        index: _i,
        children: [
          HomeScreen(onOpenTab: _go),
          const CasesScreen(),
          const LearnScreen(),
          const PortfolioScreen(),
        ],
      ),
      bottomNavigationBar: AppNavBar(
        index: _i,
        onTap: _go,
        onAdd: () => showQuickAdd(context),
      ),
    );
  }
}

/// Keeps every tab alive (filters, scroll positions) and fades the new one in.
class TabStack extends StatefulWidget {
  final int index;
  final List<Widget> children;
  const TabStack({super.key, required this.index, required this.children});

  @override
  State<TabStack> createState() => _TabStackState();
}

class _TabStackState extends State<TabStack> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 280), value: 1);

  @override
  void didUpdateWidget(TabStack old) {
    super.didUpdateWidget(old);
    if (old.index != widget.index && animOn(context)) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dir = Directionality.of(context) == TextDirection.rtl ? -1.0 : 1.0;
    return Stack(
      fit: StackFit.expand,
      children: [
        for (var i = 0; i < widget.children.length; i++)
          Offstage(
            offstage: i != widget.index,
            child: TickerMode(
              enabled: i == widget.index,
              child: AnimatedBuilder(
                animation: _c,
                child: widget.children[i],
                builder: (context, child) {
                  final v = i == widget.index ? Curves.easeOutCubic.transform(_c.value) : 1.0;
                  return Opacity(
                    opacity: v,
                    child: Transform.translate(offset: Offset((1 - v) * 18 * dir, 0), child: child),
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData selected;
  final String label;
  const _NavItem(this.icon, this.selected, this.label);
}

const List<_NavItem> _kNav = [
  _NavItem(Icons.home_outlined, Icons.home_rounded, 'Home'),
  _NavItem(Icons.folder_copy_outlined, Icons.folder_copy, 'Cases'),
  _NavItem(Icons.school_outlined, Icons.school, 'Learn'),
  _NavItem(Icons.insights_outlined, Icons.insights, 'Portfolio'),
];

/// Bottom bar with a sliding pill, bouncing icons and a raised "add case" button.
class AppNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onAdd;
  const AppNavBar({super.key, required this.index, required this.onTap, required this.onAdd});

  Widget _item(BuildContext context, int i) {
    final cs = Theme.of(context).colorScheme;
    final sel = i == index;
    final it = _kNav[i];
    final on = animOn(context);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => onTap(i),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: on ? const Duration(milliseconds: 320) : Duration.zero,
                curve: Curves.easeOutBack,
                width: sel ? 60 : 36,
                height: 32,
                decoration: BoxDecoration(
                  color: sel ? cs.primaryContainer : Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: AnimatedScale(
                  scale: sel ? 1.12 : 1.0,
                  duration: on ? const Duration(milliseconds: 320) : Duration.zero,
                  curve: Curves.easeOutBack,
                  child: Icon(
                    sel ? it.selected : it.icon,
                    size: 24,
                    color: sel ? cs.onPrimaryContainer : cs.onSurfaceVariant,
                  ),
                ),
              ),
              const SizedBox(height: 3),
              AnimatedDefaultTextStyle(
                duration: on ? const Duration(milliseconds: 250) : Duration.zero,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: sel ? FontWeight.w800 : FontWeight.w500,
                  color: sel ? cs.onSurface : cs.onSurfaceVariant,
                  fontFamily: Theme.of(context).textTheme.bodyMedium?.fontFamily,
                ),
                child: Text(it.label),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surfaceContainer,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
        side: BorderSide(color: cs.outlineVariant.withAlpha(120)),
      ),
      clipBehavior: Clip.antiAlias,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 80,
          child: Row(
            children: [
              _item(context, 0),
              _item(context, 1),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: _AddButton(onTap: onAdd),
              ),
              _item(context, 2),
              _item(context, 3),
            ],
          ),
        ),
      ),
    );
  }
}

class _AddButton extends StatefulWidget {
  final VoidCallback onTap;
  const _AddButton({required this.onTap});

  @override
  State<_AddButton> createState() => _AddButtonState();
}

class _AddButtonState extends State<_AddButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Semantics(
      button: true,
      label: tr('New case'),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _down ? 0.86 : 1.0,
          duration: const Duration(milliseconds: 140),
          curve: Curves.easeOut,
          child: AnimatedRotation(
            turns: _down ? 0.125 : 0,
            duration: const Duration(milliseconds: 180),
            child: Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: paletteGradient(context),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: cs.primary.withAlpha(80),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: const Icon(Icons.add_rounded, color: Colors.white, size: 32),
            ),
          ),
        ),
      ),
    );
  }
}
