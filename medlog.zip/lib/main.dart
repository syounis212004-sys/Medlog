import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import 'data.dart';
import 'screens_home.dart';
import 'screens_learn.dart';
import 'screens_portfolio.dart';
import 'widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MedLogApp());
}

class MedLogApp extends StatefulWidget {
  const MedLogApp({super.key});

  @override
  State<MedLogApp> createState() => _MedLogAppState();
}

class _MedLogAppState extends State<MedLogApp> with WidgetsBindingObserver {
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.init().then((_) => store.applySecure());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final p = _pausedAt;
      if (p != null && DateTime.now().difference(p).inSeconds > 30) {
        store.lock();
      }
      _pausedAt = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF00796B);
    return MaterialApp(
      title: 'MedLog',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: seed),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: seed,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      // The lock screen is drawn above the Navigator, so pushed screens can
      // never cover it.
      builder: (context, child) {
        return AnimatedBuilder(
          animation: store,
          builder: (context, _) {
            return Stack(
              fit: StackFit.expand,
              children: [
                child ?? const SizedBox.shrink(),
                if (store.ready && store.locked) const Positioned.fill(child: PinScreen()),
              ],
            );
          },
        );
      },
      home: const Root(),
    );
  }
}

class Root extends StatelessWidget {
  const Root({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.ready) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return const Shell();
      },
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _i,
        children: const [
          HomeScreen(),
          CasesScreen(),
          LearnScreen(),
          PortfolioScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          NavigationDestination(
            icon: Icon(PhosphorIconsRegular.house),
            selectedIcon: Icon(PhosphorIconsFill.house),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(PhosphorIconsRegular.folders),
            selectedIcon: Icon(PhosphorIconsFill.folders),
            label: 'Cases',
          ),
          NavigationDestination(
            icon: Icon(PhosphorIconsRegular.graduationCap),
            selectedIcon: Icon(PhosphorIconsFill.graduationCap),
            label: 'Learn',
          ),
          NavigationDestination(
            icon: Icon(PhosphorIconsRegular.chartLineUp),
            selectedIcon: Icon(PhosphorIconsFill.chartLineUp),
            label: 'Portfolio',
          ),
        ],
      ),
    );
  }
}
