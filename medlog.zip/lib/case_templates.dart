import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// The order in which a case is written, per rotation. The data (assets/data/case_templates.json) comes from published
/// clerkship forms and clinical-documentation guidance (see its `sources`); it is bundled, so no internet and no AI is needed.
///
/// Section ids understood by the case PDF engine:
/// patient, cc, hpi, ros, pmh, psh, meds, family, social, spec (rotation-specific history), exam, specx (rotation-specific
/// findings), inv, assess, mgmt, progress, outcome, learning.

/// Used when the asset is not loaded (and in tests that do not load it): the general order of a history and physical.
const List<String> kCoreSectionIds = [
  'patient', 'cc', 'hpi', 'pmh', 'psh', 'meds', 'family', 'social', 'ros', 'spec', 'exam', 'specx', 'inv', 'assess', 'mgmt', 'progress', 'outcome', 'learning',
];

/// Where a section belongs when a rotation's list does not mention it (so that a section with data is never dropped).
const List<String> kCanonicalSectionIds = [
  'patient', 'cc', 'hpi', 'ros', 'pmh', 'psh', 'meds', 'family', 'social', 'spec', 'exam', 'specx', 'inv', 'assess', 'mgmt', 'progress', 'outcome', 'learning',
];

class CaseTemplates {
  static Map<String, dynamic>? _d;

  static bool get loaded => _d != null;

  static Future<void> ensureLoaded() async {
    if (_d != null) return;
    try {
      loadFrom(await rootBundle.loadString('assets/data/case_templates.json'));
    } catch (_) {}
  }

  static void loadFrom(String json) {
    _d = jsonDecode(json) as Map<String, dynamic>;
  }

  /// The research name of a rotation of the app ("Emergency" -> "Emergency Medicine").
  static String rotationName(String appSpecialty) {
    final m = (_d?['appRotationMap'] as Map?)?.cast<String, dynamic>();
    return '${m?[appSpecialty] ?? appSpecialty}';
  }

  static Map<String, dynamic>? _rot(String appSpecialty) {
    final r = (_d?['rotations'] as Map?)?.cast<String, dynamic>();
    final x = r?[rotationName(appSpecialty)];
    return x is Map ? x.cast<String, dynamic>() : null;
  }

  /// The section ids in the order of this rotation (the general order when the rotation is unknown, e.g. "Other").
  static List<String> idsFor(String appSpecialty) {
    final r = _rot(appSpecialty);
    final ids = r == null ? null : (r['ids'] as List?)?.map((e) => '$e').toList();
    return ids == null || ids.isEmpty ? kCoreSectionIds : ids;
  }

  /// Scores and classifications the sources name for this rotation (shown only as a reminder of what to record).
  static List<String> scoresFor(String appSpecialty) => [for (final e in (_rot(appSpecialty)?['scores'] as List? ?? const [])) '$e'];

  static List<Map<String, String>> sourcesFor(String appSpecialty) => [
        for (final e in (_rot(appSpecialty)?['sources'] as List? ?? const []))
          if (e is Map) {for (final k in e.keys) '$k': '${e[k]}'}
      ];

  /// [ids] with every id of [present] that is missing put where it belongs by [kCanonicalSectionIds].
  static List<String> completeOrder(List<String> ids, Iterable<String> present) {
    final out = [...ids];
    int rank(String id) => kCanonicalSectionIds.indexOf(id);
    for (final id in present) {
      if (out.contains(id)) continue;
      var at = out.length;
      for (var i = 0; i < out.length; i++) {
        if (rank(out[i]) > rank(id)) {
          at = i;
          break;
        }
      }
      out.insert(at, id);
    }
    return out;
  }
}
