import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as mm show Text;

import 'ai/ai_api.dart';
import 'ai/ai_context.dart';
import 'ai/ai_quiz.dart';
import 'ai/ai_study_hooks.dart' show kAiWebGroup;
import 'app_icons.dart';
import 'data.dart';
import 'rotation_bar.dart';
import 'ui_kit.dart';
import 'i18n.dart';
import 'lib_user.dart';
import 'library.dart';
import 'screens_ai_study.dart' show WrittenAnswerScreen;
import 'screens_library.dart' show openArticle;
import 'ui.dart';
import 'widgets.dart';

/// "AI question bank": a separate section (never mixed with the rule-based quiz). Questions are generated
/// from library passages when AI is on and online, checked locally, saved on the phone and practised offline.

const Map<String, String> _modeLabels = {
  'all': 'All saved questions',
  'core': 'Core 250 topics',
  'course': 'One course',
  'weak': 'My weak spots',
  'topic': 'A topic',
};

const Map<String, String> _levelLabels = {'mixed': 'Mixed', 'easy': 'Easy', 'medium': 'Medium', 'hard': 'Hard'};

/// Small label that marks every AI question.
class AiBadge extends StatelessWidget {
  final String label;
  const AiBadge({super.key, this.label = 'AI-generated'});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: cs.tertiaryContainer, borderRadius: BorderRadius.circular(10)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.auto_awesome, size: 13, color: cs.onTertiaryContainer),
        const SizedBox(width: 4),
        Flexible(child: Text(label, style: TextStyle(fontSize: 12, color: cs.onTertiaryContainer, fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

// ================================================================ setup

class AiQuizScreen extends StatefulWidget {
  const AiQuizScreen({super.key});
  @override
  State<AiQuizScreen> createState() => _AiQuizScreenState();
}

class _AiQuizScreenState extends State<AiQuizScreen> {
  String _mode = 'all';
  String? _pack;
  final TextEditingController _topic = TextEditingController();
  String _level = 'mixed';
  String _style = 'any';
  int _count = 10;
  bool _busy = false;
  String? _msg;

  @override
  void initState() {
    super.initState();
    _topUp();
  }

  @override
  void dispose() {
    _topic.dispose();
    super.dispose();
  }

  Future<void> _topUp() async {
    final r = await maybeTopUp();
    if (r != null && mounted) setState(() => _msg = r.accepted > 0 ? trp('{n} new AI questions saved.', {'n': r.accepted}) : null);
  }

  AiPick get _pick => AiPick(mode: _mode, packId: _pack, query: _topic.text.trim(), level: _level, style: _style, count: _count);

  Future<void> _generate() async {
    if (_mode == 'course' && _pack == null) {
      setState(() => _msg = tr('Choose a course first.'));
      return;
    }
    if (_mode == 'topic' && _topic.text.trim().isEmpty) {
      setState(() => _msg = tr('Type a topic first.'));
      return;
    }
    setState(() {
      _busy = true;
      _msg = null;
    });
    final style = _style == 'any' ? 'vignette' : _style;
    final r = await generateMore(_mode == 'rotation' ? 'core' : _mode, packId: _pack, query: _topic.text.trim(), style: style, level: _level, count: _count, save: false);
    if (!mounted) return;
    var kept = 0;
    if (r.added.isNotEmpty) kept = await chooseGeneratedQuestions(context, r.added);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _msg = r.disabled
          ? tr('AI is off. Turn it on in Settings to generate questions.')
          : r.offline
              ? tr('You are offline: practising from your saved questions.')
              : r.capped
                  ? tr('Daily limit of AI requests reached. Try again tomorrow.')
                  : r.error != null && r.generated == 0
                      ? '${tr('Could not generate questions now. Your saved questions still work.')} (${r.error})'
                      : trp('{a} saved, {d} rejected by the checks.', {'a': kept, 'd': r.generated - r.accepted});
    });
  }

  final Set<String> _sel = {};
  bool _list = false;

  String get _rotId {
    final r = store.currentRotation();
    return r == null ? '' : '${r['id']}';
  }

  AiPick get _pickNow => _mode == 'rotation'
      ? AiPick(mode: 'rotation', packId: _rotId, level: _level, style: _style, count: _count)
      : _pick;

  Future<void> _startNow() async {
    setState(() => _busy = true);
    final p = _pickNow;
    final (qs, relaxed) = await selectFromBank(p);
    if (!mounted) return;
    setState(() => _busy = false);
    if (qs.isEmpty) {
      setState(() => _msg = tr('No saved questions match yet. Generate some when AI is on and you are online.'));
      return;
    }
    if (relaxed) snack(context, tr('Not enough saved questions for every filter: showing the closest ones.'));
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AiSessionScreen(pick: p, questions: qs)));
    if (mounted) setState(() {});
  }

  Future<void> _delete(Iterable<String> ids, String what) async {
    final n = ids.length;
    if (n == 0) return;
    final ok = await confirmDialog(context, trp('Delete {n} questions?', {'n': n}), action: 'Delete');
    if (!ok) return;
    await aiDeleteQs(ids);
    if (mounted) {
      setState(_sel.clear);
      snack(context, tr(what));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final bank = aiBank();
    final seen = bank.fold<int>(0, (n, q) => n + q.seen);
    final right = bank.fold<int>(0, (n, q) => n + q.correct);
    final on = Ai.enabled;
    final packs = [for (final p in library.textPacks) if (p.kind != 'user') p];
    final rot = store.currentRotation();
    final rotQs = [for (final q in bank) if (rot != null && q.m['rot'] == rot['id']) q];
    final modes = <String, String>{
      if (rot != null) 'rotation': 'This rotation',
      ..._modeLabels,
    };
    if (!modes.containsKey(_mode)) _mode = modes.keys.first;
    final shown = _mode == 'rotation' ? rotQs : bank;
    return AiContextScope(
      ctx: const AiScreenContext(kind: 'quiz', title: 'AI question bank'),
      child: Scaffold(
        appBar: AppBar(
          title: _sel.isEmpty ? const Text('AI question bank') : mm.Text(trp('{n} selected', {'n': _sel.length})),
          actions: [
            if (_sel.isNotEmpty) ...[
              IconButton(tooltip: tr('Delete'), icon: Icon(AppIcons.delete), onPressed: () => _delete(_sel.toList(), 'Deleted.')),
              IconButton(tooltip: tr('Cancel'), icon: const Icon(Icons.close), onPressed: () => setState(_sel.clear)),
            ] else
              IconButton(tooltip: tr('Practice history'), icon: const Icon(Icons.history), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiHistoryScreen()))),
          ],
        ),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
          const RotationBar(),
          const SizedBox(height: 12),
          AppCard(
            key: const ValueKey('aiPracticeCard'),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                DropdownButtonFormField<String>(
                  key: const ValueKey('aiSource'),
                  isExpanded: true,
                  initialValue: _mode,
                  decoration: InputDecoration(labelText: tr('Questions from')),
                  items: [for (final e in modes.entries) DropdownMenuItem(value: e.key, child: mm.Text(tr(e.value)))],
                  onChanged: (v) => setState(() => _mode = v ?? 'all'),
                ),
                if (_mode == 'course') ...[
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    isExpanded: true,
                    initialValue: _pack,
                    hint: Text('Choose a course'),
                    items: [for (final p in packs) DropdownMenuItem(value: p.id, child: mm.Text(p.title, overflow: TextOverflow.ellipsis))],
                    onChanged: (v) => setState(() => _pack = v),
                  ),
                ],
                if (_mode == 'topic') ...[
                  const SizedBox(height: 8),
                  AppSearchBox(controller: _topic, hint: tr('Topic, e.g. pneumonia')),
                ],
                const SizedBox(height: 12),
                Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 12, runSpacing: 6, children: [
                  mm.Text(tr('Number of questions'), style: theme.textTheme.labelLarge),
                  SegmentedButton<int>(
                    showSelectedIcon: false,
                    style: const ButtonStyle(visualDensity: VisualDensity.compact),
                    segments: [for (final n in const [5, 10, 15]) ButtonSegment(value: n, label: mm.Text('$n'))],
                    selected: {_count},
                    onSelectionChanged: (v) => setState(() => _count = v.first),
                  ),
                ]),
                const SizedBox(height: 12),
                FilledButton.icon(key: const ValueKey('aiStart'), onPressed: _busy ? null : _startNow, icon: Icon(AppIcons.quiz), label: Text('Start practice')),
                const SizedBox(height: 6),
                Row(children: [
                  Expanded(
                    child: mm.Text(
                      '${trp('{n} saved', {'n': bank.length})}${seen > 0 ? ' · ${trp('{p}% correct so far', {'p': (right * 100 / seen).round()})}' : ''}',
                      style: theme.textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ),
                  TextButton.icon(
                    key: const ValueKey('aiGenerate'),
                    onPressed: _busy || !on ? null : _generate,
                    icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(AppIcons.ai, size: 18),
                    label: Text('Generate more'),
                  ),
                ]),
                if (!on) Text('Turn AI on in Settings to generate new questions.', style: theme.textTheme.bodySmall),
                if (_msg != null) Padding(padding: const EdgeInsets.only(top: 6), child: mm.Text(_msg!, style: TextStyle(color: cs.primary))),
              ]),
            ),
          ),
          Fold(
            id: 'ai_adv',
            title: tr('Advanced'),
            icon: AppIcons.filter,
            children: [
              mm.Text(tr('Difficulty'), style: theme.textTheme.labelLarge),
              const SizedBox(height: 4),
              SegmentedButton<String>(
                showSelectedIcon: false,
                segments: [for (final e in _levelLabels.entries) ButtonSegment(value: e.key, label: mm.Text(tr(e.value)))],
                selected: {_level},
                onSelectionChanged: (v) => setState(() => _level = v.first),
              ),
              const SizedBox(height: 10),
              mm.Text(tr('Style'), style: theme.textTheme.labelLarge),
              const SizedBox(height: 4),
              DropdownButtonFormField<String>(
                isExpanded: true,
                initialValue: _style,
                items: [
                  DropdownMenuItem(value: 'any', child: Text('Any')),
                  for (final e in kAiStyles.entries) DropdownMenuItem(value: e.key, child: mm.Text(tr(e.value))),
                ],
                onChanged: (v) => setState(() => _style = v ?? 'any'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('Add missed questions to review cards'),
                value: quizAutoCards(),
                onChanged: (v) async {
                  await setQuizAutoCards(v);
                  if (mounted) setState(() {});
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('Check each new question with a second AI pass'),
                subtitle: Text('Uses more requests; rejects questions where the check disagrees.'),
                value: aiVerifyOn(),
                onChanged: (v) async {
                  await setAiVerify(v);
                  if (mounted) setState(() {});
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('Top up the bank when low'),
                subtitle: Text('When you open this screen online and fewer than 20 questions are saved.'),
                value: aiTopUpOn(),
                onChanged: (v) async {
                  await setAiTopUp(v);
                  if (mounted) setState(() {});
                },
              ),
              Text(trp('AI requests today: {n} of {c}', {'n': aiRequestsToday(), 'c': aiDailyCap()}), style: theme.textTheme.bodySmall),
            ],
          ),
          const SizedBox(height: 4),
          Fold(
            id: 'ai_myq',
            title: tr('My questions'),
            icon: AppIcons.questions,
            subtitle: '${shown.length}',
            initiallyOpen: _list,
            children: [
              if (shown.isEmpty)
                Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('No saved questions yet. Generate some when AI is on and you are online.'))
              else ...[
                if (rotQs.isNotEmpty && _sel.isEmpty)
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: TextButton.icon(
                      key: const ValueKey('aiDeleteRot'),
                      onPressed: () => _delete([for (final q in rotQs) q.id], 'Deleted.'),
                      icon: Icon(AppIcons.delete, size: 18, color: cs.error),
                      label: mm.Text(tr('Delete all of this rotation'), style: TextStyle(color: cs.error)),
                    ),
                  ),
                for (final q in shown.take(60))
                  Dismissible(
                    key: ValueKey('aiq_${q.id}'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: AlignmentDirectional.centerEnd,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      color: cs.errorContainer,
                      child: Icon(AppIcons.delete, color: cs.onErrorContainer),
                    ),
                    onDismissed: (_) async {
                      await aiDeleteQs([q.id]);
                      if (mounted) setState(() {});
                    },
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      selected: _sel.contains(q.id),
                      leading: _sel.isEmpty ? null : Checkbox(value: _sel.contains(q.id), onChanged: (_) => setState(() => _sel.contains(q.id) ? _sel.remove(q.id) : _sel.add(q.id))),
                      title: mm.Text(q.stem, maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: mm.Text(q.shownTitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                      onLongPress: () => setState(() => _sel.add(q.id)),
                      onTap: _sel.isEmpty ? null : () => setState(() => _sel.contains(q.id) ? _sel.remove(q.id) : _sel.add(q.id)),
                    ),
                  ),
                if (shown.length > 60) Padding(padding: const EdgeInsets.only(top: 6), child: mm.Text(trp('+ {n} more', {'n': shown.length - 60}), style: theme.textTheme.bodySmall)),
                Padding(padding: const EdgeInsets.only(top: 6), child: Text('Swipe a question to delete it, or press and hold to select several.', style: theme.textTheme.bodySmall)),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Text('Questions are written by AI from library passages and checked by the app. They may still contain mistakes: every question shows its source sentence. AI never changes your records.', style: theme.textTheme.bodySmall),
        ]),
      ),
    );
  }
}


/// The questions the AI just made are NOT saved by themselves: the person looks at them and keeps the ones they want.
/// Returns how many were saved (0 when none chosen or cancelled).
Future<int> chooseGeneratedQuestions(BuildContext context, List<AiQ> qs) async {
  if (qs.isEmpty) return 0;
  final picked = await showModalBottomSheet<List<AiQ>>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => _ChooseQuestionsSheet(qs: qs),
  );
  if (picked == null || picked.isEmpty) return 0;
  for (final q in picked) {
    await aiSaveQ(q.m);
  }
  store.refresh();
  return picked.length;
}

class _ChooseQuestionsSheet extends StatefulWidget {
  final List<AiQ> qs;
  const _ChooseQuestionsSheet({required this.qs});
  @override
  State<_ChooseQuestionsSheet> createState() => _ChooseQuestionsSheetState();
}

class _ChooseQuestionsSheetState extends State<_ChooseQuestionsSheet> {
  final Set<String> _sel = {};

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final all = _sel.length == widget.qs.length;
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.85,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Row(children: [
              Expanded(child: mm.Text(tr('Choose the questions to keep'), style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
              TextButton(
                key: const ValueKey('genSelectAll'),
                onPressed: () => setState(() {
                  if (all) {
                    _sel.clear();
                  } else {
                    _sel.addAll([for (final q in widget.qs) q.id]);
                  }
                }),
                child: Text(all ? 'Clear' : 'Select all'),
              ),
            ]),
          ),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Align(alignment: AlignmentDirectional.centerStart, child: Text('Nothing is saved until you choose. Each question shows its correct answer and source.', style: theme.textTheme.bodySmall))),
          const Divider(),
          Expanded(
            child: ListView(children: [
              for (final q in widget.qs)
                CheckboxListTile(
                  key: ValueKey('gen_${q.id}'),
                  controlAffinity: ListTileControlAffinity.leading,
                  value: _sel.contains(q.id),
                  onChanged: (v) => setState(() => v == true ? _sel.add(q.id) : _sel.remove(q.id)),
                  title: mm.Text(q.stem, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: mm.Text('${tr('Answer')}: ${q.correctText}\n${q.shownTitle}', maxLines: 4, overflow: TextOverflow.ellipsis),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: Text('Discard'))),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  key: const ValueKey('genSave'),
                  onPressed: _sel.isEmpty ? null : () => Navigator.pop(context, [for (final q in widget.qs) if (_sel.contains(q.id)) q]),
                  child: mm.Text(trp('Save {n}', {'n': _sel.length})),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ================================================================ session

class AiSessionScreen extends StatefulWidget {
  final AiPick pick;
  final List<AiQ> questions;
  const AiSessionScreen({super.key, required this.pick, required this.questions});
  @override
  State<AiSessionScreen> createState() => _AiSessionScreenState();
}

class _AiSessionScreenState extends State<AiSessionScreen> {
  int _i = 0;
  int? _picked;
  bool _revealed = false; // short answer / after answering
  bool _done = false;
  final List<(AiQ, bool)> _results = [];
  String? _explain;
  bool _explaining = false;

  AiQ get _q => widget.questions[_i];

  Future<void> _answer(bool ok, {int? picked}) async {
    final q = _q;
    setState(() {
      _picked = picked ?? -1;
      _revealed = true;
      _results.add((q, ok));
    });
    await aiRecord(q, ok);
    if (!ok) {
      final made = await aiMissToCard(q);
      if (made && mounted) snack(context, tr('Added to your review cards.'));
    }
  }

  Future<void> _next() async {
    if (_i + 1 >= widget.questions.length) {
      await aiSaveSession(pick: widget.pick, results: _results);
      if (mounted) setState(() => _done = true);
    } else {
      setState(() {
        _i++;
        _picked = null;
        _revealed = false;
        _explain = null;
      });
    }
  }

  Future<void> _flag() async {
    await aiFlag(_q);
    if (mounted) snack(context, tr('Flagged: this question will not be asked again.'));
  }

  Future<void> _card() async {
    final q = _q;
    final ok = await addLibraryCard(front: q.cardFront, back: q.cardBack, source: q.title, packId: q.packId, title: q.title);
    if (mounted) snack(context, ok ? tr('Added to your review cards.') : tr('Already in your review cards.'));
  }

  Future<void> _explainIt() async {
    setState(() => _explaining = true);
    final q = _q;
    final picked = _picked != null && _picked! >= 0 && _picked! < q.options.length ? q.options[_picked!] : tr('(did not know)');
    final r = await explainMistake(q, picked);
    if (!mounted) return;
    setState(() {
      _explaining = false;
      _explain = r.ok && r.text.trim().isNotEmpty ? r.text.trim() : tr('No explanation available now (offline or AI off). The source sentence above is the reference.');
    });
  }

  @override
  Widget build(BuildContext context) {
    return AiContextScope(ctx: const AiScreenContext(kind: 'quiz', title: 'AI practice'), child: _body(context));
  }

  Widget _body(BuildContext context) {
    if (_done) return _results_(context);
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final q = _q;
    final ok = _results.isNotEmpty && _revealed && _results.last.$1 == q ? _results.last.$2 : false;
    return Scaffold(
      appBar: AppBar(title: Text(trp('Question {i} of {n}', {'i': _i + 1, 'n': widget.questions.length}))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        LinearProgressIndicator(value: (_i + (_revealed ? 1 : 0)) / widget.questions.length),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
          AiBadge(label: q.isWeb ? kAiWebGroup : 'AI-generated'),
          mm.Text(q.shownTitle, style: theme.textTheme.bodySmall),
        ]),
        const SizedBox(height: 12),
        mm.Text(q.stem, style: theme.textTheme.titleMedium),
        const SizedBox(height: 12),
        if (q.isShort) ...[
          if (!_revealed) FilledButton(onPressed: () => setState(() => _revealed = true), child: Text('Show the answer')),
        ] else
          for (var i = 0; i < q.options.length; i++) _option(q, i, cs),
        if (_revealed) ...[
          const SizedBox(height: 12),
          if (q.isShort) _shortResult(q),
          if (!q.isShort)
            Row(children: [
              Icon(ok ? Icons.check_circle : Icons.cancel, color: ok ? Colors.green : cs.error),
              const SizedBox(width: 8),
              Expanded(child: Text(ok ? 'Correct' : 'Not quite')),
            ]),
          const SizedBox(height: 8),
          AppCard(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (q.isShort) mm.Text(q.answerText, style: const TextStyle(fontWeight: FontWeight.bold)),
                mm.Text(q.explanation),
                const SizedBox(height: 8),
                Text(q.isWeb ? 'Cited fact' : 'Source sentence', style: theme.textTheme.labelLarge),
                mm.Text('“${q.quote}”', style: const TextStyle(fontStyle: FontStyle.italic)),
                mm.Text('${q.shownTitle}${q.section.isEmpty ? '' : ' · ${q.section}'}', style: theme.textTheme.bodySmall),
                if (q.isWeb && q.citeUrl.isNotEmpty) mm.Text(q.citeUrl, style: theme.textTheme.bodySmall?.copyWith(color: cs.primary), textDirection: TextDirection.ltr),
              ]),
            ),
          ),
          Wrap(spacing: 8, runSpacing: 4, children: [
            if (q.packId.isNotEmpty) TextButton.icon(onPressed: () => openArticle(context, q.packId, q.index), icon: const Icon(Icons.article_outlined), label: Text('Open the article')),
            if (q.quote.length >= 25)
              TextButton.icon(
                key: const ValueKey('writeAnswer'),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WrittenAnswerScreen(question: q.stem, reference: '${q.quote}\n${q.explanation}\n${q.isShort ? q.answerText : q.correctText}', sourceLabel: q.shownTitle))),
                icon: const Icon(Icons.edit_note, size: 20),
                label: Text('Write my answer (AI grades)'),
              ),
            TextButton.icon(onPressed: _card, icon: const Icon(Icons.style_outlined), label: Text('Add to review cards')),
            TextButton.icon(onPressed: _flag, icon: const Icon(Icons.flag_outlined), label: Text('Flag as wrong')),
            if (!ok && Ai.enabled)
              TextButton.icon(onPressed: _explaining ? null : _explainIt, icon: const Icon(Icons.auto_awesome, size: 18), label: Text('Explain my mistake')),
          ]),
          if (_explaining) const LinearProgressIndicator(),
          if (_explain != null)
            AppCard(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const AiBadge(), const SizedBox(height: 6), mm.Text(_explain!)]),
              ),
            ),
          const SizedBox(height: 8),
          FilledButton(onPressed: _next, child: Text(_i + 1 >= widget.questions.length ? 'Finish' : 'Next question')),
        ],
      ]),
    );
  }

  Widget _shortResult(AiQ q) {
    if (_results.isNotEmpty && _results.last.$1 == q && _picked != null) return const SizedBox.shrink();
    return Wrap(spacing: 8, children: [
      FilledButton(onPressed: () => _answer(true), child: Text('I knew it')),
      OutlinedButton(onPressed: () => _answer(false), child: Text('I missed it')),
    ]);
  }

  Widget _option(AiQ q, int i, ColorScheme cs) {
    final answered = _revealed;
    final isKey = i == q.answer;
    final isPick = _picked == i;
    Color? bg;
    if (answered && isKey) bg = Colors.green.withValues(alpha: 0.18);
    if (answered && isPick && !isKey) bg = cs.errorContainer;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Material(
        color: bg ?? cs.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: isPick ? cs.primary : cs.outlineVariant)),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: answered ? null : () => _answer(i == q.answer, picked: i),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              mm.Text(q.isTf ? '' : '${String.fromCharCode(65 + i)}.  '),
              Expanded(child: mm.Text(q.options[i])),
              if (answered && isKey) const Icon(Icons.check, color: Colors.green, size: 20),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _results_(BuildContext context) {
    final theme = Theme.of(context);
    final right = _results.where((r) => r.$2).length;
    final by = <String, List<bool>>{};
    for (final r in _results) {
      (by[r.$1.topic] ??= []).add(r.$2);
    }
    final topics = by.entries.toList()..sort((a, b) => (a.value.where((x) => x).length / a.value.length).compareTo(b.value.where((x) => x).length / b.value.length));
    final missed = [for (final r in _results) if (!r.$2) r.$1];
    return Scaffold(
      appBar: AppBar(title: const Text('Results')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const AiBadge(),
        const SizedBox(height: 8),
        mm.Text('$right / ${_results.length}', style: theme.textTheme.displaySmall),
        const SectionHeader('By topic'),
        for (final t in topics)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: mm.Text(t.key),
            trailing: mm.Text('${t.value.where((x) => x).length}/${t.value.length}'),
          ),
        if (missed.isNotEmpty) ...[
          const SectionHeader('To revise'),
          for (final q in missed)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: mm.Text(q.stem, maxLines: 3, overflow: TextOverflow.ellipsis),
              subtitle: mm.Text(q.shownTitle),
              onTap: q.packId.isEmpty ? null : () => openArticle(context, q.packId, q.index),
            ),
        ],
        const SizedBox(height: 12),
        FilledButton(onPressed: () => Navigator.pop(context), child: Text('Done')),
      ]),
    );
  }
}

// ================================================================ history

class AiHistoryScreen extends StatelessWidget {
  const AiHistoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final log = [...store.listOf(kAiLog)]..sort((a, b) => '${b['date']}'.compareTo('${a['date']}'));
    final flags = store.listOf(kAiFlags).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Practice history')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (log.isEmpty) Text('No AI practice sessions yet.'),
        for (final r in log)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.auto_awesome),
            title: mm.Text('${r['correct']} / ${r['n']}'),
            subtitle: mm.Text('${'${r['date']}'.split('T').first} · ${tr(_modeLabels['${r['mode']}'] ?? 'All')}${'${r['query']}'.isEmpty ? '' : ' · ${r['query']}'}'),
          ),
        if (flags > 0) Padding(padding: const EdgeInsets.only(top: 12), child: Text(trp('{n} questions flagged as wrong and excluded.', {'n': flags}))),
      ]),
    );
  }
}
