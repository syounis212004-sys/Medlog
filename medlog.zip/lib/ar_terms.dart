import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// Arabic words people type for common medical terms, with the English words the library is written in.
/// A short built-in list; assets/data/terms_ar_en.json ({"terms":[{"en":..,"ar":[..],"abbr":[..]}]}) adds more when present.
const Map<String, String> _builtin = {
  'سكري': 'diabetes', 'السكري': 'diabetes', 'ضغط': 'hypertension', 'الضغط': 'hypertension', 'ارتفاع الضغط': 'hypertension',
  'جلطة': 'thrombosis', 'جلطة قلبية': 'myocardial infarction', 'الجلطة القلبية': 'myocardial infarction', 'جلطة دماغية': 'stroke', 'سكتة': 'stroke',
  'فشل القلب': 'heart failure', 'قصور القلب': 'heart failure', 'ذبحة': 'angina', 'الذبحة الصدرية': 'angina',
  'ربو': 'asthma', 'الربو': 'asthma', 'التهاب رئوي': 'pneumonia', 'التهاب الرئة': 'pneumonia', 'سعال': 'cough', 'كحة': 'cough',
  'ضيق نفس': 'dyspnea', 'ضيق التنفس': 'dyspnea', 'انسداد رئوي': 'pulmonary embolism', 'جلطة رئوية': 'pulmonary embolism',
  'حمى': 'fever', 'حرارة': 'fever', 'صداع': 'headache', 'شقيقة': 'migraine', 'صرع': 'epilepsy', 'تشنج': 'seizure',
  'فشل كلوي': 'renal failure', 'الفشل الكلوي': 'renal failure', 'حصى': 'kidney stones', 'حصوات الكلى': 'kidney stones',
  'التهاب المسالك البولية': 'urinary tract infection', 'التهاب بولي': 'urinary tract infection',
  'التهاب الزائدة': 'appendicitis', 'الزائدة': 'appendicitis', 'التهاب المرارة': 'cholecystitis', 'حصى المرارة': 'gallstones',
  'التهاب البنكرياس': 'pancreatitis', 'قرحة': 'ulcer', 'قرحة المعدة': 'peptic ulcer', 'نزيف': 'bleeding', 'نزف': 'bleeding',
  'إسهال': 'diarrhea', 'اسهال': 'diarrhea', 'امساك': 'constipation', 'إمساك': 'constipation', 'قيء': 'vomiting', 'غثيان': 'nausea',
  'كسر': 'fracture', 'كسور': 'fracture', 'خلع': 'dislocation', 'التواء': 'sprain', 'التهاب المفاصل': 'arthritis', 'النقرس': 'gout',
  'هشاشة العظام': 'osteoporosis', 'ألم الظهر': 'back pain', 'الم الظهر': 'back pain', 'ألم الصدر': 'chest pain', 'الم الصدر': 'chest pain',
  'ألم البطن': 'abdominal pain', 'الم البطن': 'abdominal pain', 'فقر الدم': 'anemia', 'أنيميا': 'anemia', 'انيميا': 'anemia',
  'غدة درقية': 'thyroid', 'الغدة الدرقية': 'thyroid', 'اكتئاب': 'depression', 'قلق': 'anxiety', 'ذهان': 'psychosis',
  'حمل': 'pregnancy', 'الحمل': 'pregnancy', 'ولادة': 'labor', 'تسمم الحمل': 'preeclampsia', 'إجهاض': 'miscarriage',
  'تسمم': 'poisoning', 'إنتان': 'sepsis', 'تعفن الدم': 'sepsis', 'صدمة': 'shock', 'التهاب السحايا': 'meningitis',
  'سل': 'tuberculosis', 'السل': 'tuberculosis', 'حصبة': 'measles', 'جدري الماء': 'varicella', 'التهاب الكبد': 'hepatitis',
  'تشمع الكبد': 'cirrhosis', 'سرطان': 'cancer', 'ورم': 'tumor', 'حساسية': 'allergy', 'أكزيما': 'eczema', 'طفح': 'rash',
  'غيبوبة': 'coma', 'إغماء': 'syncope', 'اغماء': 'syncope', 'دوخة': 'dizziness', 'دوار': 'vertigo', 'خفقان': 'palpitations',
};

class ArTerms {
  static Map<String, String> _extra = const {};
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final j = jsonDecode(await rootBundle.loadString('assets/data/terms_ar_en.json')) as Map;
      final m = <String, String>{};
      for (final t in (j['terms'] as List? ?? const [])) {
        if (t is! Map) continue;
        final en = '${t['en'] ?? ''}'.trim();
        if (en.isEmpty) continue;
        for (final a in (t['ar'] as List? ?? const [])) {
          m[_norm('$a')] = en;
        }
      }
      _extra = m;
    } catch (_) {}
  }

  static String _norm(String s) => s.replaceAll(RegExp(r'[ً-ْـ]'), '').replaceAll(RegExp(r'[أإآ]'), 'ا').replaceAll('ى', 'ي').replaceAll('ة', 'ه').trim().toLowerCase();

  static bool hasArabic(String s) => RegExp(r'[؀-ۿ]').hasMatch(s);

  /// The English term for an Arabic search text, or null. Whole text first, then each word.
  static String? englishFor(String q) {
    final t = _norm(q);
    if (t.isEmpty || !hasArabic(t)) return null;
    final table = {for (final e in _builtin.entries) _norm(e.key): e.value, ..._extra};
    final whole = table[t];
    if (whole != null) return whole;
    final words = t.split(RegExp(r'\s+'));
    String? one(String w) => table[w] ?? (w.startsWith('ال') ? table[w.substring(2)] : null);
    final out = <String>[];
    var i = 0;
    while (i < words.length) {
      String? found;
      var used = 1;
      for (var n = (words.length - i).clamp(1, 3); n >= 1 && found == null; n--) {
        final phrase = words.sublist(i, i + n).join(' ');
        found = table[phrase] ?? (n == 1 ? one(phrase) : null);
        if (found != null) used = n;
      }
      if (found != null && !out.contains(found)) out.add(found);
      i += used;
    }
    return out.isEmpty ? null : out.join(' ');
  }
}
