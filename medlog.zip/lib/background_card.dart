import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'dosing.dart';
import 'formulary.dart';
import 'i18n.dart';
import 'plan_item.dart' show composeDrugLine, drugSuggestions, kFreqs, kRoutes, kUnits;
import 'screens_dosing.dart' show findInteractions;
import 'ph.dart';
import 'sem.dart';
import 'case_ui.dart';

/// What the patient already has: chronic diseases, the medicines taken at home and the allergies, as chips at the top of
/// the History. The words stay in the same case fields as before ('pmh', 'drugs', 'allergies'), so the written history,
/// the PDF and every other place that reads them keep working.

const List<String> kChronicChoices = [
  'DM',
  'HTN',
  'IHD',
  'Heart failure',
  'AF',
  'Asthma',
  'COPD',
  'CKD',
  'Chronic liver disease',
  'Epilepsy',
  'Stroke',
  'Hypothyroidism',
  'Cancer',
  'Anemia',
  'Obesity',
  'HIV',
  'TB',
  'Depression',
];
const String kNoChronic = 'No significant past medical history';
const List<String> kAllergyChoices = ['Penicillin', 'Sulfa', 'NSAIDs', 'Aspirin', 'Latex', 'Contrast', 'Eggs', 'Seafood', 'Nuts'];
const String kNkda = 'NKDA';
const String kNoMeds = 'No regular medications';
const List<String> kCommonMeds = [
  'Metformin',
  'Insulin',
  'Gliclazide',
  'Amlodipine',
  'Enalapril',
  'Losartan',
  'Bisoprolol',
  'Furosemide',
  'Aspirin',
  'Clopidogrel',
  'Warfarin',
  'Apixaban',
  'Atorvastatin',
  'Omeprazole',
  'Levothyroxine',
  'Salbutamol',
  'Prednisolone',
];

/// Items of a written list: split at commas, semicolons or new lines (medicines: new lines and semicolons only).
List<String> splitItems(String text, {bool medicines = false}) {
  final re = medicines ? RegExp(r'[\n;]') : RegExp(r'[\n;,]');
  return [for (final e in text.split(re)) if (e.trim().isNotEmpty) e.trim()];
}

String joinItems(List<String> items, {bool medicines = false}) => items.join(medicines ? '\n' : ', ');

bool _isNone(String s) => const {'nkda', 'none', 'no', 'nka', 'no significant past medical history', 'no regular medications', 'nil'}.contains(s.toLowerCase());

/// Reminders that follow from the chronic diseases and medicines written for the case (plain facts, not decisions).
List<String> backgroundNotes(String pmh, String meds, String allergies) {
  final p = pmh.toLowerCase(), d = meds.toLowerCase();
  final out = <String>[];
  if (RegExp(r'\bckd\b|kidney|renal|dialysis|esrd').hasMatch(p)) out.add('Kidney disease: drug doses may need adjusting (kidney card in Drugs).');
  if (RegExp(r'cirrhosis|liver').hasMatch(p)) out.add('Liver disease: check drugs cleared by the liver.');
  if (RegExp(r'warfarin|apixaban|rivaroxaban|dabigatran|enoxaparin|heparin|clopidogrel|ticagrelor|aspirin').hasMatch(d)) out.add('Takes a blood thinner or antiplatelet: ask about bleeding and the last dose.');
  if (RegExp(r'insulin|gliclazide|glimepiride|glibenclamide').hasMatch(d) || RegExp(r'\bdm\b|diabet').hasMatch(p)) out.add('Diabetes: check glucose.');
  if (RegExp(r'prednisolone|dexamethasone|hydrocortisone|methotrexate|azathioprine|tacrolimus').hasMatch(d)) out.add('Steroid or immunosuppressant: infection and adrenal risk.');
  if (RegExp(r'\bpregnan').hasMatch(p)) out.add('Pregnancy: check each drug for pregnancy.');
  return out;
}

/// The drugs of the loaded files that the written medicine lines name.
List<FDrug> drugsNamedIn(Iterable<String> lines) {
  final out = <FDrug>[];
  for (final l in lines) {
    final t = l.toLowerCase();
    for (final d in dosing.fdrugs) {
      final names = [d.name, ...d.aka].map((e) => e.toLowerCase()).where((e) => e.length >= 4);
      if (names.any((n) => RegExp('(^|[^a-z])${RegExp.escape(n)}([^a-z]|\$)').hasMatch(t)) && !out.any((e) => e.key == d.key)) {
        out.add(d);
        break;
      }
    }
  }
  return out;
}

class BackgroundCard extends StatefulWidget {
  final CaseRec rec;

  /// Writes a field (the case editor also refreshes its text boxes) and saves.
  final void Function(String key, String value) write;

  /// Copies the background of an earlier case (null: no button).
  final Future<void> Function()? copyFrom;

  /// Names of the drugs already in the plan (for the interaction reminder).
  final List<String> planDrugs;
  const BackgroundCard({super.key, required this.rec, required this.write, this.copyFrom, this.planDrugs = const []});
  @override
  State<BackgroundCard> createState() => _BackgroundCardState();
}

class _BackgroundCardState extends State<BackgroundCard> {
  final _freePmh = TextEditingController();
  final _freeAllergy = TextEditingController();

  CaseRec get rec => widget.rec;

  @override
  void dispose() {
    _freePmh.dispose();
    _freeAllergy.dispose();
    super.dispose();
  }

  List<String> get _pmh => splitItems(rec.s('pmh'));
  List<String> get _meds => splitItems(rec.s('drugs'), medicines: true);
  List<String> get _allergies => splitItems(rec.s('allergies'));

  bool _has(List<String> l, String v) => l.any((e) => e.toLowerCase() == v.toLowerCase());

  void _toggle(String key, List<String> cur, String v, {String? none, bool medicines = false}) {
    var l = [...cur];
    if (_has(l, v)) {
      l.removeWhere((e) => e.toLowerCase() == v.toLowerCase());
    } else {
      if (none != null) l.removeWhere((e) => _isNone(e));
      if (v == none) l = [v];
      else l.add(v);
    }
    widget.write(key, joinItems(l, medicines: medicines));
    setState(() {});
  }

  void _addFree(String key, List<String> cur, TextEditingController c, {String? none}) {
    final v = c.text.trim();
    if (v.isEmpty) return;
    c.clear();
    if (!_has(cur, v)) {
      final l = [...cur];
      if (none != null) l.removeWhere((e) => _isNone(e));
      l.add(v);
      widget.write(key, joinItems(l));
    }
    setState(() {});
  }

  Future<void> _editMed([String? old]) async {
    final line = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _MedSheet(initial: old),
    );
    if (line == null) return;
    final l = [..._meds];
    l.removeWhere((e) => _isNone(e));
    if (old != null) {
      final i = l.indexOf(old);
      if (i >= 0) {
        line.isEmpty ? l.removeAt(i) : l[i] = line;
      } else if (line.isNotEmpty) {
        l.add(line);
      }
    } else if (line.isNotEmpty && !_has(l, line)) {
      l.add(line);
    }
    widget.write('drugs', joinItems(l, medicines: true));
    setState(() {});
  }

  Widget _title(IconData icon, String label, {Color? color}) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 6),
        child: Row(children: [
          Icon(icon, size: 18, color: color ?? Theme.of(context).colorScheme.primary),
          const SizedBox(width: 6),
          Expanded(child: Text(label, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: color))),
        ]),
      );

  Widget _chipSet(List<String> chosen, List<String> options, void Function(String) onTap, {String? none, Color? color, String keyPrefix = 'bg'}) {
    final all = <String>[
      if (none != null) none,
      ...options,
      for (final c in chosen) if (!options.any((o) => o.toLowerCase() == c.toLowerCase()) && c != none) c,
    ];
    return Wrap(spacing: 6, runSpacing: 4, children: [
      for (final o in all)
        FilterChip(
          key: ValueKey('${keyPrefix}_$o'),
          label: m.Text(o),
          selected: _has(chosen, o),
          selectedColor: color?.withValues(alpha: 0.25),
          visualDensity: VisualDensity.compact,
          onSelected: (_) => onTap(o),
        ),
    ]);
  }

  Widget _freeField(TextEditingController c, String label, VoidCallback onAdd, String key) => Padding(
        padding: const EdgeInsets.only(top: 8),
        child: TextField(
          key: ValueKey(key),
          controller: c,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => onAdd(),
          decoration: InputDecoration(
            isDense: true,
            labelText: tr(label),
            suffixIcon: IconButton(tooltip: tr('Add'), icon: const Icon(AppIcons.add), onPressed: onAdd),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final pmh = _pmh, meds = _meds, al = _allergies;
    final hasAllergy = al.isNotEmpty && !al.every(_isNone);
    final notes = backgroundNotes(rec.s('pmh'), rec.s('drugs'), rec.s('allergies'));
    final named = drugsNamedIn([...meds, ...widget.planDrugs]);
    final hits = named.length >= 2 ? findInteractions(named) : const [];
    final filled = pmh.isNotEmpty || meds.isNotEmpty || al.isNotEmpty;
    return Card(
      key: const ValueKey('background_card'),
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: PhExpansionTile(
        initiallyExpanded: false,
        leading: Icon(hasAllergy ? AppIcons.warn : Ph.identificationCard, color: hasAllergy ? Sem.danger : null),
        title: Text('Background', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: filled
            ? m.Text(
                [
                  if (hasAllergy) '${tr('ALLERGY')}: ${al.join(', ')}',
                  if (pmh.isNotEmpty) pmh.take(4).join(', ') + (pmh.length > 4 ? ' +${pmh.length - 4}' : ''),
                  if (meds.isNotEmpty) '${meds.length} ${tr('medicines')}',
                ].join('  •  '),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: hasAllergy ? Sem.danger : null),
              )
            : Text('Chronic diseases, medicines and allergies'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.copyFrom != null)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton.icon(
                key: const ValueKey('bg_copy'),
                onPressed: widget.copyFrom,
                icon: const Icon(Ph.copy, size: 18),
                label: Text('Copy from an earlier case of this patient'),
              ),
            ),
          _title(AppIcons.warn, 'Allergies', color: Sem.danger),
          _chipSet(al, kAllergyChoices, (v) => _toggle('allergies', al, v, none: kNkda), none: kNkda, color: Sem.danger, keyPrefix: 'al'),
          _freeField(_freeAllergy, 'Other allergy (and the reaction)', () => _addFree('allergies', al, _freeAllergy, none: kNkda), 'bg_allergy_field'),
          _title(Ph.heartbeat, 'Chronic diseases'),
          _chipSet(pmh, kChronicChoices, (v) => _toggle('pmh', pmh, v, none: kNoChronic), none: kNoChronic, keyPrefix: 'pmh'),
          _freeField(_freePmh, 'Other disease', () => _addFree('pmh', pmh, _freePmh, none: kNoChronic), 'bg_pmh_field'),
          _title(Ph.pill, 'Medicines taken at home'),
          if (meds.isEmpty) m.Text(tr('No medicines written yet.'), style: theme.textTheme.bodySmall),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (final d in meds)
              InputChip(
                key: ValueKey('med_$d'),
                label: m.Text(d, overflow: TextOverflow.ellipsis),
                visualDensity: VisualDensity.compact,
                onPressed: _isNone(d) ? null : () => _editMed(d),
                onDeleted: () {
                  widget.write('drugs', joinItems([...meds]..remove(d), medicines: true));
                  setState(() {});
                },
              ),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 4, children: [
            ActionChip(
              key: const ValueKey('bg_add_med'),
              avatar: const Icon(AppIcons.add, size: 16),
              label: Text('Add a medicine'),
              backgroundColor: theme.colorScheme.primaryContainer,
              visualDensity: VisualDensity.compact,
              onPressed: () => _editMed(),
            ),
            if (!_has(meds, kNoMeds))
              ActionChip(
                key: const ValueKey('bg_no_meds'),
                label: Text('No regular medicines'),
                visualDensity: VisualDensity.compact,
                onPressed: () {
                  widget.write('drugs', kNoMeds);
                  setState(() {});
                },
              ),
          ]),
          if (notes.isNotEmpty || hits.isNotEmpty) ...[
            const SizedBox(height: 12),
            for (final n in notes)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Ph.info, size: 16, color: theme.colorScheme.tertiary),
                  const SizedBox(width: 6),
                  Expanded(child: Text(n, style: theme.textTheme.bodySmall)),
                ]),
              ),
            for (final h in hits.take(3))
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(AppIcons.warn, size: 16, color: Sem.warning),
                  const SizedBox(width: 6),
                  Expanded(child: m.Text('${h.a} + ${h.b}: ${h.effect} (${h.severity})', style: theme.textTheme.bodySmall)),
                ]),
              ),
            Text('Reminders from what is written. They are not decisions.', style: theme.textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic)),
          ],
        ],
      ),
    );
  }
}

class _MedSheet extends StatefulWidget {
  final String? initial;
  const _MedSheet({this.initial});
  @override
  State<_MedSheet> createState() => _MedSheetState();
}

class _MedSheetState extends State<_MedSheet> {
  final _name = TextEditingController();
  final _amount = TextEditingController();
  final _days = TextEditingController();
  final Map<String, dynamic> _x = {'unit': 'mg'};
  List<String> _suggest = const [];

  @override
  void initState() {
    super.initState();
    // an existing line is shown as the name, so editing it never loses what was written
    _name.text = widget.initial ?? '';
  }

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    _days.dispose();
    super.dispose();
  }

  String _line() {
    final x = {..._x, 'amount': _amount.text.trim(), 'days': _days.text.trim()};
    final detail = composeDrugLine(x);
    final n = _name.text.trim();
    if (n.isEmpty) return '';
    return detail.isEmpty ? n : '$n $detail';
  }

  Widget _chips(String label, List<String> options, String key) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (final o in options)
              ChoiceChip(
                key: ValueKey('med_${key}_$o'),
                label: m.Text(o),
                selected: '${_x[key] ?? ''}' == o,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => setState(() => _x[key] = _x[key] == o ? '' : o),
              ),
          ]),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final typed = _name.text.trim();
    final sug = typed.isEmpty ? kCommonMeds : _suggest;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(child: Text(widget.initial == null ? 'Add a medicine' : 'Medicine', style: theme.textTheme.titleLarge)),
            if (widget.initial != null)
              IconButton(tooltip: tr('Delete'), key: const ValueKey('med_delete'), icon: const Icon(AppIcons.delete), onPressed: () => Navigator.pop(context, '')),
          ]),
          const SizedBox(height: 12),
          TextField(
            key: const ValueKey('med_name'),
            controller: _name,
            decoration: InputDecoration(labelText: tr('Medicine')),
            onChanged: (v) => setState(() => _suggest = drugSuggestions(v)),
          ),
          if (sug.isNotEmpty && !sug.contains(typed))
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Wrap(spacing: 6, runSpacing: 4, children: [
                for (final n in sug)
                  ActionChip(
                    key: ValueKey('med_sug_$n'),
                    label: m.Text(n),
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() {
                      _name.text = n;
                      _suggest = const [];
                    }),
                  ),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: TextField(
              key: const ValueKey('med_amount'),
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: tr('Dose (optional)')),
            ),
          ),
          _chips('Unit', kUnits, 'unit'),
          _chips('Route', kRoutes, 'route'),
          _chips('Frequency', kFreqs, 'freq'),
          const SizedBox(height: 16),
          FilledButton(
            key: const ValueKey('med_save'),
            onPressed: () => Navigator.pop(context, _line()),
            child: Text('Save'),
          ),
        ]),
      ),
    );
  }
}
