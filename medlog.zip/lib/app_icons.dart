import 'package:flutter/material.dart';

/// One icon for one meaning, used everywhere: the same word never gets two different pictures.
/// All are from the rounded outlined family, so they have the same weight.
class AppIcons {
  static const IconData home = Icons.home_outlined;
  static const IconData cases = Icons.folder_open_outlined;
  static const IconData library = Icons.menu_book_outlined;
  static const IconData learn = Icons.school_outlined;
  static const IconData tools = Icons.apps_outlined;
  static const IconData add = Icons.add_rounded;
  static const IconData search = Icons.search_rounded;
  static const IconData settings = Icons.settings_outlined;
  static const IconData ai = Icons.auto_awesome_outlined;
  static const IconData flashcards = Icons.style_outlined;
  static const IconData quiz = Icons.quiz_outlined;
  static const IconData questions = Icons.help_outline_rounded;
  static const IconData plan = Icons.event_note_outlined;
  static const IconData calculator = Icons.calculate_outlined;
  static const IconData doses = Icons.medication_outlined;
  static const IconData share = Icons.ios_share_outlined;
  static const IconData pdf = Icons.picture_as_pdf_outlined;
  static const IconData star = Icons.star_outline_rounded;
  static const IconData done = Icons.task_alt_outlined;
  static const IconData more = Icons.more_horiz_rounded;
  static const IconData delete = Icons.delete_outline_rounded;
  static const IconData privacy = Icons.shield_outlined;
}
