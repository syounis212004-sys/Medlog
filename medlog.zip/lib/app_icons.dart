import 'package:flutter/material.dart';
import 'package:health_icons/health_icons.dart';

import 'ph.dart';

/// One icon for one meaning, used everywhere: the same word never gets two different pictures.
/// All come from one family (Phosphor, regular weight), so they have the same stroke and the same look.
class AppIcons {
  static const IconData home = IconData(0xe2c2, fontFamily: 'PhosphorRegular');
  static const IconData homeOn = IconData(0xe2c2, fontFamily: 'PhosphorFill');
  static const IconData cases = IconData(0xe256, fontFamily: 'PhosphorRegular');
  static const IconData casesOn = IconData(0xe256, fontFamily: 'PhosphorFill');
  static const IconData library = IconData(0xe0e6, fontFamily: 'PhosphorRegular');
  static const IconData libraryOn = IconData(0xe0e6, fontFamily: 'PhosphorFill');
  static const IconData learn = IconData(0xe62c, fontFamily: 'PhosphorRegular');
  static const IconData tools = IconData(0xe464, fontFamily: 'PhosphorRegular');
  static const IconData toolsOn = IconData(0xe464, fontFamily: 'PhosphorFill');
  static const IconData add = IconData(0xe3d4, fontFamily: 'PhosphorBold');
  static const IconData search = IconData(0xe30c, fontFamily: 'PhosphorRegular');
  static const IconData settings = IconData(0xe270, fontFamily: 'PhosphorRegular');
  static const IconData ai = IconData(0xe6a2, fontFamily: 'PhosphorRegular');
  static const IconData flashcards = IconData(0xee50, fontFamily: 'PhosphorRegular');
  static const IconData quiz = IconData(0xe742, fontFamily: 'PhosphorRegular');
  static const IconData questions = IconData(0xe3e8, fontFamily: 'PhosphorRegular');
  static const IconData plan = IconData(0xe712, fontFamily: 'PhosphorRegular');
  static const IconData calculator = IconData(0xe538, fontFamily: 'PhosphorRegular');
  static const IconData doses = IconData(0xe700, fontFamily: 'PhosphorRegular');
  static const IconData share = IconData(0xeaf0, fontFamily: 'PhosphorRegular');
  static const IconData pdf = IconData(0xe702, fontFamily: 'PhosphorRegular');
  static const IconData star = IconData(0xe46a, fontFamily: 'PhosphorRegular');
  static const IconData done = IconData(0xe184, fontFamily: 'PhosphorRegular');
  static const IconData more = IconData(0xe1fe, fontFamily: 'PhosphorRegular');
  static const IconData delete = IconData(0xe4a6, fontFamily: 'PhosphorRegular');
  static const IconData privacy = IconData(0xe40c, fontFamily: 'PhosphorRegular');
  static const IconData rotation = IconData(0xe39c, fontFamily: 'PhosphorRegular');
  static const IconData filter = IconData(0xe434, fontFamily: 'PhosphorRegular');
  static const IconData image = IconData(0xe2ca, fontFamily: 'PhosphorRegular');
  static const IconData camera = IconData(0xe10e, fontFamily: 'PhosphorRegular');
  static const IconData mic = IconData(0xe326, fontFamily: 'PhosphorRegular');
  static const IconData notes = IconData(0xe34c, fontFamily: 'PhosphorRegular');
  static const IconData target = IconData(0xe47c, fontFamily: 'PhosphorRegular');
  static const IconData guideline = IconData(0xe198, fontFamily: 'PhosphorRegular');
  static const IconData flag = IconData(0xe244, fontFamily: 'PhosphorRegular');
  static const IconData calendar = IconData(0xe10a, fontFamily: 'PhosphorRegular');
  static const IconData chevronRight = IconData(0xe13a, fontFamily: 'PhosphorRegular', matchTextDirection: true);
  static const IconData arrowForward = IconData(0xe06c, fontFamily: 'PhosphorRegular', matchTextDirection: true);
  static const IconData undo = IconData(0xe038, fontFamily: 'PhosphorRegular', matchTextDirection: true);
  static const IconData send = IconData(0xe396, fontFamily: 'PhosphorRegular', matchTextDirection: true);
  static const IconData check = IconData(0xe182, fontFamily: 'PhosphorRegular');
  static const IconData info = IconData(0xe2ce, fontFamily: 'PhosphorRegular');
  static const IconData doneFill = IconData(0xe184, fontFamily: 'PhosphorFill');
  static const IconData verified = IconData(0xe606, fontFamily: 'PhosphorRegular');
  static const IconData viva = IconData(0xe75c, fontFamily: 'PhosphorRegular');
  static const IconData article = IconData(0xe0a8, fontFamily: 'PhosphorRegular');
  static const IconData warn = IconData(0xe4e0, fontFamily: 'PhosphorRegular');
  static const IconData starFill = IconData(0xe46a, fontFamily: 'PhosphorFill');
  static const IconData idea = IconData(0xe2dc, fontFamily: 'PhosphorRegular');
  static const IconData dot = IconData(0xe18a, fontFamily: 'PhosphorFill');
  static const IconData web = IconData(0xe288, fontFamily: 'PhosphorRegular');
  static const IconData help = IconData(0xe3e8, fontFamily: 'PhosphorRegular');
  static const IconData heal = IconData(0xe0b2, fontFamily: 'PhosphorRegular');
  static const IconData chat = IconData(0xe17e, fontFamily: 'PhosphorRegular');
  static const IconData hospital = IconData(0xe56e, fontFamily: 'PhosphorRegular');
  static const IconData history = IconData(0xe1a0, fontFamily: 'PhosphorRegular');
  static const IconData folders = IconData(0xe260, fontFamily: 'PhosphorRegular');
  static const IconData error = IconData(0xe4e2, fontFamily: 'PhosphorRegular');
  static const IconData refresh = IconData(0xe036, fontFamily: 'PhosphorRegular');
  static const IconData brain = IconData(0xe74e, fontFamily: 'PhosphorRegular');
  static const IconData close = IconData(0xe4f6, fontFamily: 'PhosphorRegular');
  static const IconData bolt = IconData(0xe2de, fontFamily: 'PhosphorRegular');
  static const IconData textSize = IconData(0xe6ee, fontFamily: 'PhosphorRegular');
  static const IconData science = IconData(0xe79e, fontFamily: 'PhosphorRegular');
  static const IconData lock = IconData(0xe2fa, fontFamily: 'PhosphorRegular');
  static const IconData edit = IconData(0xe3b4, fontFamily: 'PhosphorRegular');
  static const IconData download = IconData(0xe20c, fontFamily: 'PhosphorRegular');
  static const IconData compare = IconData(0xe0a0, fontFamily: 'PhosphorRegular');
  static const IconData clipboard = IconData(0xe196, fontFamily: 'PhosphorRegular');
  static const IconData eye = IconData(0xe220, fontFamily: 'PhosphorRegular');
  static const IconData upload = IconData(0xe4be, fontFamily: 'PhosphorRegular');
  static const IconData translate = IconData(0xe4a2, fontFamily: 'PhosphorRegular');
  static const IconData moreV = IconData(0xe208, fontFamily: 'PhosphorRegular');
  static const IconData read = IconData(0xe8f2, fontFamily: 'PhosphorRegular');
}

/// The picture of a specialty: the same one in the rotation grid, the filters and the summaries.
/// Organs and specialties come from Health Icons (outline, CC0 icons), the rest from Phosphor.
IconData specialtyIcon(String name) {
  final n = name.toLowerCase();
  bool has(String k) => n.contains(k);
  if (has('ortho')) return HealthIcons.orthopaedicsOutline;
  if (has('cardio')) return HealthIcons.cardiologyOutline;
  if (has('neuro')) return HealthIcons.neurologyOutline;
  if (has('psych')) return HealthIcons.mentalHealthOutline;
  if (has('pedia')) return HealthIcons.pediatricsOutline;
  if (has('ob') || has('gyn')) return HealthIcons.gynecologyOutline;
  if (has('emerg')) return HealthIcons.accidentAndEmergencyOutline;
  if (has('icu') || has('intensive')) return HealthIcons.intensiveCareUnitOutline;
  if (has('surg')) return HealthIcons.generalSurgeryOutline;
  if (has('ent') || has('ear')) return HealthIcons.earNoseThroatOutline;
  if (has('oph') || has('eye')) return HealthIcons.eyeOutline;
  if (has('derm')) return Ph.hand;
  if (has('uro')) return HealthIcons.urologyOutline;
  if (has('anes')) return HealthIcons.ventilatorOutline;
  if (has('family')) return Ph.usersThree;
  if (has('internal') || has('medicine')) return HealthIcons.stethoscopeOutline;
  if (has('dental') || has('tooth')) return HealthIcons.toothOutline;
  if (has('radio')) return HealthIcons.radiologyOutline;
  if (has('patho') || has('lab')) return HealthIcons.microscopeOutline;
  if (has('pharm')) return HealthIcons.pharmacyOutline;
  return Ph.stethoscope;
}
