import 'package:flutter/material.dart';

/// One icon for one meaning, used everywhere: the same word never gets two different pictures.
/// All come from one family (Phosphor, regular weight), so they have the same stroke and the same look.
class AppIcons {
  static const IconData home = IconData(0xe2c2, fontFamily: 'PhosphorRegular');
  static const IconData homeOn = IconData(0xe2c2, fontFamily: 'PhosphorFill');
  static const IconData cases = IconData(0xe256, fontFamily: 'PhosphorRegular');
  static const IconData casesOn = IconData(0xe256, fontFamily: 'PhosphorFill');
  static const IconData library = IconData(0xe0e6, fontFamily: 'PhosphorRegular');
  static const IconData libraryOn = IconData(0xe0e6, fontFamily: 'PhosphorFill');
  static const IconData learn = IconData(0xe62c, fontFamily: 'PhosphorRegular');
  static const IconData tools = IconData(0xe464, fontFamily: 'PhosphorRegular');
  static const IconData toolsOn = IconData(0xe464, fontFamily: 'PhosphorFill');
  static const IconData add = IconData(0xe3d4, fontFamily: 'PhosphorBold');
  static const IconData search = IconData(0xe30c, fontFamily: 'PhosphorRegular');
  static const IconData settings = IconData(0xe270, fontFamily: 'PhosphorRegular');
  static const IconData ai = IconData(0xe6a2, fontFamily: 'PhosphorRegular');
  static const IconData flashcards = IconData(0xee50, fontFamily: 'PhosphorRegular');
  static const IconData quiz = IconData(0xe742, fontFamily: 'PhosphorRegular');
  static const IconData questions = IconData(0xe3e8, fontFamily: 'PhosphorRegular');
  static const IconData plan = IconData(0xe712, fontFamily: 'PhosphorRegular');
  static const IconData calculator = IconData(0xe538, fontFamily: 'PhosphorRegular');
  static const IconData doses = IconData(0xe700, fontFamily: 'PhosphorRegular');
  static const IconData share = IconData(0xeaf0, fontFamily: 'PhosphorRegular');
  static const IconData pdf = IconData(0xe702, fontFamily: 'PhosphorRegular');
  static const IconData star = IconData(0xe46a, fontFamily: 'PhosphorRegular');
  static const IconData done = IconData(0xe184, fontFamily: 'PhosphorRegular');
  static const IconData more = IconData(0xe1fe, fontFamily: 'PhosphorRegular');
  static const IconData delete = IconData(0xe4a6, fontFamily: 'PhosphorRegular');
  static const IconData privacy = IconData(0xe40c, fontFamily: 'PhosphorRegular');
  static const IconData rotation = IconData(0xe39c, fontFamily: 'PhosphorRegular');
  static const IconData filter = IconData(0xe434, fontFamily: 'PhosphorRegular');
  static const IconData image = IconData(0xe2ca, fontFamily: 'PhosphorRegular');
  static const IconData camera = IconData(0xe10e, fontFamily: 'PhosphorRegular');
  static const IconData mic = IconData(0xe326, fontFamily: 'PhosphorRegular');
  static const IconData notes = IconData(0xe34c, fontFamily: 'PhosphorRegular');
  static const IconData target = IconData(0xe47c, fontFamily: 'PhosphorRegular');
  static const IconData guideline = IconData(0xe198, fontFamily: 'PhosphorRegular');
  static const IconData flag = IconData(0xe244, fontFamily: 'PhosphorRegular');
  static const IconData calendar = IconData(0xe10a, fontFamily: 'PhosphorRegular');
  static const IconData read = IconData(0xe8f2, fontFamily: 'PhosphorRegular');
}

/// The picture of a specialty: the same one in the rotation grid, the filters and the summaries.
IconData specialtyIcon(String name) {
  final n = name.toLowerCase();
  bool has(String k) => n.contains(k);
  if (has('ortho')) return IconData(0xe7f2, fontFamily: 'PhosphorRegular');
  if (has('cardio')) return IconData(0xe2ac, fontFamily: 'PhosphorRegular');
  if (has('neuro')) return IconData(0xe74e, fontFamily: 'PhosphorRegular');
  if (has('psych')) return IconData(0xe74e, fontFamily: 'PhosphorRegular');
  if (has('pedia')) return IconData(0xe774, fontFamily: 'PhosphorRegular');
  if (has('ob') || has('gyn')) return IconData(0xe818, fontFamily: 'PhosphorRegular');
  if (has('emerg')) return IconData(0xe9b8, fontFamily: 'PhosphorRegular');
  if (has('icu') || has('intensive')) return IconData(0xe0cc, fontFamily: 'PhosphorRegular');
  if (has('surg')) return IconData(0xeae0, fontFamily: 'PhosphorRegular');
  if (has('ent') || has('ear')) return IconData(0xe70c, fontFamily: 'PhosphorRegular');
  if (has('oph') || has('eye')) return IconData(0xe220, fontFamily: 'PhosphorRegular');
  if (has('derm')) return IconData(0xe298, fontFamily: 'PhosphorRegular');
  if (has('uro')) return IconData(0xe210, fontFamily: 'PhosphorRegular');
  if (has('anes')) return IconData(0xe968, fontFamily: 'PhosphorRegular');
  if (has('family')) return IconData(0xe2c2, fontFamily: 'PhosphorRegular');
  if (has('internal') || has('medicine')) return IconData(0xe7ea, fontFamily: 'PhosphorRegular');
  if (has('dental') || has('tooth')) return IconData(0xe9cc, fontFamily: 'PhosphorRegular');
  if (has('radio')) return IconData(0xe836, fontFamily: 'PhosphorRegular');
  if (has('patho') || has('lab')) return IconData(0xe79e, fontFamily: 'PhosphorRegular');
  if (has('pharm')) return IconData(0xe700, fontFamily: 'PhosphorRegular');
  return IconData(0xe56e, fontFamily: 'PhosphorRegular');
}
