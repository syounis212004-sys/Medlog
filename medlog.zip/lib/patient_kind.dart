import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'dose_context.dart';
import 'i18n.dart';

/// Who the dose is for. It decides the population of the regimens shown (child or adult) and, for a pregnant woman,
/// brings the pregnancy statements of the label up front. The choice is remembered, and a case sets it by itself.
enum PatientKind { child, man, woman, pregnant }

extension PatientKindX on PatientKind {
  String get label => switch (this) {
        PatientKind.child => 'Child',
        PatientKind.man => 'Man',
        PatientKind.woman => 'Woman',
        PatientKind.pregnant => 'Pregnant',
      };

  /// The population of the dosing files this kind uses.
  String get population => this == PatientKind.child ? 'pediatric' : 'adult';
}

class PatientKinds {
  static const _k = 'dosePatientKind';

  static PatientKind? saved() {
    final v = store.settings[_k];
    for (final k in PatientKind.values) {
      if (k.name == v) return k;
    }
    return null;
  }

  static Future<void> save(PatientKind? k) async {
    if (k == null) {
      store.settings.remove(_k);
    } else {
      store.settings[_k] = k.name;
    }
    await store.saveSettings();
  }

  /// From the case the screen was opened from: age group, sex and any sign of pregnancy in what was written.
  static PatientKind? fromContext(DoseContext? p) {
    if (p == null) return null;
    if (p.isChild) return PatientKind.child;
    if (!p.isAdult && p.sex.isEmpty) return null;
    if (p.female) return p.pregnant ? PatientKind.pregnant : PatientKind.woman;
    if (p.sex.toUpperCase().startsWith('M')) return PatientKind.man;
    return null;
  }

  static final RegExp _warn = RegExp(r'contraindicat|avoid|not recommended|teratogen|category\s*[dx]\b|should not be used|fetal (harm|risk)', caseSensitive: false);

  /// True when a pregnancy statement of a label warns against the drug.
  static bool warns(String pregnancyText) => _warn.hasMatch(pregnancyText);
}

/// Four small figures drawn with the same line, so they match the other icons: child, man, woman, pregnant woman.
class PatientIcon extends StatelessWidget {
  final PatientKind kind;
  final double size;
  final Color color;
  const PatientIcon(this.kind, {super.key, this.size = 30, required this.color});

  @override
  Widget build(BuildContext context) => CustomPaint(size: Size(size, size), painter: _FigurePainter(kind, color));
}

class _FigurePainter extends CustomPainter {
  final PatientKind kind;
  final Color color;
  _FigurePainter(this.kind, this.color);

  @override
  void paint(Canvas canvas, Size s) {
    final u = s.width / 24;
    final line = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.9 * u
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    Offset o(double x, double y) => Offset(x * u, y * u);
    switch (kind) {
      case PatientKind.child:
        canvas.drawCircle(o(12, 8.5), 3.6 * u, line);
        canvas.drawLine(o(12, 12.4), o(12, 18.5), line);
        canvas.drawLine(o(8, 14.5), o(16, 14.5), line);
        canvas.drawLine(o(12, 18.5), o(9.6, 22), line);
        canvas.drawLine(o(12, 18.5), o(14.4, 22), line);
      case PatientKind.man:
        canvas.drawCircle(o(12, 5), 2.8 * u, line);
        canvas.drawLine(o(12, 8.2), o(12, 15), line);
        canvas.drawLine(o(7.5, 10), o(16.5, 10), line);
        canvas.drawLine(o(12, 15), o(9, 22), line);
        canvas.drawLine(o(12, 15), o(15, 22), line);
      case PatientKind.woman:
        canvas.drawCircle(o(12, 5), 2.8 * u, line);
        final dress = Path()
          ..moveTo(12 * u, 8.2 * u)
          ..lineTo(12 * u, 9 * u)
          ..lineTo(7 * u, 17 * u)
          ..lineTo(17 * u, 17 * u)
          ..lineTo(12 * u, 9 * u);
        canvas.drawPath(dress, line);
        canvas.drawLine(o(10, 17), o(10, 22), line);
        canvas.drawLine(o(14, 17), o(14, 22), line);
      case PatientKind.pregnant:
        canvas.drawCircle(o(10.5, 5), 2.8 * u, line);
        // the back, then a round belly in front
        final body = Path()
          ..moveTo(10 * u, 8.2 * u)
          ..cubicTo(8.5 * u, 11 * u, 8.5 * u, 13 * u, 9.5 * u, 15 * u)
          ..moveTo(10.5 * u, 8.6 * u)
          ..cubicTo(15.5 * u, 8.6 * u, 19.5 * u, 11.5 * u, 17 * u, 15.5 * u)
          ..cubicTo(15.5 * u, 17.2 * u, 12.5 * u, 16.8 * u, 11 * u, 15.6 * u);
        canvas.drawPath(body, line);
        canvas.drawLine(o(10.5, 16), o(9.8, 22), line);
        canvas.drawLine(o(13.5, 16.4), o(14.2, 22), line);
    }
  }

  @override
  bool shouldRepaint(_FigurePainter old) => old.kind != kind || old.color != color;
}

/// A row of the four figures. Tapping the chosen one again clears it ("all").
class PatientKindPicker extends StatelessWidget {
  final PatientKind? value;
  final ValueChanged<PatientKind?> onChanged;
  const PatientKindPicker({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Row(children: [
      for (final k in PatientKind.values)
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Material(
              key: ValueKey('kind_${k.name}'),
              color: value == k ? cs.primaryContainer : cs.surfaceContainerLow,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => onChanged(value == k ? null : k),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(children: [
                    PatientIcon(k, size: 30, color: value == k ? cs.onPrimaryContainer : cs.primary),
                    const SizedBox(height: 4),
                    m.Text(tr(k.label), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontWeight: value == k ? FontWeight.w800 : FontWeight.w600, color: value == k ? cs.onPrimaryContainer : cs.onSurfaceVariant)),
                  ]),
                ),
              ),
            ),
          ),
        ),
    ]);
  }
}
