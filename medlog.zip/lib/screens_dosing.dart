import 'app_icons.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'calculators.dart';
import 'data.dart';
import 'dose_calc.dart';
import 'dose_context.dart';
import 'dosing.dart';
import 'drug_compare.dart';
import 'formulary.dart';
import 'i18n.dart';
import 'patient_kind.dart';
import 'ui.dart';
import 'ui_kit.dart';
import 'widgets.dart';
import 'ph.dart';
import 'sem.dart';

bool _hasArabic(String s) => RegExp(r'[\u0600-\u06FF]').hasMatch(s);

/// English medical text keeps its own direction; a string that also has Arabic words follows the app direction.
Widget _en(String s, {TextStyle? style, int? maxLines}) {
  final t = m.Text(s, style: style, maxLines: maxLines, overflow: maxLines == null ? null : TextOverflow.ellipsis);
  return _hasArabic(s) ? t : Directionality(textDirection: TextDirection.ltr, child: t);
}

bool _isFav(String key) => (store.settings['doseFav'] is List) && (store.settings['doseFav'] as List).contains(key);

Future<void> _toggleFav(String key) async {
  final l = [if (store.settings['doseFav'] is List) ...(store.settings['doseFav'] as List).map((e) => '$e')];
  l.contains(key) ? l.remove(key) : l.add(key);
  store.settings['doseFav'] = l;
  await store.saveSettings();
}

/// Doses, durations and the notes around them, from the user's own files (kept on this phone).
class DosingScreen extends StatefulWidget {
  /// The patient of the case the screen was opened from (weight, creatinine): used by the calculators.
  final DoseContext? patient;
  const DosingScreen({super.key, this.patient});
  @override
  State<DosingScreen> createState() => _DosingScreenState();
}

class _DosingScreenState extends State<DosingScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 2, vsync: this);
  final _q = TextEditingController();
  PatientKind? _kind; // who the dose is for (decides the population)
  String get _pop => _kind?.population ?? '';
  bool _starred = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    dosing.addListener(_changed);
    if (!dosing.loaded) dosing.load();
    // a case chooses by itself; otherwise the last choice is remembered
    _kind = PatientKinds.fromContext(widget.patient); // only when a case says who the patient is; otherwise the picker is inside the drug
  }

  @override
  void dispose() {
    dosing.removeListener(_changed);
    _tabs.dispose();
    _q.dispose();
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  Future<void> _import() async {
    setState(() => _busy = true);
    try {
      final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any);
      if (r == null) return;
      final added = await dosing.importFiles([for (final f in r.files) if (f.path != null) f.path!]);
      if (mounted) snack(context, trp('{n} dosing files added. They stay on this phone.', {'n': added.length}));
      for (final p in added) {
        if (!mounted) break;
        if (pendingApprovals(p.id) > 0) await confirmApproveWholeFile(context, p);
      }
    } on FormatException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (e) {
      if (mounted) snack(context, 'Import failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _manage() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
            Text('Your dosing files', style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (dosing.packs.isEmpty) Text('Nothing imported yet.'),
            for (final p in dosing.packs)
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: _en(p.title),
                subtitle: _en('${p.drugs} ${tr('drugs')} • ${p.durations} ${tr('durations')}${p.source.isEmpty ? '' : '\n${p.source}'}'),
                trailing: IconButton(
                  icon: const Icon(AppIcons.delete),
                  tooltip: tr('Remove'),
                  onPressed: () async {
                    await dosing.remove(p.id);
                    setS(() {});
                  },
                ),
              ),
            const SizedBox(height: 8),
            for (final p in dosing.packs.where((p) => dosing.fdrugs.any((d) => d.pack == p.id)))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: FilledButton.tonalIcon(
                  onPressed: () async {
                    await confirmApproveWholeFile(ctx, p);
                    setS(() {});
                  },
                  icon: const Icon(AppIcons.check),
                  label: Text(pendingApprovals(p.id) == 0 ? 'The whole file is approved' : trp('Approve the whole file ({n} regimens)', {'n': pendingApprovals(p.id)})),
                ),
              ),
            OutlinedButton.icon(onPressed: () => _formatHelp(ctx), icon: const Icon(AppIcons.info), label: Text('File format')),
          ]),
        ),
      ),
    );
  }

  void _formatHelp(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Dosing file format'),
        content: SingleChildScrollView(
          child: Text('A JSON file with schemaVersion 1, meta (id, title, source), drugs (name, aka, class, routes, regimens with indication, population, route, dose, frequency, duration, max, notes, page; renal, hepatic, pregnancy, cautions, contraindications, interactions, monitoring, adverse, pearls) and durations (condition, regimen, duration, notes, page). Several files or a ZIP can be imported. The files stay on this phone.'),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final empty = dosing.loaded && dosing.packs.isEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text('Doses & durations'),
        actions: [
          IconButton(icon: const Icon(Ph.fileArrowUp), tooltip: tr('Import a dosing file'), onPressed: _busy ? null : _import),
          IconButton(icon: const Icon(Ph.folderOpen), tooltip: tr('Your dosing files'), onPressed: _manage),
        ],
        bottom: TabBar(controller: _tabs, tabs: [Tab(text: tr('Drugs')), Tab(text: tr('Durations'))]),
      ),
      body: !dosing.loaded
          ? const Center(child: CircularProgressIndicator())
          : empty
              ? _emptyState(theme)
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                    child: Row(children: [
                      Icon(AppIcons.privacy, size: 18, color: theme.colorScheme.tertiary),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text('From your own files. Check every dose against your hospital protocol and the current official label before you use it.',
                            style: theme.textTheme.bodySmall),
                      ),
                    ]),
                  ),
                  if (widget.patient != null) _patientBar(theme),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: AppSearchBox(controller: _q, hint: tr('Search a drug, brand name, class or indication'), onChanged: (_) => setState(() {})),
                  ),
                  Expanded(child: TabBarView(controller: _tabs, children: [_drugList(), _durationList()])),
                ]),
    );
  }

  Widget _patientBar(ThemeData theme) {
    final p = widget.patient!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: theme.colorScheme.primaryContainer.withValues(alpha: .4), borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Icon(Ph.user, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Expanded(
            child: _en([
              '${tr('Case')} ${p.code}',
              p.weightKg == null ? tr('no weight in the case') : '${DoseCalc.fmt(p.weightKg!)} kg',
              if (p.creatinineMgDl != null) '${tr('creatinine')} ${DoseCalc.fmt(p.creatinineMgDl!)} mg/dL',
            ].join('  •  '), style: theme.textTheme.bodySmall),
          ),
        ]),
      ),
    );
  }

  Widget _emptyState(ThemeData theme) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Ph.testTube, size: 56, color: theme.colorScheme.primary),
            const SizedBox(height: 12),
            Text('Your own dose reference', style: theme.textTheme.titleLarge, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text('Import the dosing files you prepared from your books or hospital protocols. They stay on this phone and work offline.', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _busy ? null : _import, icon: const Icon(Ph.fileArrowUp), label: Text('Import a dosing file')),
            TextButton(onPressed: () => _formatHelp(context), child: Text('File format')),
          ]),
        ),
      );

  Widget _drugList() {
    var list = dosing.searchDrugs(_q.text, population: _pop);
    var flist = dosing.searchFormulary(_q.text, population: _pop);
    if (_starred) {
      list = [for (final d in list) if (_isFav(d.key)) d];
      flist = [for (final d in flist) if (_isFav(d.key)) d];
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
      if (dosing.fdrugs.length >= 2)
        AppCard(
          child: ListTile(
            key: const ValueKey('open_interactions'),
            leading: const Icon(AppIcons.warn),
            title: Text('Check interactions'),
            subtitle: Text('Pick the drugs of one patient: the interactions written in your files appear.'),
            trailing: const Icon(AppIcons.chevronRight),
            onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const InteractionCheckScreen())),
          ),
        ),
      if (dosing.fdrugs.length >= 2)
        AppCard(
          child: ListTile(
            key: const ValueKey('open_compare'),
            leading: const Icon(AppIcons.compare),
            title: Text('Compare drugs'),
            subtitle: Text('Two or three drugs side by side: indications, contraindications, pregnancy, adverse effects.'),
            trailing: const Icon(AppIcons.chevronRight),
            onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const DrugCompareScreen())),
          ),
        ),
      Align(
        alignment: AlignmentDirectional.centerStart,
        child: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: FilterChip(avatar: const Icon(AppIcons.starFill, size: 16), label: Text('Starred'), selected: _starred, visualDensity: VisualDensity.compact, onSelected: (v) => setState(() => _starred = v)),
        ),
      ),
      const SizedBox(height: 6),
      if (list.isEmpty && flist.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Nothing found.'))),
      for (final d in flist.take(300))
        AppCard(
          child: ListTile(
            leading: Icon(d.hasRegimens ? AppIcons.calculator : AppIcons.library),
            title: _en(d.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: _en([if (d.drugClass.isNotEmpty) d.drugClass, d.hasRegimens ? countLabel(d.regimens.length, 'regimen') : tr('Label text only')].join('  •  '), maxLines: 2),
            trailing: _kind == PatientKind.pregnant && PatientKinds.warns(d.pregnancy.map((x) => x.text).join(' ')) ? Icon(AppIcons.warn, color: Theme.of(context).colorScheme.error, size: 22) : (_isFav(d.key) ? const Icon(AppIcons.starFill, color: Sem.star, size: 20) : const Icon(AppIcons.chevronRight)),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FDrugScreen(drug: d, patient: widget.patient, kind: _kind))).then((_) => setState(() {})),
          ),
        ),
      for (final d in list.take(300))
        AppCard(
          child: ListTile(
            title: _en(d.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: _en([if (d.drugClass.isNotEmpty) d.drugClass, if (d.routes.isNotEmpty) d.routes.join(' / '), countLabel(d.regimens.length, 'regimen')].join('  •  '), maxLines: 2),
            trailing: _kind == PatientKind.pregnant && PatientKinds.warns(d.pregnancy) ? Icon(AppIcons.warn, color: Theme.of(context).colorScheme.error, size: 22) : (_isFav(d.key) ? const Icon(AppIcons.starFill, color: Sem.star, size: 20) : const Icon(AppIcons.chevronRight)),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DrugDetailScreen(drug: d))).then((_) => setState(() {})),
          ),
        ),
      if (list.length > 300) Padding(padding: const EdgeInsets.all(8), child: Text('Showing the first 300. Type more to narrow it down.')),
    ]);
  }

  Widget _durationList() {
    final list = dosing.searchDurations(_q.text);
    if (dosing.durations.isEmpty) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('The imported files have no duration tables.', textAlign: TextAlign.center)));
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      if (list.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Nothing found.'))),
      for (final d in list.take(300))
        AppCard(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _en(d.condition, style: const TextStyle(fontWeight: FontWeight.w700)),
              if (d.regimen.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en(d.regimen)),
              if (d.duration.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: _en(d.duration, style: TextStyle(fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                ),
              if (d.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en(d.notes, style: Theme.of(context).textTheme.bodySmall)),
              if (d.page.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en('${tr('Source page')}: ${d.page}', style: Theme.of(context).textTheme.bodySmall)),
            ]),
          ),
        ),
    ]);
  }
}

class DrugDetailScreen extends StatefulWidget {
  final DrugEntry drug;
  const DrugDetailScreen({super.key, required this.drug});
  @override
  State<DrugDetailScreen> createState() => _DrugDetailScreenState();
}

class _DrugDetailScreenState extends State<DrugDetailScreen> {
  DrugEntry get d => widget.drug;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    String packTitle() {
      for (final p in dosing.packs) {
        if (p.id == d.pack) return p.title;
      }
      return d.pack;
    }

    return Scaffold(
      appBar: AppBar(
        title: _en(d.name),
        actions: [
          IconButton(tooltip: tr('Favourite'), 
            icon: Icon(_isFav(d.key) ? AppIcons.starFill : AppIcons.star, color: _isFav(d.key) ? Sem.star : null),
            onPressed: () async {
              await _toggleFav(d.key);
              if (mounted) setState(() {});
            },
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        if (d.aka.isNotEmpty) _en(d.aka.join(', '), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        Wrap(spacing: 6, runSpacing: 4, children: [
          if (d.drugClass.isNotEmpty) Chip(label: _en(d.drugClass), visualDensity: VisualDensity.compact),
          for (final r in d.routes) Chip(label: _en(r), visualDensity: VisualDensity.compact),
        ]),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: theme.colorScheme.tertiaryContainer.withValues(alpha: .4), borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Icon(AppIcons.privacy, size: 18, color: theme.colorScheme.tertiary),
            const SizedBox(width: 8),
            Expanded(
              child: Text('From your file. Check this dose against your hospital protocol and the current official label before you use it.',
                  style: theme.textTheme.bodySmall),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        if (d.regimens.isEmpty) Text('No regimens in the file.'),
        for (final r in d.regimens) _regimen(r, theme),
        if (d.renal.isNotEmpty && d.renal == d.hepatic) _block('Renal and hepatic', d.renal) else ...[_block('Renal', d.renal), _block('Hepatic', d.hepatic)],
        _block('Pregnancy and breastfeeding', d.pregnancy),
        _list('Contraindications', d.contraindications),
        _list('Cautions', d.cautions),
        _list('Interactions', d.interactions),
        _list('Monitoring', d.monitoring),
        _list('Adverse effects', d.adverse),
        _list('Pearls', d.pearls),
        const SizedBox(height: 12),
        _en('${tr('Source')}: ${packTitle()}${d.page.isEmpty ? '' : ' • ${tr('page')} ${d.page}'}', style: theme.textTheme.bodySmall),
      ]),
    );
  }

  Widget _row(String label, String v, {bool strong = false}) {
    if (v.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 92, child: Text(label, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant))),
        Expanded(child: _en(v, style: strong ? const TextStyle(fontWeight: FontWeight.w800, fontSize: 15) : null)),
      ]),
    );
  }

  Widget _regimen(DoseRegimen r, ThemeData theme) => AppCard(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: _en(r.indication.isEmpty ? '—' : r.indication, style: const TextStyle(fontWeight: FontWeight.w700))),
              if (r.population.isNotEmpty) Chip(label: _en(r.population), visualDensity: VisualDensity.compact),
            ]),
            _row('Route', r.route),
            _row('Dose', r.dose, strong: true),
            _row('Frequency', r.frequency, strong: true),
            _row('Duration', r.duration, strong: true),
            _row('Maximum', r.max),
            _row('Notes', r.notes),
            if (r.verify)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Row(children: [
                  Icon(AppIcons.warn, size: 16, color: theme.colorScheme.error),
                  const SizedBox(width: 6),
                  Expanded(child: Text('Unclear in the source: check the original.', style: TextStyle(color: theme.colorScheme.error, fontSize: 12))),
                ]),
              ),
            if (r.page.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: _en('${tr('Source page')}: ${r.page}', style: theme.textTheme.bodySmall)),
          ]),
        ),
      );

  Widget _block(String title, String text) {
    if (text.isEmpty) return const SizedBox.shrink();
    return AppCard(child: ExpansionTile(title: Text(title), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12), expandedCrossAxisAlignment: CrossAxisAlignment.start, children: [_en(text)]));
  }

  Widget _list(String title, List<String> items) {
    if (items.isEmpty) return const SizedBox.shrink();
    return AppCard(
      child: ExpansionTile(
        title: Text(title),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [for (final i in items) Padding(padding: const EdgeInsets.only(bottom: 4), child: _en('• $i'))],
      ),
    );
  }
}


// ============================================================ source-bound drug reference + calculator

String _approvalKey(FDrug d, FRegimen r) => '${d.pack}|${r.id}';

/// The stored approval of a regimen: {'on': date, 'h': fingerprint of the numbers}. A plain date (older versions) has no
/// fingerprint and so never counts for the current numbers.
Map? _approvalOf(FDrug d, FRegimen r) {
  final m = store.settings['formApprove'];
  if (m is! Map) return null;
  final v = m[_approvalKey(d, r)];
  if (v == null) return null;
  return v is Map ? v : {'on': '$v', 'h': ''};
}

DoseStatus doseStatus(FDrug d, FRegimen r) {
  if (r.fileApproved) return DoseStatus.verified;
  final a = _approvalOf(d, r);
  if (a == null) return DoseStatus.underReview;
  return a['h'] == doseFingerprint(d, r) ? DoseStatus.verified : DoseStatus.invalid;
}

Future<void> _setApproval(FDrug d, FRegimen r, bool on) async {
  final m = <String, dynamic>{if (store.settings['formApprove'] is Map) ...Map<String, dynamic>.from(store.settings['formApprove'] as Map)};
  if (on) {
    m[_approvalKey(d, r)] = {'on': DateTime.now().toIso8601String().substring(0, 10), 'h': doseFingerprint(d, r)};
  } else {
    m.remove(_approvalKey(d, r));
  }
  store.settings['formApprove'] = m;
  await store.saveSettings();
}

/// How many regimens of an imported file still wait for the person's approval.
int pendingApprovals(String packId) {
  var n = 0;
  for (final d in dosing.fdrugs.where((d) => d.pack == packId)) {
    for (final r in d.regimens) {
      if (doseStatus(d, r) != DoseStatus.verified) n++;
    }
  }
  return n;
}

/// Approves every regimen of one file at once (one write). Each approval is still tied to the numbers it was given for,
/// so a re-imported file with changed numbers asks again.
Future<int> approveWholeFile(String packId) async {
  final m = <String, dynamic>{if (store.settings['formApprove'] is Map) ...Map<String, dynamic>.from(store.settings['formApprove'] as Map)};
  final on = DateTime.now().toIso8601String().substring(0, 10);
  var n = 0;
  for (final d in dosing.fdrugs.where((d) => d.pack == packId)) {
    for (final r in d.regimens) {
      if (doseStatus(d, r) == DoseStatus.verified) continue;
      m[_approvalKey(d, r)] = {'on': on, 'h': doseFingerprint(d, r)};
      n++;
    }
  }
  store.settings['formApprove'] = m;
  await store.saveSettings();
  store.refresh();
  return n;
}

Future<void> confirmApproveWholeFile(BuildContext context, DosePack p) async {
  var sure = false;
  final todo = pendingApprovals(p.id);
  if (todo == 0) {
    snack(context, tr('Every regimen of this file is already approved.'));
    return;
  }
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text('Approve the whole file'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          m.Text(trp('{n} regimens will be approved for calculation, in {d} drugs.', {'n': todo, 'd': dosing.fdrugs.where((d) => d.pack == p.id).length})),
          const SizedBox(height: 8),
          Text('The approval stays on this phone. If a new version of the file changes a number, that regimen asks again. You can remove approvals one by one inside each drug.', style: const TextStyle(fontSize: 13)),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: sure,
            onChanged: (v) => setS(() => sure = v == true),
            title: Text('I accept this file as my reference and I check every dose against the source and my hospital protocol.'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
          FilledButton(onPressed: sure ? () => Navigator.pop(ctx, true) : null, child: Text('Approve')),
        ],
      ),
    ),
  );
  if (ok == true) {
    final n = await approveWholeFile(p.id);
    if (context.mounted) snack(context, trp('{n} regimens approved.', {'n': n}));
  }
}

class FDrugScreen extends StatefulWidget {
  /// Who the dose is for (child, man, woman, pregnant): the regimens of that group come first.
  final PatientKind? kind;
  final FDrug drug;
  final DoseContext? patient;
  const FDrugScreen({super.key, required this.drug, this.patient, this.kind});
  @override
  State<FDrugScreen> createState() => _FDrugScreenState();
}

class _FDrugScreenState extends State<FDrugScreen> {
  FDrug get d => widget.drug;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final srcs = [for (final id in d.sourceIds) if (dosing.fsources[id] != null) dosing.fsources[id]!];
    return Scaffold(
      appBar: AppBar(
        title: _en(d.name),
        actions: [
          IconButton(tooltip: tr('Favourite'), 
            icon: Icon(_isFav(d.key) ? AppIcons.starFill : AppIcons.star, color: _isFav(d.key) ? Sem.star : null),
            onPressed: () async {
              await _toggleFav(d.key);
              if (mounted) setState(() {});
            },
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        if (d.aka.isNotEmpty) _en(d.aka.join(', '), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        if (d.drugClass.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Wrap(children: [Chip(label: _en(d.drugClass), visualDensity: VisualDensity.compact)])),
        const SizedBox(height: 6),
        _banner(theme),
        const SizedBox(height: 8),
        if (d.hasRegimens) _CalcCard(drug: d, patient: widget.patient, kind: widget.kind) else AppCard(child: Padding(padding: const EdgeInsets.all(12), child: Text('No structured dose in the file for this drug: read the label dosing text below.'))),
        _KidneyCard(patient: widget.patient),
        _renalMentions(theme, open: false),
        _texts('Indications', d.indications, open: true),
        _texts('Contraindications', d.contraindications, open: true),
        _texts('Warnings and precautions', d.cautions),
        if (d.interactions.isNotEmpty)
          AppCard(
            child: ExpansionTile(
              title: Text('Interactions'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final i in d.interactions)
                  _LabelText('${i.with_.isEmpty ? '' : '${i.with_}: '}${i.effect}${i.severity.isEmpty ? '' : ' (${i.severity})'}'),
              ],
            ),
          ),
        _texts('Pregnancy', d.pregnancy),
        _texts('Breastfeeding', d.lactation),
        _texts('Adverse reactions', d.adverse),
        _texts('Label dosing text', d.dosingText),
        if (d.forms.isNotEmpty)
          AppCard(
            child: ExpansionTile(
              title: Text('Products in the file'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [for (final f in d.forms) _en('• ${f.form}: ${f.label}${f.route.isEmpty ? '' : ' (${f.route})'}')],
            ),
          ),
        if (srcs.isNotEmpty)
          AppCard(
            child: ExpansionTile(
              title: Text('Sources'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final s in srcs)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _en(s.shortName, style: const TextStyle(fontWeight: FontWeight.w600)),
                      _en('${s.publisher.isEmpty ? '' : s.publisher}${s.accessed.isEmpty ? '' : ' • ${tr('accessed')} ${s.accessed}'}', style: theme.textTheme.bodySmall),
                      if (s.url.isNotEmpty) SelectableText(s.url, style: theme.textTheme.bodySmall),
                      if (s.license.isNotEmpty) _en(s.license, style: theme.textTheme.bodySmall),
                    ]),
                  ),
              ],
            ),
          ),
      ]),
    );
  }

  Widget _banner(ThemeData theme) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: theme.colorScheme.tertiaryContainer.withValues(alpha: .4), borderRadius: BorderRadius.circular(12)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(AppIcons.privacy, size: 18, color: theme.colorScheme.tertiary),
          const SizedBox(width: 8),
          Expanded(
            child: Text('Taken from official drug labels. Not clinically approved: calculate only regimens you have checked against the source and your hospital protocol.',
                style: theme.textTheme.bodySmall),
          ),
        ]),
      );

  /// Sentences of the label about the kidneys, found for the reader.
  Widget _renalMentions(ThemeData theme, {required bool open}) {
    final r = renalSentences(d);
    if (r.isEmpty) return const SizedBox.shrink();
    return AppCard(
      child: ExpansionTile(
        initiallyExpanded: open,
        title: Text('Kidney (renal) mentions in the label'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [for (final x in r) Padding(padding: const EdgeInsets.only(bottom: 6), child: _en(x))],
      ),
    );
  }

  Widget _texts(String title, List<FText> items, {bool open = false}) {
    if (items.isEmpty) return const SizedBox.shrink();
    return AppCard(
      child: ExpansionTile(
        initiallyExpanded: open,
        title: Text(title),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [for (final t in items) _LabelText(t.text)],
      ),
    );
  }
}

/// A paragraph of label text, cleaned for reading and shortened until the user asks for all of it.
class _LabelText extends StatefulWidget {
  final String text;
  const _LabelText(this.text);
  @override
  State<_LabelText> createState() => _LabelTextState();
}

class _LabelTextState extends State<_LabelText> {
  bool _all = false;
  static const _max = 900;

  @override
  Widget build(BuildContext context) {
    final t = cleanLabelText(widget.text);
    final long = t.length > _max;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _en(long && !_all ? '${t.substring(0, _max)}…' : t),
        if (long)
          TextButton(
            style: TextButton.styleFrom(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero),
            onPressed: () => setState(() => _all = !_all),
            child: Text(_all ? 'Show less' : 'Show all'),
          ),
      ]),
    );
  }
}

class _CalcCard extends StatefulWidget {
  final FDrug drug;
  final DoseContext? patient;
  final PatientKind? kind;
  const _CalcCard({required this.drug, this.patient, this.kind});
  @override
  State<_CalcCard> createState() => _CalcCardState();
}

class _CalcCardState extends State<_CalcCard> {
  final _w = TextEditingController(), _a = TextEditingController(), _h = TextEditingController();
  bool _lb = false, _years = false;
  String _regId = '';
  String _formId = '';
  PatientKind? _kind;

  FDrug get d => widget.drug;
  FRegimen get _reg => d.regimens.firstWhere((r) => r.id == _regId, orElse: () => d.regimens.first);

  @override
  void initState() {
    super.initState();
    final p = widget.patient;
    if (p != null && p.weightKg != null) _w.text = DoseCalc.fmt(p.weightKg!);
    // who the dose is for: the case first, then what was chosen last time. The regimens of that group come first.
    _kind = widget.kind ?? PatientKinds.fromContext(p) ?? PatientKinds.saved();
    _pickRegimen();
  }

  void _pickRegimen() {
    final p = widget.patient;
    final k = _kind;
    final group = k != null ? k.population : (p == null ? '' : (p.isChild ? 'pediatric' : (p.isAdult ? 'adult' : '')));
    final match = group.isEmpty ? <FRegimen>[] : [for (final r in d.regimens) if (r.group.toLowerCase().contains(group)) r];
    _regId = (match.isNotEmpty ? match.first : d.regimens.first).id;
    _formId = _formsFor(_reg).isEmpty ? '' : (_formsFor(_reg).any((f) => f.id == _reg.formId) ? _reg.formId : _formsFor(_reg).first.id);
  }

  @override
  void dispose() {
    _w.dispose();
    _a.dispose();
    _h.dispose();
    super.dispose();
  }

  List<FForm> _formsFor(FRegimen r) {
    final byComponent = [for (final f in d.forms) if (r.component.isEmpty || f.component.isEmpty || f.component == r.component) f];
    return byComponent;
  }

  double? _num(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));

  DoseStatus get _status => doseStatus(d, _reg);
  bool get _approved => _status == DoseStatus.verified;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = _reg;
    final forms = _formsFor(r);
    final w = _num(_w), a = _num(_a), h = _num(_h);
    final input = DoseInput(
      weightKg: w == null ? null : (_lb ? w * 0.45359237 : w),
      ageMonths: a == null ? null : (_years ? a * 12 : a),
      heightCm: h,
    );
    FForm? form;
    for (final f in forms) {
      if (f.id == _formId) form = f;
    }
    final res = _approved ? DoseCalc.compute(r, input, form: form) : null;
    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(AppIcons.calculator, color: theme.colorScheme.primary),
            const SizedBox(width: 8),
            Text('Dose calculator', style: theme.textTheme.titleMedium),
          ]),
          const SizedBox(height: 8),
          PatientKindPicker(
            value: _kind,
            onChanged: (k) {
              setState(() {
                _kind = k;
                _pickRegimen();
              });
              if (widget.patient == null) PatientKinds.save(k);
            },
          ),
          if (_kind == PatientKind.pregnant && d.pregnancy.isNotEmpty) _pregnancyNote(theme),
          const SizedBox(height: 8),
          _picker(tr('Regimen'), r.label, () async {
            final v = await _pick<String>(tr('Regimen'), [for (final x in d.regimens) (x.id, x.label)], _regId);
            if (v == null) return;
            setState(() {
              _regId = v;
              final fs = _formsFor(_reg);
              _formId = fs.isEmpty ? '' : (fs.any((f) => f.id == _reg.formId) ? _reg.formId : fs.first.id);
            });
          }),
          const SizedBox(height: 8),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: _numField(_w, tr('Weight'), _lb ? 'lb' : 'kg', () => setState(() => _lb = !_lb))),
            const SizedBox(width: 8),
            Expanded(child: _numField(_a, tr('Age'), _years ? tr('years') : tr('months'), () => setState(() => _years = !_years))),
          ]),
          if (r.basis == 'bsa' || (widget.patient?.creatinineMgDl != null && widget.patient!.isChild))
            Padding(padding: const EdgeInsets.only(top: 8), child: _numField(_h, tr('Height'), 'cm', null)),
          if (widget.patient != null) _kidneyBlock(theme, input),
          if (forms.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: _picker(tr('Product (for the volume)'), form == null ? '' : '${form.form}: ${form.label}', () async {
                final v = await _pick<String>(tr('Product (for the volume)'), [for (final f in forms) (f.id, '${f.form}: ${f.label}')], _formId);
                if (v != null) setState(() => _formId = v);
              }),
            ),
          const SizedBox(height: 10),
          if (!_approved) _approvalBox(theme) else _result(theme, res!),
        ]),
      ),
    );
  }

  /// A field that shows the whole chosen text (up to 3 lines) and opens a list of the options.
  Widget _picker(String label, String value, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: InputDecorator(
          decoration: InputDecoration(labelText: label, isDense: true, suffixIcon: const Icon(Ph.caretDown)),
          child: _en(value.isEmpty ? '—' : value, maxLines: 3),
        ),
      );

  Future<T?> _pick<T>(String title, List<(T, String)> options, T current) {
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
          child: ListView(shrinkWrap: true, children: [
            Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Text(title, style: Theme.of(ctx).textTheme.titleMedium)),
            for (final o in options)
              ListTile(
                title: _en(o.$2),
                trailing: o.$1 == current ? const Icon(AppIcons.check) : null,
                onTap: () => Navigator.pop(ctx, o.$1),
              ),
          ]),
        ),
      ),
    );
  }

  /// The creatinine of the case with the day it was recorded, the kidney function it gives, and the label's kidney
  /// sentences when the function is reduced.
  Widget _kidneyBlock(ThemeData theme, DoseInput input) {
    final p = widget.patient!;
    if (p.creatinineMgDl == null) return const SizedBox.shrink();
    final days = p.creatinineAgeDays;
    final old = days != null && days >= 2;
    final ageYears = input.ageMonths == null ? null : input.ageMonths! / 12;
    final cl = p.clearance(ageYears: ageYears, weight: input.weightKg, heightCm: input.heightCm);
    final low = cl != null && cl.value < 60;
    final mentions = renalSentences(d);
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: (low ? theme.colorScheme.errorContainer : theme.colorScheme.surfaceContainerHighest).withValues(alpha: .6),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _en('${tr('Creatinine')} ${DoseCalc.fmt(p.creatinineMgDl!)} mg/dL${days == null ? '' : ' — ${tr('recorded')} ${days == 0 ? tr('today') : '$days ${tr('days ago')}'}'}',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          if (old) Text('This value may have changed: check the latest result before you rely on it.', style: TextStyle(color: theme.colorScheme.error, fontSize: 12)),
          const SizedBox(height: 4),
          if (cl != null)
            _en('${tr('Kidney function')}: ≈ ${DoseCalc.fmt(cl.value.roundToDouble())} mL/min (${cl.method})', style: const TextStyle(fontWeight: FontWeight.w700))
          else
            Text(p.isChild ? 'Enter the age and the height to estimate the kidney function.' : 'Enter the age to estimate the kidney function.', style: theme.textTheme.bodySmall),
          if (low) ...[
            const SizedBox(height: 6),
            Text('Reduced kidney function: this drug may need a different dose. Read what the label says:', style: TextStyle(color: theme.colorScheme.error, fontWeight: FontWeight.w700)),
            for (final x in mentions) Padding(padding: const EdgeInsets.only(top: 4), child: _en(x, style: theme.textTheme.bodySmall)),
            if (mentions.isEmpty) Text('The label text in the file does not mention the kidneys: check another source.'),
          ] else if (mentions.isNotEmpty && cl != null)
            Text('The label has kidney-related statements: see "Kidney (renal) mentions in the label".', style: theme.textTheme.bodySmall),
        ]),
      ),
    );
  }

  Widget _numField(TextEditingController c, String label, String unit, VoidCallback? toggle) => TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          labelText: label,
          isDense: true,
          suffix: toggle == null
              ? m.Text(unit)
              : InkWell(onTap: toggle, child: Padding(padding: const EdgeInsets.all(2), child: m.Text(unit, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)))),
        ),
      );

  /// What the file says about this drug in pregnancy: a warning (red) only when the text warns, otherwise a plain note.
  Widget _pregnancyNote(ThemeData theme) {
    final text = d.pregnancy.take(2).map((x) => x.text).join(' ');
    final warn = PatientKinds.warns(text);
    final shown = text.length > 320 ? '${text.substring(0, 320)}…' : text;
    return Container(
      key: const ValueKey('pregnancy_note'),
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: (warn ? theme.colorScheme.errorContainer : theme.colorScheme.surfaceContainerHighest).withValues(alpha: 0.7), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(warn ? AppIcons.warn : AppIcons.info, size: 18, color: warn ? theme.colorScheme.error : theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text(warn ? 'Caution in pregnancy' : 'In pregnancy', style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 4),
        _en(shown, maxLines: 8),
      ]),
    );
  }

  Widget _approvalBox(ThemeData theme) {
    final stale = _status == DoseStatus.invalid;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: theme.colorScheme.errorContainer.withValues(alpha: .35), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(stale ? 'Your earlier approval does not cover the current numbers of this regimen.' : 'This regimen is not approved for calculation yet.', style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
            stale
                ? 'The numbers changed since you approved it (for example after importing a new file), or the approval was given by an older version. Check it again against the source.'
                : 'Compare its numbers with the source and your hospital protocol, then approve it here. The approval stays on this phone only.',
            style: theme.textTheme.bodySmall),
        const SizedBox(height: 6),
        Wrap(spacing: 8, children: [
          FilledButton.tonalIcon(onPressed: _review, icon: const Icon(AppIcons.guideline), label: Text('Check it against the source')),
          if (d.regimens.length > 1)
            OutlinedButton.icon(
              onPressed: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => DrugReviewScreen(drug: d)));
                if (mounted) setState(() {});
              },
              icon: const Icon(Ph.listChecks),
              label: Text('Review all regimens of this drug'),
            ),
        ]),
      ]),
    );
  }

  Future<void> _review() async {
    final r = _reg;
    var sure = false;
    String range(double? a, double? b, String u) => a == null && b == null ? '—' : (a == b || b == null ? '${DoseCalc.fmt(a ?? b!)} $u' : '${DoseCalc.fmt(a!)}–${DoseCalc.fmt(b)} $u');
    final lines = <String>[
      '${tr('Indication')}: ${r.indication.isEmpty ? '—' : r.indication}',
      '${tr('For')}: ${[r.group, if (r.ageMin != null) '${tr('age from')} ${DoseCalc.fmt(r.ageMin!)} ${tr('months')}', if (r.ageMax != null) '${tr('age under')} ${DoseCalc.fmt(r.ageMax!)} ${tr('months')}', if (r.weightMin != null) '${tr('weight from')} ${DoseCalc.fmt(r.weightMin!)} kg', if (r.weightMax != null) '${tr('weight under')} ${DoseCalc.fmt(r.weightMax!)} kg'].where((e) => e.isNotEmpty).join(', ')}',
      '${tr('Route')}: ${r.route.isEmpty ? '—' : r.route}',
      '${tr('Dose')}: ${range(r.doseMin, r.doseMax, '${r.doseUnit}${r.dosePer.isEmpty ? '' : '/${r.dosePer}'}${r.dosePerUnit.isEmpty ? '' : ' ${tr('per')} ${r.dosePerUnit == 'day' ? tr('day') : tr('dose')}'}')}',
      '${tr('Frequency')}: ${r.freqText.isEmpty ? '—' : r.freqText}',
      if (r.maxSingle != null) '${tr('Maximum single dose')}: ${DoseCalc.fmt(r.maxSingle!)} ${r.maxSingleUnit}',
      if (r.maxDaily != null) '${tr('Maximum per day')}: ${DoseCalc.fmt(r.maxDaily!)} ${r.maxDailyUnit}',
      if (r.maxDailyPerKg != null) '${tr('Maximum per kg per day')}: ${DoseCalc.fmt(r.maxDailyPerKg!)} ${r.maxDailyPerKgUnit}',
      if (r.notes.isNotEmpty) '${tr('Notes')}: ${r.notes}',
    ];
    final src = d.dosingText.isEmpty ? '' : cleanLabelText(d.dosingText.first.text);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text('Check against the source'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Flexible(
                child: SingleChildScrollView(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Numbers in the file', style: const TextStyle(fontWeight: FontWeight.w700)),
                    for (final l in lines) Padding(padding: const EdgeInsets.only(top: 2), child: _en(l)),
                    if (src.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text('Label dosing text (start)', style: const TextStyle(fontWeight: FontWeight.w700)),
                      _en(src.length > 1500 ? '${src.substring(0, 1500)}…' : src),
                    ],
                  ]),
                ),
              ),
              const Divider(),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: sure,
                onChanged: (v) => setS(() => sure = v == true),
                title: Text('I checked these numbers against the source and my hospital protocol.'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel')),
            FilledButton(onPressed: sure ? () => Navigator.pop(ctx, true) : null, child: Text('Approve')),
          ],
        ),
      ),
    );
    if (ok == true) {
      await _setApproval(d, r, true);
      if (mounted) setState(() {});
    }
  }

  String _range(double a, double b, String u) => (a - b).abs() < 1e-9 ? '${DoseCalc.fmt(a)} $u' : '${DoseCalc.fmt(a)}–${DoseCalc.fmt(b)} $u';

  Widget _result(ThemeData theme, DoseResult res) {
    final r = _reg;
    final children = <Widget>[];
    if (res.blockers.isNotEmpty) {
      for (final b in res.blockers) {
        children.add(Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(AppIcons.info, size: 16, color: theme.colorScheme.primary),
            const SizedBox(width: 6),
            Expanded(child: Text(b)),
          ]),
        ));
      }
    } else {
      final per = res.perDoseMin == null ? null : _range(res.perDoseMin!, res.perDoseMax!, res.unit);
      children.addAll([
        if (per != null) ...[
          Text('Per dose', style: theme.textTheme.bodySmall),
          _en(per, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: theme.colorScheme.primary)),
        ],
        if (res.volumeMin != null) ...[
          const SizedBox(height: 4),
          Text('Volume / amount of the product', style: theme.textTheme.bodySmall),
          _en(_range(res.volumeMin!, res.volumeMax!, res.volumeUnit), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        ],
        if (res.dailyMin != null) ...[
          const SizedBox(height: 4),
          Text('Per day', style: theme.textTheme.bodySmall),
          _en(_range(res.dailyMin!, res.dailyMax!, res.unit), style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
        if (r.freqText.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en('${tr('Frequency')}: ${r.freqText}')),
        if (r.durationText.isNotEmpty) _en('${tr('Duration')}: ${r.durationText}'),
        if (r.administration.isNotEmpty) _en('${tr('Administration')}: ${r.administration}'),
        const SizedBox(height: 4),
        _en(res.formula, style: theme.textTheme.bodySmall),
      ]);
      for (final x in res.warnings) {
        children.add(Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(AppIcons.warn, size: 16, color: theme.colorScheme.error),
            const SizedBox(width: 6),
            Expanded(child: Text(x, style: TextStyle(color: theme.colorScheme.error))),
          ]),
        ));
      }
      for (final x in res.notes) {
        children.add(Padding(padding: const EdgeInsets.only(top: 4), child: Text(x, style: theme.textTheme.bodySmall)));
      }
      if (r.notes.isNotEmpty) children.add(Padding(padding: const EdgeInsets.only(top: 6), child: _en(r.notes, style: theme.textTheme.bodySmall)));
      children.add(Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text('Renal and hepatic adjustment, allergies and interactions are not calculated: check them yourself.', style: theme.textTheme.bodySmall),
      ));
    }
    children.add(Row(children: [
      Expanded(child: _en('${tr('Source')}: ${dosing.fsources[r.source.split('#').first]?.shortName ?? r.source.split('#').first}', style: theme.textTheme.bodySmall)),
      if (!r.fileApproved)
        TextButton(
          style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
          onPressed: () async {
            await _setApproval(d, r, false);
            if (mounted) setState(() {});
          },
          child: Text('Remove my approval'),
        ),
    ]));
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: theme.colorScheme.primaryContainer.withValues(alpha: .35), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}


/// Lines that put the numbers of a regimen in front of the person who approves it.
List<String> regimenSummaryLines(FRegimen r) {
  String range(double? a, double? b, String u) => a == null && b == null ? '—' : (a == b || b == null ? '${DoseCalc.fmt(a ?? b!)} $u' : '${DoseCalc.fmt(a!)}–${DoseCalc.fmt(b)} $u');
  return [
    '${tr('For')}: ${[r.group, if (r.ageMin != null) '${tr('age from')} ${DoseCalc.fmt(r.ageMin!)} ${tr('months')}', if (r.ageMax != null) '${tr('age under')} ${DoseCalc.fmt(r.ageMax!)} ${tr('months')}', if (r.weightMin != null) '${tr('weight from')} ${DoseCalc.fmt(r.weightMin!)} kg', if (r.weightMax != null) '${tr('weight under')} ${DoseCalc.fmt(r.weightMax!)} kg'].where((e) => e.isNotEmpty).join(', ')}',
    '${tr('Route')}: ${r.route.isEmpty ? '—' : r.route}',
    '${tr('Dose')}: ${range(r.doseMin, r.doseMax, '${r.doseUnit}${r.dosePer.isEmpty ? '' : '/${r.dosePer}'}${r.dosePerUnit.isEmpty ? '' : ' ${tr('per')} ${r.dosePerUnit == 'day' ? tr('day') : tr('dose')}'}')}',
    '${tr('Frequency')}: ${r.freqText.isEmpty ? '—' : r.freqText}',
    if (r.maxSingle != null) '${tr('Maximum single dose')}: ${DoseCalc.fmt(r.maxSingle!)} ${r.maxSingleUnit}',
    if (r.maxDaily != null) '${tr('Maximum per day')}: ${DoseCalc.fmt(r.maxDaily!)} ${r.maxDailyUnit}',
    if (r.maxDailyPerKg != null) '${tr('Maximum per kg per day')}: ${DoseCalc.fmt(r.maxDailyPerKg!)} ${r.maxDailyPerKgUnit}',
  ];
}

/// All regimens of one drug on one page, each with its status. The person compares them with the source and
/// approves the whole list at once instead of one regimen at a time.
class DrugReviewScreen extends StatefulWidget {
  final FDrug drug;
  const DrugReviewScreen({super.key, required this.drug});
  @override
  State<DrugReviewScreen> createState() => _DrugReviewScreenState();
}

class _DrugReviewScreenState extends State<DrugReviewScreen> {
  FDrug get d => widget.drug;
  final Set<String> _pick = {};
  bool _sure = false;

  List<FRegimen> get _todo => [for (final r in d.regimens) if (doseStatus(d, r) != DoseStatus.verified) r];

  Future<void> _approve() async {
    for (final r in d.regimens) {
      if (_pick.contains(r.id)) await _setApproval(d, r, true);
    }
    if (mounted) {
      setState(() {
        _pick.clear();
        _sure = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final todo = _todo;
    final src = d.dosingText.isEmpty ? '' : cleanLabelText(d.dosingText.first.text);
    return Scaffold(
      appBar: AppBar(title: _en(d.name)),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        Text('Compare each regimen with the label and your hospital protocol, then approve the ones that match. The approval is tied to these numbers and stays on this phone only.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 8),
        if (src.isNotEmpty)
          AppCard(
            child: ExpansionTile(
              title: Text('Label dosing text'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              children: [_en(src.length > 4000 ? '${src.substring(0, 4000)}…' : src)],
            ),
          ),
        for (final r in d.regimens) _tile(theme, r),
        const SizedBox(height: 8),
        if (todo.isNotEmpty) ...[
          Row(children: [
            TextButton(onPressed: () => setState(() => _pick..clear()..addAll([for (final r in todo) r.id])), child: Text('Select all')),
            TextButton(onPressed: () => setState(_pick.clear), child: Text('Clear')),
          ]),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: _sure,
            onChanged: (v) => setState(() => _sure = v == true),
            title: Text('I compared the selected regimens with the source and my hospital protocol.'),
          ),
          FilledButton.icon(
            onPressed: _sure && _pick.isNotEmpty ? _approve : null,
            icon: const Icon(AppIcons.check),
            label: Text(_pick.length == todo.length ? 'Approve all' : trp('Approve {n} selected', {'n': _pick.length})),
          ),
        ] else
          Padding(padding: const EdgeInsets.only(top: 8), child: Text('All regimens of this drug are approved.', style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.w700))),
      ]),
    );
  }

  Widget _tile(ThemeData theme, FRegimen r) {
    final st = doseStatus(d, r);
    final (label, color) = switch (st) {
      DoseStatus.verified => ('Verified', Sem.success),
      DoseStatus.underReview => ('Under review', Sem.warning),
      DoseStatus.invalid => ('Changed since approval', theme.colorScheme.error),
    };
    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            if (st != DoseStatus.verified)
              Checkbox(
                value: _pick.contains(r.id),
                onChanged: (v) => setState(() => v == true ? _pick.add(r.id) : _pick.remove(r.id)),
              ),
            Expanded(child: _en(r.label, style: const TextStyle(fontWeight: FontWeight.w700))),
            Chip(label: Text(label, style: TextStyle(color: color, fontSize: 12)), visualDensity: VisualDensity.compact, side: BorderSide(color: color)),
          ]),
          for (final l in regimenSummaryLines(r)) Padding(padding: const EdgeInsets.only(top: 2), child: _en(l, style: theme.textTheme.bodySmall)),
        ]),
      ),
    );
  }
}


// ============================================================ kidney function card

/// Cockcroft-Gault clearance and CKD-EPI 2021 eGFR from the numbers the person types (or the case gives), with the stage of
/// the eGFR. It only estimates: the label text under it and the hospital protocol decide the dose.
class _KidneyCard extends StatefulWidget {
  final DoseContext? patient;
  const _KidneyCard({this.patient});
  @override
  State<_KidneyCard> createState() => _KidneyCardState();
}

class _KidneyCardState extends State<_KidneyCard> {
  final _age = TextEditingController(), _wt = TextEditingController(), _cr = TextEditingController();
  bool _female = false, _umol = false;

  @override
  void initState() {
    super.initState();
    final p = widget.patient;
    if (p != null) {
      _female = p.female;
      if (p.weightKg != null) _wt.text = DoseCalc.fmt(p.weightKg!);
      if (p.creatinineMgDl != null) _cr.text = DoseCalc.fmt(double.parse(p.creatinineMgDl!.toStringAsFixed(2)));
    } else if (PatientKinds.saved() != null) {
      _female = PatientKinds.saved() == PatientKind.woman || PatientKinds.saved() == PatientKind.pregnant;
    }
  }

  @override
  void dispose() {
    _age.dispose();
    _wt.dispose();
    _cr.dispose();
    super.dispose();
  }

  double? _n(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));

  static String stage(double egfr) => egfr >= 90 ? 'G1' : egfr >= 60 ? 'G2' : egfr >= 45 ? 'G3a' : egfr >= 30 ? 'G3b' : egfr >= 15 ? 'G4' : 'G5';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final age = _n(_age), kg = _n(_wt);
    var scr = _n(_cr);
    if (scr != null && _umol) scr = scr / 88.4;
    final ok = age != null && age >= 18 && age <= 120 && scr != null && scr > 0.1 && scr < 30;
    final cg = ok && kg != null && kg > 20 ? cockcroftGault(age.round(), kg, scr, _female) : null;
    final egfr = ok ? egfrCkdEpi2021(scr, age.round(), _female) : null;
    Widget field(String key, String label, TextEditingController c) => Expanded(
          child: TextField(key: ValueKey(key), controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: tr(label))),
        );
    return AppCard(
      child: ExpansionTile(
        key: const ValueKey('kidney_card'),
        leading: Icon(AppIcons.calculator, color: theme.colorScheme.primary),
        title: Text('Kidney function'),
        subtitle: Text('Estimate it, then read the renal text of the label below.'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        children: [
          Row(children: [field('kid_age', 'Age (years)', _age), const SizedBox(width: 8), field('kid_wt', 'Weight (kg)', _wt)]),
          const SizedBox(height: 8),
          Row(children: [
            field('kid_cr', _umol ? 'Creatinine (µmol/L)' : 'Creatinine (mg/dL)', _cr),
            const SizedBox(width: 8),
            SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: [ButtonSegment(value: false, label: m.Text('mg/dL')), ButtonSegment(value: true, label: m.Text('µmol/L'))],
              selected: {_umol},
              onSelectionChanged: (v) => setState(() => _umol = v.first),
            ),
          ]),
          const SizedBox(height: 8),
          SegmentedButton<bool>(
            showSelectedIcon: false,
            segments: [ButtonSegment(value: false, label: Text('Male')), ButtonSegment(value: true, label: Text('Female'))],
            selected: {_female},
            onSelectionChanged: (v) => setState(() => _female = v.first),
          ),
          const SizedBox(height: 10),
          if (egfr == null)
            Text('Enter age (18 or more) and creatinine.', style: theme.textTheme.bodySmall)
          else ...[
            m.Text('eGFR (CKD-EPI 2021): ${egfr.round()} mL/min/1.73 m² • ${stage(egfr)}', key: const ValueKey('kid_egfr'), style: const TextStyle(fontWeight: FontWeight.w800)),
            if (cg != null) m.Text('${tr('Creatinine clearance (Cockcroft-Gault)')}: ${cg.round()} mL/min', key: const ValueKey('kid_cg'), style: const TextStyle(fontWeight: FontWeight.w800)),
            if (cg == null) Text('Add the weight to get the Cockcroft-Gault clearance.', style: theme.textTheme.bodySmall),
            const SizedBox(height: 4),
            Text('An estimate for stable kidney function. Many labels use Cockcroft-Gault for dosing. Check the label text and your protocol.', style: theme.textTheme.bodySmall),
          ],
        ],
      ),
    );
  }
}

// ============================================================ interaction check

/// The drugs of one patient: every interaction the imported files list between two of them.
class InteractionCheckScreen extends StatefulWidget {
  const InteractionCheckScreen({super.key});
  @override
  State<InteractionCheckScreen> createState() => _InteractionCheckScreenState();
}

class InteractionHit {
  final String a, b, effect, severity, source;
  const InteractionHit(this.a, this.b, this.effect, this.severity, this.source);
}

/// Pairs of [picked] drugs that have a listed interaction: the entry of one drug names the other (by name or alias).
List<InteractionHit> findInteractions(List<FDrug> picked) {
  final out = <InteractionHit>[];
  final seen = <String>{};
  String key(String x, String y) => ([x, y]..sort()).join('|');
  List<String> names(FDrug d) => [
        for (final n in [d.name, ...d.aka])
          for (final w in n.toLowerCase().replaceAll(RegExp(r'[()/,]'), ' ').split(RegExp(r'\s+')))
            if (w.length >= 4 && !const {'acid', 'sodium', 'sulfate', 'chloride', 'human', 'short', 'acting', 'regular', 'bromide'}.contains(w)) w
      ];
  for (final a in picked) {
    for (final i in a.interactions) {
      final w = i.with_.toLowerCase();
      for (final b in picked) {
        if (identical(a, b) || a.key == b.key) continue;
        if (names(b).any((n) => w.contains(n))) {
          final k = '${key(a.key, b.key)}|${i.effect}';
          if (seen.add(k)) out.add(InteractionHit(a.name, b.name, i.effect, i.severity, i.source));
        }
      }
    }
  }
  const order = {'major': 0, 'severe': 0, 'contraindicated': 0, 'moderate': 1, 'minor': 2};
  out.sort((x, y) => (order[x.severity.toLowerCase()] ?? 1).compareTo(order[y.severity.toLowerCase()] ?? 1));
  return out;
}

class _InteractionCheckScreenState extends State<InteractionCheckScreen> {
  final _q = TextEditingController();
  final List<FDrug> _picked = [];

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final found = _q.text.trim().length < 2
        ? <FDrug>[]
        : [for (final d in dosing.fdrugs) if (d.name.toLowerCase().contains(_q.text.trim().toLowerCase()) || d.aka.any((a) => a.toLowerCase().contains(_q.text.trim().toLowerCase()))) if (!_picked.any((p) => p.key == d.key)) d].take(8).toList();
    final hits = _picked.length >= 2 ? findInteractions(_picked) : <InteractionHit>[];
    return Scaffold(
      appBar: AppBar(title: Text('Check interactions')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        Text('Only the interactions written in your imported files are shown. No result does not prove that two drugs are safe together.', style: theme.textTheme.bodySmall),
        const SizedBox(height: 10),
        TextField(key: const ValueKey('ix_search'), controller: _q, onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: tr('Add a drug'), prefixIcon: const Icon(AppIcons.search))),
        for (final d in found)
          ListTile(
            key: ValueKey('ix_add_${d.key}'),
            dense: true,
            title: _en(d.name),
            trailing: const Icon(AppIcons.add),
            onTap: () => setState(() {
              _picked.add(d);
              _q.clear();
            }),
          ),
        if (_picked.isNotEmpty) ...[
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final d in _picked) InputChip(label: m.Text(d.name, overflow: TextOverflow.ellipsis), onDeleted: () => setState(() => _picked.remove(d))),
          ]),
        ],
        const SizedBox(height: 12),
        if (_picked.length < 2)
          Text('Pick at least two drugs.')
        else if (hits.isEmpty)
          Text('No interaction between these drugs is listed in your files.', key: const ValueKey('ix_none'))
        else
          for (final h in hits)
            AppCard(
              key: ValueKey('ix_${h.a}_${h.b}'),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(AppIcons.warn, size: 18, color: h.severity.toLowerCase().contains('major') || h.severity.toLowerCase().contains('severe') || h.severity.toLowerCase().contains('contra') ? theme.colorScheme.error : theme.colorScheme.tertiary),
                    const SizedBox(width: 6),
                    Expanded(child: _en('${h.a} + ${h.b}', style: const TextStyle(fontWeight: FontWeight.w800))),
                    if (h.severity.isNotEmpty) _en(h.severity, style: theme.textTheme.labelMedium),
                  ]),
                  const SizedBox(height: 4),
                  _en(h.effect),
                  if (h.source.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en('${tr('Source')}: ${dosing.fsources[h.source]?.shortName ?? h.source}', style: theme.textTheme.bodySmall)),
                ]),
              ),
            ),
      ]),
    );
  }
}
