import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'dosing.dart';
import 'i18n.dart';
import 'ui.dart';
import 'widgets.dart';

Widget _en(String s, {TextStyle? style, int? maxLines}) =>
    Directionality(textDirection: TextDirection.ltr, child: m.Text(s, style: style, maxLines: maxLines, overflow: maxLines == null ? null : TextOverflow.ellipsis));

bool _isFav(String key) => (store.settings['doseFav'] is List) && (store.settings['doseFav'] as List).contains(key);

Future<void> _toggleFav(String key) async {
  final l = [if (store.settings['doseFav'] is List) ...(store.settings['doseFav'] as List).map((e) => '$e')];
  l.contains(key) ? l.remove(key) : l.add(key);
  store.settings['doseFav'] = l;
  await store.saveSettings();
}

/// Doses, durations and the notes around them, from the user's own files (kept on this phone).
class DosingScreen extends StatefulWidget {
  const DosingScreen({super.key});
  @override
  State<DosingScreen> createState() => _DosingScreenState();
}

class _DosingScreenState extends State<DosingScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 2, vsync: this);
  final _q = TextEditingController();
  String _pop = ''; // '' | adult | pediatric
  bool _starred = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    dosing.addListener(_changed);
    if (!dosing.loaded) dosing.load();
  }

  @override
  void dispose() {
    dosing.removeListener(_changed);
    _tabs.dispose();
    _q.dispose();
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  Future<void> _import() async {
    setState(() => _busy = true);
    try {
      final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any);
      if (r == null) return;
      final added = await dosing.importFiles([for (final f in r.files) if (f.path != null) f.path!]);
      if (mounted) snack(context, trp('{n} dosing files added. They stay on this phone.', {'n': added.length}));
    } on FormatException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (e) {
      if (mounted) snack(context, 'Import failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _manage() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
            Text('Your dosing files', style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (dosing.packs.isEmpty) Text('Nothing imported yet.'),
            for (final p in dosing.packs)
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: _en(p.title),
                subtitle: _en('${p.drugs} ${tr('drugs')} • ${p.durations} ${tr('durations')}${p.source.isEmpty ? '' : '\n${p.source}'}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  tooltip: tr('Remove'),
                  onPressed: () async {
                    await dosing.remove(p.id);
                    setS(() {});
                  },
                ),
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: () => _formatHelp(ctx), icon: const Icon(Icons.info_outline), label: Text('File format')),
          ]),
        ),
      ),
    );
  }

  void _formatHelp(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Dosing file format'),
        content: SingleChildScrollView(
          child: Text('A JSON file with schemaVersion 1, meta (id, title, source), drugs (name, aka, class, routes, regimens with indication, population, route, dose, frequency, duration, max, notes, page; renal, hepatic, pregnancy, cautions, contraindications, interactions, monitoring, adverse, pearls) and durations (condition, regimen, duration, notes, page). Several files or a ZIP can be imported. The files stay on this phone.'),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final empty = dosing.loaded && dosing.packs.isEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text('Doses & durations'),
        actions: [
          IconButton(icon: const Icon(Icons.file_open_outlined), tooltip: tr('Import a dosing file'), onPressed: _busy ? null : _import),
          IconButton(icon: const Icon(Icons.folder_open), tooltip: tr('Your dosing files'), onPressed: _manage),
        ],
        bottom: TabBar(controller: _tabs, tabs: [Tab(text: tr('Drugs')), Tab(text: tr('Durations'))]),
      ),
      body: !dosing.loaded
          ? const Center(child: CircularProgressIndicator())
          : empty
              ? _emptyState(theme)
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                    child: Row(children: [
                      Icon(Icons.shield_outlined, size: 18, color: theme.colorScheme.tertiary),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text('From your own files. Check every dose against your hospital protocol and the current official label before you use it.',
                            style: theme.textTheme.bodySmall),
                      ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: TextField(
                      controller: _q,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        labelText: tr('Search a drug, brand name, class or indication'),
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _q.text.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(_q.clear)),
                      ),
                    ),
                  ),
                  Expanded(child: TabBarView(controller: _tabs, children: [_drugList(), _durationList()])),
                ]),
    );
  }

  Widget _emptyState(ThemeData theme) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.medication_liquid_outlined, size: 56, color: theme.colorScheme.primary),
            const SizedBox(height: 12),
            Text('Your own dose reference', style: theme.textTheme.titleLarge, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text('Import the dosing files you prepared from your books or hospital protocols. They stay on this phone and work offline.', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _busy ? null : _import, icon: const Icon(Icons.file_open_outlined), label: Text('Import a dosing file')),
            TextButton(onPressed: () => _formatHelp(context), child: Text('File format')),
          ]),
        ),
      );

  Widget _drugList() {
    var list = dosing.searchDrugs(_q.text, population: _pop);
    if (_starred) list = [for (final d in list) if (_isFav(d.key)) d];
    return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
      Wrap(spacing: 6, children: [
        ChoiceChip(label: Text('All'), selected: _pop.isEmpty, visualDensity: VisualDensity.compact, onSelected: (_) => setState(() => _pop = '')),
        ChoiceChip(label: Text('Adult'), selected: _pop == 'adult', visualDensity: VisualDensity.compact, onSelected: (_) => setState(() => _pop = _pop == 'adult' ? '' : 'adult')),
        ChoiceChip(label: Text('Pediatric'), selected: _pop == 'pediatric', visualDensity: VisualDensity.compact, onSelected: (_) => setState(() => _pop = _pop == 'pediatric' ? '' : 'pediatric')),
        FilterChip(avatar: const Icon(Icons.star, size: 16), label: Text('Starred'), selected: _starred, visualDensity: VisualDensity.compact, onSelected: (v) => setState(() => _starred = v)),
      ]),
      const SizedBox(height: 6),
      if (list.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Nothing found.'))),
      for (final d in list.take(300))
        AppCard(
          child: ListTile(
            title: _en(d.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: _en([if (d.drugClass.isNotEmpty) d.drugClass, if (d.routes.isNotEmpty) d.routes.join(' / '), '${d.regimens.length} ${tr('regimens')}'].join('  •  '), maxLines: 2),
            trailing: _isFav(d.key) ? const Icon(Icons.star, color: Colors.amber, size: 20) : const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DrugDetailScreen(drug: d))).then((_) => setState(() {})),
          ),
        ),
      if (list.length > 300) Padding(padding: const EdgeInsets.all(8), child: Text('Showing the first 300. Type more to narrow it down.')),
    ]);
  }

  Widget _durationList() {
    final list = dosing.searchDurations(_q.text);
    if (dosing.durations.isEmpty) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('The imported files have no duration tables.', textAlign: TextAlign.center)));
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      if (list.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Nothing found.'))),
      for (final d in list.take(300))
        AppCard(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _en(d.condition, style: const TextStyle(fontWeight: FontWeight.w700)),
              if (d.regimen.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en(d.regimen)),
              if (d.duration.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: _en(d.duration, style: TextStyle(fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                ),
              if (d.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en(d.notes, style: Theme.of(context).textTheme.bodySmall)),
              if (d.page.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: _en('${tr('Source page')}: ${d.page}', style: Theme.of(context).textTheme.bodySmall)),
            ]),
          ),
        ),
    ]);
  }
}

class DrugDetailScreen extends StatefulWidget {
  final DrugEntry drug;
  const DrugDetailScreen({super.key, required this.drug});
  @override
  State<DrugDetailScreen> createState() => _DrugDetailScreenState();
}

class _DrugDetailScreenState extends State<DrugDetailScreen> {
  DrugEntry get d => widget.drug;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    String packTitle() {
      for (final p in dosing.packs) {
        if (p.id == d.pack) return p.title;
      }
      return d.pack;
    }

    return Scaffold(
      appBar: AppBar(
        title: _en(d.name),
        actions: [
          IconButton(
            icon: Icon(_isFav(d.key) ? Icons.star : Icons.star_border, color: _isFav(d.key) ? Colors.amber : null),
            onPressed: () async {
              await _toggleFav(d.key);
              if (mounted) setState(() {});
            },
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        if (d.aka.isNotEmpty) _en(d.aka.join(', '), style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        Wrap(spacing: 6, runSpacing: 4, children: [
          if (d.drugClass.isNotEmpty) Chip(label: _en(d.drugClass), visualDensity: VisualDensity.compact),
          for (final r in d.routes) Chip(label: _en(r), visualDensity: VisualDensity.compact),
        ]),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: theme.colorScheme.tertiaryContainer.withValues(alpha: .4), borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Icon(Icons.shield_outlined, size: 18, color: theme.colorScheme.tertiary),
            const SizedBox(width: 8),
            Expanded(
              child: Text('From your file. Check this dose against your hospital protocol and the current official label before you use it.',
                  style: theme.textTheme.bodySmall),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        if (d.regimens.isEmpty) Text('No regimens in the file.'),
        for (final r in d.regimens) _regimen(r, theme),
        if (d.renal.isNotEmpty && d.renal == d.hepatic) _block('Renal and hepatic', d.renal) else ...[_block('Renal', d.renal), _block('Hepatic', d.hepatic)],
        _block('Pregnancy and breastfeeding', d.pregnancy),
        _list('Contraindications', d.contraindications),
        _list('Cautions', d.cautions),
        _list('Interactions', d.interactions),
        _list('Monitoring', d.monitoring),
        _list('Adverse effects', d.adverse),
        _list('Pearls', d.pearls),
        const SizedBox(height: 12),
        _en('${tr('Source')}: ${packTitle()}${d.page.isEmpty ? '' : ' • ${tr('page')} ${d.page}'}', style: theme.textTheme.bodySmall),
      ]),
    );
  }

  Widget _row(String label, String v, {bool strong = false}) {
    if (v.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 92, child: Text(label, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant))),
        Expanded(child: _en(v, style: strong ? const TextStyle(fontWeight: FontWeight.w800, fontSize: 15) : null)),
      ]),
    );
  }

  Widget _regimen(DoseRegimen r, ThemeData theme) => AppCard(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: _en(r.indication.isEmpty ? '—' : r.indication, style: const TextStyle(fontWeight: FontWeight.w700))),
              if (r.population.isNotEmpty) Chip(label: _en(r.population), visualDensity: VisualDensity.compact),
            ]),
            _row('Route', r.route),
            _row('Dose', r.dose, strong: true),
            _row('Frequency', r.frequency, strong: true),
            _row('Duration', r.duration, strong: true),
            _row('Maximum', r.max),
            _row('Notes', r.notes),
            if (r.verify)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Row(children: [
                  Icon(Icons.warning_amber_rounded, size: 16, color: theme.colorScheme.error),
                  const SizedBox(width: 6),
                  Expanded(child: Text('Unclear in the source: check the original.', style: TextStyle(color: theme.colorScheme.error, fontSize: 12))),
                ]),
              ),
            if (r.page.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: _en('${tr('Source page')}: ${r.page}', style: theme.textTheme.bodySmall)),
          ]),
        ),
      );

  Widget _block(String title, String text) {
    if (text.isEmpty) return const SizedBox.shrink();
    return AppCard(child: ExpansionTile(title: Text(title), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12), expandedCrossAxisAlignment: CrossAxisAlignment.start, children: [_en(text)]));
  }

  Widget _list(String title, List<String> items) {
    if (items.isEmpty) return const SizedBox.shrink();
    return AppCard(
      child: ExpansionTile(
        title: Text(title),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [for (final i in items) Padding(padding: const EdgeInsets.only(bottom: 4), child: _en('• $i'))],
      ),
    );
  }
}
