import 'app_icons.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'i18n.dart';
import 'library.dart';
import 'ref_data.dart';
import 'screens_library.dart';
import 'ui.dart';
import 'widgets.dart';

/// A weekly study plan for one rotation: the core topics of its specialty spread over the weeks between its start and
/// end dates (must-know topics first, the last week kept for review when the rotation is long enough). For each topic
/// the person chooses the source: an article of the library or a chapter of one of their own books.

class PlanTopic {
  final String topic;
  final bool must;
  final int week; // 1-based
  const PlanTopic(this.topic, this.must, this.week);
}

class RotationPlan {
  /// Number of weeks of the rotation (at least 1); a rotation without an end date counts [fallbackWeeks].
  static int weeksOf(DateTime start, DateTime? end, {int fallbackWeeks = 4}) {
    if (end == null || end.isBefore(start)) return fallbackWeeks;
    final days = end.difference(start).inDays + 1;
    return (days / 7).ceil().clamp(1, 52);
  }

  /// 1-based week of [today] inside the rotation, clamped to 1..weeks.
  static int currentWeek(DateTime start, int weeks, DateTime today) {
    final d = DateTime(today.year, today.month, today.day).difference(DateTime(start.year, start.month, start.day)).inDays;
    return ((d < 0 ? 0 : d) ~/ 7 + 1).clamp(1, weeks);
  }

  /// Spreads [topics] (maps with 'topic' and 'priority') over [weeks]: must-know first, evenly, and a free last week
  /// for review when there are 4 weeks or more. [moved] holds topics the person put in another week.
  static List<PlanTopic> build(List<Map<String, dynamic>> topics, int weeks, {Map<String, int> moved = const {}}) {
    final must = [for (final t in topics) if (t['priority'] == 'must') t];
    final rest = [for (final t in topics) if (t['priority'] != 'must') t];
    final ordered = [...must, ...rest];
    if (ordered.isEmpty) return const [];
    final usable = weeks >= 4 ? weeks - 1 : weeks;
    final per = (ordered.length / usable).ceil();
    final out = <PlanTopic>[];
    for (var i = 0; i < ordered.length; i++) {
      final name = '${ordered[i]['topic']}';
      final w = (moved[name] ?? (i ~/ per + 1)).clamp(1, weeks);
      out.add(PlanTopic(name, ordered[i]['priority'] == 'must', w));
    }
    return out;
  }

  static Set<String> _words(String s) => {for (final w in s.toLowerCase().split(RegExp(r'[^a-z0-9]+'))) if (w.length > 5) w};

  /// Topics that appear in the diagnoses / complaints of cases logged in the rotation (a shared long word).
  static Set<String> metInCases(List<String> topics, Iterable<CaseRec> cases) {
    final seen = <String>{};
    for (final c in cases) {
      seen.addAll(_words('${c.s('workingDx')} ${c.s('finalDx')} ${c.s('cc')} ${c.s('ddx')}'));
    }
    return {
      for (final t in topics)
        if (_words(t).any(seen.contains)) t
    };
  }
}

/// Where the plan of a rotation keeps the person's choices: settings['rotPlan'][rotationId] = {src: {topic: {p, i, t}}, week: {topic: n}}.
class RotationPlanStore {
  static Map<String, dynamic> _of(String id) {
    final all = store.settings['rotPlan'];
    final m = all is Map ? all[id] : null;
    return m is Map ? Map<String, dynamic>.from(m) : <String, dynamic>{};
  }

  static Map<String, dynamic>? source(String id, String topic) {
    final s = _of(id)['src'];
    final v = s is Map ? s[topic] : null;
    return v is Map ? Map<String, dynamic>.from(v) : null;
  }

  static Map<String, int> moved(String id) {
    final w = _of(id)['week'];
    return w is Map ? {for (final e in w.entries) '${e.key}': (e.value as num).toInt()} : <String, int>{};
  }

  static Future<void> _write(String id, void Function(Map<String, dynamic> m) edit) async {
    final all = <String, dynamic>{if (store.settings['rotPlan'] is Map) ...Map<String, dynamic>.from(store.settings['rotPlan'] as Map)};
    final m = _of(id);
    edit(m);
    all[id] = m;
    store.settings['rotPlan'] = all;
    await store.saveSettings();
  }

  static Future<void> setSource(String id, String topic, Map<String, dynamic>? src) => _write(id, (m) {
        final s = <String, dynamic>{if (m['src'] is Map) ...Map<String, dynamic>.from(m['src'] as Map)};
        src == null ? s.remove(topic) : s[topic] = src;
        m['src'] = s;
      });

  static Future<void> setWeek(String id, String topic, int? week) => _write(id, (m) {
        final s = <String, dynamic>{if (m['week'] is Map) ...Map<String, dynamic>.from(m['week'] as Map)};
        week == null ? s.remove(topic) : s[topic] = week;
        m['week'] = s;
      });
}

DateTime? _d(Object? s) => s == null || '$s'.isEmpty ? null : DateTime.tryParse('$s');

class RotationPlanScreen extends StatefulWidget {
  final J rotation;
  const RotationPlanScreen({super.key, required this.rotation});
  @override
  State<RotationPlanScreen> createState() => _RotationPlanScreenState();
}

class _RotationPlanScreenState extends State<RotationPlanScreen> {
  List<Map<String, dynamic>> _topics = const [];
  bool _loaded = false;

  String get _id => '${widget.rotation['id']}';
  String get _spec => '${widget.rotation['name']}';

  @override
  void initState() {
    super.initState();
    RefData.curriculum().then((c) {
      final specs = c['specialties'];
      final data = specs is Map && specs[_spec] is Map ? specs[_spec] as Map : const {};
      if (mounted) {
        setState(() {
          _topics = [for (final t in (data['coreTopics'] as List? ?? const [])) Map<String, dynamic>.from(t as Map)];
          _loaded = true;
        });
      }
    });
  }

  Set<String> _done() {
    final m = store.settings['rotDone'];
    return m is Map && m[_spec] is List ? {for (final e in m[_spec] as List) '$e'} : <String>{};
  }

  Future<void> _toggle(String topic) async {
    final m = store.settings['rotDone'];
    final map = m is Map ? Map<String, dynamic>.from(m) : <String, dynamic>{};
    final s = _done();
    if (!s.remove(topic)) s.add(topic);
    map[_spec] = s.toList();
    store.settings['rotDone'] = map;
    await store.saveSettings();
    if (mounted) setState(() {});
  }

  Future<void> _pickSource(String topic) async {
    final res = await showModalBottomSheet<Map<String, dynamic>?>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => _SourceSheet(topic: topic, current: RotationPlanStore.source(_id, topic)),
    );
    if (res == null) return;
    await RotationPlanStore.setSource(_id, topic, res.isEmpty ? null : res);
    if (mounted) setState(() {});
  }

  Future<void> _moveWeek(String topic, int weeks, int now) async {
    final w = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Text('Move to week', style: Theme.of(ctx).textTheme.titleMedium)),
          for (var i = 1; i <= weeks; i++)
            ListTile(dense: true, title: Text(trp('Week {n}', {'n': i})), trailing: i == now ? const Icon(AppIcons.check) : null, onTap: () => Navigator.pop(ctx, i)),
        ]),
      ),
    );
    if (w == null) return;
    await RotationPlanStore.setWeek(_id, topic, w);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final start = _d(widget.rotation['start']) ?? DateTime.now();
    final end = _d(widget.rotation['end']);
    final weeks = RotationPlan.weeksOf(start, end);
    final cur = RotationPlan.currentWeek(start, weeks, DateTime.now());
    final plan = RotationPlan.build(_topics, weeks, moved: RotationPlanStore.moved(_id));
    final done = _done();
    final inRot = [
      for (final c in store.cases.values)
        if (c.s('specialty') == _spec && c.s('date').compareTo(fmtDate(start)) >= 0 && (end == null || c.s('date').compareTo(fmtDate(end)) <= 0)) c
    ];
    final met = RotationPlan.metInCases([for (final t in plan) t.topic], inRot);
    final studied = plan.where((t) => done.contains(t.topic)).length;
    return Scaffold(
      appBar: AppBar(title: Text('Study plan')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : plan.isEmpty
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('This specialty has no core topics to plan.', textAlign: TextAlign.center)))
              : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
                  AppCard(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(tr(_spec), style: theme.textTheme.titleMedium),
                        const SizedBox(height: 2),
                        Directionality(
                          textDirection: TextDirection.ltr,
                          child: m.Text('${fmtDate(start)}${end == null ? '' : '  →  ${fmtDate(end)}'}', style: theme.textTheme.bodySmall),
                        ),
                        const SizedBox(height: 10),
                        Row(children: [
                          Expanded(child: Text(trp('Week {a} of {b}', {'a': cur, 'b': weeks}), style: theme.textTheme.titleSmall)),
                          Directionality(textDirection: TextDirection.ltr, child: m.Text('$studied / ${plan.length}', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
                        ]),
                        const SizedBox(height: 6),
                        LinearProgressIndicator(value: studied / plan.length, minHeight: 8, borderRadius: BorderRadius.circular(8)),
                        const SizedBox(height: 8),
                        Text(trp('{n} cases logged in this rotation', {'n': inRot.length}), style: theme.textTheme.bodySmall),
                      ]),
                    ),
                  ),
                  for (var w = 1; w <= weeks; w++) ..._week(theme, cs, plan, w, weeks, cur, done, met),
                  const SizedBox(height: 8),
                  Text('The topic list comes from public curricula and was drafted with an AI assistant. Check it against your own program.', style: theme.textTheme.bodySmall),
                ]),
    );
  }

  List<Widget> _week(ThemeData theme, ColorScheme cs, List<PlanTopic> plan, int w, int weeks, int cur, Set<String> done, Set<String> met) {
    final items = [for (final t in plan) if (t.week == w) t];
    final review = items.isEmpty && w == weeks && weeks >= 4;
    if (items.isEmpty && !review) return const [];
    final nDone = items.where((t) => done.contains(t.topic)).length;
    return [
      Fold(
        id: 'plan_${_id}_$w',
        title: trp('Week {n}', {'n': w}) + (w == cur ? '  •  ${tr('this week')}' : ''),
        icon: w == cur ? Icons.today : (w < cur ? AppIcons.history : Icons.event_outlined),
        initiallyOpen: w == cur,
        subtitle: review ? tr('Review and catch up') : '$nDone / ${items.length}',
        children: [
          if (review) Text('Keep this week to go back over what you did not finish and to test yourself.', style: theme.textTheme.bodySmall),
          for (final t in items) _row(theme, cs, t, weeks, done.contains(t.topic), met.contains(t.topic)),
        ],
      ),
    ];
  }

  Widget _row(ThemeData theme, ColorScheme cs, PlanTopic t, int weeks, bool done, bool met) {
    final src = RotationPlanStore.source(_id, t.topic);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CheckboxListTile(
        key: ValueKey('plan_${t.topic}'),
        contentPadding: EdgeInsets.zero,
        dense: true,
        controlAffinity: ListTileControlAffinity.leading,
        value: done,
        onChanged: (_) => _toggle(t.topic),
        title: Directionality(textDirection: TextDirection.ltr, child: Align(alignment: AlignmentDirectional.centerStart, child: m.Text(t.topic))),
        subtitle: Wrap(spacing: 8, children: [
          if (t.must) Text('Must know', style: theme.textTheme.labelSmall?.copyWith(color: cs.primary, fontWeight: FontWeight.w700)),
          if (met) Text('Seen in your cases', style: theme.textTheme.labelSmall?.copyWith(color: cs.tertiary, fontWeight: FontWeight.w700)),
        ]),
        secondary: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'src') _pickSource(t.topic);
            if (v == 'week') _moveWeek(t.topic, weeks, t.week);
            if (v == 'clear') RotationPlanStore.setSource(_id, t.topic, null).then((_) => mounted ? setState(() {}) : null);
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'src', child: Text('Choose the source')),
            PopupMenuItem(value: 'week', child: Text('Move to another week')),
            if (src != null) PopupMenuItem(value: 'clear', child: Text('Remove the source')),
          ],
        ),
      ),
      Padding(
        padding: const EdgeInsetsDirectional.only(start: 48, bottom: 8),
        child: src == null
            ? Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
                  onPressed: () => _pickSource(t.topic),
                  icon: const Icon(Icons.add_link, size: 18),
                  label: Text('Choose the source'),
                ),
              )
            : Align(
                alignment: AlignmentDirectional.centerStart,
                child: ActionChip(
                  avatar: Icon('${src['k']}' == 'book' ? AppIcons.library : AppIcons.library, size: 16),
                  label: m.Text('${src['t']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                  onPressed: () {
                    final idx = (src['i'] as num?)?.toInt();
                    if (idx != null && library.pack('${src['p']}') != null) {
                      openArticle(context, '${src['p']}', idx);
                    } else {
                      snack(context, tr('This source is no longer installed. Choose another.'));
                    }
                  },
                ),
              ),
      ),
    ]);
  }
}

/// Searching the library (the person's own books first) for the source of one topic.
class _SourceSheet extends StatefulWidget {
  final String topic;
  final Map<String, dynamic>? current;
  const _SourceSheet({required this.topic, required this.current});
  @override
  State<_SourceSheet> createState() => _SourceSheetState();
}

class _SourceSheetState extends State<_SourceSheet> {
  late final TextEditingController _c = TextEditingController(text: _short(widget.topic));
  List<LibHit> _hits = const [];
  bool _busy = false;
  bool _books = false;

  static String _short(String t) => t.split(':').first.split('(').first.trim();

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final q = _c.text.trim();
    if (q.isEmpty || !library.ready) return;
    setState(() => _busy = true);
    var h = await library.searchEx(q, limit: 40, body: true);
    h = [...h.where((x) => library.pack(x.packId)?.kind == 'book'), ...h.where((x) => library.pack(x.packId)?.kind != 'book')];
    if (_books) h = [for (final x in h) if (library.pack(x.packId)?.kind == 'book') x];
    if (mounted) {
      setState(() {
        _hits = h;
        _busy = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.8,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
              child: Row(children: [
                Expanded(child: Directionality(textDirection: TextDirection.ltr, child: m.Text(widget.topic, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall))),
                if (widget.current != null) TextButton(onPressed: () => Navigator.pop(context, <String, dynamic>{}), child: Text('Remove')),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
              child: TextField(
                controller: _c,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _run(),
                decoration: InputDecoration(isDense: true, prefixIcon: const Icon(AppIcons.search), labelText: tr('Search the library and my books'), suffixIcon: IconButton(icon: const Icon(AppIcons.arrowForward), onPressed: _run)),
              ),
            ),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: FilterChip(
                  avatar: const Icon(AppIcons.library, size: 16),
                  label: Text('My books only'),
                  selected: _books,
                  visualDensity: VisualDensity.compact,
                  onSelected: (v) {
                    setState(() => _books = v);
                    _run();
                  },
                ),
              ),
            ),
            if (_busy) const LinearProgressIndicator(),
            Expanded(
              child: _hits.isEmpty && !_busy
                  ? Center(child: Text('Nothing found', style: theme.textTheme.bodyMedium))
                  : ListView(children: [
                      for (final h in _hits)
                        ListTile(
                          dense: true,
                          leading: Icon(library.pack(h.packId)?.kind == 'book' ? AppIcons.library : AppIcons.library),
                          title: m.Text(stripSource(h.title), maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
                          subtitle: m.Text(library.pack(h.packId)?.title ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
                          onTap: () => Navigator.pop(context, <String, dynamic>{'p': h.packId, 'i': h.index, 't': stripSource(h.title), 'k': library.pack(h.packId)?.kind ?? ''}),
                        ),
                    ]),
            ),
          ]),
        ),
      ),
    );
  }
}
