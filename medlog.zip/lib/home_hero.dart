import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'i18n.dart';
import 'sparks.dart';

/// Part of the day, from the clock: it sets the colours of the welcome card.
enum DayPart { morning, day, evening, night }

DayPart dayPartOf(DateTime t) {
  final h = t.hour;
  if (h >= 5 && h < 11) return DayPart.morning;
  if (h >= 11 && h < 16) return DayPart.day;
  if (h >= 16 && h < 19) return DayPart.evening;
  return DayPart.night;
}

String greetingOf(DateTime t) => switch (dayPartOf(t)) {
      DayPart.morning => 'Good morning',
      DayPart.day => 'Good afternoon',
      DayPart.evening => 'Good evening',
      DayPart.night => 'Good night',
    };

/// The four looks of the welcome card (SharqMed, Eastern Dawn): by the local clock, start included, end excluded.
enum DawnState { morning, afternoon, evening, night }

DawnState dawnStateOf(DateTime t) {
  final h = t.hour;
  if (h >= 5 && h < 12) return DawnState.morning;
  if (h >= 12 && h < 17) return DawnState.afternoon;
  if (h >= 17 && h < 21) return DawnState.evening;
  return DawnState.night;
}

/// Greeting of the card: evening and night share "Good evening".
String dawnGreeting(DawnState s) => switch (s) {
      DawnState.morning => 'Good morning',
      DawnState.afternoon => 'Good afternoon',
      DawnState.evening || DawnState.night => 'Good evening',
    };

String dawnAsset(DawnState s) => 'assets/brand/dawn/${s.name}.png';

/// The moment the look changes next (05:00, 12:00, 17:00, 21:00): the card is redrawn then.
DateTime nextDawnBoundary(DateTime t) {
  for (final h in const [5, 12, 17, 21]) {
    final b = DateTime(t.year, t.month, t.day, h);
    if (b.isAfter(t)) return b;
  }
  return DateTime(t.year, t.month, t.day + 1, 5);
}

/// Dark ink on the light morning card, ivory on the others.
Color dawnInk(DawnState s) => s == DawnState.morning ? const Color(0xFF012525) : const Color(0xFFF8EFE6);

/// The welcome card of Home: the Eastern Dawn picture of the time of day (art on the trailing side), the greeting, the
/// date and the practical line of the day. It looks again when the app is resumed and at 05:00, 12:00, 17:00 and 21:00.
class HomeHero extends StatefulWidget {
  final DateTime now;
  const HomeHero({super.key, required this.now});

  @override
  State<HomeHero> createState() => _HomeHeroState();
}

class _HomeHeroState extends State<HomeHero> with WidgetsBindingObserver {
  late DateTime _now = widget.now;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _arm();
  }

  @override
  void didUpdateWidget(HomeHero old) {
    super.didUpdateWidget(old);
    _now = widget.now;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _tick();
  }

  void _arm() {
    _timer?.cancel();
    final n = DateTime.now();
    _timer = Timer(nextDawnBoundary(n).difference(n) + const Duration(seconds: 1), _tick);
  }

  void _tick() {
    if (!mounted) return;
    setState(() => _now = DateTime.now());
    _arm();
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = dawnStateOf(_now);
    final ink = dawnInk(state);
    // only the first name fits the card: "dr.mohammed" rather than a cut-off long name
    final who = store.author.trim().split(RegExp(r'\s+')).first;
    final spark = Sparks.ofDay(_now);
    final g = dawnGreeting(state);
    final reduce = MediaQuery.of(context).disableAnimations;
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final card = Container(
      key: ValueKey('home_hero_${state.name}'),
      width: double.infinity,
      constraints: const BoxConstraints(minHeight: 120),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22)),
      child: Stack(children: [
        // the picture only is mirrored for right-to-left; the text lives in the layout
        Positioned.fill(
          child: Transform.flip(
            flipX: rtl,
            child: Image.asset(dawnAsset(state), fit: BoxFit.cover, alignment: Alignment.centerRight, excludeFromSemantics: true),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: FractionallySizedBox(
            widthFactor: 0.68,
            alignment: AlignmentDirectional.centerStart,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              m.Text(who.isEmpty ? tr(g) : '${tr(g)}, $who',
                  key: const ValueKey('hero_greeting'),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: ink, fontSize: 24, height: 1.15, fontWeight: FontWeight.w700, fontFamily: isAr ? 'Cairo' : null)),
              const SizedBox(height: 6),
              m.Text(prettyDate(todayStr()), key: const ValueKey('hero_date'), style: TextStyle(color: ink, fontSize: 14, fontWeight: FontWeight.w500, fontFamily: isAr ? 'Cairo' : null)),
              if (spark != null) ...[
                const SizedBox(height: 8),
                Directionality(
                  textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
                  child: SizedBox(
                    width: double.infinity,
                    child: _VerseIn(
                      key: ValueKey('verse_${spark.id}'),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        for (final l in spark.lines) m.Text(l, style: TextStyle(color: ink.withAlpha(235), fontSize: 13, height: 1.45, fontWeight: FontWeight.w600)),
                        if (spark.author.isNotEmpty) m.Text(spark.author, style: TextStyle(color: ink.withAlpha(200), fontSize: 12, height: 1.45)),
                      ]),
                    ),
                  ),
                ),
              ],
            ]),
          ),
        ),
      ]),
    );
    return Container(
      key: const Key('home_hero'),
      child: AnimatedSwitcher(
        duration: Duration(milliseconds: reduce ? 0 : 250),
        // the default layout loosens the constraints and the card shrank to its text: keep the full width
        layoutBuilder: (cur, prev) => Stack(fit: StackFit.passthrough, alignment: Alignment.topCenter, children: [...prev, if (cur != null) cur]),
        child: card,
      ),
    );
  }
}

/// The verse fades and rises once when the card first shows.
class _VerseIn extends StatefulWidget {
  final Widget child;
  const _VerseIn({super.key, required this.child});

  @override
  State<_VerseIn> createState() => _VerseInState();
}

class _VerseInState extends State<_VerseIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));

  @override
  void initState() {
    super.initState();
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        child: widget.child,
        builder: (_, child) {
          final v = Curves.easeOutCubic.transform(_c.value);
          return Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 10 * (1 - v)), child: child));
        },
      );
}
