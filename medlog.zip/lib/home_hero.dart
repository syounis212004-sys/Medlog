import 'dart:math' as math;

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'data.dart';
import 'i18n.dart';
import 'sparks.dart';

/// Part of the day, from the clock: it sets the colours of the welcome card.
enum DayPart { morning, day, evening, night }

DayPart dayPartOf(DateTime t) {
  final h = t.hour;
  if (h >= 5 && h < 11) return DayPart.morning;
  if (h >= 11 && h < 16) return DayPart.day;
  if (h >= 16 && h < 19) return DayPart.evening;
  return DayPart.night;
}

String greetingOf(DateTime t) => switch (dayPartOf(t)) {
      DayPart.morning => 'Good morning',
      DayPart.day => 'Good afternoon',
      DayPart.evening => 'Good evening',
      DayPart.night => 'Good night',
    };

List<Color> _sky(DayPart p) => switch (p) {
      DayPart.morning => const [Color(0xFFF2B46E), Color(0xFF8DBBD8)],
      DayPart.day => const [Color(0xFF4F9AE0), Color(0xFFB9E1F3)],
      DayPart.evening => const [Color(0xFFD9774F), Color(0xFF5E4586)],
      DayPart.night => const [Color(0xFF0E1A33), Color(0xFF2A4470)],
    };

/// The welcome card of Home: a landscape whose sky follows the time of day, the greeting, and the verse of the day.
class HomeHero extends StatelessWidget {
  final DateTime now;
  const HomeHero({super.key, required this.now});

  @override
  Widget build(BuildContext context) {
    final part = dayPartOf(now);
    // only the first name fits the card: "dr.mohammed" rather than a cut-off long name
    final who = store.author.trim().split(RegExp(r'\s+')).first;
    final spark = Sparks.ofDay(now);
    final g = greetingOf(now);
    return Container(
      key: const Key('home_hero'),
      height: spark == null ? 168 : 214,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(24)),
      child: Stack(fit: StackFit.expand, children: [
        CustomPaint(painter: _ScenePainter(part, now)),
        // a soft shade under the text, so it stays readable on every sky
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0x00000000), Color(0x73000000)]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            m.Text(who.isEmpty ? tr(g) : '${tr(g)}, $who',
                maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800, shadows: [Shadow(blurRadius: 6, color: Color(0x55000000))])),
            const SizedBox(height: 2),
            m.Text(prettyDate(todayStr()), style: const TextStyle(color: Color(0xE6FFFFFF), fontSize: 13.5, fontWeight: FontWeight.w500)),
            const Spacer(),
            if (spark != null)
              Directionality(
                textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
                child: SizedBox(
                  width: double.infinity,
                  child: _VerseIn(
                    key: ValueKey('verse_${spark.id}'),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      for (final l in spark.lines)
                        m.Text(l, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16.5, height: 1.6, fontWeight: FontWeight.w600, shadows: [Shadow(blurRadius: 6, color: Color(0x66000000))])),
                      if (spark.author.isNotEmpty)
                        m.Text(spark.author, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xD9FFFFFF), fontSize: 12.5, height: 1.6)),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ]),
    );
  }
}

/// The verse fades and rises once when the card first shows.
class _VerseIn extends StatefulWidget {
  final Widget child;
  const _VerseIn({super.key, required this.child});

  @override
  State<_VerseIn> createState() => _VerseInState();
}

class _VerseInState extends State<_VerseIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));

  @override
  void initState() {
    super.initState();
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        child: widget.child,
        builder: (_, child) {
          final v = Curves.easeOutCubic.transform(_c.value);
          return Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 10 * (1 - v)), child: child));
        },
      );
}

class _ScenePainter extends CustomPainter {
  final DayPart part;
  final DateTime now;
  const _ScenePainter(this.part, this.now);

  @override
  void paint(Canvas canvas, Size s) {
    final sky = _sky(part);
    canvas.drawRect(Offset.zero & s, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: sky).createShader(Offset.zero & s));

    // stars at night
    if (part == DayPart.night) {
      final r = math.Random(7);
      final p = Paint()..color = const Color(0xCCFFFFFF);
      for (var i = 0; i < 36; i++) {
        canvas.drawCircle(Offset(r.nextDouble() * s.width, r.nextDouble() * s.height * 0.6), r.nextDouble() * 1.3 + 0.4, p);
      }
    }

    // sun or moon on an arc that follows the hour
    final h = now.hour + now.minute / 60.0;
    final dayFrac = part == DayPart.night ? (((h >= 19 ? h - 19 : h + 5) / 10).clamp(0.0, 1.0)) : ((h - 5) / 14).clamp(0.0, 1.0);
    final cx = s.width * (0.12 + 0.76 * dayFrac);
    final cy = s.height * (0.62 - 0.42 * math.sin(dayFrac * math.pi));
    final glow = switch (part) {
      DayPart.night => const Color(0x33FFFFFF),
      DayPart.evening => const Color(0x55FFC38A),
      _ => const Color(0x55FFF1B8),
    };
    canvas.drawCircle(Offset(cx, cy), 46, Paint()..color = glow);
    canvas.drawCircle(Offset(cx, cy), part == DayPart.night ? 15 : 19, Paint()..color = part == DayPart.night ? const Color(0xFFF4F1E4) : const Color(0xFFFFF4CC));

    // three layers of hills
    void hills(double base, double amp, double phase, Color c) {
      final path = Path()..moveTo(0, s.height);
      for (var x = 0.0; x <= s.width; x += 4) {
        final y = s.height * base - amp * math.sin(x / s.width * math.pi * 2 + phase) - amp * 0.4 * math.sin(x / s.width * math.pi * 5 + phase * 2);
        path.lineTo(x, y);
      }
      path
        ..lineTo(s.width, s.height)
        ..close();
      canvas.drawPath(path, Paint()..color = c);
    }

    final dark = part == DayPart.night || part == DayPart.evening;
    hills(0.80, 10, 0.6, Color.lerp(sky.last, Colors.black, dark ? 0.25 : 0.12)!.withAlpha(150));
    hills(0.88, 9, 2.1, Color.lerp(sky.last, Colors.black, dark ? 0.42 : 0.22)!.withAlpha(190));
    hills(0.95, 7, 4.0, Color.lerp(sky.last, Colors.black, dark ? 0.6 : 0.34)!);
  }

  @override
  bool shouldRepaint(_ScenePainter old) => old.part != part || old.now.hour != now.hour;
}
