import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

/// Phosphor icon for each specialty (modern, consistent line icons).
IconData specialtyIcon(String name) {
  switch (name) {
    case 'Internal Medicine':
      return PhosphorIconsRegular.stethoscope;
    case 'General Surgery':
      return PhosphorIconsRegular.scissors;
    case 'Pediatrics':
      return PhosphorIconsRegular.baby;
    case 'OB/GYN':
      return PhosphorIconsRegular.babyCarriage;
    case 'Emergency':
      return PhosphorIconsRegular.siren;
    case 'ICU':
      return PhosphorIconsRegular.heartbeat;
    case 'Orthopedics':
      return PhosphorIconsRegular.bone;
    case 'Family Medicine':
      return PhosphorIconsRegular.usersThree;
    case 'Neurology':
      return PhosphorIconsRegular.brain;
    case 'Psychiatry':
      return PhosphorIconsRegular.smiley;
    case 'ENT':
      return PhosphorIconsRegular.ear;
    case 'Ophthalmology':
      return PhosphorIconsRegular.eye;
    case 'Dermatology':
      return PhosphorIconsRegular.handPalm;
    case 'Urology':
      return PhosphorIconsRegular.drop;
    case 'Anesthesia':
      return PhosphorIconsRegular.wind;
    case 'Cardiology':
      return PhosphorIconsRegular.heart;
    default:
      return PhosphorIconsRegular.firstAidKit;
  }
}

Color specialtyColor(String name) {
  switch (name) {
    case 'Internal Medicine':
      return const Color(0xFF00796B);
    case 'General Surgery':
      return const Color(0xFF5E35B1);
    case 'Pediatrics':
      return const Color(0xFFF9A825);
    case 'OB/GYN':
      return const Color(0xFFD81B60);
    case 'Emergency':
      return const Color(0xFFE53935);
    case 'ICU':
      return const Color(0xFF3949AB);
    case 'Orthopedics':
      return const Color(0xFF6D4C41);
    case 'Family Medicine':
      return const Color(0xFF43A047);
    case 'Neurology':
      return const Color(0xFF8E24AA);
    case 'Psychiatry':
      return const Color(0xFF00ACC1);
    case 'ENT':
      return const Color(0xFFEF6C00);
    case 'Ophthalmology':
      return const Color(0xFF1E88E5);
    case 'Dermatology':
      return const Color(0xFFEC407A);
    case 'Urology':
      return const Color(0xFF039BE5);
    case 'Anesthesia':
      return const Color(0xFF546E7A);
    case 'Cardiology':
      return const Color(0xFFC62828);
    default:
      return const Color(0xFF757575);
  }
}

/// Round avatar with the specialty icon on a soft tint of its color.
class SpecialtyAvatar extends StatelessWidget {
  final String specialty;
  final double size;
  final bool selected;
  const SpecialtyAvatar(this.specialty, {super.key, this.size = 44, this.selected = false});

  @override
  Widget build(BuildContext context) {
    final col = specialtyColor(specialty);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: selected ? Theme.of(context).colorScheme.primary : col.withAlpha(36),
        borderRadius: BorderRadius.circular(size / 3),
      ),
      child: Icon(
        selected ? Icons.check : specialtyIcon(specialty),
        size: size * 0.55,
        color: selected ? Theme.of(context).colorScheme.onPrimary : col,
      ),
    );
  }
}

/// Flat rounded card with a thin outline (lighter and faster than elevated cards).
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry margin;
  final Color? color;
  const AppCard({
    super.key,
    required this.child,
    this.margin = const EdgeInsets.symmetric(vertical: 4),
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      margin: margin,
      color: color ?? cs.surfaceContainerLow,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: cs.outlineVariant),
      ),
      child: child,
    );
  }
}
