import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/painting.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'i18n.dart';

/// PDF export that is safe for Arabic: the text is drawn by Flutter's own text
/// engine (shaping, right-to-left, Cairo font) onto page images, and the images
/// are placed in the PDF. The text is not selectable, but it always looks right.

const double _pw = 1240; // A4 at 150 dpi
const double _ph = 1754;
const double _margin = 110;

bool _isRtlLine(String s) {
  var ar = 0, lat = 0;
  for (final r in s.runes) {
    if (r >= 0x0600 && r <= 0x06FF) {
      ar++;
    } else if ((r >= 0x41 && r <= 0x5A) || (r >= 0x61 && r <= 0x7A)) {
      lat++;
    }
  }
  return ar > lat;
}

class _Line {
  final String text;
  final double size;
  final bool bold;
  const _Line(this.text, this.size, this.bold);
}

/// Splits a plain-text document into styled lines: first line is the title,
/// lines that end with ':' or are written in capitals become headings.
List<_Line> _styled(String title, String body) {
  final out = <_Line>[_Line(title, 44, true), const _Line('', 20, false)];
  for (final raw in body.split('\n')) {
    final t = raw.trimRight();
    if (t.isEmpty) {
      out.add(const _Line('', 14, false));
    } else if (t.startsWith('## ')) {
      out.add(_Line(t.substring(3), 32, true));
    } else {
      out.add(_Line(t, 25, false));
    }
  }
  return out;
}

Future<List<Uint8List>> renderPages(String title, String body, {String footer = 'MedLog'}) async {
  final family = isAr ? 'Cairo' : 'Tinos';
  final pages = <Uint8List>[];
  final lines = _styled(title, body);
  var i = 0;
  while (i < lines.length || pages.isEmpty) {
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec, const Rect.fromLTWH(0, 0, _pw, _ph));
    canvas.drawRect(const Rect.fromLTWH(0, 0, _pw, _ph), Paint()..color = const Color(0xFFFFFFFF));
    var y = _margin;
    while (i < lines.length) {
      final l = lines[i];
      final rtl = _isRtlLine(l.text);
      final tp = TextPainter(
        text: TextSpan(
          text: l.text.isEmpty ? ' ' : l.text,
          style: TextStyle(
            color: const Color(0xFF111111),
            fontFamily: family,
            fontSize: l.size,
            height: 1.45,
            fontWeight: l.bold ? FontWeight.w700 : FontWeight.w400,
          ),
        ),
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        textAlign: TextAlign.start,
      )..layout(minWidth: _pw - 2 * _margin, maxWidth: _pw - 2 * _margin);
      if (y + tp.height > _ph - _margin && y > _margin) break;
      tp.paint(canvas, Offset(_margin, y));
      y += tp.height + (l.bold ? 6 : 2);
      i++;
    }
    final f = TextPainter(
      text: TextSpan(text: '$footer  •  ${pages.length + 1}', style: TextStyle(color: const Color(0xFF777777), fontFamily: 'Tinos', fontSize: 20)),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: _pw - 2 * _margin);
    f.paint(canvas, Offset(_margin, _ph - 70));
    final img = await rec.endRecording().toImage(_pw.toInt(), _ph.toInt());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    pages.add(data!.buffer.asUint8List());
    if (i >= lines.length) break;
  }
  return pages;
}

Future<Uint8List> buildPdf(String title, String body) async {
  final pages = await renderPages(title, body, footer: 'MedLog  •  Dr. Mohammed Samir Abu Younis');
  final doc = pw.Document(title: title, author: 'MedLog', creator: 'MedLog');
  for (final p in pages) {
    final image = pw.MemoryImage(p);
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: pw.EdgeInsets.zero,
      build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
    ));
  }
  return Uint8List.fromList(await doc.save());
}

Future<File> writePdf(String title, String body, {String fileName = 'MedLog'}) async {
  final bytes = await buildPdf(title, body);
  final dir = await getTemporaryDirectory();
  final safe = fileName.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
  final f = File('${dir.path}/$safe.pdf');
  await f.writeAsBytes(bytes, flush: true);
  return f;
}
