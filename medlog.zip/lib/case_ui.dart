import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'i18n.dart';
import 'motion.dart';
import 'ph.dart';
import 'sem.dart';

/// Building blocks shared by the case editor and other forms: a titled section card, a segmented selector with a
/// sliding thumb, an expansion tile with the app's own caret, and the text-field border.

/// A filled box with a thin line all around it. It stays an "underline" kind of border for the framework, so the
/// floating label sits inside the box instead of cutting through its top edge.
class BoxInputBorder extends UnderlineInputBorder {
  const BoxInputBorder({super.borderSide = const BorderSide(), super.borderRadius = const BorderRadius.all(Radius.circular(14))});

  @override
  BoxInputBorder copyWith({BorderSide? borderSide, BorderRadius? borderRadius}) =>
      BoxInputBorder(borderSide: borderSide ?? this.borderSide, borderRadius: borderRadius ?? this.borderRadius);

  @override
  BoxInputBorder scale(double t) => BoxInputBorder(borderSide: borderSide.scale(t), borderRadius: borderRadius * t);

  @override
  ShapeBorder? lerpFrom(ShapeBorder? a, double t) => a is BoxInputBorder
      ? BoxInputBorder(borderSide: BorderSide.lerp(a.borderSide, borderSide, t), borderRadius: BorderRadius.lerp(a.borderRadius, borderRadius, t)!)
      : super.lerpFrom(a, t);

  @override
  ShapeBorder? lerpTo(ShapeBorder? b, double t) => b is BoxInputBorder
      ? BoxInputBorder(borderSide: BorderSide.lerp(borderSide, b.borderSide, t), borderRadius: BorderRadius.lerp(borderRadius, b.borderRadius, t)!)
      : super.lerpTo(b, t);

  @override
  void paint(Canvas canvas, Rect rect,
      {double? gapStart, double gapExtent = 0.0, double gapPercentage = 0.0, TextDirection? textDirection}) {
    if (borderSide.style == BorderStyle.none || borderSide.width <= 0) return;
    final r = borderRadius.resolve(textDirection).toRRect(rect).deflate(borderSide.width / 2);
    canvas.drawRRect(r, borderSide.toPaint());
  }

  @override
  bool operator ==(Object other) => other is BoxInputBorder && other.borderSide == borderSide && other.borderRadius == borderRadius;

  @override
  int get hashCode => Object.hash(borderSide, borderRadius, 'box');
}

/// A group of related fields: an icon and a title, then the fields, inside one quiet card.
class CaseSection extends StatelessWidget {
  final IconData icon;
  final String title;
  final List<Widget> children;
  final Widget? trailing;
  const CaseSection({super.key, required this.icon, required this.title, required this.children, this.trailing});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: cs.outlineVariant.withAlpha(150)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Semantics(
          header: true,
          child: Row(children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(11)),
              child: Icon(icon, size: 18, color: cs.onPrimaryContainer),
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: cs.onSurface))),
            if (trailing != null) trailing!,
          ]),
        ),
        const SizedBox(height: 12),
        ...children,
      ]),
    );
  }
}

/// One choice of [PillSegments].
class PillItem {
  final Key? key;
  final IconData icon;
  final String label;
  final bool done;
  const PillItem(this.icon, this.label, {this.key, this.done = false});
}

/// Equal segments in one rounded track; the chosen one is marked by a thumb that slides to it.
class PillSegments extends StatelessWidget {
  final List<PillItem> items;
  final int selected;
  final ValueChanged<int> onSelected;
  const PillSegments({super.key, required this.items, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final n = items.length;
    final on = animOn(context);
    final big = MediaQuery.textScalerOf(context).scale(1.0) > 1.15;
    return Container(
      height: big ? 56 : 46,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: cs.surfaceContainerHigh, borderRadius: BorderRadius.circular(999)),
      child: Stack(children: [
        AnimatedAlign(
          alignment: AlignmentDirectional(n <= 1 ? 0 : -1 + 2 * selected.clamp(0, n - 1) / (n - 1), 0),
          duration: on ? const Duration(milliseconds: 320) : Duration.zero,
          curve: Curves.easeOutCubic,
          child: FractionallySizedBox(
            widthFactor: 1 / n,
            heightFactor: 1,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: cs.primaryContainer,
                borderRadius: BorderRadius.circular(999),
                boxShadow: [BoxShadow(color: cs.shadow.withAlpha(28), blurRadius: 6, offset: const Offset(0, 1))],
              ),
            ),
          ),
        ),
        Row(children: [
          for (var i = 0; i < n; i++)
            Expanded(
              child: Semantics(
                button: true,
                selected: i == selected,
                child: InkWell(
                  key: items[i].key,
                  borderRadius: BorderRadius.circular(999),
                  onTap: () => onSelected(i),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Stack(clipBehavior: Clip.none, children: [
                        Icon(items[i].icon, size: 18, color: i == selected ? cs.onPrimaryContainer : cs.onSurfaceVariant),
                        if (items[i].done)
                          PositionedDirectional(
                            top: -2,
                            end: -4,
                            child: Container(
                              width: 7,
                              height: 7,
                              decoration: BoxDecoration(color: Sem.success, shape: BoxShape.circle, border: Border.all(color: cs.surface, width: 1)),
                            ),
                          ),
                      ]),
                      const SizedBox(width: 6),
                      Flexible(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: AnimatedDefaultTextStyle(
                            duration: on ? const Duration(milliseconds: 200) : Duration.zero,
                            style: DefaultTextStyle.of(context).style.copyWith(
                                  fontSize: 13.5,
                                  fontWeight: i == selected ? FontWeight.w800 : FontWeight.w500,
                                  color: i == selected ? cs.onPrimaryContainer : cs.onSurfaceVariant,
                                ),
                            child: Text(items[i].label, maxLines: 1),
                          ),
                        ),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
        ]),
      ]),
    );
  }
}

/// [ExpansionTile] with the app's own caret (it turns when the tile opens) instead of the Material arrow.
class PhExpansionTile extends StatefulWidget {
  final Widget title;
  final Widget? subtitle;
  final Widget? leading;
  final List<Widget> children;
  final EdgeInsetsGeometry? childrenPadding;
  final EdgeInsetsGeometry? tilePadding;
  final CrossAxisAlignment? expandedCrossAxisAlignment;
  final bool initiallyExpanded;
  final bool? dense;
  final ShapeBorder? shape;
  final ShapeBorder? collapsedShape;
  final Color? backgroundColor;
  final Color? collapsedBackgroundColor;
  final ValueChanged<bool>? onExpansionChanged;
  const PhExpansionTile({
    super.key,
    required this.title,
    this.subtitle,
    this.leading,
    this.children = const [],
    this.childrenPadding,
    this.tilePadding,
    this.expandedCrossAxisAlignment,
    this.initiallyExpanded = false,
    this.dense,
    this.shape,
    this.collapsedShape,
    this.backgroundColor,
    this.collapsedBackgroundColor,
    this.onExpansionChanged,
  });

  @override
  State<PhExpansionTile> createState() => _PhExpansionTileState();
}

class _PhExpansionTileState extends State<PhExpansionTile> {
  late bool _open = widget.initiallyExpanded;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ExpansionTile(
      title: widget.title,
      subtitle: widget.subtitle,
      leading: widget.leading,
      childrenPadding: widget.childrenPadding,
      tilePadding: widget.tilePadding,
      expandedCrossAxisAlignment: widget.expandedCrossAxisAlignment,
      initiallyExpanded: widget.initiallyExpanded,
      dense: widget.dense,
      shape: widget.shape,
      collapsedShape: widget.collapsedShape,
      backgroundColor: widget.backgroundColor,
      collapsedBackgroundColor: widget.collapsedBackgroundColor,
      trailing: AnimatedRotation(
        turns: _open ? 0.5 : 0,
        duration: animOn(context) ? const Duration(milliseconds: 220) : Duration.zero,
        curve: Curves.easeOutCubic,
        child: Icon(Ph.caretDown, size: 20, color: _open ? cs.primary : cs.onSurfaceVariant),
      ),
      onExpansionChanged: (v) {
        setState(() => _open = v);
        widget.onExpansionChanged?.call(v);
      },
      children: widget.children,
    );
  }
}

/// Cross-fade with a small lift, for content that replaces other content in place (sub-pages, steps).
class SwapIn extends StatelessWidget {
  final Widget child;
  const SwapIn({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    if (!animOn(context)) return child;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 240),
      reverseDuration: const Duration(milliseconds: 90),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeIn,
      layoutBuilder: (cur, prev) => Stack(alignment: Alignment.topCenter, children: [...prev, if (cur != null) cur]),
      transitionBuilder: (c, a) => FadeTransition(
        opacity: a,
        child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, 0.015), end: Offset.zero).animate(a), child: c),
      ),
      child: child,
    );
  }
}

/// A short celebration over the screen (a ring that opens and a check that draws itself). It does not block touches
/// and removes itself; nothing is shown when animations are off.
void celebrate(BuildContext context) {
  if (!animOn(context)) return;
  final overlay = Overlay.maybeOf(context, rootOverlay: true);
  if (overlay == null) return;
  late final OverlayEntry entry;
  entry = OverlayEntry(builder: (_) => _Celebration(onDone: () => entry.remove()));
  overlay.insert(entry);
}

class _Celebration extends StatefulWidget {
  final VoidCallback onDone;
  const _Celebration({required this.onDone});

  @override
  State<_Celebration> createState() => _CelebrationState();
}

class _CelebrationState extends State<_Celebration> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed) widget.onDone();
    })
    ..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return IgnorePointer(
      child: ExcludeSemantics(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final t = _c.value;
            final pop = Curves.elasticOut.transform((t / 0.55).clamp(0.0, 1.0));
            final fade = t < 0.8 ? 1.0 : 1 - (t - 0.8) / 0.2;
            final ring = Curves.easeOutCubic.transform((t / 0.7).clamp(0.0, 1.0));
            return Opacity(
              opacity: fade.clamp(0.0, 1.0),
              child: Center(
                child: SizedBox(
                  width: 220,
                  height: 220,
                  child: Stack(alignment: Alignment.center, children: [
                    for (final k in const [1.0, 0.72])
                      Container(
                        width: 96 + 124 * ring * k,
                        height: 96 + 124 * ring * k,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Sem.success.withAlpha((150 * (1 - ring)).round()), width: 3),
                        ),
                      ),
                    Transform.scale(
                      scale: 0.4 + 0.6 * pop,
                      child: Container(
                        width: 96,
                        height: 96,
                        decoration: BoxDecoration(
                          color: Sem.success,
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: cs.shadow.withAlpha(60), blurRadius: 18, offset: const Offset(0, 6))],
                        ),
                        child: const Icon(Ph.check, size: 52, color: Color(0xFFFFFFFF)),
                      ),
                    ),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// A card that gives slightly under the finger and springs back. It only watches the touch; taps go to the child.
class PressScale extends StatefulWidget {
  final Widget child;
  const PressScale({super.key, required this.child});

  @override
  State<PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<PressScale> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v && mounted) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    if (!animOn(context)) return widget.child;
    return Listener(
      onPointerDown: (_) => _set(true),
      onPointerUp: (_) => _set(false),
      onPointerCancel: (_) => _set(false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1,
        duration: Duration(milliseconds: _down ? 90 : 320),
        curve: _down ? Curves.easeOut : Curves.easeOutBack,
        child: widget.child,
      ),
    );
  }
}

/// The large icon of an empty or waiting screen, in a soft round badge.
class IconBadge extends StatelessWidget {
  final IconData icon;
  final double size;
  const IconBadge(this.icon, {super.key, this.size = 84});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: cs.primaryContainer, shape: BoxShape.circle),
      child: Icon(icon, size: size * 0.48, color: cs.onPrimaryContainer),
    );
  }
}

/// The answers of one question as an orderly group: short ones as equal chips in rows, medium ones in two equal
/// columns, long ones one per line, so nothing is cut off and every answer has the same height. [muted] answers
/// ("Not assessed", ...) sit apart below as small chips.
class OptionGroup extends StatelessWidget {
  final List<String> options;
  final List<String> muted;
  final Set<String> selected;
  final bool multi;
  final void Function(String) onTap;
  final String keyPrefix;
  const OptionGroup({super.key, required this.options, this.muted = const [], required this.selected, required this.multi, required this.onTap, this.keyPrefix = 'opt'});

  static const double _h = 48;

  @override
  Widget build(BuildContext context) {
    final longest = options.fold<int>(0, (n, o) => o.length > n ? o.length : n);
    final tier = longest <= 14 ? 0 : (longest <= 30 ? 1 : 2);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: LayoutBuilder(builder: (context, c) {
        const gap = 8.0;
        final w = c.maxWidth;
        final colW = tier == 1 ? (w - gap) / 2 : (tier == 2 ? w : null);
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (options.isNotEmpty)
            Wrap(spacing: gap, runSpacing: gap, children: [
              for (final o in options) SizedBox(width: colW, child: _tile(context, o, compact: tier == 0)),
            ]),
          if (muted.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(spacing: gap, runSpacing: gap, children: [for (final o in muted) _tile(context, o, compact: true, quiet: true)]),
          ],
        ]);
      }),
    );
  }

  Widget _tile(BuildContext context, String o, {required bool compact, bool quiet = false}) {
    final cs = Theme.of(context).colorScheme;
    final on = selected.contains(o);
    final bg = on ? cs.primaryContainer : cs.surfaceContainerLow;
    final fg = on ? cs.onPrimaryContainer : (quiet ? cs.onSurfaceVariant : cs.onSurface);
    final icon = multi ? (on ? Ph.checkSquare : Ph.square) : (on ? Ph.checkCircle : Ph.radioButton);
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: on ? cs.primary : cs.outlineVariant, width: on ? 1.6 : 1)),
      child: InkWell(
        key: ValueKey('${keyPrefix}_$o'),
        borderRadius: BorderRadius.circular(14),
        onTap: () => onTap(o),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: quiet ? 40 : _h, minWidth: compact ? 64 : 0),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: compact ? 14 : 12, vertical: 8),
            child: Row(mainAxisSize: compact ? MainAxisSize.min : MainAxisSize.max, children: [
              if (!compact || on) ...[Icon(icon, size: 20, color: on ? cs.primary : cs.onSurfaceVariant), const SizedBox(width: 8)],
              Flexible(child: m.Text(o, softWrap: true, style: TextStyle(fontSize: quiet ? 13.5 : 15, height: 1.25, fontWeight: on ? FontWeight.w700 : FontWeight.w500, color: fg))),
            ]),
          ),
        ),
      ),
    );
  }
}
