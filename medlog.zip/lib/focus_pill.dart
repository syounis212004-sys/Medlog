import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;

import 'app_icons.dart';
import 'data.dart' show two;
import 'focus_service.dart';
import 'focus_session.dart';
import 'i18n.dart';

/// (No tooltips here: the pill sits above the Navigator, where there is no Overlay.)
/// The small timer on top of every screen while a focus session runs: the time left, pause/resume, and a tap that opens
/// the full screen. It hides itself while that screen is open, and during a mock exam (which has its own clock).
class FocusPill extends StatelessWidget {
  final NavigatorState? Function() navigator;
  const FocusPill({super.key, required this.navigator});

  /// Screens that need the whole attention (the mock exam) raise this while they are open.
  static final ValueNotifier<int> suppress = ValueNotifier<int>(0);

  @override
  Widget build(BuildContext context) {
    final s = FocusService.instance;
    return ListenableBuilder(
      listenable: Listenable.merge([s, FocusSessionScreen.open, suppress]),
      builder: (context, _) {
        if (!s.active || FocusSessionScreen.open.value > 0 || suppress.value > 0) return const SizedBox.shrink();
        final cs = Theme.of(context).colorScheme;
        final rest = s.phase == FocusPhase.rest;
        final d = s.left;
        final t = '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
        return SafeArea(
          child: Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Material(
                key: const ValueKey('focus_pill'),
                color: (rest ? cs.tertiaryContainer : cs.primaryContainer).withValues(alpha: 0.96),
                elevation: 3,
                borderRadius: BorderRadius.circular(22),
                child: InkWell(
                  borderRadius: BorderRadius.circular(22),
                  onTap: () => navigator()?.push(MaterialPageRoute<void>(builder: (_) => const FocusSessionScreen())),
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(12, 2, 4, 2),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(rest ? Icons.coffee_outlined : AppIcons.bolt, size: 16, color: rest ? cs.onTertiaryContainer : cs.onPrimaryContainer),
                      const SizedBox(width: 6),
                      Directionality(textDirection: TextDirection.ltr, child: m.Text(t, key: const ValueKey('pill_time'), style: TextStyle(fontWeight: FontWeight.w800, fontFeatures: const [FontFeature.tabularFigures()], color: rest ? cs.onTertiaryContainer : cs.onPrimaryContainer))),
                      if (!rest)
                        Semantics(
                          label: tr(s.paused ? 'Resume' : 'Pause'),
                          button: true,
                          child: IconButton(
                          key: const ValueKey('pill_pause'),
                          visualDensity: VisualDensity.compact,
                          iconSize: 18,
                          icon: Icon(s.paused ? Icons.play_arrow_rounded : Icons.pause_rounded, color: cs.onPrimaryContainer),
                          onPressed: s.paused ? s.resume : s.pause,
                        ))
                      else
                        const SizedBox(width: 10),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
